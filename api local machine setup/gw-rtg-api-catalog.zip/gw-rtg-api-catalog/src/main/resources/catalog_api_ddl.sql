CREATE SCHEMA IF NOT EXISTS SXT_PRM;
CREATE SCHEMA IF NOT EXISTS SXT_USER;
CREATE SCHEMA IF NOT EXISTS SXT_ENT;
CREATE SCHEMA IF NOT EXISTS SXT_STATE;

// Stores metadata on platform schemas (i.e., named descriptors)
CREATE TABLE SXT_PRM.SXT_SCHEMA (
  ID         VARCHAR,    // the primary key
  CATALOG_ID VARCHAR, // the catalog identifier (default 'SXT' for now)
  SCHEMA_ID  VARCHAR, // the schema identifier
  ORG_ID     VARCHAR, // the organization identifier
  ISPUBLIC   BOOLEAN, // whether or not the namespace has public tables

  // (CATALOG_ID, SCHEMA_ID) combination must be unique
  PRIMARY KEY (ID)
) WITH "public_key=64df1541c552946d85d92e10ea7667b969b98a2a1618b1209b17307d2d42ca0f, access_type=public_read, template=replicated";

// Stores metadata on platform database tables
CREATE TABLE SXT_PRM.SXT_TABLE (
  ID          VARCHAR,      // the primary key
  CATALOG_ID  VARCHAR,   // the catalog identifier (default 'SXT' for now)
  SCHEMA_ID   VARCHAR,   // the schema identifier
  TABLE_ID    VARCHAR,   // the table identifier
  PUBLIC_KEY  VARCHAR,   // the public key for request authorization
  ACCESS_TYPE VARCHAR,   // defines the general authorization policy  
  IMMUTABLE   BOOLEAN,   // whether or not the table only allows appends
  TAMPERPROOF BOOLEAN,   // whether or not the table has Proof-of-SQL guarantees
  ENCRYPTED   BOOLEAN,   // whether or not the table has column-level encryption
  SIZE        VARCHAR,   // the human-readable table size (will include units e.g. KB, TB, etc)
  ORG_ID      VARCHAR,   // the owning organization identifier (non-null for private tables)
  CREATED     TIMESTAMP, // the date/time stamp when the table was created
  
  // (CATALOG_ID, SCHEMA_ID, TABLE_ID) combination must be unique
  PRIMARY KEY (ID)
) WITH "public_key=64df1541c552946d85d92e10ea7667b969b98a2a1618b1209b17307d2d42ca0f, access_type=public_read, template=replicated";

// Stores metadata on individual platform database table columns
CREATE TABLE SXT_PRM.SXT_TABLE_COLUMN (
  ID              VARCHAR,    // the primary key
  CATALOG_ID      VARCHAR, // the catalog identifier (default 'SXT' for now)
  SCHEMA_ID       VARCHAR, // the schema identifier
  TABLE_ID        VARCHAR, // the table identifier
  COLUMN_ID       VARCHAR, // the column identifier
  POSITION        INTEGER, // the column ordinal position (1-based)
  NULLABLE        BOOLEAN, // whether or not the column can have nulls
  RADIX           INTEGER, // for numeric types, the column radix (either 10 or 2)
  AUTOGENERATE    BOOLEAN, // whether or not the column values are auto-generated
  AUTOINCREMENT   BOOLEAN, // whether or not the column values are auto-incremented
  DATA_TYPE       VARCHAR, // the column value type (as string)
  DEFAULT_VALUE   VARCHAR, // the column default value (as string)
  COLUMN_SIZE     INTEGER, // the column size/precision
  PRIMARY_KEY_SEQ INTEGER, // the column sequence in the primary key (-1 for non primary keys)
  MAX_BYTES       INTEGER, // for char types, the maximum # of bytes
  ORG_ID          VARCHAR, // the owning organization identifier (non-null for private tables)
  ENCRYPTED       BOOLEAN, // whether or not the column is encrypted
  ENC_TYPE        VARCHAR, // the encryption type (null if ENCRYPTED = false)
  ENC_OPTION      VARCHAR, // the encryption option (null if ENCRYPTED = false)

  // (CATALOG_ID, SCHEMA_ID, TABLE_ID, COLUMN_ID) combination must be unique
  PRIMARY KEY (ID)
) WITH "public_key=64df1541c552946d85d92e10ea7667b969b98a2a1618b1209b17307d2d42ca0f, access_type=public_read, template=replicated";

// Stores metadata on platform database table indexes
CREATE TABLE SXT_PRM.SXT_INDEX (
  ID          VARCHAR,    // the primary key
  CATALOG_ID  VARCHAR, // the catalog identifier (default 'SXT' for now)
  SCHEMA_ID   VARCHAR, // the schema identifier
  TABLE_ID    VARCHAR, // the table identifier
  INDEX_ID    VARCHAR, // the index identifier
  NON_UNIQUE  BOOLEAN, // whether or not index values can be non-unique
  COLLATION   VARCHAR, // index collation order ("A" - ascending, "D" - descending, NULL - not applicable)
  COLUMNS     VARCHAR, // the indexed column identifiers (comma-separated for composite)
  POSITIONS   VARCHAR, // the indexed column positions (comma-separated for composite)
  INDEX_TYPE  VARCHAR, // the index type. One of { 0, 1, 2, 3 }
  ORG_ID      VARCHAR, // the owning organization identifier (non-null for private tables)
  
  // (CATALOG_ID, SCHEMA_ID, TABLE_ID, INDEX_ID) combination must be unique
  PRIMARY KEY (ID)
) WITH "public_key=64df1541c552946d85d92e10ea7667b969b98a2a1618b1209b17307d2d42ca0f, access_type=public_read, template=replicated";

// Stores metadata on foreign key relationships between platform tables
CREATE TABLE SXT_PRM.SXT_FKEY (
  ID            VARCHAR,    // the primary key
  
  // Primary key (PK) column reference
  PK_CATALOG_ID VARCHAR, // the PK catalog identifier (default 'SXT' for now)
  PK_SCHEMA_ID  VARCHAR, // the PK schema identifier
  PK_TABLE_ID   VARCHAR, // the PK table identifier
  PK_COLUMN_ID  VARCHAR, // the PK column identifier

  // Foreign key (FK) column reference
  FK_CATALOG_ID VARCHAR, // the FK catalog identifier (default 'SXT' for now)
  FK_SCHEMA_ID  VARCHAR, // the FK schema identifier
  FK_TABLE_ID   VARCHAR, // the FK table identifier
  FK_COLUMN_ID  VARCHAR, // the FK column identifier
  
  // Relationship information
  SEQUENCE      INTEGER, // the sequence # of the column within the foreign key (1-based)
  CARDINALITY   VARCHAR, // describes the relationship (i.e., "One-to-one", "One-to-many")
  ORG_ID        VARCHAR, // the owning organization identifier (non-null for private tables)

  // (PK_*, FK_*) combination must be unique
	PRIMARY KEY (ID)
) WITH "public_key=64df1541c552946d85d92e10ea7667b969b98a2a1618b1209b17307d2d42ca0f, access_type=public_read, template=replicated";

// Stores metadata on platform views
CREATE TABLE SXT_PRM.SXT_VIEW (
  ID          VARCHAR,    // the primary key
  CATALOG_ID  VARCHAR, // the catalog identifier (default 'SXT' for now)
  SCHEMA_ID   VARCHAR, // the schema identifier
  VIEW_NAME   VARCHAR, // the view name (unique identifier across platform views)
  OWNER_ID    VARCHAR, // the creating users identifier (to be replaced with pubK)
  RESOURCE_ID VARCHAR, // the views backing resource identifier
  VIEW_TEXT   VARCHAR, // the views backing SQL text
  DESCRIPTION VARCHAR, // the optional view description
  PARAMETERS  VARCHAR, // the JSON serialized parameters (if provided)
  ISPUBLIC    BOOLEAN, // whether or not the view is publicly-executable
  MODIFIED    TIMESTAMP, // the date/time of last modification

  // (CATALOG_ID, SCHEMA_ID, VIEW_ID) combination must be unique
  PRIMARY KEY (ID)
) WITH "public_key=64df1541c552946d85d92e10ea7667b969b98a2a1618b1209b17307d2d42ca0f, access_type=public_read, template=replicated";

// Stores metadata on indexed blockchains
CREATE TABLE SXT_PRM.SXT_CHAINS (
  ID         VARCHAR,    // the primary key
  CATALOG_ID VARCHAR, // the catalog identifier (default 'SXT' for now)
  SCHEMA_ID  VARCHAR, // the schema identifier
  CHAIN_ID   VARCHAR, // the blockchain identifier (e.g. "Ethereum")
  
    PRIMARY KEY (ID)
) WITH "public_key=64df1541c552946d85d92e10ea7667b969b98a2a1618b1209b17307d2d42ca0f, access_type=public_read, template=replicated";

// Stores basic user profile information
// NOTE: all fields except for USER_ID are optional
CREATE TABLE SXT_USER.USER_PROFILE (
  USER_ID      VARCHAR, // the user identifier
  USER_NAME    VARCHAR, // the username (like a twitter handle)
  DISPLAY_NAME VARCHAR, // the name to display in the user profile
  EMAIL_ADDR   VARCHAR, // the email address
  BIO          VARCHAR, // the user bio
  SETTINGS     VARCHAR, // the JSON-serialized user settings
  PRIMARY KEY (USER_ID)
) WITH "public_key=64df1541c552946d85d92e10ea7667b969b98a2a1618b1209b17307d2d42ca0f, access_type=public_read, template=replicated";

// Stores metadata on user-created tags
CREATE TABLE SXT_ENT.TAG (
  ID          VARCHAR,    // the primary key
  TAG_ID      VARCHAR, // the tag identifier
  METADATA    VARCHAR, // stores additional tag metadata (e.g., HTML color)
  PRIMARY KEY (ID)
) WITH "public_key=64df1541c552946d85d92e10ea7667b969b98a2a1618b1209b17307d2d42ca0f, access_type=public_read, template=replicated";

// Stores tag relationships to other platform entities
CREATE TABLE SXT_ENT.TAG_RELATION (
  TAG_ID      VARCHAR,    // the tag primary key
  ENT_ID      VARCHAR,    // the tagged entity primary key
  ENT_TYPE    VARCHAR, // the entity type identifier
  PRIMARY KEY (TAG_ID, ENT_ID)
) WITH "public_key=64df1541c552946d85d92e10ea7667b969b98a2a1618b1209b17307d2d42ca0f, access_type=public_read, template=replicated";

// Stores metadata on user-created visual widgets
CREATE TABLE SXT_ENT.WIDGET (
  ID          VARCHAR,      // the primary key
  WIDGET_NAME VARCHAR,   // the widget name
  WIDGET_TYPE VARCHAR,   // the widget type { TABLE, GRAPH, COUNTER, MARKDOWN }
  OWNER_ID    VARCHAR,   // the owning users identifier
  DESCRIPTION VARCHAR,   // the optional widget description
  METADATA    VARCHAR,   // the optional JSON-serialized metadata
  MODIFIED    TIMESTAMP, // the date/time of last modification
  ISPUBLIC    BOOLEAN,   // whether or not the widget is publicly-viewable
  VIEW_ID     VARCHAR,      // the view reference
  SLUG        VARCHAR,   // the public widget slug (if published)

  PRIMARY KEY (ID),
  FOREIGN KEY (VIEW_ID)  REFERENCES SXT_PRM.SXT_VIEW (ID)
) WITH "public_key=64df1541c552946d85d92e10ea7667b969b98a2a1618b1209b17307d2d42ca0f, access_type=public_read, template=replicated";

// Stores the relationships of dashboards and widgets
CREATE TABLE SXT_ENT.DASHBOARD_WIDGET (
  DASHBOARD_ID VARCHAR,    // the dashboard primary key
  WIDGET_ID    VARCHAR,    // the widget primary key
  METADATA     VARCHAR, // the optional JSON-serialized metadata

  PRIMARY KEY (DASHBOARD_ID , WIDGET_ID)
) WITH "public_key=64df1541c552946d85d92e10ea7667b969b98a2a1618b1209b17307d2d42ca0f, access_type=public_read, template=replicated";


// Stores metadata on user-created visual dashboards
CREATE TABLE SXT_ENT.DASHBOARD (
  ID          VARCHAR,      // the primary key
  DASH_NAME   VARCHAR,   // the dashbaord name
  DESCRIPTION VARCHAR,   // the optional dashboard description
  OWNER_ID    VARCHAR,   // the owning users identifier
  METADATA    VARCHAR,   // the optional JSON-serialized metadata
  MODIFIED    TIMESTAMP, // the date/time of last modification
  ISPUBLIC    BOOLEAN,   // whether or not the dashbaord is publicly-viewable
  SLUG        VARCHAR,   // the public dashboard slug (if published)
  DESCRIPTION_TITLE VARCHAR, // the optional dashboard description title
  PRIMARY KEY (ID)
) WITH "public_key=64df1541c552946d85d92e10ea7667b969b98a2a1618b1209b17307d2d42ca0f, access_type=public_read, template=replicated";


// Stores metadata on queries executed
CREATE TABLE SXT_STATE.QUERY_HISTORY (
  QUERY_ID      VARCHAR,      // the querys unique identifier (primary key)
  USER_ID       VARCHAR,   // the requesting user identifier
  SQL_TEXT      VARCHAR,   // the SQL text executed
  GATEWAY_ID    VARCHAR,   // the id of the gateway who processed the request
  WAREHOUSE_ID  VARCHAR,   // the id of the warehouse who processed the request
  RUNTIME       INTEGER,   // the runtime (in ns) of the request execution
  EXEC_TIME     TIMESTAMP, // the date/time stamp when the query was executed (in UTC)
  ROW_COUNT     INTEGER,   // the number of rows returned for queries, update count for DML/DDL
  RESPONSE_SIZE INTEGER,   // the query response size returned from the DW (in bytes)
  CPU_SECONDS   VARCHAR,   // the CPU seconds used by the data warehouse
  IO            VARCHAR,   // the I/O used by the data warehouse
  ERROR_DETAILS VARCHAR,   // the error details (if the request failed, otherwise null)
  ORIGIN        VARCHAR,   // where the request came from (e.g., dapp, JDBC Driver, REST API)
  METADATA      VARCHAR,   // stores additional data about the request (e.g., Blockchain API)
  PRIMARY KEY (QUERY_ID)
) WITH "public_key=64df1541c552946d85d92e10ea7667b969b98a2a1618b1209b17307d2d42ca0f, access_type=public_read, template=replicated";

------SXT_TABLE TABLE INDEX----------
 CREATE INDEX SXT_TABLE_TABLE_ID_IDX ON SXT_PRM.SXT_TABLE ("TABLE_ID" DESC) PARALLEL 8;
 CREATE INDEX SXT_TABLE_SCHEMA_ID_IDX ON SXT_PRM.SXT_TABLE ("SCHEMA_ID" DESC) PARALLEL 8;
 CREATE INDEX SXT_TABLE_ORG_ID_IDX ON SXT_PRM.SXT_TABLE ("ORG_ID" DESC) PARALLEL 8;
 CREATE INDEX SXT_TABLE_ACCESS_TYPE_IDX ON SXT_PRM.SXT_TABLE ("ACCESS_TYPE" DESC) PARALLEL 8;
 
------SXT_TABLE_COLUMN TABLE INDEX----------
 CREATE INDEX SXT_TABLE_COLUMN_TABLE_ID_IDX ON SXT_PRM.SXT_TABLE_COLUMN ("TABLE_ID" DESC) PARALLEL 8;
 CREATE INDEX SXT_TABLE_COLUMN_SCHEMA_ID_IDX ON SXT_PRM.SXT_TABLE_COLUMN ("SCHEMA_ID" DESC) PARALLEL 8;
 CREATE INDEX SXT_TABLE_COLUMN_COLUMN_ID_IDX ON SXT_PRM.SXT_TABLE_COLUMN ("COLUMN_ID" DESC) PARALLEL 8;
 
 
------SXT_FKEY TABLE INDEX----------
 CREATE INDEX SXT_FKEY_PK_COLUMN_ID_IDX ON SXT_PRM.SXT_FKEY ("PK_COLUMN_ID" DESC) PARALLEL 8;
 CREATE INDEX SXT_FKEY_PK_TABLE_ID_IDX ON SXT_PRM.SXT_FKEY ("PK_TABLE_ID" DESC) PARALLEL 8;
 CREATE INDEX SXT_FKEY_PK_SCHEMA_ID_IDX ON SXT_PRM.SXT_FKEY ("PK_SCHEMA_ID" DESC) PARALLEL 8;
 CREATE INDEX SXT_FKEY_FK_COLUMN_ID_IDX ON SXT_PRM.SXT_FKEY ("FK_COLUMN_ID" DESC) PARALLEL 8;
 CREATE INDEX SXT_FKEY_FK_TABLE_ID_IDX ON SXT_PRM.SXT_FKEY ("FK_TABLE_ID" DESC) PARALLEL 8;
 CREATE INDEX SXT_FKEY_FK_SCHEMA_ID_IDX ON SXT_PRM.SXT_FKEY ("FK_SCHEMA_ID" DESC) PARALLEL 8;
 CREATE INDEX SXT_FKEY_CARDINALITY_IDX ON SXT_PRM.SXT_FKEY ("CARDINALITY" DESC) PARALLEL 8;
 
