package io.spaceandtime.routing.ignitedao;

import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

import org.apache.commons.lang3.StringUtils;
import org.springframework.stereotype.Component;
import io.spaceandtime.routing.constant.MessageEnum;
import io.spaceandtime.routing.constant.TagTypeEnum;
import io.spaceandtime.routing.errorHandler.AppException;
import io.spaceandtime.routing.jdbcdao.BaseIgniteSqlDAOImpl;
import io.spaceandtime.routing.mapper.SRCMapper;
import io.spaceandtime.routing.model.TagDto;
import io.spaceandtime.routing.query.CatalogAPIQuery;

@Component
public class TagDAOImpl extends BaseIgniteSqlDAOImpl implements TagDAO {

	@Override
	public List<TagDto> getAllTags(String tagId, Boolean popular, String tagType, Boolean isPublic) {
	    checkUserAuthorization(isPublic);
	    String qry = CatalogAPIQuery.GET_TAGS;
	    if (!StringUtils.isAllBlank(tagId))
		qry += "WHERE LOWER(TAG_ID) LIKE LOWER(CONCAT('%', '" + tagId + "', '%'))";

	    if (popular) {
		qry = CatalogAPIQuery.GET_POPULAR_TAGS;
		if (tagType.equalsIgnoreCase(TagTypeEnum.DASHBOARD.toString())) {
		    qry += "JOIN SXT_ENT.DASHBOARD d ON tr.ENT_ID  = d.ID WHERE d.ISPUBLIC = true";
		} else if (tagType.equalsIgnoreCase(TagTypeEnum.VIEW.toString())) {
		    qry += "JOIN SXT_PRM.SXT_VIEW v ON tr.ENT_ID  = v.ID WHERE v.ISPUBLIC = true";
		} else if (tagType.equalsIgnoreCase(TagTypeEnum.WIDGET.toString())
			|| tagType.equalsIgnoreCase(TagTypeEnum.GRAPH.toString())
			|| tagType.equalsIgnoreCase(TagTypeEnum.TABLE.toString())
			|| tagType.equalsIgnoreCase(TagTypeEnum.MARKDOWNCARD.toString())
			|| tagType.equalsIgnoreCase(TagTypeEnum.COUNTERCARD.toString())) {
		    qry += "JOIN SXT_ENT.WIDGET w ON tr.ENT_ID  = w.ID WHERE w.ISPUBLIC = true";
		} else {
		    throw new AppException(MessageEnum.INVALID_TAG_TYPE, tagType);
		}
		qry += " GROUP BY t.ID, t.TAG_ID, t.METADATA ORDER BY COUNT DESC;";
	    }
	    List<Map<String, Object>> tagList = getPlatformEntitiesData(qry);
	    return getAllTags(tagList);
	}

	private List<TagDto> getAllTags(List<Map<String, Object>> tagList) {
		List<TagDto> tags = tagList.stream().map(tagMap -> SRCMapper.mapAllPopularTags(tagMap))
				.collect(Collectors.toList());
		return tags;
	}
}
