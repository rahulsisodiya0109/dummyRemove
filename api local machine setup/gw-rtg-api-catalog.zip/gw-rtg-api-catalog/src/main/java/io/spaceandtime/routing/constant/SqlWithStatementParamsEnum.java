package io.spaceandtime.routing.constant;

public enum SqlWithStatementParamsEnum {
	ACCESS_TYPE("access_type"), 
	IMMUTABLE("immutable"), 
	PUBLIC_KEY("public_key");

	public final String paramName;


	SqlWithStatementParamsEnum(String paramName) {
		this.paramName = paramName;
	}

}
