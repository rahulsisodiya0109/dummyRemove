package io.spaceandtime.routing.configs.providers;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import io.spaceandtime.routing.constant.EnvironmentConstant;
import io.spaceandtime.storage.core.IStorageConfigProvider;

@Component
public class KeyDbConfigProvider implements IStorageConfigProvider {

	@Value(EnvironmentConstant.KEYDB_HOST)
	private String HOST;
	@Value(EnvironmentConstant.KEYDB_PORT)
	private int PORT;
	@Value(EnvironmentConstant.KEYDB_PASSWORD)
	private String PASSWORD;

	@Override
	public String getHost() { return HOST; }

	@Override
	public String getPassword() { return PASSWORD; }

	@Override
	public int getPort() { return PORT; }
	
}
