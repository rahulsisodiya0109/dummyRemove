package io.spaceandtime.routing.utils;

import java.util.List;

public class Page<T> {

	private List<T> content;

	private Pageable pageable;

	public List<T> getContent() {
		return content;
	}

	public void setContent(List<T> content) {
		this.content = content;
	}

	public Pageable getPageable() {
		return pageable;
	}

	public void setPageable(Pageable pageable) {
		this.pageable = pageable;
	}

}
