package io.spaceandtime.routing.ro;

import java.util.List;
import java.util.UUID;

import io.swagger.v3.oas.annotations.media.Schema;

public class SavedQueryRequest {

	@Schema(description = "the view reference", example = "", required = false)
	private UUID viewId;

	@Schema(description = "the query name", example = "", required = false)
	private String queryName;

	@Schema(description = "the querys backing resource identifier", example = "", required = false)
	private String resourceId;

	@Schema(description = "the querys backing SQL text", example = "", required = false)
	private String queryText;

	@Schema(description = "the containing the savedquery description", example = "This query returns the number of ethereum blocks that had a transaction count greater than the provided value", required = false)
	private String description;

	@Schema(description = "the JSON serialized parameters", example = "", required = false)
	private String parameters;

	@Schema(description = "containing the tags", required = false)
	private List<TagRequest> tags;

	public UUID getViewId() {
		return viewId;
	}

	public void setViewId(UUID viewId) {
		this.viewId = viewId;
	}

	public String getQueryName() {
		return queryName;
	}

	public void setQueryName(String queryName) {
		this.queryName = queryName;
	}

	public String getResourceId() {
		return resourceId;
	}

	public void setResourceId(String resourceId) {
		this.resourceId = resourceId;
	}

	public String getQueryText() {
		return queryText;
	}

	public void setQueryText(String queryText) {
		this.queryText = queryText;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public String getParameters() {
		return parameters;
	}

	public void setParameters(String parameters) {
		this.parameters = parameters;
	}

	public List<TagRequest> getTags() {
		return tags;
	}

	public void setTags(List<TagRequest> tags) {
		this.tags = tags;
	}

}
