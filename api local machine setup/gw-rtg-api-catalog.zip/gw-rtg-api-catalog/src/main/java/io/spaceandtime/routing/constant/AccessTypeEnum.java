package io.spaceandtime.routing.constant;

import java.util.ArrayList;
import java.util.List;

import io.spaceandtime.routing.errorHandler.AppException;
import io.spaceandtime.routing.utils.StringUtils;

public enum AccessTypeEnum {
	
	PERMISSIONED("permissioned"), 
	PUBLIC_READ("public_read"), 
	PUBLIC_APPEND("public_append"),
	PUBLIC_WRITE("public_write");

	private String accessType;
	public static List<String> accessTypeList = new ArrayList<>();

	AccessTypeEnum(String string) {
		this.accessType = string;
	}

	static {
		for (AccessTypeEnum constant : AccessTypeEnum.class.getEnumConstants()) {
			accessTypeList.add(constant.getAccessType());
		}
	}

	public String getAccessType() {
		return accessType;
	}

	public String toString() {
		return this.accessType;
	}
	
	public static void checkValidAccessType(String name) {
		if (StringUtils.isEmpty(name)||!accessTypeList.contains(name)) {
			throw new AppException(MessageEnum.INVALID_ACCESSTYPE,name);

		}
	}

}
