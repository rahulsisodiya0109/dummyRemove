package io.spaceandtime.routing.constant;

import java.util.ArrayList;
import java.util.List;

import io.spaceandtime.routing.errorHandler.AppException;
import io.spaceandtime.routing.utils.StringUtils;

public enum TagTypeEnum {

    DASHBOARD("DASHBOARD"), WIDGET("WIDGET"), VIEW("VIEW"), GRAPH("GRAPH"), TABLE("TABLE"),
    MARKDOWNCARD("MARKDOWNCARD"), COUNTERCARD("COUNTERCARD");


    private String tagType;
    public static List<String> tagTypeList = new ArrayList<>();

    static {
	for (TagTypeEnum constant : TagTypeEnum.class.getEnumConstants()) {
	    tagTypeList.add(constant.getTagType());
	}
    }

    TagTypeEnum(String string) {
	this.tagType = string;
    }

    public String getTagType() {
	return tagType;
    }

    public String toString() {
	return this.tagType;
    }

    public static void checkValidTagType(String tagtype) {
	if (StringUtils.isEmpty(tagtype) || !tagTypeList.contains(tagtype)) {
	    throw new AppException(MessageEnum.INVALID_TAG_TYPE, tagtype);

	}
    }
}
