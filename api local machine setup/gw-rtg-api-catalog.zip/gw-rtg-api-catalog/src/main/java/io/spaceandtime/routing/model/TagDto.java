package io.spaceandtime.routing.model;

import com.fasterxml.jackson.annotation.JsonProperty;

public class TagDto {

	@JsonProperty("id")
	private String id;

	@JsonProperty("tagId")
	private String tagId;

	@JsonProperty("count")
	private Long count;

	@JsonProperty("metadata")
	private String metadata;

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public String getTagId() {
		return tagId;
	}

	public Long getCount() {
		return count;
	}

	public void setCount(Long count) {
		this.count = count;
	}

	public void setTagId(String tagId) {
		this.tagId = tagId;
	}

	public void setCount(long l) {
		this.count = l;
	}

	public String getMetadata() {
		return metadata;
	}

	public void setMetadata(String metadata) {
		this.metadata = metadata;
	}

}
