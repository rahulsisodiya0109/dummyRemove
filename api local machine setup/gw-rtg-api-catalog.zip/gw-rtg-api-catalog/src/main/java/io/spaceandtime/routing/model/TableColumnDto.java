package io.spaceandtime.routing.model;

import java.util.List;

public class TableColumnDto {

	private String column;

	private String table;

	private String namespace;

	private String dataType;

	private Integer primaryKeySequence;

	private List<TableForeignKeyDto> relationship;

	public String getColumn() {
		return column;
	}

	public void setColumn(String column) {
		this.column = column;
	}

	public String getTable() {
		return table;
	}

	public void setTable(String table) {
		this.table = table;
	}

	public String getNamespace() {
		return namespace;
	}

	public void setNamespace(String namespace) {
		this.namespace = namespace;
	}

	public String getDataType() {
		return dataType;
	}

	public void setDataType(String dataType) {
		this.dataType = dataType;
	}

	public Integer getPrimaryKeySequence() {
		return primaryKeySequence;
	}

	public void setPrimaryKeySequence(Integer primaryKeySequence) {
		this.primaryKeySequence = primaryKeySequence;
	}

	public List<TableForeignKeyDto> getRelationship() {
		return relationship;
	}

	public void setRelationship(List<TableForeignKeyDto> relationship) {
		this.relationship = relationship;
	}

}
