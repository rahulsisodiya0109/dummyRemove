package io.spaceandtime.routing.model;

import com.fasterxml.jackson.annotation.JsonProperty;

public class NameSpace {

	@JsonProperty("namespace")
	private String namespace;
	
	@JsonProperty("owner")
	private String owner;
	
	@JsonProperty("public_key")
	private String publicKey;

	public String getNamespace() {
		return namespace;
	}

	public void setNamespace(String namespace) {
		this.namespace = namespace;
	}

	public String getOwner() {
		return owner;
	}

	public void setOwner(String owner) {
		this.owner = owner;
	}

	public String getPublicKey() {
		return publicKey;
	}

	public void setPublicKey(String publicKey) {
		this.publicKey = publicKey;
	}
	
	
}
