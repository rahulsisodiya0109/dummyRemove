package io.spaceandtime.routing.constant;

public class ColumnConstant {

	public static final String TABLE_ID = "TABLE_ID";
	public static final String PUBLIC_KEY = "PUBLIC_KEY";
	public static final String IMMUTABLE = "IMMUTABLE";
	public static final String ACCESS_TYPE = "ACCESS_TYPE";
	public static final String ENCRYPTED = "ENCRYPTED";
	public static final String TAMPERPROOF = "TAMPERPROOF";
	public static final String OWNERID = "OWNERID";
	public static final String ORG_ID = "ORG_ID";

	public static final String COLUMN_ID = "COLUMN_ID";
	public static final String DATA_TYPE = "DATA_TYPE";
	public static final String POSITION = "POSITION";
	public static final String NULLABLE = "NULLABLE";
	public static final String AUTOGENERATE = "AUTOGENERATE";
	public static final String AUTOINCREMENT = "AUTOINCREMENT";
	public static final String DEFAULT_VALUE = "DEFAULT_VALUE";
	public static final String COLUMN_SIZE = "COLUMN_SIZE";
	public static final String PRIMARY_KEY_SEQ = "PRIMARY_KEY_SEQ";
	public static final String MAX_BYTES = "MAXBYTES";
	public static final String ENC_TYPE = "ENC_TYPE";
	public static final String ENC_OPTION = "ENC_OPTION";

	public static final String PK_COLUMN_ID = "PK_COLUMN_ID";
	public static final String PK_TABLE_ID = "PK_TABLE_ID";
	public static final String FK_COLUMN_ID = "FK_COLUMN_ID";
	public static final String FK_TABLE_ID = "FK_TABLE_ID";
	public static final String FK_SCHEMA_ID = "FK_SCHEMA_ID";
	public static final String SEQUENCE = "SEQUENCE";
	public static final Object PK_SCHEMA_ID = "PK_SCHEMA_ID";
	public static final Object PK_CATALOG_ID = "PK_CATALOG_ID";
	public static final Object FK_CATALOG_ID = "FK_CATALOG_ID";
	public static final Object RADIX = "RADIX";
	public static final Object INDEX_ID = "INDEX_ID";
	public static final Object INDEX_TYPE = "INDEX_TYPE";
	public static final Object COLLATION = "COLLATION";
	public static final Object NON_UNIQUE = "NON_UNIQUE";
	public static final Object POSITIONS = "POSITIONS";
	public static final Object COLUMNS = "COLUMNS";

	public static final String VIEW_NAME = "VIEW_NAME";
	public static final String DESCRIPTION = "DESCRIPTION";
	public static final String VIEW_TEXT = "VIEW_TEXT";
	public static final String PARAMETERS = "PARAMETERS";
	public static final String CATALOG_ID = "CATALOG_ID";
	public static final String SCHEMA_ID = "SCHEMA_ID";

	public static final Object CARDINALITY = "CARDINALITY";

	public static final String STRING = "string";
	public static final String BOOLEAN = "boolean";
	public static final String INTEGER = "integer";
	public static final String CHAR = "char";
	public static final String DOUBLE = "double";
	public static final String FLOAT = "float";
	public static final String DECIMAL = "decimal";
	public static final String SHORT = "short";
	public static final String BIGINT = "bigint";
	public static final String DATATYPE_UUID = "uuid";
	public static final String DATE = "date";
	public static final String TIMESTAMP = "timestamp";
	public static final String TIME = "time";

	public static final String TRUE = "true";
	public static final String FALSE = "false";
	public static final String USERID = "USER_ID";
	public static final String USERNAME = "USER_NAME";
	public static final String DISPLAYNAME = "DISPLAY_NAME";
	public static final String EMAILADDR = "EMAIL_ADDR";
	public static final String BIO = "BIO";
	public static final String SETTINGS = "SETTINGS";

	public static final String QUERYID = "QUERY_ID";

	public static final String ID = "ID";
	public static final String WIDGETNAME = "WIDGET_NAME";
	public static final String WIDGETTYPE = "WIDGET_TYPE";
	public static final String OWNER_ID = "OWNER_ID";
	public static final String METADATA = "METADATA";
	public static final String MODIFIED = "MODIFIED";
	public static final String ISPUBLIC = "ISPUBLIC";
	public static final String VIEWID = "VIEW_ID";
	public static final String SLUG = "SLUG";
	public static final String DESCRIPTION_TITLE = "DESCRIPTION_TITLE";

	public static final String ORGANIZATIONID = "organizationId";

	public static final String SQLTEXT = "SQL_TEXT";
	public static final String GATEWAYID = "GATEWAY_ID";
	public static final String WAREHOUSEID = "WAREHOUSE_ID";
	public static final String RUNTIME = "RUNTIME";
	public static final String GWRUNTIME = "GW_RUNTIME";
	public static final String EXECTIME = "EXEC_TIME";
	public static final String ROW_COUNT = "ROW_COUNT";
	public static final String RESPONSE_SIZE = "RESPONSE_SIZE";
	public static final String CPU_SECONDS = "CPU_SECONDS";
	public static final String IO = "IO";
	public static final String ERROR_DETAILS = "ERROR_DETAILS";
	public static final String ORIGIN = "ORIGIN";

	public static final String DASHBOARDNAME = "DASH_NAME";
	public static final String WIDGETID = "WIDGET_ID";

	public static final String QUERY_NAME = "QUERY_NAME";
	public static final String RESOURCE_ID = "RESOURCE_ID";
	public static final String QUERY_TEXT = "QUERY_TEXT";
	public static final String VIEW_ID = "VIEW_ID";
	public static final String TAG_ID = "TAG_ID";
	public static final String VIEW = "VIEW";
	public static final String WIDGET = "WIDGET";
	public static final String DASHBOARD = "DASHBOARD";
	public static final Object DASHBOARD_ID = "ID";
	public static final Object COUNT = "COUNT";

	public static final String TAG_COLUMN = "tags";
	public static final String ASCENDING_ORDER = "ASC";
	public static final String DESCENDING_ORDER = "DESC";
	public static final String CHAIN_ID = "CHAIN_ID";
	public static final String CLONE = "_clone";

	public static final String ACTIVE = "active";
	public static final String LASTPAYMENT = "lastPayment";
	public static final String SUBSCRIPTIONTYPE = "subscriptionType";

	public static final String ETH = "ETH";
	public static final String AVAX= "AVAX";
	public static final String BNB = "BNB";
	public static final String MATIC = "MATIC";
	public static final String SUI = "SUI";

	public static final Object CREATED = "CREATED";
	public static final String SIZE = "SIZE";
	
	public static final String TAG = "TAGS";
	
	public static final String ALL = "ALL";
	public static final String PUBLISHED = "PUBLISHED";
	public static final String UNPUBLISHED = "UNPUBLISHED";
}
