package io.spaceandtime.routing.model;

public class BlockChainDto {
	
	private String chainId;

	public String getChainId() {
		return chainId;
	}

	public void setChainId(String chainId) {
		this.chainId = chainId;
	}
}
