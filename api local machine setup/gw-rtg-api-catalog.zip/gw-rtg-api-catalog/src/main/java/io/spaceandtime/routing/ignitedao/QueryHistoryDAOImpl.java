package io.spaceandtime.routing.ignitedao;

import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import io.spaceandtime.routing.constant.SortOrderEnum;
import io.spaceandtime.routing.jdbcdao.BaseIgniteSqlDAOImpl;
import io.spaceandtime.routing.logging.AppLogger;
import io.spaceandtime.routing.logging.Log;
import io.spaceandtime.routing.mapper.SRCMapper;
import io.spaceandtime.routing.model.QueryHistoryDto;
import io.spaceandtime.routing.query.CatalogAPIQuery;
import io.spaceandtime.routing.storage.IKeyDBProvider;
import io.spaceandtime.routing.utils.Page;
import io.spaceandtime.routing.utils.PaginationUtil;
import io.spaceandtime.storage.state.RequestLog;

@Component
public class QueryHistoryDAOImpl extends BaseIgniteSqlDAOImpl implements QueryHistoryDAO {

    private static @Log AppLogger logger;

    public static final String COLON = ":";

    @Autowired
	private IKeyDBProvider _keydbProvider;

    @Override
    public Page<QueryHistoryDto> getQueryHistory(String queryId, Timestamp fromDate, Timestamp toDate, String origin,
	    int pageNo, int pageSize, SortOrderEnum sortOrder, String sortBy, boolean isRecent) {

	String userId = getUserId();
	List<QueryHistoryDto> queryHistoryDto = new ArrayList<>();
	int count = 0;
	if (!isRecent) {
	    // fetching record from global platform table
	    List<String> filters = new ArrayList<>();
	    filters.add("USER_ID = '" + userId + "'");
	    if (queryId != null) {
		filters.add("QUERY_ID = '" + queryId + "'");
	    }
	    if (fromDate != null) {
		filters.add("EXEC_TIME >= '" + fromDate + "'");
	    }
	    if (toDate != null) {
		filters.add("EXEC_TIME <= '" + toDate + "'");
	    }
	    String qryText = CatalogAPIQuery.GET_QUERY_HISTORY;
	    String qryCounts = CatalogAPIQuery.GET_QUERY_HISTORY_COUNT;
	    if (!filters.isEmpty()) {
		qryText += " WHERE " + String.join(" AND ", filters);
		qryCounts += "WHERE " + String.join(" AND ", filters);
	    }
	    count = getTotalRecords(qryCounts);
	    qryText = buildPaginatedQuery(pageNo, pageSize, sortOrder, buildSortByColumnName(sortBy), qryText);
	    List<Map<String, Object>> queryHistoryData = getPlatformEntitiesData(qryText);
	    queryHistoryDto = getQueryHistory(queryHistoryData);
	} else {
	    // fetching records from keydb
		List<RequestLog> keydbLogs;
		try {
			keydbLogs = _keydbProvider.getRequestLogForUser(userId);
		} catch (Exception ex) {
			keydbLogs = null;
		}
		List<QueryHistoryDto> results = new ArrayList<>();
		if (keydbLogs != null && !keydbLogs.isEmpty()) {
			for (RequestLog log : keydbLogs) {
				if (queryId != null && !queryId.equals(log.getRequestId().toString())) continue;
				if (origin != null && !origin.equals(log.getOrigin())) continue;
				if (fromDate != null && !fromDate.toInstant().isAfter(log.getExecutedTime())) continue;
				if (toDate != null && !toDate.toInstant().isBefore(log.getExecutedTime())) continue;
				QueryHistoryDto qh = new QueryHistoryDto(log);
				results.add(qh);
			}
		}
	    count = results.size();
	    results = sortKeyDbList(results, sortOrder, sortBy);
	    queryHistoryDto = PaginationUtil.getSubList(results, pageNo, pageSize);
	}
	logger.infoFormat("pageNo: {0} pageSize: {1} count: {2}", pageNo, pageSize, count);
	return pageableContent(pageNo, pageSize, count, queryHistoryDto);
    }

    private List<QueryHistoryDto> sortKeyDbList(List<QueryHistoryDto> queryHistoryDto, SortOrderEnum sortOrder,
	    String sortBy) {
	Comparator<QueryHistoryDto> comparator;
	switch (sortBy.toUpperCase()) {
	case QUERYID:
	    comparator = Comparator.comparing(QueryHistoryDto::getQueryId);
	    break;
	case USERID:
	    comparator = Comparator.comparing(QueryHistoryDto::getUserId);
	    break;
	case GATEWAYID:
	    comparator = Comparator.comparing(QueryHistoryDto::getGatewayId);
	    break;
	case WAREHOUSEID:
	    comparator = Comparator.comparing(QueryHistoryDto::getWarehouseId);
	    break;
	case RUNTIME:
	    comparator = Comparator.comparingLong(QueryHistoryDto::getRunTime);
	    break;
	case EXECTIME:
	    comparator = Comparator.comparing(QueryHistoryDto::getExecTime);
	    break;
	case RESPONSESIZE:
	    comparator = Comparator.comparingLong(QueryHistoryDto::getResponseSize);
	    break;
	case ORIGIN:
	    comparator = Comparator.comparing(QueryHistoryDto::getOrigin);
	    break;
	default:
	    comparator = Comparator.comparing(QueryHistoryDto::getQueryId);
	}
	if (sortOrder.getSortOrder().equalsIgnoreCase("DESC"))
	    comparator = comparator.reversed();
	return queryHistoryDto.stream().sorted(comparator).collect(Collectors.toList());
    }

    private List<QueryHistoryDto> getQueryHistory(List<Map<String, Object>> queryHistoryData) {
	List<QueryHistoryDto> queryHistoryList = new ArrayList<>();
	for (Map<String, Object> queryHistoryMap : queryHistoryData) {
	    QueryHistoryDto queryHistory = SRCMapper.getQueryHistory(queryHistoryMap);
	    queryHistoryList.add(queryHistory);
	}
	return queryHistoryList;
    }
}
