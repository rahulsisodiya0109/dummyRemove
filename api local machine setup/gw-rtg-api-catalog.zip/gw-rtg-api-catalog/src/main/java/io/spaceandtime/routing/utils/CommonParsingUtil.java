package io.spaceandtime.routing.utils;

import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import org.apache.calcite.sql.SqlBasicCall;
import org.apache.calcite.sql.SqlCall;
import org.apache.calcite.sql.SqlKind;
import org.apache.calcite.sql.SqlNode;
import org.apache.calcite.sql.SqlSelect;
import org.apache.calcite.sql.SqlWith;
import org.apache.calcite.sql.SqlWithItem;
import org.apache.calcite.sql.parser.SqlParser;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import io.spaceandtime.routing.constant.DBConstants;

public class CommonParsingUtil {

	private static final String DOT_CHARACTER = ".";
	private static final Logger LOG = LoggerFactory.getLogger(CommonParsingUtil.class);
	private static final String INVALID_TRANSACTION_BATCH_ERROR = "Invalid transaction - Batch Error";
	public static final String DEFAULT_NAMESPACE = "public";

	public static RequestParserDto parse(String query) throws SQLException {
		LOG.info("********************************");
		RequestParserDto requestDto = new RequestParserDto();

		if (query == null || query.isEmpty()) {
			return requestDto;
		}
		query = query.trim();
		requestDto.setSqlQuery(query);
		TransactionDto txnDto = processTransaction(query);
		if (!(txnDto.isTransaction())) {
			parseNormalQuery(query, requestDto);
		} else {
			// Process Transaction to get resource identifier from first statement
			requestDto = parseTransactionFirstQuery(requestDto);

		}

		return requestDto;

	}

	private static RequestParserDto parseTransactionFirstQuery(RequestParserDto requestDto) throws SQLException {
		LOG.info("Input query is a transaction");
		String[] transactionTokens = requestDto.getSqlQuery().split(";");
		String firstQuery = transactionTokens[1].strip();
		String[] keyWords = firstQuery.split(" ", 2);
		requestDto.setOperation(keyWords[0]);
		requestDto.setOperationType(getOperationType(firstQuery));
		LOG.info("First SQL Query in the transaction :" + firstQuery);
		LOG.info("Command Type of SQL:" + requestDto.getOperation());
		RequestParserDto txnParserDto = parse(firstQuery);
		txnParserDto.setOperationType(DBConstants.DML);
		txnParserDto.setSqlQuery(requestDto.getSqlQuery());
		return txnParserDto;
	}

	private static void parseNormalQuery(String query, RequestParserDto requestDto) throws SQLException {
		query = query.replace(";", "");
		String transformedQuery = query;
		requestDto.setOperationType(getOperationType(query));

		transformedQuery = processParameter(requestDto, transformedQuery);
		LOG.info("Operation type of SQL:" + requestDto.getOperationType());
		LOG.info("SQL Query:" + query);
		try {
			SqlParser parser = getParser(requestDto.getOperationType(), transformedQuery);
			SqlNode node = parser.parseQuery();
			if (node != null) {
				SqlCall operation = (SqlCall) node;
				requestDto.setOperation(getOperationName(operation));
				requestDto.setSqlNode(node);
				setTableName(requestDto);
			}
			requestDto.setSqlQuery(query);

		} catch (Exception e) {
			e.printStackTrace();
			final String parsingExceptionMessage = "Exception in parsing query";
			LOG.error(parsingExceptionMessage + ":{}", e.getMessage());
			throw new SQLException(parsingExceptionMessage);
		}
	}

	private static TransactionDto processTransaction(String query) throws SQLException {
		TransactionDto txnDto = new TransactionDto();
		String lowerCaseQuery = query.toLowerCase();
		if (lowerCaseQuery.startsWith(DBConstants.BEGIN)
				&& (lowerCaseQuery.endsWith(DBConstants.COMMIT) || lowerCaseQuery.endsWith(DBConstants.ROLLBACK))) {
			txnDto.setTransaction(true);
		}

		else if ((lowerCaseQuery.contains(DBConstants.BEGIN) && !(lowerCaseQuery.startsWith(DBConstants.BEGIN)))
				|| (lowerCaseQuery.contains(DBConstants.COMMIT) && !(lowerCaseQuery.endsWith(DBConstants.COMMIT)))
				|| (lowerCaseQuery.contains(DBConstants.ROLLBACK)
						&& !(lowerCaseQuery.endsWith(DBConstants.ROLLBACK)))) {
			throw new SQLException(INVALID_TRANSACTION_BATCH_ERROR);
		}
		return txnDto;

	}

	private static String processParameter(RequestParserDto requestDto, String transformedQuery) {
		String[] tokens = null;
		if (DBConstants.DDL.equals(requestDto.getOperationType())
				&& transformedQuery.toLowerCase().contains(DBConstants.WITH)) {
			tokens = transformedQuery.split("(?i)" + DBConstants.WITH);
			transformedQuery = tokens[0];
		}

		if (DBConstants.DDL.equals(requestDto.getOperationType())
				&& transformedQuery.toLowerCase().contains(DBConstants.FOREIGN)) {
			tokens = transformedQuery.split("(?i)" + DBConstants.FOREIGN);
			transformedQuery = tokens[0];
		}

		if (DBConstants.DDL.equals(requestDto.getOperationType())
				&& transformedQuery.toLowerCase().contains(DBConstants.PRIMARY)) {
			tokens = transformedQuery.split("(?i)" + DBConstants.PRIMARY);
			transformedQuery = tokens[0];
		}
		transformedQuery = transformedQuery.trim();
		if (transformedQuery.trim().endsWith(",")) {
			transformedQuery = transformedQuery.substring(0, transformedQuery.length() - 1) + " ) ";
		}
		return transformedQuery;
	}

	private static void setTableName(RequestParserDto dto) {
		List<String> tableNames = new ArrayList<>();
		switch (dto.getOperationType()) {
		case DBConstants.DQL:
			tableNames = CustomCalciteDQLParser.extractTableNames(dto.getSqlNode());
			break;
		case DBConstants.DDL:
			tableNames = CustomCalciteDDLParser.extractTableNames(dto.getSqlNode());
			break;
		case DBConstants.DML:
			tableNames = CustomCalciteDMLParser.extractTableNames(dto.getSqlNode());
			break;
		case DBConstants.WITH:
			processWithQuery(dto);
			break;
		default:
			break;
		}
		dto.setTableNames(tableNames);
		LOG.info("Table names:" + dto.getTableNames());
		if (dto.getTableNames().size() > 0) {
			dto.setResourceId(dto.getTableNames().get(0));
		}
		LOG.info("Primary Resource Id:" + dto.getResourceId());
	}

	private static void processWithQuery(RequestParserDto dto) {
		String primryResourceIdentifier = null;
		if (dto.getSqlNode().getKind().equals(SqlKind.WITH)) {
			final SqlWith sqlWithTable = (SqlWith) dto.getSqlNode();
			sqlWithTable.getOperandList();

			SqlNode body = sqlWithTable.body;
			String sqlQuery = body.toString();

			dto.setOperationType(getOperationType(sqlQuery));
			dto.setSqlQuery(sqlQuery);
			dto.setSqlNode(body);
			setTableName(dto);

			String primaryBodyResourceId = dto.getResourceId();
			primryResourceIdentifier = primaryBodyResourceId;
			SqlWithItem sqlNode = null;
			String itemName = null;
			SqlSelect selectOperand = null;
			List<SqlNode> withItemOperandList = sqlWithTable.withList;
			for (SqlNode eachItem : withItemOperandList) {
				sqlNode = (SqlWithItem) eachItem;
				if (sqlNode.query.getKind().equals(SqlKind.SELECT)) {
					selectOperand = (SqlSelect) sqlNode.query;
					if (selectOperand.getFrom() != null) {
						itemName = selectOperand.getFrom().toString();
					}
				}

				if (itemName == null) {
					itemName = sqlNode.name.toString();
				}
				if (!(itemName.equals(primaryBodyResourceId))) {
					primryResourceIdentifier = itemName;
					break;
				}
			}
			dto.setResourceId(getTargetResource(primryResourceIdentifier));
			LOG.info("Primary Resource Id:" + primryResourceIdentifier);
		}
	}

	public static String getOperationName(SqlCall operation) {

		return operation != null ? operation.getOperator().getName() : null;
	}

	public static String getOperationType(String query) {
		String operationType = null;
		query = query.toLowerCase();
		String firstWord = query.split("\\s+")[0];

		switch (firstWord) {
		case DBConstants.SELECT:
			operationType = DBConstants.DQL;
			break;
		case DBConstants.INSERT:
		case DBConstants.UPDATE:
		case DBConstants.DELETE:
		case DBConstants.MERGE:
			operationType = DBConstants.DML;
			break;
		case DBConstants.CREATE:
		case DBConstants.DROP:
		case DBConstants.ALTER:
			operationType = DBConstants.DDL;
			break;
		case DBConstants.WITH:
			operationType = DBConstants.WITH;
			break;
		}

		return operationType;
	}

	public static String getTargetResource(SqlNode node) {
		String element = node.toString();

		element = getTargetResource(element);
		return element;
	}

	public static String getTargetResource(String element) {
		if (element != null && !(element.contains(DOT_CHARACTER))) {
			element = DEFAULT_NAMESPACE + DOT_CHARACTER + element;
		}
		return element;
	}

	public static String getTargetResource(SqlBasicCall targetElement, Integer index) {
		if (index == null) {
			index = 0;
		}
		return getTargetResource(targetElement.operand(index));

	}

	public static SqlParser getParser(String operationType, String query) {
		SqlParser parser = null;
		if (DBConstants.DQL.equals(operationType) || DBConstants.DML.equals(operationType)
				|| DBConstants.WITH.equals(operationType)) {
			parser = SqlParser.create(query);
		}

		else if (DBConstants.DDL.equals(operationType)) {
			parser = CustomCalciteDDLParser.getSqlParser(query);
		}

		return parser;

	}

}
