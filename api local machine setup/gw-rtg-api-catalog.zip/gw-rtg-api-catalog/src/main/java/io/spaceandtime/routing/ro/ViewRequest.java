package io.spaceandtime.routing.ro;

import java.util.List;

import com.fasterxml.jackson.annotation.JsonIgnore;

import io.swagger.v3.oas.annotations.media.Schema;

public class ViewRequest {

	@JsonIgnore
	private String id;

	@Schema(description = "Unique view identifier", example = "eth_num_blocks_with_txn_cnt", required = true)
	private String viewName;

	@Schema(description = "containing the view SQL", example = "SELECT COUNT(*) FROM ETH.BLOCK WHERE TRANSACTION_COUNT > {{COUNT}}", required = true)
	private String viewText;

	@Schema(description = "containing the resource identifier", example = "ETH.BLOCK", required = true)
	private String resourceId;

	@Schema(description = "containing the view description", example = "This view returns the number of ethereum blocks that had a transaction count greater than the provided value", required = false)
	private String description;

	@JsonIgnore
	private String ownerId;

	@Schema(description = "containing the view publish status", example = "true", required = false)
	private Boolean isPublic;

	@Schema(description = "Unique schema identifier", example = "ETH", required = false)
	private String schemaId;

	@Schema(description = "containing the view parameters", required = false)
	private List<ParameterRequest> parametersRequest;

	@Schema(description = "containing the user's tags for the view", required = false)
	private List<TagRequest> tags;

	public String getViewName() {
		return viewName;
	}

	public void setViewName(String viewName) {
		this.viewName = viewName;
	}

	public String getViewText() {
		return viewText;
	}

	public void setViewText(String viewText) {
		this.viewText = viewText;
	}

	public String getResourceId() {
		return resourceId;
	}

	public void setResourceId(String resourceId) {
		this.resourceId = resourceId;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public String getOwnerId() {
		return ownerId;
	}

	public void setOwnerId(String ownerId) {
		this.ownerId = ownerId;
	}

	public Boolean getIsPublic() {
		return isPublic;
	}

	public void setIsPublic(Boolean isPublic) {
		this.isPublic = isPublic;
	}

	public String getSchemaId() {
		return schemaId;
	}

	public void setSchemaId(String schemaId) {
		this.schemaId = schemaId;
	}

	public List<ParameterRequest> getParametersRequest() {
		return parametersRequest;
	}

	public void setParametersRequest(List<ParameterRequest> parametersRequest) {
		this.parametersRequest = parametersRequest;
	}

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public List<TagRequest> getTags() {
		return tags;
	}

	public void setTags(List<TagRequest> tags) {
		this.tags = tags;
	}

}
