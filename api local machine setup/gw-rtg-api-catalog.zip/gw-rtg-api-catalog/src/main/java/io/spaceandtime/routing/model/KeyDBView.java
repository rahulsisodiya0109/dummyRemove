package io.spaceandtime.routing.model;

import java.util.List;

import com.fasterxml.jackson.annotation.JsonProperty;

public class KeyDBView {

	@JsonProperty("id")
	private String id;

	@JsonProperty("viewName")
	private String viewName;

	@JsonProperty("viewText")
	private String viewText;

	@JsonProperty("resourceId")
	private String resourceId;

	@JsonProperty("viewParameters")
	private List<ViewParameter> viewParameters;

	public String getViewName() {
		return viewName;
	}

	public void setViewName(String viewName) {
		this.viewName = viewName;
	}

	public String getViewText() {
		return viewText;
	}

	public void setViewText(String viewText) {
		this.viewText = viewText;
	}

	public List<ViewParameter> getParameters() {
		return viewParameters;
	}

	public void setParameters(List<ViewParameter> viewParameters) {
		this.viewParameters = viewParameters;
	}

	public String getResourceId() {
		return resourceId;
	}

	public void setResourceId(String resourceId) {
		this.resourceId = resourceId;
	}

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

}
