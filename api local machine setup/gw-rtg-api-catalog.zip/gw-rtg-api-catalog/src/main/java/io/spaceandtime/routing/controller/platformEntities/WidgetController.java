package io.spaceandtime.routing.controller.platformEntities;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import io.spaceandtime.routing.constant.ColumnConstant;
import io.spaceandtime.routing.constant.EnvironmentConstant;
import io.spaceandtime.routing.constant.MessageEnum;
import io.spaceandtime.routing.constant.SortOrderEnum;
import io.spaceandtime.routing.constant.StatusEnum;
import io.spaceandtime.routing.constant.WidgetTypeEnum;
import io.spaceandtime.routing.errorHandler.AppException;
import io.spaceandtime.routing.ignitedao.WidgetDAO;
import io.spaceandtime.routing.model.WidgetDto;
import io.spaceandtime.routing.ro.WidgetRequest;
import io.spaceandtime.routing.utils.ErrorResponse;
import io.spaceandtime.routing.utils.Page;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.media.ArraySchema;
import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.media.Schema;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.responses.ApiResponses;
import io.swagger.v3.oas.annotations.tags.Tag;

@RestController
@RequestMapping("/v1/content")
@Tag(name = "Widget")
public class WidgetController {

	@Autowired
	private WidgetDAO widgetDAO;

	@GetMapping(value = "/widgets")
	@Operation(summary = "Get All widgets", description = "Get all widget list")
	@ApiResponses(value = {
			@ApiResponse(responseCode = "200", description = "${api.response-codes.ok.desc}", useReturnTypeSchema = true),
			@ApiResponse(responseCode = "401", description = "${api.response-codes.unauthorized.desc}", content = @Content(schema = @Schema(implementation = ErrorResponse.class))) })
	public Page<WidgetDto> getWidget(@RequestParam(value = "isPublic", defaultValue = "false") Boolean isPublic,
			@RequestParam(value = "viewId", required = false) String viewId,
			@RequestParam(value = "searchKeyword", required = false) String searchKeyword,
			@RequestParam(value = "tagId", required = false) String tagId,
			@RequestParam(value = "pageNo", defaultValue = "1") int pageNo,
			@RequestParam(value = "pageSize", defaultValue = EnvironmentConstant.PAGE_SIZE) int pageSize,
			@RequestParam(value = "sortOrder") SortOrderEnum sortOrder,
			@RequestParam(value = "status", required = false, defaultValue = ColumnConstant.ALL) StatusEnum status,
			@RequestParam(value = "sortBy", defaultValue = ColumnConstant.MODIFIED) String sortBy,
			@RequestParam WidgetTypeEnum widgetTypeEnum) {
		Page<WidgetDto> widgetDto = widgetDAO.getAllWidgets(isPublic, viewId, searchKeyword, pageNo, pageSize,
				sortOrder, sortBy, widgetTypeEnum, tagId, status);
		return widgetDto;
	}

	@GetMapping(value = "/widgets/{id}")
	@Operation(summary = "Get widget by Id", description = "Get widget by id")
	@ApiResponses(value = {
			@ApiResponse(responseCode = "200", description = "${api.response-codes.ok.desc}", content = @Content(array = @ArraySchema(schema = @Schema(implementation = WidgetDto.class)))),
			@ApiResponse(responseCode = "401", description = "${api.response-codes.unauthorized.desc}", content = @Content(schema = @Schema(implementation = ErrorResponse.class))), })
	public ResponseEntity<List<WidgetDto>> getWidget(@PathVariable(value = "id", required = true) String widgetId,
			@RequestParam(value = "isPublic", defaultValue = "false") Boolean isPublic) {
		List<WidgetDto> widgetDto = widgetDAO.getWidgetById(widgetId, isPublic);
		if (widgetDto == null || widgetDto.isEmpty()) {
			throw new AppException(MessageEnum.DASHBOARD_NOT_FOUND);
		}
		return ResponseEntity.ok().body(widgetDto);
	}

	@PostMapping(path = "/widgets")
	@Operation(summary = "Add widget", description = "Add a new widget")
	@ApiResponses(value = { @ApiResponse(responseCode = "201", description = "${api.response-codes.created.desc}"),
			@ApiResponse(responseCode = "401", description = "${api.response-codes.unauthorized.desc}", content = @Content(schema = @Schema(implementation = ErrorResponse.class))), })
	public ResponseEntity<String> createWidget(@RequestBody WidgetRequest widgetRequest) {
		String id = widgetDAO.createWidget(widgetRequest);
		return new ResponseEntity<>(id, HttpStatus.CREATED);
	}

	@PutMapping(path = "/widgets/{id}")
	@Operation(summary = "Update Widget", description = "Update widget by id")
	@ApiResponses(value = { @ApiResponse(responseCode = "204", description = "${api.response-codes.noContent.desc}"),
			@ApiResponse(responseCode = "400", description = "${api.response-codes.badRequest.desc}", content = @Content(schema = @Schema(implementation = ErrorResponse.class))),
			@ApiResponse(responseCode = "401", description = "${api.response-codes.unauthorized.desc}", content = @Content(schema = @Schema(implementation = ErrorResponse.class))) })
	public ResponseEntity<Void> updateWidget(@PathVariable(value = "id") String widgetsId,
			@RequestBody WidgetRequest widgetRequest) {
		widgetDAO.updateWidget(widgetsId, widgetRequest);
		return ResponseEntity.status(HttpStatus.NO_CONTENT).build();
	}

	@DeleteMapping(value = "/widgets/{id}")
	@Operation(summary = "Delete widgets", description = "Delete widgets")
	@ApiResponses(value = { @ApiResponse(responseCode = "200", description = "${api.response-codes.noContent.desc}"),
			@ApiResponse(responseCode = "400", description = "${api.response-codes.badRequest.desc}", content = @Content(schema = @Schema(implementation = ErrorResponse.class))),
			@ApiResponse(responseCode = "401", description = "${api.response-codes.unauthorized.desc}", content = @Content(schema = @Schema(implementation = ErrorResponse.class))) })
	public ResponseEntity<Void> deleteWidgets(@PathVariable(value = "id", required = true) String widgetsId) {
		widgetDAO.deleteWidget(widgetsId);
		return ResponseEntity.status(HttpStatus.NO_CONTENT).build();
	}

	///////////////////// publish - fork widget //////////////////////////////

	@PostMapping(value = "/widgets/{id}/publish")
	@Operation(summary = "Publish widget", description = "Publish widget ")
	@ApiResponses(value = { @ApiResponse(responseCode = "201", description = "${api.response-codes.ok.desc}"),
			@ApiResponse(responseCode = "401", description = "${api.response-codes.unauthorized.desc}", content = @Content(schema = @Schema(implementation = ErrorResponse.class))),
			@ApiResponse(responseCode = "400", description = "${api.response-codes.badRequest.desc}", content = @Content(schema = @Schema(implementation = ErrorResponse.class))) })
	public ResponseEntity<Void> publishWidget(@PathVariable(required = true) String id,
			@RequestParam(required = true) String slug) throws Exception {
		widgetDAO.publishWidget(id, slug);
		return ResponseEntity.status(HttpStatus.CREATED).build();
	}

	@PostMapping(value = "/widgets/{slug}/fork")
	@Operation(summary = "fork widget", description = "Fork widget")
	@ApiResponses(value = {
			@ApiResponse(responseCode = "201", description = "${api.response-codes.created.desc}", content = @Content(schema = @Schema(implementation = String.class))),
			@ApiResponse(responseCode = "401", description = "${api.response-codes.unauthorized.desc}", content = @Content(schema = @Schema(implementation = ErrorResponse.class))),
			@ApiResponse(responseCode = "400", description = "${api.response-codes.badRequest.desc}", content = @Content(schema = @Schema(implementation = ErrorResponse.class))) })
	public ResponseEntity<String> forkWidget(@PathVariable String slug) throws Exception {
		String forkWidgetId = widgetDAO.forkWidget(slug);
		return new ResponseEntity<>(forkWidgetId, HttpStatus.CREATED);
	}

}
