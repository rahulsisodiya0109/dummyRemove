package io.spaceandtime.routing.controller;

import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

/**
 * 
 * @author Nilesh Sharma
 *
 */
@RestController
@RequestMapping("/v1/content")
public class PlatformEntityController {

}
