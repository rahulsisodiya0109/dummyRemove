package io.spaceandtime.routing.utils;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import io.spaceandtime.api.jwt.IJwtProvider;
import io.spaceandtime.api.jwt.JwtPayload;
import io.spaceandtime.routing.constant.MessageEnum;
import io.spaceandtime.routing.errorHandler.AppException;

@Component
public class JwtUtils {

	@Autowired
	private IJwtProvider _jwtProvider;

	public JwtPayload parseJwt() {
		try {
			String accessToken = ThreadLocalUtil.getContext().getBearerToken();
			return _jwtProvider.parse(accessToken);
		} catch (Exception e) {
			throw new AppException(MessageEnum.UNAUTHORIZED_ACCESS);
		}
	}
}
