package io.spaceandtime.routing.constant;

/**
 * 
 * @author GuvalaL1
 *
 */
public enum SQLCommandTypeEnum {

	DQL, DML, DDL;

}
