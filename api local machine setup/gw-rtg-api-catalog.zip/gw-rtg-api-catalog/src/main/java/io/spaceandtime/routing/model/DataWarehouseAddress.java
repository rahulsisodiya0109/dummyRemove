package io.spaceandtime.routing.model;

import java.util.List;

import com.fasterxml.jackson.annotation.JsonProperty;

public class DataWarehouseAddress {

	@JsonProperty("thin_client")
	private ThinClientInfo thinClientInfo;

	@JsonProperty("kafka_brokers")
	private List<String> kafkaBrokers;

	@JsonProperty("network_management")
	private String networkManagement;

	public String getNetworkManagement() {
		return networkManagement;
	}

	public void setNetworkManagement(String networkManagement) {
		this.networkManagement = networkManagement;
	}


	public DataWarehouseAddress() {

	}

	public DataWarehouseAddress(List<String> kafkaBrokers, ThinClientInfo thinClientInfo, String networkManagement) {
		this.kafkaBrokers = kafkaBrokers;
		this.thinClientInfo = thinClientInfo;
		this.networkManagement = networkManagement;
	}

	public List<String> getKafkaBrokers() {
		return kafkaBrokers;
	}

	public void setKafkaBrokers(List<String> kafkaBrokers) {
		this.kafkaBrokers = kafkaBrokers;
	}

	public ThinClientInfo getThinClientInfo() {
		return thinClientInfo;
	}

	public void setThinClientInfo(ThinClientInfo thinClientInfo) {
		this.thinClientInfo = thinClientInfo;
	}

}