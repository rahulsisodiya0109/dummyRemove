package io.spaceandtime.routing.ignite;

import java.util.Collection;
import java.util.List;

import org.apache.ignite.IgniteBinary;
import org.apache.ignite.Ignition;
import org.apache.ignite.cache.query.FieldsQueryCursor;
import org.apache.ignite.cache.query.SqlFieldsQuery;
import org.apache.ignite.client.ClientAtomicConfiguration;
import org.apache.ignite.client.ClientAtomicLong;
import org.apache.ignite.client.ClientCache;
import org.apache.ignite.client.ClientCacheConfiguration;
import org.apache.ignite.client.ClientCluster;
import org.apache.ignite.client.ClientClusterGroup;
import org.apache.ignite.client.ClientCollectionConfiguration;
import org.apache.ignite.client.ClientCompute;
import org.apache.ignite.client.ClientException;
import org.apache.ignite.client.ClientIgniteSet;
import org.apache.ignite.client.ClientServices;
import org.apache.ignite.client.ClientTransactions;
import org.apache.ignite.client.IgniteClient;
import org.apache.ignite.client.IgniteClientFuture;
import org.apache.ignite.configuration.ClientConfiguration;
import org.jetbrains.annotations.Nullable;

public class IgniteThinClient implements IgniteClient {

	private IgniteClient client;

	private String clusterId;

	private boolean active;

	private ClientConfiguration cfg;

	public IgniteThinClient(ClientConfiguration cfg, String clusterId) {
		client = Ignition.startClient(cfg);
		this.active = true;
		this.clusterId = clusterId;
		this.cfg = cfg;
	}

	@Override
	public <K, V> ClientCache<K, V> getOrCreateCache(String name) throws ClientException {
		return client.getOrCreateCache(name);
	}

	@Override
	public <K, V> ClientCache<K, V> cache(String name) {
		return client.cache(name);
	}

	@Override
	public Collection<String> cacheNames() throws ClientException {
		return client.cacheNames();
	}

	@Override
	public void destroyCache(String name) throws ClientException {
		client.destroyCache(name);
	}

	@Override
	public <K, V> ClientCache<K, V> createCache(String name) throws ClientException {
		return client.createCache(name);
	}

	@Override
	public FieldsQueryCursor<List<?>> query(SqlFieldsQuery qry) {
		return client.query(qry);
	}

	@Override
	public <K, V> ClientCache<K, V> getOrCreateCache(ClientCacheConfiguration cfg) throws ClientException {
		return client.getOrCreateCache(cfg);
	}

	@Override
	public IgniteClientFuture<Collection<String>> cacheNamesAsync() throws ClientException {
		return client.cacheNamesAsync();
	}

	@Override
	public IgniteClientFuture<Void> destroyCacheAsync(String name) throws ClientException {
		return client.destroyCacheAsync(name);
	}

	@Override
	public <K, V> ClientCache<K, V> createCache(ClientCacheConfiguration cfg) throws ClientException {
		return client.getOrCreateCache(cfg);
	}

	@Override
	public <K, V> IgniteClientFuture<ClientCache<K, V>> createCacheAsync(String name) throws ClientException {
		return client.createCacheAsync(name);
	}

	@Override
	public <K, V> IgniteClientFuture<ClientCache<K, V>> createCacheAsync(ClientCacheConfiguration cfg)
			throws ClientException {
		return client.createCacheAsync(cfg);
	}

	@Override
	public IgniteBinary binary() {
		return client.binary();
	}

	@Override
	public <K, V> IgniteClientFuture<ClientCache<K, V>> getOrCreateCacheAsync(String name) throws ClientException {
		return client.getOrCreateCacheAsync(name);
	}

	@Override
	public <K, V> IgniteClientFuture<ClientCache<K, V>> getOrCreateCacheAsync(ClientCacheConfiguration cfg)
			throws ClientException {
		return client.getOrCreateCacheAsync(cfg);
	}

	@Override
	public ClientTransactions transactions() {
		return client.transactions();
	}

	@Override
	public ClientCompute compute() {
		return client.compute();
	}

	@Override
	public ClientCompute compute(ClientClusterGroup grp) {
		return client.compute(grp);
	}

	@Override
	public ClientCluster cluster() {
		return client.cluster();
	}

	@Override
	public ClientServices services() {
		return client.services();
	}

	@Override
	public ClientServices services(ClientClusterGroup grp) {
		return client.services(grp);
	}

	@Override
	public void close() {
		client.close();
	}

	public boolean isActive() {
		return active;
	}

	public void setActive(boolean active) {
		this.active = active;
	}

	public String getClusterId() {
		return clusterId;
	}

	public void setClusterId(String clusterId) {
		this.clusterId = clusterId;
	}

	public void restartClient() {
		client = Ignition.startClient(cfg);
	}

	@Override
	public ClientAtomicLong atomicLong(String name, long initVal, boolean create) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public ClientAtomicLong atomicLong(String name, ClientAtomicConfiguration cfg, long initVal, boolean create) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public <T> ClientIgniteSet<T> set(String name, @Nullable ClientCollectionConfiguration cfg) {
		// TODO Auto-generated method stub
		return null;
	}

}
