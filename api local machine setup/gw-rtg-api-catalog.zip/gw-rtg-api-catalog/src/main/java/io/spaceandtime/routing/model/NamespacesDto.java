package io.spaceandtime.routing.model;

public class NamespacesDto {

	private String schemaId;
	
	public String getSchemaId() {
		return schemaId;
	}

	public void setSchemaId(String schemaId) {
		this.schemaId = schemaId;
	}
}
