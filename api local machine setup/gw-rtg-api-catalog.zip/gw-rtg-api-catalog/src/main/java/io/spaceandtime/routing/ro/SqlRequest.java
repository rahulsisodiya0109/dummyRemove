package io.spaceandtime.routing.ro;

import io.spaceandtime.routing.utils.BaseRO;
import io.swagger.v3.oas.annotations.media.Schema;

@Schema(name = "SqlRequest")
public class SqlRequest extends BaseRO {

	@Schema(description = "Unique resource identifier that helps to connect to cluster", example = "PUBLIC.CUSTOMER", required = true)
	private String resourceId;
	@Schema(description = "DML,DDL queries can be sent using below attribute", example = "SELECT * FROM PUBLIC.CUSTOMER", required = true)
	private String sqlText;

	public String getResourceId() {
		return resourceId;
	}

	public void setResourceId(String resourceId) {
		this.resourceId = resourceId;
	}

	public String getSqlText() {
		return sqlText;
	}

	public void setSqlText(String sqlText) {
		this.sqlText = sqlText;
	}

	@Override
	public String toString() {
		return "SqlRequest [resourceId=" + resourceId + ", sqlText=" + sqlText + "]";
	}

}