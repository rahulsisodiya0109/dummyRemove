package io.spaceandtime.routing.configs;

import org.apache.ignite.configuration.ClientConfiguration;
import org.apache.ignite.configuration.ClientTransactionConfiguration;
import org.apache.ignite.transactions.TransactionConcurrency;
import org.apache.ignite.transactions.TransactionIsolation;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import io.spaceandtime.routing.constant.MessageEnum;
import io.spaceandtime.routing.errorHandler.AppException;
import io.spaceandtime.routing.ignite.IgniteThinClient;
import io.spaceandtime.routing.storage.IKeyDBProvider;
import io.spaceandtime.storage.datawarehouse.DWAddress;
import io.spaceandtime.storage.datawarehouse.DWSQLConnection;

@Configuration
public class SRCIgniteClusterConfig {

	public static final Boolean HEARTBEAT_ENABLE = true;
	public static final String SXT_CLUSTER = "SXT:CLUSTER";

	@Autowired
	IKeyDBProvider _keydbProvider;

	/**
	 * Build template from ignite configuration
	 * 
	 */
	@Bean
	public IgniteThinClient srcIgniteClient() {
		try {
			DWAddress address = _keydbProvider.getClusterAddress(SXT_CLUSTER);
			ClientConfiguration cfg = igniteConfigurations(address.getSqlConnection());
			return new IgniteThinClient(cfg, SXT_CLUSTER);
		} catch (Exception ex) {
			throw new AppException(MessageEnum.SXT_CLUSTER_NOT_CONFIGURED);
		}
	}

	/**
	 * To build ignite configuration
	 * 
	 */
	public ClientConfiguration igniteConfigurations(DWSQLConnection sqlConnection) {
		return buildConfiguration(sqlConnection.getAddress(), sqlConnection.getUsername(),
				sqlConnection.getPassword());
	}

	private ClientConfiguration buildConfiguration(String address, String username, String password) {
		ClientConfiguration client = new ClientConfiguration().setAddresses(address).setPartitionAwarenessEnabled(true)
				.setUserName(username).setUserPassword(password);
		client.setHeartbeatEnabled(HEARTBEAT_ENABLE);
		client.setTransactionConfiguration(new ClientTransactionConfiguration().setDefaultTxTimeout(10000)
				.setDefaultTxConcurrency(TransactionConcurrency.OPTIMISTIC)
				.setDefaultTxIsolation(TransactionIsolation.REPEATABLE_READ));
		return client;
	}
}
