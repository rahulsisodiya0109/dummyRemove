package io.spaceandtime.routing.ignitedao;

import java.util.List;

import io.spaceandtime.routing.constant.SortOrderEnum;
import io.spaceandtime.routing.constant.StatusEnum;
import io.spaceandtime.routing.model.DashboardDto;
import io.spaceandtime.routing.model.DashboardWidgetDto;
import io.spaceandtime.routing.ro.DashboardRequest;
import io.spaceandtime.routing.ro.DashboardWidgetRequest;
import io.spaceandtime.routing.utils.Page;

public interface DashboardDAO {

	Page<DashboardDto> getDashboard(Boolean isPublic, String searchKeyword, int pageNo, int pageSize,
			SortOrderEnum sortOrder, String sortBy, String tagId, StatusEnum status);

	String saveDashboard(DashboardRequest dashboard);

	void deleteDashboard(String dashboardId);

	void updateDashboard(DashboardRequest dashboard, String dashboardId);

	List<DashboardWidgetDto> getDashboardWidgetDto(String dashboardId);

	void saveDashboardWidget(String dashboardId, List<DashboardWidgetRequest> dashboardWidgetRequests) throws Exception;

	void updateDashboardWidget(List<DashboardWidgetRequest> dashboardWidgetRequests, String dashboardId)
			throws Exception;

	void deleteDashboardWidget(String dashboardId);

	void publishDashboard(String id, String requestSlug) throws Exception;

	String forkDashboard(String slug) throws Exception;

	List<DashboardDto> getDashboardById(String id);

	List<DashboardDto> getDashboardById(String id, Boolean isPublic);

	List<DashboardDto> getDashboardBySlug(String slug, Boolean isPublic);
}
