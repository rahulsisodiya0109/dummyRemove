package io.spaceandtime.routing.model;

import io.spaceandtime.storage.subscription.Subscription;
import io.spaceandtime.storage.subscription.SubscriptionState;

public class SubscriptionInfo {

	private String accountName;

	private String subscriptionType;

	private boolean active;

	private String lastPayment;

	public SubscriptionInfo(){}
	public SubscriptionInfo(Subscription sbsc) {
		accountName = sbsc.getName();
		subscriptionType = sbsc.getPlanName();
		active = sbsc.getState() == SubscriptionState.ACTIVE;
		lastPayment = sbsc.getLastPayment();
	}


	public String getAccountName() {
		return accountName;
	}

	public void setAccountName(String accountName) {
		this.accountName = accountName;
	}

	public String getSubscriptionType() {
		return subscriptionType;
	}

	public void setSubscriptionType(String subscriptionType) {
		this.subscriptionType = subscriptionType;
	}

	public boolean getActive() {
		return active;
	}

	public void setActive(boolean active) {
		this.active = active;
	}

	public String getLastPayment() {
		return lastPayment;
	}

	public void setLastPayment(String lastPayment) {
		this.lastPayment = lastPayment;
	}
}
