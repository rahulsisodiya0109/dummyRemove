package io.spaceandtime.routing.errorHandler;

import org.springframework.http.HttpStatus;

import io.spaceandtime.routing.utils.AppBundle;
import io.spaceandtime.routing.utils.BasePropertyEnum;

public class BadRequestException extends BaseAppException {

	private static final long serialVersionUID = 1L;

	private HttpStatus status;
	
	public BadRequestException(final BasePropertyEnum property, final Object... params){
		setMessageId(property.getMessageCode());
		setMessageText(AppBundle.getString(property, params));
		this.status = property.getStatus();
	}
	
	public HttpStatus getStatus() {
		return status;
	}
}
