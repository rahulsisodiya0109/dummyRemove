package io.spaceandtime.routing.utils;

public class TransactionDto {

	private boolean isTransaction;
	private String firstQuery;
	private boolean operationType;
	public boolean isTransaction() {
		return isTransaction;
	}
	public void setTransaction(boolean isTransaction) {
		this.isTransaction = isTransaction;
	}
	public String getFirstQuery() {
		return firstQuery;
	}
	public void setFirstQuery(String firstQuery) {
		this.firstQuery = firstQuery;
	}
	public boolean isOperationType() {
		return operationType;
	}
	public void setOperationType(boolean operationType) {
		this.operationType = operationType;
	}
}
