package io.spaceandtime.routing.utils;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.UUID;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;

public class AppUtils {

	private static final ObjectMapper mapper = new ObjectMapper();

	public static String getUUID() {
		return UUID.randomUUID().toString().replaceAll("-", "");
	}

	public static String convertObjectToJson(Object o) throws JsonProcessingException {
		return mapper.writeValueAsString(o);
	}

	public static String convertObjectToJsonString(Object o) {
		try {
			return mapper.writeValueAsString(o);
		} catch (Exception e) {
			return null;
		}
	}

	public static <T> T convertJsonToObject(Class<T> clazz, String json) {
		try {
			return mapper.readValue(json, clazz);
		} catch (Exception e) {
			return null;
		}
	}

	public static <T> T convertJsonToObject(TypeReference<T> type, String json) {
		try {
			return mapper.readValue(json, type);
		} catch (Exception e) {
			return null;
		}
	}

	/**
	 * To format the given string with values .The params in string should be
	 * ${param}
	 * 
	 * @param format
	 * @param values
	 * @return
	 */
	public static String format(String format, Map<String, Object> values) {
		StringBuilder formatter = new StringBuilder(format);
		List<Object> valueList = new ArrayList<Object>();

		Matcher matcher = Pattern.compile("\\$\\{(\\w+)}").matcher(format);

		while (matcher.find()) {
			String key = matcher.group(1);

			String formatKey = String.format("${%s}", key);
			int index = formatter.indexOf(formatKey);

			if (index != -1) {
				formatter.replace(index, index + formatKey.length(), "%s");
				valueList.add(values.get(key));
			}
		}

		return String.format(formatter.toString(), valueList.toArray());
	}

	public static String buildResourceId(String resourceId) {
		return resourceId.replace(".", ":").toUpperCase();
	}

	public static String extractViewText(String viewTextContent) {

		// Remove single line comments
		String sql = viewTextContent.replaceAll("--.*", "");

		// Remove multi-line comments
		sql = sql.replaceAll("/\\*.*?\\*/", "");

		// Trim leading and trailing white spaces
		sql = sql.trim();

		// Remove line breaks
		sql = sql.replaceAll("\n", " ");

		// Remove extra white spaces
		sql = sql.replaceAll("\\s+", " ");

		// Check if the SQL statement is valid
		if (sql.matches("(?i)^(select|insert|update|delete).*$")) {
			return sql;
		} else {
			return "";
		}
	}

}
