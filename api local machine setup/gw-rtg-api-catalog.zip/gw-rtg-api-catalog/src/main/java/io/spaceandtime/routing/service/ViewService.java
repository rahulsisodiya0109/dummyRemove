package io.spaceandtime.routing.service;

import java.util.List;


import io.spaceandtime.routing.constant.SortOrderEnum;
import io.spaceandtime.routing.constant.StatusEnum;
import io.spaceandtime.routing.model.SRCViewDto;
import io.spaceandtime.routing.modelignite.SRCView;
import io.spaceandtime.routing.ro.ViewRequest;
import io.spaceandtime.routing.utils.Page;

public interface ViewService {

	String createView(ViewRequest viewRequest) throws Exception;

	void deleteView(String viewName, String viewId) throws Exception;

	void updateView(ViewRequest viewRequest, String viewId, String viewName) throws Exception;

	List<SRCView> getViewById(String viewId);

	Page<SRCViewDto> getViews(Boolean isPublic, String searchKeyword, int pageNo, int pageSize, SortOrderEnum sortOrder, String sortBy, String tagId, StatusEnum status);

	void publishView(String viewId);

	String forkView(String viewId);

}
