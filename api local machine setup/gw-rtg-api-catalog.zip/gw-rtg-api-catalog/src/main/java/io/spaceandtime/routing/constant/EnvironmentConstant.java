package io.spaceandtime.routing.constant;

public class EnvironmentConstant {

	public static final String KEYDB_HOST = "${keydb.host}";
	public static final String KEYDB_PORT = "${keydb.port}";
	public static final String KEYDB_PASSWORD = "${keydb.password}";

	public static final String GATEWAY_SECURITY_PUBLICKEY = "${gateway.security.publicKey}";

	public static final String QUERY_MAX_ROWS = "${query.max.rows}";
	public static final String PAGE_SIZE = "${page.size}";
	
	public static final String DISCOVERY_BISCUIT = "${catalog.api.discovery.biscuit}";
	public static final String PLATFORM_ENTITIES_BISCUIT = "${catalog.api.platform.entities.biscuit}";
}
