package io.spaceandtime.routing.ignitedao;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import org.apache.ignite.cache.query.FieldsQueryCursor;
import org.springframework.stereotype.Component;

import io.spaceandtime.routing.constant.MessageEnum;
import io.spaceandtime.routing.errorHandler.AppException;
import io.spaceandtime.routing.jdbcdao.BaseIgniteSqlDAOImpl;
import io.spaceandtime.routing.mapper.SRCMapper;
import io.spaceandtime.routing.model.UserProfile;
import io.spaceandtime.routing.query.CatalogAPIQuery;
import io.spaceandtime.routing.utils.ThreadLocalUtil;

@Component
public class UserProfileDAOImpl extends BaseIgniteSqlDAOImpl implements UserProfileDAO {

	@Override
	public List<UserProfile> getUser(String userId) {

		String qryText = CatalogAPIQuery.GET_USER;
		qryText = qryText + " WHERE USER_ID= '" + userId + "' ;";
		List<Map<String, Object>> userProfileList = getPlatformEntitiesData(qryText);
		return getUserProfile(userProfileList);
	}

	@Override
	public void updateUserProfile(String userId, UserProfile userProfile) {

		userProfile.setUserId(userId);
		checkValidJsonInMetadata(userProfile.getSettings());
		if (userId.equals(getUserId())) {
			executeDML(CatalogAPIQuery.UPDATE_USER,userProfile);
		} else {
			throw new AppException(MessageEnum.USER_NOTVALID, userId);
		}

	}

	protected List<Map<String, Object>> buildResult(FieldsQueryCursor<List<?>> data) {
		List<Map<String, Object>> results = new ArrayList<>();
		List<List<?>> dataList = data.getAll();
		int countCol = data.getColumnsCount();
		dataList.forEach(row -> {
			Map<String, Object> rowData = new LinkedHashMap<>();
			for (int i = 0; i < countCol; i++) {
				rowData.put(data.getFieldName(i), row.get(i));
			}
			results.add(rowData);
		});
		data.close();
		return results;
	}

	private List<UserProfile> getUserProfile(List<Map<String, Object>> userProfile) {
		List<UserProfile> userList = new ArrayList<>();
		for (Map<String, Object> userMap : userProfile) {
			UserProfile userprofile = SRCMapper.getUser(userMap);
			userList.add(userprofile);
		}
		return userList;
	}

	@Override
	public void deleteByUserId(String userId) {
		if (userId.equals(ThreadLocalUtil.getContext().getUserId())) {
			String qryText = CatalogAPIQuery.DELETE_USER;
			qryText = qryText + " WHERE USER_ID= '" + userId + "' ;";
			executeDML(qryText);
		} else {
			throw new AppException(MessageEnum.USER_NOTVALID, userId);
		}
	}

}
