package io.spaceandtime.routing.utils;

import java.util.ArrayList;
import java.util.List;

import org.apache.calcite.config.Lex;
import org.apache.calcite.sql.SqlNode;
import org.apache.calcite.sql.ddl.SqlDropTable;
import org.apache.calcite.sql.parser.SqlParseException;
import org.apache.calcite.sql.parser.SqlParser;
import org.apache.calcite.sql.validate.SqlConformance;
import org.apache.calcite.sql.validate.SqlConformanceEnum;
import org.apache.ignite.internal.processors.query.calcite.sql.IgniteAbstractSqlAlterTable;
import org.apache.ignite.internal.processors.query.calcite.sql.IgniteSqlCreateIndex;
import org.apache.ignite.internal.processors.query.calcite.sql.IgniteSqlCreateTable;
import org.apache.ignite.internal.processors.query.calcite.sql.IgniteSqlDropIndex;
import org.apache.ignite.internal.processors.query.calcite.sql.generated.IgniteSqlParserImpl;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class CustomCalciteDDLParser {
	private static final Logger LOG = LoggerFactory.getLogger(CustomCalciteDDLParser.class);

	public static List<String> getData(final String query) throws SqlParseException {

		SqlParser parser = getSqlParser(query);
		List<String> tables = new ArrayList<>();
		final SqlNode sqlNode = parser.parseStmt();
		if (sqlNode != null) {
			tables = extractTableNames(sqlNode);
		}
		return tables;
	}

	public static SqlParser getSqlParser(String query) {
		SqlParser.Config sqlParserConfig = getSqlParserConfig();
		SqlParser parser = SqlParser.create(query, sqlParserConfig);
		return parser;
	}

	private static SqlParser.Config getSqlParserConfig() {

		SqlConformance conformance = SqlConformanceEnum.BABEL;

		return SqlParser.configBuilder().setParserFactory(IgniteSqlParserImpl.FACTORY).setConformance(conformance)
				.setLex(Lex.JAVA).setIdentifierMaxLength(256).build();
	}

	public static List<String> extractTableNames(SqlNode sqlNode) {

		final List<String> tables = new ArrayList<>();
		String tableName = null;

		switch (sqlNode.getKind()) {
		case CREATE_TABLE:
			final IgniteSqlCreateTable sqlCreateTable = (IgniteSqlCreateTable) sqlNode;
			tableName = sqlCreateTable.name().toString();
			break;

		case DROP_TABLE:
			final SqlDropTable sqlDropTable = (SqlDropTable) sqlNode;
			tableName = sqlDropTable.name.toString();
			break;

		case ALTER_TABLE:
			final IgniteAbstractSqlAlterTable sqlAlterTable = (IgniteAbstractSqlAlterTable) sqlNode;
			tableName = sqlAlterTable.name().toString();
			break;

		case CREATE_INDEX:
			final IgniteSqlCreateIndex sqlCreateIndex = (IgniteSqlCreateIndex) sqlNode;
			tableName = sqlCreateIndex.tableName().toString();
			break;

		case DROP_INDEX:
			final IgniteSqlDropIndex sqlDropIndex = (IgniteSqlDropIndex) sqlNode;
			tableName = sqlDropIndex.name().toString();
			break;
		}

		if (tableName != null) {
			tables.add(CommonParsingUtil.getTargetResource(tableName));
		}
		LOG.info("Extracted tables size:{}", tables.size());
		LOG.info("Extracted tables:{}", tables);
		return tables;
	}

}
