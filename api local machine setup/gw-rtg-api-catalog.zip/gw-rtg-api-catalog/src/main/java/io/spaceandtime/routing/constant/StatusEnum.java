package io.spaceandtime.routing.constant;

public enum StatusEnum {

	ALL("ALL"), 
	PUBLISHED("PUBLISHED"),
	UNPUBLISHED("UNPUBLISHED");

	private String status;
	
	StatusEnum(String string) {
		status = string;
	}
	
	public String getStatus() {
		return status;
	}

	public String toString() {
		return this.status;
	}
}
