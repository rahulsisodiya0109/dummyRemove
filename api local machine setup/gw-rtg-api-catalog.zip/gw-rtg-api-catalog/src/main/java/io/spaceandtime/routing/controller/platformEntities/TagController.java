package io.spaceandtime.routing.controller.platformEntities;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import io.spaceandtime.routing.controller.PlatformEntityController;
import io.spaceandtime.routing.ignitedao.TagDAO;
import io.spaceandtime.routing.model.TagDto;
import io.spaceandtime.routing.utils.ErrorResponse;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.media.ArraySchema;
import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.media.Schema;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.responses.ApiResponses;

/**
 * 
 * @author Nilesh Sharma
 *
 */

@RestController
public class TagController extends PlatformEntityController {

	@Autowired
	TagDAO tagDAO;

	/**
	 * 
	 * Get Tags
	 */
	@GetMapping(value = "/tag")
	@Operation(summary = "Get Tags", description = "Returns list of Tags")
	@ApiResponses(value = {
			@ApiResponse(responseCode = "200", description = "${api.response-codes.ok.desc}", content = @Content(array = @ArraySchema(schema = @Schema(implementation = TagDto.class)))),
			@ApiResponse(responseCode = "401", description = "${api.response-codes.unauthorized.desc}", content = @Content(schema = @Schema(implementation = ErrorResponse.class))),
			@ApiResponse(responseCode = "404", description = "${api.response-codes.notFound.desc}", content = @Content(schema = @Schema(implementation = ErrorResponse.class))) })
	public List<TagDto> getAllTags(@RequestParam(required = false) String tagId,
			@RequestParam(defaultValue = "false") Boolean popular, @RequestParam(required = false) String tagType,
			@RequestParam(value = "isPublic", defaultValue = "false") Boolean isPublic) {
		return tagDAO.getAllTags(tagId, popular, tagType, isPublic);
	}

}
