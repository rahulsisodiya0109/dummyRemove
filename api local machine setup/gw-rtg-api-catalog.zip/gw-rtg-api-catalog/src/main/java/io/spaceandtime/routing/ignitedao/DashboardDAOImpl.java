package io.spaceandtime.routing.ignitedao;

import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Map;
import java.util.UUID;
import java.util.stream.Collectors;

import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import io.spaceandtime.routing.constant.ColumnConstant;
import io.spaceandtime.routing.constant.MessageEnum;
import io.spaceandtime.routing.constant.SortOrderEnum;
import io.spaceandtime.routing.constant.StatusEnum;
import io.spaceandtime.routing.errorHandler.AppException;
import io.spaceandtime.routing.jdbcdao.BaseIgniteSqlDAOImpl;
import io.spaceandtime.routing.logging.AppLogger;
import io.spaceandtime.routing.logging.Log;
import io.spaceandtime.routing.mapper.SRCMapper;
import io.spaceandtime.routing.mapper.SortByTagIdAsc;
import io.spaceandtime.routing.mapper.SortByTagIdDesc;
import io.spaceandtime.routing.model.DashboardDto;
import io.spaceandtime.routing.model.DashboardWidgetDto;
import io.spaceandtime.routing.model.WidgetDto;
import io.spaceandtime.routing.modelignite.Dashboard;
import io.spaceandtime.routing.modelignite.DashboardWidget;
import io.spaceandtime.routing.modelignite.Widget;
import io.spaceandtime.routing.query.CatalogAPIQuery;
import io.spaceandtime.routing.ro.DashboardRequest;
import io.spaceandtime.routing.ro.DashboardWidgetRequest;
import io.spaceandtime.routing.ro.TagRequest;
import io.spaceandtime.routing.utils.Page;
import jodd.util.StringUtil;

/**
 * 
 * @author Nilesh Sharma
 *
 */
@Component
public class DashboardDAOImpl extends BaseIgniteSqlDAOImpl implements DashboardDAO {

	private static @Log AppLogger logger;

	@Autowired
	WidgetDAO widgetDAO;

	private static final String CLONE = "(Clone)";

	@Override
	public Page<DashboardDto> getDashboard(Boolean isPublic, String searchKeyword, int pageNo, int pageSize,
			SortOrderEnum sortOrder, String sortBy, String tagId, StatusEnum status) {

		String qryText = CatalogAPIQuery.GET_DASHBOARD;
		String qryCounts = CatalogAPIQuery.GET_DASHBOARD_COUNT;
		List<String> filters = new ArrayList<>();

		if (!StringUtil.isAllBlank(searchKeyword))
			filters.add("LOWER(d.DASH_NAME) LIKE LOWER(CONCAT('%', '" + searchKeyword + "', '%'))");

		if (!StringUtil.isAllBlank(tagId)) {
			qryText = CatalogAPIQuery.GET_DASHBOARD_BY_TAG;
			qryCounts = CatalogAPIQuery.GET_DASHBOARD_COUNT_BY_TAG;
			filters.add("t.TAG_ID = '" + tagId + "'");
		}

		if (isPublic) {
			filters.add(" ISPUBLIC = TRUE");
		} else {
			addStatusFilter(status, filters);
		}

		if (!filters.isEmpty()) {
			qryText += "WHERE " + String.join(" AND ", filters);
			qryCounts += "WHERE " + String.join(" AND ", filters);
		}

		int count = getTotalRecords(qryCounts);
		logger.info("total records: " + count);
		qryText = buildPaginatedQuery(pageNo, pageSize, sortOrder, buildSortByColumnName(sortBy), qryText);
		List<Map<String, Object>> dashboardList = getPlatformEntitiesData(qryText);
		List<DashboardDto> dashboardDtos = getDashboardData(dashboardList);
		if (sortBy.equalsIgnoreCase(ColumnConstant.TAG)) {
			if (sortOrder.getSortOrder().equalsIgnoreCase(ColumnConstant.ASCENDING_ORDER)) {
				for (DashboardDto dashboardDto : dashboardDtos) {
					Collections.sort(dashboardDto.getTags(), new SortByTagIdAsc());
				}
			} else {
				for (DashboardDto dashboardDto : dashboardDtos) {
					Collections.sort(dashboardDto.getTags(), new SortByTagIdDesc());
				}
			}
		}
		return pageableContent(pageNo, pageSize, count, dashboardDtos);
	}

	@Override
	public String saveDashboard(DashboardRequest dashboardRequest) {
		String userId = getUserId();
		Timestamp modified = new Timestamp(System.currentTimeMillis());
		String id = UUID.randomUUID().toString();
		checkValidJsonInMetadata(dashboardRequest.getMetadata());
		Dashboard dashboard = SRCMapper.getDashboard(dashboardRequest);
		dashboard.setId(id);
		dashboard.setModified(modified);
		dashboard.setOwnerId(userId);
		dashboard.setIsPublic(false);
		String srcSql = parseQuery(Dashboard.class, dashboard, CatalogAPIQuery.CREATE_DASHBOARD);
		executeDML(srcSql);
		if (dashboardRequest.getTags() != null)
			for (TagRequest tag : dashboardRequest.getTags())
				saveNewTagAndTagRelation(tag, dashboard.getId(), ColumnConstant.DASHBOARD);
		return id;
	}

	@Override
	public void deleteDashboard(String dashboardId) {
		String userId = getUserId();
		checkDashboardAuthorization(dashboardId, userId);
		String qryText = CatalogAPIQuery.DELETE_DASHBOARD;
		qryText = qryText + " WHERE ID='" + dashboardId + "';";
		executeDML(qryText);
		//deleting the widgets mapping from DASHBOARD_WIDGET table
		deleteDashboardWidget(dashboardId);
	}

	@Override
	public void updateDashboard(DashboardRequest dashboardRequest, String dashboardId) {
		String userId = getUserId();
		checkDashboardAuthorization(dashboardId, userId);
		Timestamp modified = new Timestamp(System.currentTimeMillis());
		checkValidJsonInMetadata(dashboardRequest.getMetadata());
		Dashboard dashboard = SRCMapper.getDashboard(dashboardRequest);
		dashboard.setModified(modified);
		dashboard.setId(dashboardId);
		dashboard.setIsPublic(false);
		String qryText = CatalogAPIQuery.UPDATE_DASHBOARD;
		qryText = qryText + " AND OWNER_ID= '" + userId + "';";
		String srcSql = parseQuery(Dashboard.class, dashboard, qryText);
		executeDML(srcSql);
		if (dashboardRequest.getTags() != null) {
			removeExistingTagsForEntity(dashboardId, ColumnConstant.DASHBOARD);
			for (TagRequest tag : dashboardRequest.getTags())
				saveNewTagAndTagRelation(tag, dashboard.getId(), ColumnConstant.DASHBOARD);
		}
	}

	@Override
	public List<DashboardWidgetDto> getDashboardWidgetDto(String dashboardId) {
		String qryText = CatalogAPIQuery.GET_DASHBOARDWIDGET;
		qryText += " WHERE DASHBOARD_ID ='" + dashboardId + "';";
		List<Map<String, Object>> dashboardWidgetList = getPlatformEntitiesData(qryText);
		return getDashboardWidgetDtoData(dashboardWidgetList);
	}

	private List<DashboardWidgetDto> getDashboardWidgetDtoData(List<Map<String, Object>> dashboardWidgetList) {
		List<DashboardWidgetDto> dashboardListDetails = new ArrayList<>();
		for (Map<String, Object> dashboradWidgetMap : dashboardWidgetList) {
			DashboardWidgetDto dashboardWidget = SRCMapper.getDashboardWidgetDto(dashboradWidgetMap);
			dashboardListDetails.add(dashboardWidget);
		}
		return dashboardListDetails;
	}

	@Override
	public void saveDashboardWidget(String dashboardId, List<DashboardWidgetRequest> dashboardWidgetsRequests)
			throws Exception {
		for (DashboardWidgetRequest dashboardWidgetRequest : dashboardWidgetsRequests) {
			String widgetId = dashboardWidgetRequest.getWidgetId();
			List<WidgetDto> widget = widgetDAO.getWidgetById(widgetId, false);
			if (widget.isEmpty())
				throw new AppException(MessageEnum.WIDGET_NOT_FOUND, dashboardWidgetRequest.getWidgetId());
			DashboardWidget dashboardWidget = new DashboardWidget();
			dashboardWidget.setDashboardId(dashboardId);
			dashboardWidget.setWidgetId(widgetId);
			checkValidJsonInMetadata(dashboardWidgetRequest.getMetadata());
			dashboardWidget.setMetadata(dashboardWidgetRequest.getMetadata());

			// checking if dashboard is already publish then added widget should
			// automatically publish with randomly generated slug.
			List<DashboardDto> dashboardList = getDashboardById(dashboardId);
			DashboardDto dashboardDto = dashboardList.isEmpty() ? null : dashboardList.get(0);
			if (dashboardDto.getIsPublic())
				widgetDAO.publishWidget(widgetId,null);

			String srcSql = parseQuery(DashboardWidget.class, dashboardWidget, CatalogAPIQuery.CREATE_DASHBOARD_WIDGET);
			executeDML(srcSql);
		}
	}

	@Override
	public void updateDashboardWidget(List<DashboardWidgetRequest> dashboardWidgetRequests, String dashboardId)
			throws Exception {
		for (DashboardWidgetRequest dashboardWidgetRequest : dashboardWidgetRequests) {
			String widgetId = dashboardWidgetRequest.getWidgetId();
			List<WidgetDto> widget = widgetDAO.getWidgetById(widgetId, false);
			if (widget.isEmpty())
				throw new AppException(MessageEnum.WIDGET_NOT_FOUND, dashboardWidgetRequest.getWidgetId());
		}
		deleteDashboardWidget(dashboardId);
		saveDashboardWidget(dashboardId, dashboardWidgetRequests);
	}

	@Override
	public void deleteDashboardWidget(String dashboardId) {
		String qryText = CatalogAPIQuery.DELETE_DASHBOARD_WIDGET;
		qryText = qryText + " WHERE DASHBOARD_ID='" + dashboardId + "';";
		executeDML(qryText);
	}

	@Override
	public void publishDashboard(String id, String requestSlug) throws Exception {
		String userId = getUserId();
		// Authorization: fail if the OWNER_ID doesn’t match the user claim of the
		// access token
		checkDashboardAuthorization(id, userId);
		List<DashboardDto> dashboardList = getDashboardById(id);
		DashboardDto dashboard = dashboardList.isEmpty() ? null : dashboardList.get(0);

		if (dashboard.getIsPublic() && requestSlug.equals(dashboard.getSlug())) {
			// Scenario 2 - Dashboard already published (ISPUBLIC column is true)
			// checking slug for the associated Dashboard
			return;
		}
		validateSlugForDashboard(requestSlug);
		dashboard.setSlug(requestSlug);
		getDashboardWidgetThenPublish(id, requestSlug);
		publishDashboard(dashboard, id);
	}

	@Override
	public List<DashboardDto> getDashboardById(String dashboardId) {
		String userId = getUserId();
		String qryText = CatalogAPIQuery.GET_DASHBOARD;
		List<String> filters = new ArrayList<>();
		filters.add("OWNER_ID = '" + userId + "'");
		// filtering by dashboardId
		if (dashboardId != null) {
			filters.add("ID = '" + dashboardId + "'");
		}
		qryText += " WHERE " + String.join(" AND ", filters) + " ORDER BY MODIFIED DESC";
		List<Map<String, Object>> dashboardMapList = getPlatformEntitiesData(qryText);
		return getDashboardData(dashboardMapList);
	}

	private void checkDashboardAuthorization(String dashboardId, String userId) {
		String qryText = CatalogAPIQuery.GET_DASHBOARD_COUNT;
		List<String> filters = new ArrayList<>();
		filters.add("OWNER_ID = '" + userId + "'");
		filters.add("ID = '" + dashboardId + "'");
		qryText += " WHERE " + String.join(" AND ", filters);
		int totalRecords = getTotalRecords(qryText);
		if (totalRecords == 0)
			throw new AppException(MessageEnum.BADREQUEST);

	}

	private List<DashboardDto> getDashboardData(List<Map<String, Object>> dashboardList) {
		List<DashboardDto> dashboardListDetails = dashboardList.stream()
				.map(sq -> SRCMapper.mapDashboardData(sq,
						getTagRelationByEntityId((String) sq.get(ColumnConstant.ID), ColumnConstant.DASHBOARD)))
				.collect(Collectors.toList());
		return dashboardListDetails;
	}

	private void getDashboardWidgetThenPublish(String id, String requestSlug) throws Exception {
		List<DashboardWidget> dashboardWidgetList = getDashboardWidget(id);

		for (DashboardWidget dashboardWidget : dashboardWidgetList) {
			// iterating each widget for dashboard and publishing it
			String widgetId = dashboardWidget.getWidgetId();
			Widget widget = getWidget(widgetId).isEmpty() ? null : getWidget(widgetId).get(0);
			if (widget != null && !widget.getIsPublic()) {
				
				widgetDAO.publishWidget(widget.getId(), null);
			}
		}
	}

	public List<Widget> getWidget(String widgetId) {
		String userId = getUserId();
		String qryText = CatalogAPIQuery.GET_WIDGET;
		List<String> filters = new ArrayList<>();
		filters.add("OWNER_ID = '" + userId + "'");
		// filtering by widgetId
		if (widgetId != null) {
			filters.add("ID = '" + widgetId + "'");
		}
		qryText += " WHERE " + String.join(" AND ", filters) + " ORDER BY MODIFIED DESC";
		List<Map<String, Object>> widgetList = getPlatformEntitiesData(qryText);
		return getWidgetData(widgetList);
	}

	private List<Widget> getWidgetData(List<Map<String, Object>> widgetList) {
		List<Widget> widgetListDetails = new ArrayList<>();
		for (Map<String, Object> widgetMap : widgetList) {
			Widget widget = SRCMapper.getwidget(widgetMap);
			widgetListDetails.add(widget);
		}
		return widgetListDetails;
	}

	public List<DashboardWidget> getDashboardWidget(String dashboardId) {
		String userId = getUserId();
		checkDashboardAuthorization(dashboardId, userId);
		String qryText = CatalogAPIQuery.GET_DASHBOARDWIDGET;
		qryText += " WHERE DASHBOARD_ID ='" + dashboardId + "';";
		List<Map<String, Object>> dashboardWidgetMapList = getPlatformEntitiesData(qryText);
		return getDashboardWidgetData(dashboardWidgetMapList);

	}

	private List<DashboardWidget> getDashboardWidgetData(List<Map<String, Object>> dashboardWidgetMapList) {
		List<DashboardWidget> dashboardWidgetList = new ArrayList<>();
		for (Map<String, Object> dashboradWidgetMap : dashboardWidgetMapList) {
			DashboardWidget dashboardWidget = SRCMapper.getDashboardWidget(dashboradWidgetMap);
			dashboardWidgetList.add(dashboardWidget);
		}
		return dashboardWidgetList;
	}

	public static DashboardWidget getDashboardWidget(Map<String, Object> dashboardWidgetMap) {
		DashboardWidget dashboardWidget = new DashboardWidget();
		dashboardWidget.setDashboardId((String) dashboardWidgetMap.get(ColumnConstant.DASHBOARD_ID));
		dashboardWidget.setWidgetId((String) dashboardWidgetMap.get(ColumnConstant.WIDGETID));
		dashboardWidget.setMetadata((String) dashboardWidgetMap.get(ColumnConstant.METADATA));
		return dashboardWidget;
	}

	private void validateSlugForDashboard(String requestSlug) {
		if (StringUtils.isAllBlank(requestSlug))
			throw new AppException(MessageEnum.BADREQUEST);

		String qryText = CatalogAPIQuery.GET_DASHBOARD_COUNT;
		qryText += " WHERE SLUG='" + requestSlug + "';";
		int totalRecords = getTotalRecords(qryText);
		if (totalRecords != 0)
			throw new AppException(MessageEnum.SLUG_ALREADY_EXIST);
	}

	public void publishDashboard(DashboardDto dashboard, String dashboardId) {
		Timestamp modified = new Timestamp(System.currentTimeMillis());
		dashboard.setModified(modified);
		dashboard.setIsPublic(true);
		dashboard.setId(dashboardId);
		String qryText = CatalogAPIQuery.PUBLISH_DASHBOARD;
		String srcSql = parseQuery(DashboardDto.class, dashboard, qryText);
		executeDML(srcSql);
		logger.info("Dashboard published");
	}

	@Override
	public String forkDashboard(String slug) throws Exception {

		String qryText = CatalogAPIQuery.GET_DASHBOARD;
		// filtering by slug
		qryText += " WHERE SLUG = '" + slug + "';";
		List<Map<String, Object>> dashboardMapList = getPlatformEntitiesData(qryText);
		DashboardDto dashboard = getDashboardData(dashboardMapList).isEmpty() ? null
				: getDashboardData(dashboardMapList).get(0);

		if (dashboard == null)
			throw new AppException(MessageEnum.SLUG_NOT_FOUND);
		// checking the ISPUBLIC flag is false (only publicly-available widgets can be
		// forked)
		if (!dashboard.getIsPublic())
			throw new AppException(MessageEnum.BADREQUEST);

		Dashboard forkDashboard = forkDashboard(dashboard);
		return forkDashboard.getId();
	}

	private Dashboard forkDashboard(DashboardDto dashboard) throws Exception {
		Dashboard forkedDashboard = new Dashboard();
		forkedDashboard.setIsPublic(false);
		forkedDashboard.setOwnerId(getUserId());
		forkedDashboard.setDashName(dashboard.getDashName() + CLONE);
		forkedDashboard.setDescription(dashboard.getDescription());
		forkedDashboard.setMetadata(dashboard.getMetadata());
		Timestamp modified = new Timestamp(System.currentTimeMillis());
		forkedDashboard.setModified(modified);
		forkedDashboard.setOwnerId(dashboard.getOwnerId());
		String newForkedDashboardId = UUID.randomUUID().toString();
		forkedDashboard.setId(newForkedDashboardId);

		String srcSql = parseQuery(Dashboard.class, forkedDashboard, CatalogAPIQuery.CREATE_DASHBOARD);
		executeDML(srcSql);
		// forking widget corresponding to the dashboard with new forked dashboard id
		forkDashboardWidget(newForkedDashboardId, dashboard.getId());

		return forkedDashboard;
	}

	private void forkDashboardWidget(String newForkedDashboardId, String dashboardId) throws Exception {
		List<DashboardWidget> dashboardWidgetList = getDashboardWidget(dashboardId);
		for (DashboardWidget dashboardWidget : dashboardWidgetList) {

			WidgetDto widget = widgetDAO.getWidgetById(dashboardWidget.getWidgetId(), false).isEmpty() ? null
					: widgetDAO.getWidgetById(dashboardWidget.getWidgetId(), false).get(0);
			String newForkedWidgetId = widgetDAO.processWidgetForking(widget);
			dashboardWidget.setDashboardId(newForkedDashboardId);
			dashboardWidget.setWidgetId(newForkedWidgetId);
			String srcSql = parseQuery(DashboardWidget.class, dashboardWidget, CatalogAPIQuery.CREATE_DASHBOARD_WIDGET);
			executeDML(srcSql);
		}
	}

	public List<DashboardDto> getDashboardById(String id, Boolean isPublic) {
		checkUserAuthorization(isPublic);
		String qryText = CatalogAPIQuery.GET_DASHBOARD;
		qryText += " WHERE ID = '" + id + "'";
		List<Map<String, Object>> dashboard = getPlatformEntitiesData(qryText);
		return getDashboardData(dashboard);
	}

	@Override
	public List<DashboardDto> getDashboardBySlug(String slug, Boolean isPublic) {
		checkUserAuthorization(isPublic);
		String qryText = CatalogAPIQuery.GET_DASHBOARD;
		qryText += " WHERE SLUG = '" + slug + "'";
		System.out.println(qryText);
		List<Map<String, Object>> dashboard = getPlatformEntitiesData(qryText);
		return getDashboardData(dashboard);
	}

}
