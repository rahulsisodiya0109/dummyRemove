package io.spaceandtime.routing.model;

public class DBCluster {

	public static final String CLUSTER_ID = "clusterId";
	public static final String ADDRESS = "address";
	public static final String USER = "username";
	public static final String PASSWORD = "password";

	private String clusterId;
	private String resourceId;
	private String address;
	private String username;
	private String password;

	public DBCluster(ThinClientInfo thinClient) {
		super();
		this.address = thinClient.getAddress();
		this.username = thinClient.getUsername();
		this.password = thinClient.getPassword();
	}

	public String getClusterId() {
		return clusterId;
	}

	public void setClusterId(String clusterId) {
		this.clusterId = clusterId;
	}

	public String getAddress() {
		return address;
	}

	public void setAddress(String address) {
		this.address = address;
	}

	public String getUsername() {
		return username;
	}

	public void setUsername(String username) {
		this.username = username;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public String getResourceId() {
		return resourceId;
	}

	public void setResourceId(String resourceId) {
		this.resourceId = resourceId;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((clusterId == null) ? 0 : clusterId.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		DBCluster other = (DBCluster) obj;
		if (clusterId == null) {
			if (other.clusterId != null)
				return false;
		} else if (!clusterId.equals(other.clusterId))
			return false;
		return true;
	}

}
