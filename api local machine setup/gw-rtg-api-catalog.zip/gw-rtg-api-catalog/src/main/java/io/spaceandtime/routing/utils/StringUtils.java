package io.spaceandtime.routing.utils;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashSet;
import java.util.List;

/**
 * 
 * @author Guvala
 *
 */
public class StringUtils {

	/**
	 * Return true if the string is empty or null
	 * 
	 * @param aStr
	 * @return boolean
	 */
	public static boolean isEmpty(String aStr) {
		if ((aStr == null) || (aStr.trim().length() == 0))
			return (true);
		return (false);
	}

	/**
	 * Take a collection of string separated by spaces, carriage return or commas,
	 * and return a list of String. Only convert the parameter String to uppercase
	 * if specified.
	 * 
	 * @param aStr
	 * @param toUpperCase
	 * @return List<String>
	 */
	public static List<String> parseMultipleValueString(String aStr, boolean toUpperCase) {
		if (isEmpty(aStr)) {
			return new ArrayList<String>();
		}

		if (toUpperCase) {
			aStr = aStr.toUpperCase();
		}

		String[] stringArray = aStr.trim().replaceAll("\\s", ",").split(",+");
		return Arrays.asList(stringArray);
	}

	/**
	 * Take a collection of string separated by spaces, carriage return or commas,
	 * and return a list of String. Only convert the parameter String to uppercase
	 * if specified. This method will remove any duplicates from the list
	 * 
	 * @param aStr
	 * @param toUpperCase
	 * @return List<String>
	 */
	public static List<String> parseMultipleValueStringToUniqueList(String aStr, boolean toUpperCase) {
		if (isEmpty(aStr)) {
			return new ArrayList<String>();
		}

		if (toUpperCase) {
			aStr = aStr.toUpperCase();
		}

		String[] stringArray = aStr.trim().replaceAll("\\s", ",").split(",+");
		return new ArrayList<String>(new HashSet<String>(Arrays.asList(stringArray)));
	}

	/**
	 * Take a collection of string separated by carriage return or commas, and
	 * return a list of String. Spaces will be ignored, as the actual value may
	 * contain a space. Only convert the parameter String to uppercase if specified.
	 * 
	 * @param aStr
	 * @param toUpperCase
	 * @return List<String>
	 */
	public static List<String> parseMultipleValueStringIgnoreSpace(String aStr, boolean toUpperCase) {
		if (isEmpty(aStr)) {
			return new ArrayList<String>();
		}

		if (toUpperCase) {
			aStr = aStr.toUpperCase();
		}

		String[] stringArray = aStr.trim().replaceAll("\r\n", ",").split(",+");
		return Arrays.asList(stringArray);
	}

	/**
	 * Take a collection of string separated by carriage return or commas, and
	 * return a list of String. Spaces will be ignored, as the actual value may
	 * contain a space. Only convert the parameter String to uppercase if specified.
	 * This method will remove any duplicates from the list
	 * 
	 * @param aStr
	 * @param toUpperCase
	 * @return List<String>
	 */
	public static List<String> parseMultipleValueStringToUniqueListIgnoreSpace(String aStr, boolean toUpperCase) {
		if (isEmpty(aStr)) {
			return new ArrayList<String>();
		}

		if (toUpperCase) {
			aStr = aStr.toUpperCase();
		}

		String[] stringArray = aStr.trim().replaceAll("\r\n", ",").split(",+");
		return new ArrayList<String>(new HashSet<String>(Arrays.asList(stringArray)));
	}

	/**
	 * Take a collection of string separated by commas only, and return a list of
	 * Strings. Only convert the parameter String to uppercase if specified.
	 * 
	 * @param aStr
	 * @param toUpperCase
	 * @return List<String>
	 */
	public static List<String> parseCommaDelimitedString(String aStr, boolean toUpperCase) {
		if (isEmpty(aStr)) {
			return new ArrayList<String>();
		}

		if (toUpperCase) {
			aStr = aStr.toUpperCase();
		}

		String[] stringArray = aStr.trim().split(",");
		return new ArrayList<String>(Arrays.asList(stringArray));
	}

	/**
	 * Take a collection of string separated by commas only, and return a list of
	 * Strings. Only convert the parameter String to uppercase if specified.
	 * 
	 * @param aStr
	 * @param toUpperCase
	 * @return List<String>
	 */
	public static List<String> parseCommaDelimitedString(String aStr) {
		if (isEmpty(aStr)) {
			return new ArrayList<String>();
		}

		String[] stringArray = aStr.trim().split(",");
		String[] trimmedArray = Arrays.stream(stringArray).map(String::trim).toArray(String[]::new);
		return new ArrayList<String>(Arrays.asList(trimmedArray));
	}

	/**
	 * Take a collection of string separated by commas only, and return a list of
	 * Strings. Only convert the parameter String to uppercase if specified.
	 * 
	 * @param aStr
	 * @param toUpperCase
	 * @return List<String>
	 */
	public static List<String> parseStringByDelimeter(String aStr, String delimeter) {
		if (isEmpty(aStr)) {
			return new ArrayList<String>();
		}

		String[] stringArray = aStr.trim().split(delimeter);
		String[] trimmedArray = Arrays.stream(stringArray).map(String::trim).toArray(String[]::new);
		return new ArrayList<String>(Arrays.asList(trimmedArray));
	}

	/**
	 * Convert a list of Strings into a single string object with each value
	 * separated by a comma
	 * 
	 * @param stringArray
	 * @return String
	 */
	public static String toCommaDelimitedString(List<String> stringArray) {
		return stringArray.toString().trim().replace("[", "").replace("]", "");
	}

	/**
	 * Convert a list of Strings into a single string object with each value
	 * separated by a comma seperated delimeter
	 * 
	 * @param stringArray
	 * @return String
	 */
	public static String getCommaSeparatedString(List<String> values) {
		StringBuilder value = new StringBuilder();
		if (values == null || values.isEmpty()) {
			return value.toString();
		}
		for (String vin : values) {
			value.append(vin);
			value.append(",");
		}
		return value.substring(0, value.lastIndexOf(","));
	}

	/**
	 * Convert a list of Strings into a single string object with each value
	 * separated by a specified delimiter passed as a parameter
	 * 
	 * @param stringArray
	 * @return String
	 */
	public static String getDelimeterSeparatedIntegers(List<Integer> values, String delimeter) {
		StringBuilder value = new StringBuilder();
		if (values == null || values.isEmpty()) {
			return value.toString();
		}
		for (Integer vin : values) {
			value.append(vin);
			value.append(delimeter);
		}
		return value.substring(0, value.lastIndexOf(delimeter));
	}

	/**
	 * Take a collection of string separated by carriage return or commas, parses
	 * the string and returns true if a value exceeds the max size. Spaces will be
	 * ignored in parsing, as the actual value may contain a space.
	 * 
	 * @param aString
	 * @param maxSize
	 * @return true if a value exceeds max size else returns false
	 */
	public static boolean exceedsSizeIgnoreSpace(String aString, int maxSize) {
		boolean exceedsSize = false;
		List<String> values = (ArrayList<String>) parseMultipleValueStringIgnoreSpace(aString, true);
		for (String value : values) {
			if (value.length() > maxSize) {
				exceedsSize = true;
			}
		}

		return exceedsSize;

	}

	/**
	 * Take a collection of string separated by carriage return or commas, parses
	 * the string and returns true if a value exceeds the max size.
	 * 
	 * @param aString
	 * @param maxSize
	 * @return true if a value exceeds max size else returns false
	 */
	public static boolean exceedsSize(String aString, int maxSize) {
		boolean exceedsSize = false;
		List<String> values = parseMultipleValueString(aString, true);
		for (String value : values) {
			if (value.length() > maxSize) {
				exceedsSize = true;
			}
		}

		return exceedsSize;

	}

	public static String trim(String aString) {
		if (StringUtils.isEmpty(aString))
			return (new String());
		return (aString.trim());
	}

	public static String toLowerCase(String aString) {
		if (StringUtils.isEmpty(aString))
			return (new String());
		return (aString.trim().toLowerCase());
	}

	/**
	 * Verify string contains another string ignore case
	 * 
	 * @param str
	 * @param searchStr
	 * @return
	 */
	public static boolean containsIgnoreCase(String str, String searchStr) {
		if (str == null || searchStr == null) {
			return false;
		}
		int len = searchStr.length();
		int max = str.length() - len;
		for (int i = 0; i <= max; i++) {
			if (str.regionMatches(true, i, searchStr, 0, len)) {
				return true;
			}
		}
		return false;
	}

	/**
	 * Case in-sensitive find of the first index within a String ("aabaabaa", "B") =
	 * 2 ("aabaabaa", "ab") = 1
	 * 
	 * @param str
	 * @param searchStr
	 * @return
	 */
	public static int indexOfIgnoreCase(String str, String searchStr) {
		return indexOfIgnoreCase(str, searchStr, 0);
	}

	private static int indexOfIgnoreCase(String str, String searchStr, int startPos) {
		if (str == null || searchStr == null) {
			return -1;
		}
		if (startPos < 0) {
			startPos = 0;
		}
		int endLimit = (str.length() - searchStr.length()) + 1;
		if (startPos > endLimit) {
			return -1;
		}
		if (searchStr.length() == 0) {
			return startPos;
		}
		for (int i = startPos; i < endLimit; i++) {
			if (str.regionMatches(true, i, searchStr, 0, searchStr.length())) {
				return i;
			}
		}
		return -1;
	}

	/**
	 * Finds the n-th index within a String ("aabaabaa", "ab", 1) = 1 ("aabaabaa",
	 * "ab", 2) = 4
	 * 
	 * @param str
	 * @param searchStr
	 * @param ordinal
	 * @return
	 */
	public static int ordinalIndexOf(String str, String searchStr, int ordinal) {
		return ordinalIndexOf(str, searchStr, ordinal, false);
	}

	/**
	 * Finds the n-th last index within a String ("aabaabaa", "a", 1) = 7
	 * ("aabaabaa", "a", 2) = 6
	 * 
	 * @param str
	 * @param searchStr
	 * @param ordinal
	 * @return
	 */
	public static int lastOrdinalIndexOf(String str, String searchStr, int ordinal) {
		return ordinalIndexOf(str, searchStr, ordinal, true);
	}

	private static int ordinalIndexOf(String str, String searchStr, int ordinal, boolean lastIndex) {
		if (str == null || searchStr == null || ordinal <= 0) {
			return -1;
		}
		if (searchStr.length() == 0) {
			return lastIndex ? str.length() : 0;
		}
		int found = 0;
		int index = lastIndex ? str.length() : -1;
		do {
			if (lastIndex) {
				index = str.lastIndexOf(searchStr, index - 1);
			} else {
				index = str.indexOf(searchStr, index + 1);
			}
			if (index < 0) {
				return index;
			}
			found++;
		} while (found < ordinal);
		return index;
	}

	/**
	 * Searches a String for substrings delimited by a start and end tag, returning
	 * all matching substrings in an array. ("[a][b][c]", "[", "]") = ["a","b","c"]
	 */
	public static String[] substringsBetween(String str, String open, String close) {
		if (str == null || isEmpty(open) || isEmpty(close)) {
			return null;
		}
		int strLen = str.length();
		if (strLen == 0) {
			return new String[0];
		}
		int closeLen = close.length();
		int openLen = open.length();
		List<String> list = new ArrayList<String>();
		int pos = 0;
		while (pos < (strLen - closeLen)) {
			int start = str.indexOf(open, pos);
			if (start < 0) {
				break;
			}
			start += openLen;
			int end = str.indexOf(close, start);
			if (end < 0) {
				break;
			}
			list.add(str.substring(start, end));
			pos = end + closeLen;
		}
		if (list.isEmpty()) {
			return null;
		}
		return (String[]) list.toArray(new String[list.size()]);
	}

	/**
	 * Gets the substring before the first occurrence of a separator
	 * 
	 * @param str
	 * @param separator
	 * @return
	 */
	public static String substringBefore(String str, String separator) {
		if (isEmpty(str) || separator == null) {
			return str;
		}
		if (separator.length() == 0) {
			return "";
		}
		int pos = str.indexOf(separator);
		if (pos == -1) {
			return str;
		}
		return str.substring(0, pos);
	}

	public static String replaceIgnoreCase(final String text, final String searchString, final String replacement) {
		return org.apache.commons.lang3.StringUtils.replaceIgnoreCase(text, searchString, replacement);
	}

}
