package io.spaceandtime.routing.utils;

import com.fasterxml.jackson.annotation.JsonIgnore;

import io.spaceandtime.routing.security.Context;

public abstract class BaseRO {

	@JsonIgnore
	private String bearerToken;
	@JsonIgnore
	private String biscuit;
	@JsonIgnore
	private String publicKey;
	@JsonIgnore
	private String sqlCommandType;

	public abstract String getResourceId();

	public String getBearerToken() {
		return bearerToken;
	}

	public void setBearerToken(String bearerToken) {
		this.bearerToken = bearerToken;
	}

	public String getBiscuit() {
		return biscuit;
	}

	public void setBiscuit(String biscuit) {
		this.biscuit = biscuit;
	}

	public String getSqlCommandType() {
		return sqlCommandType;
	}

	public void setSqlCommandType(String sqlCommandType) {
		this.sqlCommandType = sqlCommandType;
	}

	public String getPublicKey() {
		return publicKey;
	}

	public void setPublicKey(String publicKey) {
		this.publicKey = publicKey;
	}

	public void updateContext(Context context) {
		setBearerToken(context.getBearerToken());
		setBiscuit(context.getBiscuit());
		setPublicKey(context.getPublicKey());
	}

}
