package io.spaceandtime.routing.errorHandler;

import javax.servlet.http.HttpServletRequest;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.client.HttpClientErrorException.BadRequest;
import org.springframework.web.method.HandlerMethod;

import io.spaceandtime.routing.constant.MessageEnum;
import io.spaceandtime.routing.logging.AppLogger;
import io.spaceandtime.routing.logging.Log;
import io.spaceandtime.routing.utils.AppBundle;
import io.spaceandtime.routing.utils.ErrorResponse;

/**
 * 
 * @author Guvvala
 *
 */
@ControllerAdvice
public class AppExceptionHandler {

	private static @Log AppLogger logger;

	@ExceptionHandler(Throwable.class)
	public @ResponseBody ResponseEntity<ErrorResponse> handleSQLException(Throwable th, HandlerMethod handlerMethod,
			HttpServletRequest request) {
		return buildErrorResponse(th, request);
	}

	/**
	 * handles the exception and construct the message
	 * 
	 */
	public ResponseEntity<ErrorResponse> buildErrorResponse(Throwable th, HttpServletRequest request) {
		logger.error(th, th);
		if (th instanceof AppException) {
			AppException appException = (AppException) th;
			ErrorResponse errorResponse = new ErrorResponse(appException.getMessageId(), appException.getMessageText());
			errorResponse.setInstance(request.getRequestURI());
			errorResponse.setType(appException.getStatus().name().toString());
			return new ResponseEntity<ErrorResponse>(errorResponse, appException.getStatus());
		} else if (th instanceof BadRequest) {
			ErrorResponse errorResponse = new ErrorResponse(MessageEnum.BADREQUEST.messageCode,
					AppBundle.getString(MessageEnum.BADREQUEST.bundleName, MessageEnum.BADREQUEST.messageCode));
			errorResponse.setInstance(request.getRequestURI());
			errorResponse.setType(MessageEnum.BADREQUEST.name().toString());
			return new ResponseEntity<ErrorResponse>(errorResponse, HttpStatus.BAD_REQUEST);
		} else {
			ErrorResponse errorResponse = new ErrorResponse(MessageEnum.UNEXPECTEDFAILURE.messageCode, AppBundle
					.getString(MessageEnum.UNEXPECTEDFAILURE.bundleName, MessageEnum.UNEXPECTEDFAILURE.messageCode));
			errorResponse.setInstance(request.getRequestURI());
			errorResponse.setType(MessageEnum.UNEXPECTEDFAILURE.name().toString());
			return new ResponseEntity<ErrorResponse>(errorResponse, HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}

}