package io.spaceandtime.routing.utils;

import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import org.apache.calcite.sql.SqlDelete;
import org.apache.calcite.sql.SqlInsert;
import org.apache.calcite.sql.SqlMerge;
import org.apache.calcite.sql.SqlNode;
import org.apache.calcite.sql.SqlUpdate;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class CustomCalciteDMLParser {
	private static final Logger LOG = LoggerFactory.getLogger(CustomCalciteDMLParser.class);

	public static RequestParserDto getData(final String query) throws SQLException {
		RequestParserDto requestDto = CommonParsingUtil.parse(query);

		final List<String> tables = extractTableNames(requestDto.getSqlNode());
		requestDto.setTableNames(tables);
		return requestDto;
	}

	public static List<String> extractTableNames(SqlNode sqlNode) {
		List<String> tables = new ArrayList<>();
		String tableName = null;

		switch (sqlNode.getKind()) {
		case INSERT:
			SqlInsert sqlInsertTable = (SqlInsert) sqlNode;
			tableName = sqlInsertTable.getTargetTable().toString();
			break;
		case DELETE:
			SqlDelete sqlDeleteTable = (SqlDelete) sqlNode;
			tableName = sqlDeleteTable.getTargetTable().toString();
			break;
		case UPDATE:
			SqlUpdate sqlUpdateTable = (SqlUpdate) sqlNode;
			tableName = sqlUpdateTable.getTargetTable().toString();
			break;
		case MERGE:
			SqlMerge sqlMergeTable = (SqlMerge) sqlNode;
			tableName = sqlMergeTable.getTargetTable().toString();
			break;
		default:
			break;
		}

		if (tableName != null) {
			tables.add(CommonParsingUtil.getTargetResource(tableName));
		}

		LOG.info("Extracted tables size: {}", tables.size());
		LOG.info("Extracted tables: {}", tables);

		return tables;
	}

}
