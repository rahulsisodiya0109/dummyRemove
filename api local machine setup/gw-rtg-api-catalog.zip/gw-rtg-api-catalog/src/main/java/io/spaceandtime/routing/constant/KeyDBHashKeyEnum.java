package io.spaceandtime.routing.constant;

public enum KeyDBHashKeyEnum {
	
	SXT_CLUSTER_ADRRESS("ptcp:prov:dw:src:addr"), 
	DATA_WAREHOUSE_ADDRESS("ptcp:prov:dw:addr"), 
	USER_CLUSTER_AFFINITY("ptcp:user:dw:af"), 
	NAMESPACE_ASSETS("rsrc:db:ns:asst"), 
	NAMESPACE("rsrc:db:ns"), 
	DB_OBJECT_ASSIGNMENT("rsrc:db:asgn"), 
	DYNAMIC_DB_OBJECT_MAPPING("rsrc:db:map"), 
	DB_OBJECT_COLLECTION("rsrc:db:all"), 
	DATA_WAREHOUSE_ASSETS("ptcp:prov:dw:asst"),
	DATA_WAREHOUSE("ptcp:prov:dw"),
	DB_OBJECT("rsrc:db:obj"),
	TABLE("rsrc:db:tbl"),
	READ_ONLY_RESOURCE("rsrc:db:read"),
	DB_OBJECT_VIEW("rsrc:db:view"),
	DB_OBJECT_VIEW_ALL_COLLECTION("rsrc:db:view:all"),
	USERS("ptcp:user"),
	BLOCKCHAIN_REFLECTION_TABLE("rsrc:br:tbl"),
	TABLE_ANCHOR_STAMP("pf:ta:stmp"),
	ORGANIZATION("ptcp:org"),
	ORGANIZATION_GROUP("ptcp:org:grp"),
	QUERY_LOG("st:log:user"),
	TABLE_REALATION_CACHE("rsrc:db:tbl:cache"),;

	public final String hashKey;


	KeyDBHashKeyEnum(String hashKey) {
		this.hashKey = hashKey;
	}


}
