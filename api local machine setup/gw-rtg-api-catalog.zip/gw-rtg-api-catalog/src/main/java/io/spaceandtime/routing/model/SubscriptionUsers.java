package io.spaceandtime.routing.model;

import java.util.ArrayList;
import java.util.List;

import io.spaceandtime.storage.subscription.SubscriptionUserRoles;

public class SubscriptionUsers {
	private List<String> users;	

	public SubscriptionUsers(){}
	public SubscriptionUsers(SubscriptionUserRoles userRoles) {
		if (userRoles == null || userRoles.isEmpty()) {
			users = new ArrayList<>();
		} else {
			users = new ArrayList<>(userRoles.getMap().keySet());
		}
	}

	public List<String> getUsers() {
		return users;
	}

	public void setUsers(List<String> users) {
		this.users = users;
	}
}
