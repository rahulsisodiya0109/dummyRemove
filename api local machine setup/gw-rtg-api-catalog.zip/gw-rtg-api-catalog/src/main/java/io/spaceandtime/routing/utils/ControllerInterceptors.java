package io.spaceandtime.routing.utils;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.util.StopWatch;
import org.springframework.web.method.HandlerMethod;
import org.springframework.web.servlet.HandlerInterceptor;

import io.spaceandtime.routing.constant.EnvironmentConstant;
import io.spaceandtime.routing.security.Context;

public class ControllerInterceptors implements HandlerInterceptor {

	private static final String BISCUIT = "biscuit";
	private static final String AUTHORIZATION = "Authorization";
	private static final String BEARER = "Bearer ";
	private static final String EMPTY = "";

	public static final Logger log = LoggerFactory.getLogger(HandlerInterceptor.class);

	@Value(EnvironmentConstant.GATEWAY_SECURITY_PUBLICKEY)
	private String gatewayPublicKey;

	@Override
	public boolean preHandle(HttpServletRequest request, HttpServletResponse response, Object handler)
			throws Exception {
		ThreadLocalUtil.init();
		if (handler instanceof HandlerMethod) {
			StopWatch stopWatch = new StopWatch(request.getRequestURI());
			stopWatch.start(request.getRequestURI());
			String accessToken = getBearerToken(request.getHeader(AUTHORIZATION));
			String biscuit = request.getHeader(BISCUIT);
			Context context = new Context(accessToken, biscuit);
			context.setPublicKey(gatewayPublicKey);
			loadThreadLocalUtils(context);
			stopWatch.stop();
			log.info(stopWatch.shortSummary());
		}
		return true;
	}

	private static String getBearerToken(String accessToken) {
		if (StringUtils.isEmpty(accessToken)) {
			return accessToken;
		}
		return accessToken.replace(BEARER, EMPTY);
	}

	public static void loadThreadLocalUtils(Context context) {
		ThreadLocalUtil.setThreadVariable(ThreadLocalUtil.CURRENT_CONTEXT, context);
		ThreadLocalUtil.setThreadVariable(ThreadLocalUtil.USER_ID, context.getUserId());
	}

}