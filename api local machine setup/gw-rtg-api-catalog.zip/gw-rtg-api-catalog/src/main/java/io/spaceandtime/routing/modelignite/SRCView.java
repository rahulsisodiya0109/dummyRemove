package io.spaceandtime.routing.modelignite;

import java.sql.Timestamp;

import com.fasterxml.jackson.annotation.JsonProperty;

public class SRCView {

	@JsonProperty("id")
	private String id;

	@JsonProperty("catalogId")
	private String catalogId;

	@JsonProperty("schemaId")
	private String schemaId;

	@JsonProperty("viewName")
	private String viewName;

	@JsonProperty("ownerId")
	private String ownerId;

	@JsonProperty("description")
	private String description;

	@JsonProperty("viewText")
	private String viewText;

	@JsonProperty("resourceId")
	private String resourceId;

	@JsonProperty("isPublic")
	private Boolean isPublic;

	@JsonProperty("parameters")
	private String parameters;

	@JsonProperty("modified")
	private Timestamp modified;

	public String getViewName() {
		return viewName;
	}

	public void setViewName(String viewName) {
		this.viewName = viewName;
	}

	public String getOwnerId() {
		return ownerId;
	}

	public void setOwnerId(String ownerId) {
		this.ownerId = ownerId;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public String getViewText() {
		return viewText;
	}

	public void setViewText(String viewText) {
		this.viewText = viewText;
	}

	public String getResourceId() {
		return resourceId;
	}

	public void setResourceId(String resourceId) {
		this.resourceId = resourceId;
	}

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public String getCatalogId() {
		return catalogId;
	}

	public void setCatalogId(String catalogId) {
		this.catalogId = catalogId;
	}

	public String getSchemaId() {
		return schemaId;
	}

	public void setSchemaId(String schemaId) {
		this.schemaId = schemaId;
	}

	public Boolean getIsPublic() {
		return isPublic;
	}

	public void setIsPublic(Boolean isPublic) {
		this.isPublic = isPublic;
	}

	public String getParameters() {
		return parameters;
	}

	public void setParameters(String parameters) {
		this.parameters = parameters;
	}

	public Timestamp getModified() {
		return modified;
	}

	public void setModified(Timestamp modified) {
		this.modified = modified;
	}

}
