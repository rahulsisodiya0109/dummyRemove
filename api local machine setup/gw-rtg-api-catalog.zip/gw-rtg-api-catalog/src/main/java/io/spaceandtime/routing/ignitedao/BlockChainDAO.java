package io.spaceandtime.routing.ignitedao;

import java.util.List;

import io.spaceandtime.routing.model.BlockChainDto;
import io.spaceandtime.routing.model.NamespacesDto;

public interface BlockChainDAO {

	List<BlockChainDto> getBlockchains();

	List<NamespacesDto> getNamespaces(String chainId);

}
