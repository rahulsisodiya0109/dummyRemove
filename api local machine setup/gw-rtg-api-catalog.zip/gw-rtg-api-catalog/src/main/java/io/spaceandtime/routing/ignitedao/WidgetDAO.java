package io.spaceandtime.routing.ignitedao;

import java.util.List;

import io.spaceandtime.routing.constant.SortOrderEnum;
import io.spaceandtime.routing.constant.StatusEnum;
import io.spaceandtime.routing.constant.WidgetTypeEnum;
import io.spaceandtime.routing.model.WidgetDto;
import io.spaceandtime.routing.ro.WidgetRequest;
import io.spaceandtime.routing.utils.Page;

public interface WidgetDAO {

	String createWidget(WidgetRequest widget);

	void updateWidget(String widgetsId, WidgetRequest widgetRequest);

	void deleteWidget(String widgetsId);

	List<WidgetDto> getWidgetById(String widgetId, Boolean isPublic);

	Page<WidgetDto> getAllWidgets(Boolean isPublic, String viewId, String searchKeyword, int pageNo, int pageSize,
			SortOrderEnum sortOrder, String sortBy, WidgetTypeEnum widgetTypeEnum, String tagId, StatusEnum status);

	void publishWidget(String id, String slug) throws Exception;

	String forkWidget(String slug) throws Exception;

	void checkWidgetAuthorization(String widgetId, String userId);

	String processWidgetForking(WidgetDto widget) throws Exception;

}
