package io.spaceandtime.routing.query;

import java.util.HashMap;
import java.util.Map;



public enum DBQueryLimitEnum {
	
	
	MARIA("Maria", " LIMIT {0}, {1}"," ORDER BY {0} LIMIT {1},{2}"),
	MYSQL("MySQL", " LIMIT {0}, {1}"," ORDER BY {0} LIMIT {1},{2}"), 
	SQL_SERVER("SQLServer", " OFFSET {0} ROWS FETCH NEXT {1}  ROWS ONLY"," ORDER BY {0} OFFSET {1} ROWS FETCH NEXT {2}  ROWS ONLY"),
	POSTGRESS("Postgress"," LIMIT {0} OFFSET {1}"," ORDER BY {0} LIMIT {1} OFFSET {2}");

	public final String db;
	public final String limit;
	public final String nolimit;

	private static final Map<String, DBQueryLimitEnum> dialects = new HashMap<>();

	static {
		for (DBQueryLimitEnum constant : DBQueryLimitEnum.class.getEnumConstants()) {
			dialects.put(constant.db, constant);
		}
	}

	DBQueryLimitEnum(final String key, final String limit,final String nolimit) {
		this.db = key;
		this.limit = limit;
		this.nolimit=nolimit;
		
	}
	
	public static DBQueryLimitEnum findLimit(String key) {
		return dialects.get(key);
	}

}
