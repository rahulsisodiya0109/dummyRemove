package io.spaceandtime.routing.modelignite;

import java.sql.Timestamp;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonProperty;

public class SRCTable {

	@JsonIgnore
	private String id;

	@JsonProperty("table")
	private String tableId;

	@JsonProperty("namespace")
	private String schemaId;

	@JsonIgnore
	private String catalogId;

	@JsonIgnore
	private String size;

	@JsonProperty("publicKey")
	private String publicKey;

	@JsonProperty("immutable")
	private Boolean immutable;

	@JsonProperty("accessType")
	private String accessType;

	@JsonIgnore
	private String orgId;

	@JsonProperty("encrypted")
	private Boolean encrypted;

	@JsonProperty("tamperproof")
	private Boolean tamperproof;

	@JsonProperty("lastAnchored")
	private Timestamp created;

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public String getTableId() {
		return tableId;
	}

	public void setTableId(String tableId) {
		this.tableId = tableId;
	}

	public String getSchemaId() {
		return schemaId;
	}

	public void setSchemaId(String schemaId) {
		this.schemaId = schemaId;
	}

	public String getCatalogId() {
		return catalogId;
	}

	public void setCatalogId(String catalogId) {
		this.catalogId = catalogId;
	}

	public String getSize() {
		return size;
	}

	public void setSize(String size) {
		this.size = size;
	}

	public String getPublicKey() {
		return publicKey;
	}

	public void setPublicKey(String publicKey) {
		this.publicKey = publicKey;
	}

	public Boolean getImmutable() {
		return immutable;
	}

	public void setImmutable(Boolean immutable) {
		this.immutable = immutable;
	}

	public String getAccessType() {
		return accessType;
	}

	public void setAccessType(String accessType) {
		this.accessType = accessType;
	}

	public String getOrgId() {
		return orgId;
	}

	public void setOrgId(String orgId) {
		this.orgId = orgId;
	}

	public Boolean getEncrypted() {
		return encrypted;
	}

	public void setEncrypted(Boolean encrypted) {
		this.encrypted = encrypted;
	}

	public Boolean getTamperproof() {
		return tamperproof;
	}

	public void setTamperproof(Boolean tamperproof) {
		this.tamperproof = tamperproof;
	}

	public Timestamp getCreated() {
		return created;
	}

	public void setCreated(Timestamp created) {
		this.created = created;
	}

}
