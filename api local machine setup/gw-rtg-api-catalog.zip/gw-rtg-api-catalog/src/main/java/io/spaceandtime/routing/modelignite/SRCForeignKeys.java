package io.spaceandtime.routing.modelignite;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonProperty;

public class SRCForeignKeys {

	@JsonIgnore
	private String id;

	@JsonProperty("pkColumn")
	private String pkColumnId;

	@JsonProperty("pkTable")
	private String pkTableId;

	@JsonProperty("pkNamespace")
	private String pkSchemaId;

	@JsonIgnore
	private String pkCatalogId;

	@JsonProperty("fkColumn")
	private String fkColumnId;

	@JsonProperty("fkTable")
	private String fkTableId;

	@JsonProperty("fkNamespace")
	private String fkSchemaId;

	@JsonIgnore
	private String fkCatalogId;

	@JsonProperty("sequence")
	private Integer sequence;

	@JsonProperty("cardinality")
	private String cardinality;

	@JsonIgnore
	private String orgId;

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public String getPkColumnId() {
		return pkColumnId;
	}

	public void setPkColumnId(String pkColumnId) {
		this.pkColumnId = pkColumnId;
	}

	public String getPkTableId() {
		return pkTableId;
	}

	public void setPkTableId(String pkTableId) {
		this.pkTableId = pkTableId;
	}

	public String getPkSchemaId() {
		return pkSchemaId;
	}

	public void setPkSchemaId(String pkSchemaId) {
		this.pkSchemaId = pkSchemaId;
	}

	public String getPkCatalogId() {
		return pkCatalogId;
	}

	public void setPkCatalogId(String pkCatalogId) {
		this.pkCatalogId = pkCatalogId;
	}

	public String getFkColumnId() {
		return fkColumnId;
	}

	public void setFkColumnId(String fkColumnId) {
		this.fkColumnId = fkColumnId;
	}

	public String getFkTableId() {
		return fkTableId;
	}

	public void setFkTableId(String fkTableId) {
		this.fkTableId = fkTableId;
	}

	public String getFkSchemaId() {
		return fkSchemaId;
	}

	public void setFkSchemaId(String fkSchemaId) {
		this.fkSchemaId = fkSchemaId;
	}

	public String getFkCatalogId() {
		return fkCatalogId;
	}

	public void setFkCatalogId(String fkCatalogId) {
		this.fkCatalogId = fkCatalogId;
	}

	public Integer getSequence() {
		return sequence;
	}

	public void setSequence(Integer sequence) {
		this.sequence = sequence;
	}

	public String getCardinality() {
		return cardinality;
	}

	public void setCardinality(String cardinality) {
		this.cardinality = cardinality;
	}

	public String getOrgId() {
		return orgId;
	}

	public void setOrgId(String orgId) {
		this.orgId = orgId;
	}

}
