package io.spaceandtime.routing.controller.platformState;

import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import io.swagger.v3.oas.annotations.tags.Tag;

@RestController
@RequestMapping("/v1/state")
@Tag(name = "Plateform  State")
public class PlatformStateController {

}
