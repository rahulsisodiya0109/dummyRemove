package io.spaceandtime.routing.constant;

import java.util.ArrayList;
import java.util.List;

import io.spaceandtime.routing.errorHandler.AppException;
import io.spaceandtime.routing.utils.StringUtils;

public enum SqlOperationEnum {
	 
	CREATE("CREATE"), 
	ALTER("ALTER"),
	DROP("DROP"), 
	SELECT("SELECT"), 
	INSERT("INSERT"), 
	UPDATE("UPDATE"), 
	MERGE("MERGE"), 
	DELETE("DELETE");

	private String operationType;
	
	public static List<String> operationTypeList = new ArrayList<>();

	SqlOperationEnum(String string) {
		this.operationType = string;
	}

	static {
		for (SqlOperationEnum constant : SqlOperationEnum.class.getEnumConstants()) {
			operationTypeList.add(constant.operationType);
		}
	}

	public String getOperationType() {
		return operationType;
	}

	public void setOperationType(String operationType) {
		this.operationType = operationType;
	}

	public static List<String> getOperationTypeList() {
		return operationTypeList;
	}

	public static void setOperationTypeList(List<String> operationTypeList) {
		SqlOperationEnum.operationTypeList = operationTypeList;
	}

	public static void checkValidOperationType(String name) {
		if (StringUtils.isEmpty(name)||!operationTypeList.contains(name.toUpperCase())) {
			throw new AppException(MessageEnum.INVALID_SQLOPERATION, name);

		}
	}

}
