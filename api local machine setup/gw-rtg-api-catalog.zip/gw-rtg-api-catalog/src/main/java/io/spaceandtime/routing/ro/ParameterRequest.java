package io.spaceandtime.routing.ro;

import io.swagger.v3.oas.annotations.media.Schema;

public class ParameterRequest {
	@Schema(description  = "containing the view parameter name",example = "COUNT", required = false)
	private String name;
	@Schema(description  = "containing the view parameter type",example = "integer",  required = false)
	private String type;

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getType() {
		return type;
	}

	public void setType(String type) {
		this.type = type;
	}

}
