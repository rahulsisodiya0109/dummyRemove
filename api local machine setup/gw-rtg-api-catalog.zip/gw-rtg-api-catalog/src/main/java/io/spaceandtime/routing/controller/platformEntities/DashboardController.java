package io.spaceandtime.routing.controller.platformEntities;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import io.spaceandtime.routing.constant.ColumnConstant;
import io.spaceandtime.routing.constant.EnvironmentConstant;
import io.spaceandtime.routing.constant.MessageEnum;
import io.spaceandtime.routing.constant.SortOrderEnum;
import io.spaceandtime.routing.constant.StatusEnum;
import io.spaceandtime.routing.errorHandler.AppException;
import io.spaceandtime.routing.ignitedao.DashboardDAO;
import io.spaceandtime.routing.model.DashboardDto;
import io.spaceandtime.routing.model.DashboardWidgetDto;
import io.spaceandtime.routing.ro.DashboardRequest;
import io.spaceandtime.routing.ro.DashboardWidgetRequest;
import io.spaceandtime.routing.utils.ErrorResponse;
import io.spaceandtime.routing.utils.Page;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.media.ArraySchema;
import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.media.Schema;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.responses.ApiResponses;
import io.swagger.v3.oas.annotations.tags.Tag;

@RestController
@RequestMapping("/v1/content")
@Tag(name = "Dashboard API")
public class DashboardController {

	@Autowired
	private DashboardDAO dashboardDAO;

	@GetMapping("/dashboards")
	@Operation(summary = "Get dashboard", description = "Get dashboard list")
	@ApiResponses(value = {
			@ApiResponse(responseCode = "200", description = "${api.response-codes.ok.desc}", useReturnTypeSchema = true),
			@ApiResponse(responseCode = "401", description = "${api.response-codes.unauthorized.desc}", content = @Content(schema = @Schema(implementation = ErrorResponse.class))), })
	public Page<DashboardDto> getDashboard(@RequestParam(value = "isPublic", defaultValue = "false") Boolean isPublic,
			@RequestParam(value = "searchKeyword", required = false) String searchKeyword,
			@RequestParam(value = "tagId", required = false) String tagId,
			@RequestParam(value = "pageNo", defaultValue = "1") int pageNo,
			@RequestParam(value = "pageSize", defaultValue = EnvironmentConstant.PAGE_SIZE) int pageSize,
			@RequestParam(value = "sortOrder") SortOrderEnum sortOrder,
			@RequestParam(value = "status", defaultValue = ColumnConstant.ALL) StatusEnum status,
			@RequestParam(value = "sortBy", defaultValue = ColumnConstant.MODIFIED) String sortBy) {
		return dashboardDAO.getDashboard(isPublic, searchKeyword, pageNo, pageSize, sortOrder, sortBy, tagId, status);
	}

	@GetMapping("/dashboards/{id}")
	@Operation(summary = "Get dashboard by Id", description = "Get dashboard by id ")
	@ApiResponses(value = {
			@ApiResponse(responseCode = "200", description = "${api.response-codes.ok.desc}", content = @Content(array = @ArraySchema(schema = @Schema(implementation = DashboardDto.class)))),
			@ApiResponse(responseCode = "401", description = "${api.response-codes.unauthorized.desc}", content = @Content(schema = @Schema(implementation = ErrorResponse.class))),
			@ApiResponse(responseCode = "404", description = "${api.response-codes.notFound.desc}", content = @Content(schema = @Schema(implementation = ErrorResponse.class))) })
	public ResponseEntity<List<DashboardDto>> getDashboardById(@PathVariable String id,
			@RequestParam(value = "isPublic", defaultValue = "false") Boolean isPublic) {
		List<DashboardDto> dashboarDto = dashboardDAO.getDashboardById(id, isPublic);
		if (dashboarDto == null || dashboarDto.isEmpty()) {
			throw new AppException(MessageEnum.DASHBOARD_NOT_FOUND);
		}
		return ResponseEntity.ok().body(dashboarDto);
	}

	@GetMapping("/dashboards/slug/{slug}")
	@Operation(summary = "Get dashboard by  slug", description = "Get dashboard by slug")
	@ApiResponses(value = {
			@ApiResponse(responseCode = "200", description = "${api.response-codes.ok.desc}", content = @Content(array = @ArraySchema(schema = @Schema(implementation = DashboardDto.class)))),
			@ApiResponse(responseCode = "401", description = "${api.response-codes.unauthorized.desc}", content = @Content(schema = @Schema(implementation = ErrorResponse.class))), })
	public List<DashboardDto> getDashboardBySlug(@PathVariable String slug,
			@RequestParam(value = "isPublic", defaultValue = "false") Boolean isPublic) {
		List<DashboardDto> dashboarDto = dashboardDAO.getDashboardBySlug(slug, isPublic);
		return dashboarDto;
	}

	@PostMapping(value = "/dashboards")
	@Operation(summary = "Create dashboard", description = "Create a new dashboard")
	@ApiResponses(value = { @ApiResponse(responseCode = "201", description = "${api.response-codes.created.desc}"),
			@ApiResponse(responseCode = "401", description = "${api.response-codes.unauthorized.desc}", content = @Content(schema = @Schema(implementation = ErrorResponse.class))), })
	public ResponseEntity<String> add(@RequestBody DashboardRequest dashboardRequest) {
		String id = dashboardDAO.saveDashboard(dashboardRequest);
		return new ResponseEntity<>(id, HttpStatus.CREATED);
	}

	@PutMapping(path = "/dashboards/{id}")
	@Operation(summary = "Update dashboard", description = "Updates dashboard by id")
	@ApiResponses(value = { @ApiResponse(responseCode = "204", description = "${api.response-codes.noContent.desc}"),
			@ApiResponse(responseCode = "400", description = "${api.response-codes.badRequest.desc}", content = @Content(schema = @Schema(implementation = ErrorResponse.class))),
			@ApiResponse(responseCode = "401", description = "${api.response-codes.unauthorized.desc}", content = @Content(schema = @Schema(implementation = ErrorResponse.class))) })
	public ResponseEntity<Void> updateDashboard(@PathVariable String id, @RequestBody DashboardRequest dashboard) {
		dashboardDAO.updateDashboard(dashboard, id);
		return ResponseEntity.status(HttpStatus.NO_CONTENT).build();
	}

	@DeleteMapping(value = "/dashboards/{id}")
	@Operation(summary = "Delete dashboard", description = "Delete dashboard by id")
	@ApiResponses(value = {
			@ApiResponse(responseCode = "200", description = "${api.response-codes.ok.desc}", content = @Content(array = @ArraySchema(schema = @Schema(implementation = DashboardRequest.class)))),
			@ApiResponse(responseCode = "401", description = "${api.response-codes.unauthorized.desc}", content = @Content(schema = @Schema(implementation = ErrorResponse.class))),
			@ApiResponse(responseCode = "404", description = "${api.response-codes.notFound.desc}", content = @Content(schema = @Schema(implementation = ErrorResponse.class))) })
	public ResponseEntity<Void> delete(@PathVariable(required = true) String id) {
		dashboardDAO.deleteDashboard(id);
		return ResponseEntity.status(HttpStatus.NO_CONTENT).build();
	}

	@GetMapping(value = "/dashboards/{id}/widgets")
	@Operation(summary = "Get dashboard widgets", description = "Get dashboard widget list")
	@ApiResponses(value = {
			@ApiResponse(responseCode = "200", description = "${api.response-codes.ok.desc}", content = @Content(array = @ArraySchema(schema = @Schema(implementation = DashboardWidgetDto.class)))),
			@ApiResponse(responseCode = "401", description = "${api.response-codes.unauthorized.desc}", content = @Content(schema = @Schema(implementation = ErrorResponse.class))),
			@ApiResponse(responseCode = "404", description = "${api.response-codes.notFound.desc}", content = @Content(schema = @Schema(implementation = ErrorResponse.class))) })
	public List<DashboardWidgetDto> getDashboardWidget(@PathVariable(required = true) String id) {

		return dashboardDAO.getDashboardWidgetDto(id);
	}

	@PostMapping(value = "/dashboards/{id}/widgets")
	@Operation(summary = "Create DashboardWidget", description = "Create new dashboard widget")
	@ApiResponses(value = { @ApiResponse(responseCode = "201", description = "${api.response-codes.created.desc}"),
			@ApiResponse(responseCode = "401", description = "${api.response-codes.unauthorized.desc}", content = @Content(schema = @Schema(implementation = ErrorResponse.class))),
			@ApiResponse(responseCode = "404", description = "${api.response-codes.notFound.desc}", content = @Content(schema = @Schema(implementation = ErrorResponse.class))) })
	public ResponseEntity<String> addDashboardWidget(@PathVariable(required = true) String id,
			@RequestBody List<DashboardWidgetRequest> dashboardWidgetRequests) throws Exception {
		dashboardDAO.saveDashboardWidget(id, dashboardWidgetRequests);
		return new ResponseEntity<>(id, HttpStatus.CREATED);
	}

	@PutMapping(path = "/dashboards/{id}/widgets", consumes = { MediaType.APPLICATION_JSON_VALUE })
	@Operation(summary = "Update DashboardWidget", description = "Update dashboard widget by dashboard id.")
	@ApiResponses(value = { @ApiResponse(responseCode = "204", description = "${api.response-codes.noContent.desc}"),
			@ApiResponse(responseCode = "401", description = "${api.response-codes.unauthorized.desc}", content = @Content(schema = @Schema(implementation = ErrorResponse.class))),
			@ApiResponse(responseCode = "404", description = "${api.response-codes.notFound.desc}", content = @Content(schema = @Schema(implementation = ErrorResponse.class))) })
	public ResponseEntity<Void> updateDashboardWidget(@PathVariable(required = true) String id,
			@RequestBody List<DashboardWidgetRequest> dashboardWidgetRequests) throws Exception {
		dashboardDAO.updateDashboardWidget(dashboardWidgetRequests, id);
		return ResponseEntity.status(HttpStatus.NO_CONTENT).build();
	}

	@DeleteMapping(value = "/dashboards/{id}/widgets")
	@Operation(summary = "Delete DashboardWidget", description = "Delete dashboard widget by id.")
	@ApiResponses(value = { @ApiResponse(responseCode = "200", description = "${api.response-codes.ok.desc}"),
			@ApiResponse(responseCode = "400", description = "${api.response-codes.badRequest.desc}", content = @Content(schema = @Schema(implementation = ErrorResponse.class))),
			@ApiResponse(responseCode = "401", description = "${api.response-codes.unauthorized.desc}", content = @Content(schema = @Schema(implementation = ErrorResponse.class))) })
	public ResponseEntity<Void> deleteDashboardWidget(@PathVariable(required = true) String id) {
		dashboardDAO.deleteDashboardWidget(id);
		return ResponseEntity.status(HttpStatus.NO_CONTENT).build();
	}

///////////////////// publish - fork dashboard //////////////////////////////

	@PostMapping(value = "/dashboards/{id}/publish")
	@Operation(summary = "publish dashboards", description = "Publish  dashboards ")
	@ApiResponses(value = { @ApiResponse(responseCode = "201", description = "${api.response-codes.ok.desc}"),
			@ApiResponse(responseCode = "401", description = "${api.response-codes.unauthorized.desc}", content = @Content(schema = @Schema(implementation = ErrorResponse.class))),
			@ApiResponse(responseCode = "400", description = "${api.response-codes.badRequest.desc}", content = @Content(schema = @Schema(implementation = ErrorResponse.class))) })
	public ResponseEntity<Void> publishDashboard(@PathVariable(required = true) String id,
			@RequestParam(required = true) String slug) throws Exception {
		dashboardDAO.publishDashboard(id, slug);
		return ResponseEntity.status(HttpStatus.CREATED).build();
	}

	@PostMapping(value = "/dashboards/{slug}/fork")
	@Operation(summary = "Fork dashboards", description = "Fork a new dashboards ")
	@ApiResponses(value = {
			@ApiResponse(responseCode = "201", description = "${api.response-codes.created.desc}", content = @Content(array = @ArraySchema(schema = @Schema(implementation = String.class)))),
			@ApiResponse(responseCode = "401", description = "${api.response-codes.unauthorized.desc}", content = @Content(schema = @Schema(implementation = ErrorResponse.class))),
			@ApiResponse(responseCode = "400", description = "${api.response-codes.badRequest.desc}", content = @Content(schema = @Schema(implementation = ErrorResponse.class))) })

	public ResponseEntity<String> forkDashboard(@PathVariable(required = true) String slug) throws Exception {

		String dashboardId = dashboardDAO.forkDashboard(slug);
		return new ResponseEntity<>(dashboardId, HttpStatus.CREATED);
	}

}
