package io.spaceandtime.routing.security;

public class Context {

	private String bearerToken;
	private String biscuit;
	private String userId;
	private String publicKey;

	public Context(String bearerToken, String biscuit, String userId) {
		super();
		this.bearerToken = bearerToken;
		this.biscuit = biscuit;
		this.userId = userId;
	}

	public Context(String bearerToken, String biscuit) {
		this.bearerToken = bearerToken;
		this.biscuit = biscuit;
	}

	public String getBearerToken() {
		return bearerToken;
	}

	public void setBearerToken(String bearerToken) {
		this.bearerToken = bearerToken;
	}

	public String getBiscuit() {
		return biscuit;
	}

	public void setBiscuit(String biscuit) {
		this.biscuit = biscuit;
	}

	public String getUserId() {
		return userId;
	}

	public void setUserId(String userId) {
		this.userId = userId;
	}

	public String getPublicKey() {
		return publicKey;
	}

	public void setPublicKey(String publicKey) {
		this.publicKey = publicKey;
	}

}
