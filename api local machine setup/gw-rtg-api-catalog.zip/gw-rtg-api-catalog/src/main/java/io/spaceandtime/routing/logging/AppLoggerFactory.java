package io.spaceandtime.routing.logging;

import org.apache.logging.log4j.LogManager;

/**
 * 
 * @author Guvala
 *
 */
public class AppLoggerFactory {
	public static AppLogger getLogger(String name) {
		AppLogger logger = new AppLogger();
		logger.setLogger(LogManager.getLogger(name));
		return logger;
	}

}
