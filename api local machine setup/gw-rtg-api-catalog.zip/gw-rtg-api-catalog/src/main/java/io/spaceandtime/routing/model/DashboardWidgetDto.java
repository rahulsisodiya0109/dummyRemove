package io.spaceandtime.routing.model;

public class DashboardWidgetDto {

	private String dashboardId;

	private String widgetId;

	private String metadata;

	public String getDashboardId() {
		return dashboardId;
	}

	public void setDashboardId(String dashboardId) {
		this.dashboardId = dashboardId;
	}

	public String getWidgetId() {
		return widgetId;
	}

	public void setWidgetId(String widgetId) {
		this.widgetId = widgetId;
	}

	public String getMetadata() {
		return metadata;
	}

	public void setMetadata(String metada) {
		this.metadata = metada;
	}
}
