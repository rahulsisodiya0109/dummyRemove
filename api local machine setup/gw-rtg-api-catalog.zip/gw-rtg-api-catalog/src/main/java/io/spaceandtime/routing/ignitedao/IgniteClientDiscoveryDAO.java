package io.spaceandtime.routing.ignitedao;

import java.util.List;

import io.spaceandtime.routing.constant.ScopeEnum;
import io.spaceandtime.routing.model.TableRelationDto;
import io.spaceandtime.routing.modelignite.SRCForeignKeys;
import io.spaceandtime.routing.modelignite.SRCIndex;
import io.spaceandtime.routing.modelignite.SRCSchema;
import io.spaceandtime.routing.modelignite.SRCTable;
import io.spaceandtime.routing.modelignite.SRCTableColumns;

public interface IgniteClientDiscoveryDAO {

	List<SRCSchema> getSchemas(ScopeEnum scope);

	List<SRCTable> getTables(ScopeEnum scope, String namespace);

	List<SRCTableColumns> getTableColumns(String namespace, String table);

	List<SRCIndex> getIndex(String namespace, String table);

	List<SRCForeignKeys> getForeignKeyFromPrimarykey(String namespace, String table, String keyColumn);

	List<SRCForeignKeys> getPrimarykeyFromForeignKey(String namespace, String table, String keyColumn);

	List<SRCTableColumns> getTablesPrimarykey(String namespace, String table);

	List<TableRelationDto> getTableRelations(String namespace, ScopeEnum scope);

	Boolean isAuthorizationRequired(String resourceId, String operation);

}
