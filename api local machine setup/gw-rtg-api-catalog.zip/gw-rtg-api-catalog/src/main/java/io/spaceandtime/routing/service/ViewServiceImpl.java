package io.spaceandtime.routing.service;

import static io.spaceandtime.routing.constant.ColumnConstant.CLONE;

import java.sql.Timestamp;
import java.util.List;
import java.util.Map;
import java.util.UUID;

import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import io.spaceandtime.routing.constant.AccessTypeEnum;
import io.spaceandtime.routing.constant.ColumnConstant;
import io.spaceandtime.routing.constant.MessageEnum;
import io.spaceandtime.routing.constant.SortOrderEnum;
import io.spaceandtime.routing.constant.StatusEnum;
import io.spaceandtime.routing.errorHandler.AppException;
import io.spaceandtime.routing.ignitedao.ViewDAO;
import io.spaceandtime.routing.jdbcdao.BaseIgniteSqlDAOImpl;
import io.spaceandtime.routing.logging.AppLogger;
import io.spaceandtime.routing.logging.Log;
import io.spaceandtime.routing.mapper.KeyDBMapper;
import io.spaceandtime.routing.mapper.SRCMapper;
import io.spaceandtime.routing.model.SRCViewDto;
import io.spaceandtime.routing.modelignite.SRCTable;
import io.spaceandtime.routing.modelignite.SRCView;
import io.spaceandtime.routing.query.CatalogAPIQuery;
import io.spaceandtime.routing.ro.TagRequest;
import io.spaceandtime.routing.ro.ViewRequest;
import io.spaceandtime.routing.storage.IKeyDBProvider;
import io.spaceandtime.routing.utils.AppUtils;
import io.spaceandtime.routing.utils.CustomCalciteDQLParser;
import io.spaceandtime.routing.utils.Page;
import io.spaceandtime.routing.utils.RequestParserDto;
import io.spaceandtime.storage.database.DbView;

@Service
public class ViewServiceImpl extends BaseIgniteSqlDAOImpl implements ViewService {

	private static @Log AppLogger logger;

	private static final String SELECT = "select";
	private static final String DEFAULT_CATALOG_ID = "SXT";

	@Autowired
	private IKeyDBProvider _keydbProvider;
	@Autowired
	private ViewDAO viewDAO;

	@Override
	public String createView(ViewRequest viewRequest) throws Exception {

		String viewTextContent = viewRequest.getViewText();
		String viewText = AppUtils.extractViewText(viewTextContent);
		logger.info(viewText);
		if (!(viewText.toLowerCase().startsWith(SELECT))) {
			throw new AppException(MessageEnum.INVALID_VIEW, viewRequest.getViewName());
		}

		if (_keydbProvider.viewExists(viewRequest.getViewName())) {
			throw new AppException(MessageEnum.VIEW_ALREADY_EXIST, viewRequest.getViewName());
		}
		// validating the parameters are set, iterate through each parameter object and
		// validate that the name is being used appropriately in the view SQL text
		validateParameter(viewRequest);
		viewRequest.setOwnerId(getUserId());
		viewRequest.setIsPublic(false);
		updateResourceIdFormat(viewRequest);

		SRCView srcView = SRCMapper.getView(viewRequest);
		srcView.setCatalogId(DEFAULT_CATALOG_ID);
		String id = UUID.randomUUID().toString();
		srcView.setId(id);
		srcView.setModified(new Timestamp(System.currentTimeMillis()));
		DbView keyDBView = KeyDBMapper.getView(viewRequest);

		// creating a new entry in the SRC cluster
		viewDAO.createViewSrc(srcView);
		// creating a new entry in the View object in KeyDB
		// adding the viewName to the All Views Collection object
		_keydbProvider.createView(keyDBView.getViewId(), keyDBView);
		_keydbProvider.setViewIdToName(id, keyDBView.getViewId());

		if (viewRequest.getTags() != null)
			for (TagRequest tag : viewRequest.getTags())
				saveNewTagAndTagRelation(tag, id, ColumnConstant.VIEW);
		return id;
	}

	private void updateResourceIdFormat(ViewRequest viewRequest) {
		viewRequest.setResourceId(viewRequest.getResourceId().replace(".", ":").toUpperCase());
	}

	private void validateParameter(ViewRequest viewRequest) {
		if (viewRequest.getParametersRequest() != null) {
			String viewSQLText = viewRequest.getViewText();

			long count = viewRequest.getParametersRequest().stream()
					.filter(viewRequestParameter -> viewSQLText.contains("{{" + viewRequestParameter.getName() + "}}"))
					.count();
			if (count != viewRequest.getParametersRequest().size())
				throw new AppException(MessageEnum.BADREQUEST);
		}
	}

	@Override
	public void deleteView(String viewName, String viewId) throws Exception {
		validateInput(viewId, viewName);

		List<Map<String, Object>> viewSrcList = viewDAO.getViewSrc(viewId, viewName);

		SRCView srcView = viewDAO.getViewData(viewSrcList).get(0);
		// fail if view reference to any widget
		checkViewReferences(srcView.getId());

		if (viewSrcList.isEmpty()) {
			throw new AppException(MessageEnum.VIEW_NOT_FOUND, srcView.getViewName());
		}

		if (!srcView.getOwnerId().equals(getUserId())) {
			throw new AppException(MessageEnum.INVALID_OWNERSHIP);
		}
		// deleting the views
		viewDAO.deleteViewSrc(srcView.getViewName());
		_keydbProvider.deleteView(srcView.getViewName());
		_keydbProvider.removeViewIdMap(srcView.getId());

	}

	private void checkViewReferences(String id) {
		int widgetCount = countWidgetByViewId(id);
		if (widgetCount != 0)
			throw new AppException(MessageEnum.FAILED_VIEW_DELETION);
	}

	public int countWidgetByViewId(String viewId) {
		String qryText = CatalogAPIQuery.GET_WIDGET_COUNT;
		qryText += " WHERE VIEW_ID ='" + viewId + "'";
		int count = getTotalRecords(qryText);
		return count;
	}

	private void validateInput(String viewId, String viewName) {
		if (StringUtils.isAllBlank(viewId) && StringUtils.isAllBlank(viewName))
			throw new AppException(MessageEnum.BADREQUEST);
	}

	@Override

	public void updateView(ViewRequest viewRequest, String viewId, String viewName) throws Exception {
		validateInput(viewId, viewName);

		String viewTextContent = viewRequest.getViewText();
		String viewText = AppUtils.extractViewText(viewTextContent);
		if (!(viewText.toLowerCase().startsWith(SELECT))) {
			throw new AppException(MessageEnum.INVALID_VIEW, viewRequest.getViewName());
		}

		if (viewRequest.getIsPublic())
			checkReferenceTableRequiredAuthorization(viewText);

		List<Map<String, Object>> viewSrcList = viewDAO.getViewSrc(viewId, viewName);
		SRCView srcView = viewDAO.getViewData(viewSrcList).isEmpty() ? null : viewDAO.getViewData(viewSrcList).get(0);
		if (srcView == null)
			throw new AppException(MessageEnum.VIEW_NOT_FOUND);

		if (isViewNameExist(srcView.getId(), viewRequest.getViewName())) {
			throw new AppException(MessageEnum.VIEW_ALREADY_EXIST, viewRequest.getViewName());
		}

		if (!srcView.getOwnerId().equals(getUserId())) {
			throw new AppException(MessageEnum.INVALID_OWNERSHIP, viewName);
		}

		updateResourceIdFormat(viewRequest);

		// populating updated data from viewrequest
		SRCView updatedSrcView = SRCMapper.getUpdatedView(srcView, viewRequest);
		updatedSrcView.setModified(new Timestamp(System.currentTimeMillis()));
		DbView keyDBView = KeyDBMapper.getKeyDBView(updatedSrcView);

		// updating entry in the View object in KeyDB and SXT_META.SXT_VIEWS table in
		// the SRC cluster

		if (srcView.getViewName().equalsIgnoreCase(viewRequest.getViewName())) {
			_keydbProvider.setView(keyDBView.getViewId(), keyDBView);
		} else {
			// NOTE: we can't modified key in keydb object so deleting the existing values
			// and adding new one
			_keydbProvider.deleteView(keyDBView.getViewId());
			// creating a new entry in the View object in KeyDB
			// adding the viewName to the All Views Collection object
			_keydbProvider.createView(keyDBView.getViewId(), keyDBView);
		}
		viewDAO.updateViewSrc(updatedSrcView);
		if (viewRequest.getTags() != null) {
			removeExistingTagsForEntity(srcView.getId(), ColumnConstant.VIEW);
			for (TagRequest tag : viewRequest.getTags())
				saveNewTagAndTagRelation(tag, srcView.getId(), ColumnConstant.VIEW);
		}
	}

	private boolean isViewNameExist(String viewId, String requestedViewName) {
		return viewDAO.isViewNameExist(viewId, requestedViewName);
	}

	private void checkReferenceTableRequiredAuthorization(String qryText) {
		logger.info("checkReferenceTableRequiredAuthorization >> " + qryText);
		RequestParserDto requestParserDto = CustomCalciteDQLParser.getData(qryText);
		List<String> extractTableNames = CustomCalciteDQLParser.extractTableNames(requestParserDto.getSqlNode());
		logger.info("Tables extracted from SQL Text=" + extractTableNames);

		for (String tableName : extractTableNames) {
			String[] resource = tableName.split("[.]", 0);
			SRCTable srcTable = getSRCTableByName(resource[0], resource[1]).isEmpty()
					|| getSRCTableByName(resource[0], resource[1]) == null ? null
							: getSRCTableByName(resource[0], resource[1]).get(0);
			logger.info("TableName=" + srcTable.getTableId() + " AccessType=" + srcTable.getAccessType());
			// checking if any table is permissioned
			if (srcTable != null && (AccessTypeEnum.PERMISSIONED).toString().equals(srcTable.getAccessType())) {
				throw new AppException(MessageEnum.FAILED_VIEW_OPERATION);
			}
		}
	}

	@Override
	public List<SRCView> getViewById(String viewId) {
		return viewDAO.getViewById(viewId);
	}

	@Override
	public Page<SRCViewDto> getViews(Boolean isPublic, String searchKeyword, int pageNo, int pageSize,
			SortOrderEnum sortOrder, String sortBy, String tagId, StatusEnum status) {
		return viewDAO.getViewList(searchKeyword, isPublic, pageNo, pageSize, sortOrder, sortBy, tagId, status);

	}

	@Override
	public void publishView(String viewId) {
		// Authorization: fail if the OWNER_ID doesn’t match the user claim of the
		// access token
		viewDAO.checkViewAuthorization(viewId);
		SRCView srcView = getViewById(viewId).isEmpty() ? null : getViewById(viewId).get(0);
		if (srcView != null) {
			String viewTextContent = srcView.getViewText();
			String viewText = AppUtils.extractViewText(viewTextContent);
			// Check if referenced table(s) require authorization,If so, we must fail on the
			// publish operation
			checkReferenceTableRequiredAuthorization(viewText);
			// Set the ISPUBLIC flag to true in the SRC
			srcView.setIsPublic(true);
			srcView.setModified(new Timestamp(System.currentTimeMillis()));
			// updating view
			viewDAO.updateViewSrc(srcView);
		}
	}

	@Override
	public String forkView(String viewId) {
		// Authorization: fail if the OWNER_ID doesn’t match the user claim of the
		// access token
		SRCView srcView = getViewById(viewId).isEmpty() ? null : getViewById(viewId).get(0);
		SRCView newSRCView = null;
		if (srcView != null && srcView.getIsPublic()) {
			newSRCView = getClonedView(srcView);
			viewDAO.executeCreateView(newSRCView);

		} else {
			throw new AppException(MessageEnum.BADREQUEST);
		}
		return newSRCView.getId();
	}

	private SRCView getClonedView(SRCView srcView) {
		SRCView newSRCView = new SRCView();
		String id = UUID.randomUUID().toString();
		newSRCView.setId(id);
		newSRCView.setCatalogId(srcView.getCatalogId());
		newSRCView.setDescription(srcView.getDescription());
		newSRCView.setIsPublic(false);
		newSRCView.setOwnerId(getUserId());
		newSRCView.setParameters(srcView.getParameters());
		newSRCView.setResourceId(srcView.getResourceId());
		newSRCView.setSchemaId(srcView.getSchemaId());
		newSRCView.setViewName(srcView.getViewName() + CLONE);
		newSRCView.setViewText(srcView.getViewText());
		return newSRCView;
	}

}
