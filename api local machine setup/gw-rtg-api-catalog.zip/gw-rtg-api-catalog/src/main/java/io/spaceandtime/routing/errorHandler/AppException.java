package io.spaceandtime.routing.errorHandler;

import org.springframework.http.HttpStatus;

import io.spaceandtime.routing.utils.AppBundle;
import io.spaceandtime.routing.utils.BasePropertyEnum;

public class AppException extends BaseAppException {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	private HttpStatus status;

	/**
	 * Default constructor
	 */
	public AppException() {

	}

	/**
	 * Creates new AppException
	 * 
	 * @param messageId
	 * @param messageTextParams
	 */
	public AppException(final BasePropertyEnum property, final Object... params) {
		setMessageId(property.getMessageCode());
		setMessageText(AppBundle.getString(property, params));
		this.status = property.getStatus();
	}

	/**
	 * Creates new AppException
	 * 
	 * @param messageId
	 * @param messageTextParams
	 */
	public AppException(final Throwable th, final BasePropertyEnum property, final Object... params) {
		super(th);
		this.setThrowable(th);
		setMessageId(property.getMessageCode());
		setMessageText(AppBundle.getString(property, params));
		this.status = property.getStatus();
	}

	/**
	 * Creates new AppException
	 * 
	 * @param messageId
	 * @param messageTextParams
	 */
	public AppException(final String messageId, final Object... messageTextParams) {
		setMessageId(messageId);
		setMessageText(messageId);
		setMessageTextParams(messageTextParams);
	}

	public AppException(final Throwable th) {
		super(th);
		this.setThrowable(th);
	}

	/**
	 * String representation of the exception object
	 */
	@Override
	public String toString() {
		StringBuffer message = new StringBuffer();
		message.append(getMessageText());
		if (throwable != null) {
			message.append(", cause: ");
			message.append(getThrowable());
		}
		return message.toString();
	}

	public HttpStatus getStatus() {
		return status;
	}

}
