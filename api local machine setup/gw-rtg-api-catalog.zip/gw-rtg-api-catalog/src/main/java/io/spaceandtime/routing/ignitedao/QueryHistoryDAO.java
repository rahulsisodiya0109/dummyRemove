package io.spaceandtime.routing.ignitedao;

import java.sql.Timestamp;

import io.spaceandtime.routing.constant.SortOrderEnum;
import io.spaceandtime.routing.model.QueryHistoryDto;
import io.spaceandtime.routing.utils.Page;

/**
 * 
 * @author Nilesh Sharma
 *
 */

public interface QueryHistoryDAO {
    Page<QueryHistoryDto> getQueryHistory(String id, Timestamp from, Timestamp to, String origin, int pageNo,
	    int pageSize, SortOrderEnum sortOrder, String sortBy, boolean isRecent);

}
