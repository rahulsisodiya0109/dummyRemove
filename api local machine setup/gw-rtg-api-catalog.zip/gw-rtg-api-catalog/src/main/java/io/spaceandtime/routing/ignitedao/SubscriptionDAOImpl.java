package io.spaceandtime.routing.ignitedao;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.util.StringUtils;

import io.spaceandtime.routing.constant.MessageEnum;
import io.spaceandtime.routing.errorHandler.AppException;
import io.spaceandtime.routing.jdbcdao.BaseIgniteSqlDAOImpl;
import io.spaceandtime.routing.logging.AppLogger;
import io.spaceandtime.routing.logging.Log;
import io.spaceandtime.routing.model.*;
import io.spaceandtime.routing.storage.IKeyDBProvider;
import io.spaceandtime.storage.subscription.Subscription;
import io.spaceandtime.storage.subscription.SubscriptionUserRoles;

/**
 * 
 * @author Nilesh Sharma
 *
 */
@Component
public class SubscriptionDAOImpl extends BaseIgniteSqlDAOImpl implements SubscriptionDAO {

	private static @Log AppLogger logger;

	@Autowired
	IKeyDBProvider _keydbProvider;

	@Override
	public SubscriptionInfo getSubscription() {
		Subscription subscription = null;
		try {
			String subscriptionId = getOrganizationIdByUserId();
			if (StringUtils.hasLength(subscriptionId)) {
				subscription = _keydbProvider.getSubscription(subscriptionId);
			}
		} catch (Exception ex) {
			subscription = null;
		}
		if (subscription == null) {
			throw new AppException(MessageEnum.SUBSCRIPTION_NOT_FOUND);
		}
		return new SubscriptionInfo(subscription);
	}

	@Override
	public SubscriptionUsers getUsersInSubscription() {
		SubscriptionUserRoles userRoles = null;
		try {
			
			String subscriptionId = getOrganizationIdByUserId();
			if (StringUtils.hasLength(subscriptionId)) {
				userRoles = _keydbProvider.getSubscriptionUserRoles(subscriptionId);
			}
		} catch (Exception ex) {
			userRoles = null;
		}
		if (userRoles == null) {
			throw new AppException(MessageEnum.SUBSCRIPTION_NOT_FOUND);
		}
		return new SubscriptionUsers(userRoles);
	}
}
