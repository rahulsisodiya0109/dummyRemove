package io.spaceandtime.routing.ro;

import io.spaceandtime.routing.utils.BaseRO;
import io.swagger.v3.oas.annotations.media.Schema;

@Schema(name = "SqlDQLRequest")
public class SqlDQLRequest extends BaseRO {

	@Schema(description = "Unique resource identifier that helps to connect to cluster", example = "PUBLIC.CUSTOMER", required = true)
	private String resourceId;
	@Schema(description = "DQL queries can be sent using below attribute", example = "SELECT * FROM PUBLIC.CUSTOMER", required = true)
	private String sqlText;
	@Schema(description = "Row count can be sent using below attribute", example = "1000", required = false)
	private Long rowCount;

	public SqlDQLRequest(String resourceId, String sqlText) {
		super();
		this.resourceId = resourceId;
		this.sqlText = sqlText;
	}

	public String getResourceId() {
		return resourceId;
	}

	public void setResourceId(String resourceId) {
		this.resourceId = resourceId;
	}

	public String getSqlText() {
		return sqlText;
	}

	public void setSqlText(String sqlText) {
		this.sqlText = sqlText;
	}

	public Long getRowCount() {
		return rowCount;
	}

	public void setRowCount(Long rowCount) {
		this.rowCount = rowCount;
	}

}
