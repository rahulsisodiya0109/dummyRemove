package io.spaceandtime.routing.utils;

import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import org.apache.calcite.sql.SqlBasicCall;
import org.apache.calcite.sql.SqlIdentifier;
import org.apache.calcite.sql.SqlJoin;
import org.apache.calcite.sql.SqlKind;
import org.apache.calcite.sql.SqlNode;
import org.apache.calcite.sql.SqlOrderBy;
import org.apache.calcite.sql.SqlSelect;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class CustomCalciteDQLParser {
	private static final Logger LOG = LoggerFactory.getLogger(CustomCalciteDQLParser.class);

	public static RequestParserDto getData(final String query) {
		RequestParserDto requestDto = null;
		try {
			requestDto = CommonParsingUtil.parse(query);
		} catch (SQLException e) {
			e.printStackTrace();
			LOG.error("Exception occured during SQL parsing:{}", e.getMessage());
		}

		final List<String> tables = extractTableNames(requestDto.getSqlNode());
		requestDto.setTableNames(tables);
		return requestDto;
	}

	public static List<String> extractTableNames(SqlNode node) {

		SqlNode mainNode = node;
		final List<String> tables = new ArrayList<>();

		// If order by comes in the query.
		if (node.getKind().equals(SqlKind.ORDER_BY)) {
			// Retrieve exact select.
			node = ((SqlSelect) ((SqlOrderBy) node).query).getFrom();
		} else {
			node = ((SqlSelect) node).getFrom();
		}

		if (node == null) {
			return tables;
		}

		// Case when only 1 data set in the query.
		if (node.getKind().equals(SqlKind.AS)) {
			tables.add(CommonParsingUtil.getTargetResource((SqlBasicCall) node, 0));
			return tables;
		}

		// Case when there are more than 1 data sets in the query.
		if (node.getKind().equals(SqlKind.JOIN)) {
			final SqlJoin from = (SqlJoin) node;

			// Case when only 2 data sets are in the query.
			if (from.getLeft().getKind().equals(SqlKind.AS)) {
				tables.add(CommonParsingUtil.getTargetResource((SqlBasicCall) from.getLeft(), 0));
			} else {
				// Case when more than 2 data sets are in the query.
				SqlIdentifier left = (SqlIdentifier) from.getLeft();
				tables.add(CommonParsingUtil.getTargetResource(left));

			}

		}

		else {
			tables.add(CommonParsingUtil.getTargetResource(node));
		}

		// Check for subqueries
		getSubquery(mainNode, tables);
		LOG.info("Extracted tables size:{}", tables.size());
		LOG.info("Extracted tables:{}", tables);
		return tables;
	}

	private static void getSubquery(SqlNode node, final List<String> tables) {
		SqlBasicCall where = null;
		if (!(node.getKind().equals(SqlKind.ORDER_BY))) {
			// Retrieve exact select.
			where = (SqlBasicCall) ((SqlSelect) node).getWhere();
		}

		if (where != null) {
			// Case when there is only 1 where clause
			if (where.operand(0).getKind().equals(SqlKind.IDENTIFIER)
					&& where.operand(1).getKind().equals(SqlKind.SELECT)) {
				tables.addAll(extractTableNames(where.operand(1)));
			}
		}
	}

}
