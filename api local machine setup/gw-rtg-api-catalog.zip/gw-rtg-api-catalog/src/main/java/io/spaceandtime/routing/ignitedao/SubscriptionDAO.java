package io.spaceandtime.routing.ignitedao;

import io.spaceandtime.routing.model.SubscriptionInfo;
import io.spaceandtime.routing.model.SubscriptionUsers;

public interface SubscriptionDAO {

	SubscriptionInfo getSubscription();

	SubscriptionUsers getUsersInSubscription();

}
