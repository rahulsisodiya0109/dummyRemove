package io.spaceandtime.routing.controller.platformState;

import java.sql.Timestamp;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import io.spaceandtime.routing.constant.ColumnConstant;
import io.spaceandtime.routing.constant.EnvironmentConstant;
import io.spaceandtime.routing.constant.SortOrderEnum;
import io.spaceandtime.routing.ignitedao.QueryHistoryDAO;
import io.spaceandtime.routing.model.QueryHistoryDto;
import io.spaceandtime.routing.utils.Page;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.Parameter;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.responses.ApiResponses;

@RestController
public class QueryHistoryController extends PlatformStateController {

    @Autowired
    private QueryHistoryDAO savedQueryDAO;

    @GetMapping(value = "/history")
    @Operation(summary = "Get QueryHistory by id", description = "Returns Query for id specified.")
    @ApiResponses(value = { @ApiResponse(responseCode = "404", description = "QueryHistory not found") })
    public ResponseEntity<Page<QueryHistoryDto>> getQuery(
	    @Parameter(description = "query's unique identifier", required = false) @RequestParam(required = false) String queryId,
	    @Parameter(description = "from date/time filter", required = false) @RequestParam(required = false) Timestamp from,
	    @Parameter(description = "to date/time filter", required = false) @RequestParam(required = false) Timestamp to,
	    @Parameter(description = "origin app filter", required = false) @RequestParam(required = false) String origin,
	    @RequestParam(value = "pageNo", defaultValue = "1") int pageNo,
	    @RequestParam(value = "pageSize", defaultValue = EnvironmentConstant.PAGE_SIZE) int pageSize,
	    @RequestParam(value = "sortOrder") SortOrderEnum sortOrder,
	    @RequestParam(value = "sortBy", defaultValue = ColumnConstant.QUERYID) String sortBy,
	    @Parameter(description = "request to fetch recent records of 15 min", required = false) @RequestParam(value = "isRecent", defaultValue = "true") boolean isRecent) {
	Page<QueryHistoryDto> queryHistoryList = savedQueryDAO.getQueryHistory(queryId, from, to, origin, pageNo,
		pageSize, sortOrder, sortBy,isRecent);
	return ResponseEntity.ok().body(queryHistoryList);
    }
}
