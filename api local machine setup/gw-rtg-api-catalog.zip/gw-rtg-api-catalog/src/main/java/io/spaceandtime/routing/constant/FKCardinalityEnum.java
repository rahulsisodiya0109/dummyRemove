package io.spaceandtime.routing.constant;

public enum FKCardinalityEnum {
	ONE_TO_ONE("One-to-one"), 
	ONE_TO_MANY("One-to-many");
	

	private String name;

	FKCardinalityEnum(String name) {
		this.name = name;
	}

	public String getName() {
		return name;
	}

	

}
