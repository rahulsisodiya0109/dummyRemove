package io.spaceandtime.routing.model;

import com.fasterxml.jackson.annotation.JsonProperty;

public class DBObject {

	@JsonProperty("object_name")
	private String objectName;

	@JsonProperty("namespace")
	private String namespace;

	@JsonProperty("owner")
	private String owner;

	@JsonProperty("public_key")
	private String publicKey;

	@JsonProperty("resource_type")
	private String resourceType;

	public String getObjectName() {
		return objectName;
	}

	public void setObjectName(String objectName) {
		this.objectName = objectName;
	}

	public String getNamespace() {
		return namespace;
	}

	public void setNamespace(String namespace) {
		this.namespace = namespace;
	}

	public String getOwner() {
		return owner;
	}

	public void setOwner(String owner) {
		this.owner = owner;
	}

	public String getPublicKey() {
		return publicKey;
	}

	public void setPublicKey(String publicKey) {
		this.publicKey = publicKey;
	}

	public String getResourceType() {
		return resourceType;
	}

	public void setResourceType(String resourceType) {
		this.resourceType = resourceType;
	}

}
