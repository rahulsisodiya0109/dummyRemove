package io.spaceandtime.routing.ro;

import io.swagger.v3.oas.annotations.media.Schema;

public class TagRequest {

	@Schema(description = "the tag identifier", example = "", required = false)
	private String tagId;

	@Schema(description = "stores additional tag metadata (e.g., HTML color)", example = "", required = false)
	private String metadata;

	public String getTagId() {
		return tagId;
	}

	public void setTagId(String tagId) {
		this.tagId = tagId;
	}

	public String getMetadata() {
		return metadata;
	}

	public void setMetadata(String metadata) {
		this.metadata = metadata;
	}

}
