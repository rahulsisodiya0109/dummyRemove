package io.spaceandtime.routing.configs;

import org.springframework.stereotype.Component;

import io.spaceandtime.api.openapi.IApiSpec;

@Component
public class CatalogApiSpec implements IApiSpec {
	@Override
	public String title() { return "Catalog REST APIs"; }
	@Override
	public String description() { return "Supports user catalog operations"; }
	@Override
	public String version() { return "2.0"; }
	@Override
	public boolean jwtAuth() { return true; }
}