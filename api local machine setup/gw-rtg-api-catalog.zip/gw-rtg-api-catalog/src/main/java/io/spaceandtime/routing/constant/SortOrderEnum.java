package io.spaceandtime.routing.constant;

import java.util.ArrayList;
import java.util.List;

import io.spaceandtime.routing.errorHandler.AppException;
import io.spaceandtime.routing.utils.StringUtils;

/**
 * 
 * @author Nilesh Sharma
 *
 */
public enum SortOrderEnum {
	ASC("ASC"),
	DESC("DESC");

	private String sortOrder;

	public static List<String> sortOrderList = new ArrayList<>();

	SortOrderEnum(String string) {
		this.sortOrder = string;
	}

	static {
		for (SortOrderEnum constant : SortOrderEnum.class.getEnumConstants()) {
			sortOrderList.add(constant.getSortOrder());
		}
	}

	public String getSortOrder() {
		return sortOrder;
	}

	public String toString() {
		return this.sortOrder;
	}

	public static void checkValidSortOrder(String name) {
		if (StringUtils.isEmpty(name) || !sortOrderList.contains(name)) {
			throw new AppException(MessageEnum.INVALID_SORT_ORDER, name);

		}
	}

}
