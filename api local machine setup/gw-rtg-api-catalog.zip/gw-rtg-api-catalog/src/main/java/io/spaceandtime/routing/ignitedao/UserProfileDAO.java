package io.spaceandtime.routing.ignitedao;

import java.util.List;

import io.spaceandtime.routing.model.UserProfile;

public interface UserProfileDAO {

	List<UserProfile> getUser(String userId);

	void updateUserProfile(String userId, UserProfile userProfile);

	void deleteByUserId(String userId);

}
