package io.spaceandtime.routing.utils;

public class Pageable {

	private int totalPages;

	private int number;

	private int size;

	private int numberOfElements;

	private int totalElements;

	private Boolean first;

	private Boolean last;

	private Boolean empty;

	public int getTotalPages() {
		return totalPages;
	}

	public void setTotalPages(int totalPages) {
		this.totalPages = totalPages;
	}

	public int getNumber() {
		return number;
	}

	public void setNumber(int number) {
		this.number = number;
	}

	public int getSize() {
		return size;
	}

	public void setSize(int size) {
		this.size = size;
	}

	public int getNumberOfElements() {
		return numberOfElements;
	}

	public void setNumberOfElements(int numberOfElements) {
		this.numberOfElements = numberOfElements;
	}

	public int getTotalElements() {
		return totalElements;
	}

	public void setTotalElements(int totalElements) {
		this.totalElements = totalElements;
	}

	public Boolean getFirst() {
		return first;
	}

	public void setFirst(Boolean first) {
		this.first = first;
	}

	public Boolean getLast() {
		return last;
	}

	public void setLast(Boolean last) {
		this.last = last;
	}

	public Boolean getEmpty() {
		return empty;
	}

	public void setEmpty(Boolean empty) {
		this.empty = empty;
	}

	@Override
	public String toString() {
		return "Pageable [totalPages=" + totalPages + ", number=" + number + ", size=" + size + ", numberOfElements="
				+ numberOfElements + ", totalElements=" + totalElements + ", first=" + first + ", last=" + last
				+ ", empty=" + empty + "]";
	}

}
