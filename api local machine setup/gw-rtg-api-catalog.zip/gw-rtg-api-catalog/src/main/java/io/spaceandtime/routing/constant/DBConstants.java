package io.spaceandtime.routing.constant;

public class DBConstants {

	public static final String CREATE = "create";

	public static final String DROP = "drop";

	public static final String ALTER = "alter";

	public static final String WITH = "with";

	public static final String MERGE = "merge";

	public static final String DELETE = "delete";

	public static final String UPDATE = "update";

	public static final String INSERT = "insert";

	public static final String SELECT = "select";

	public static final String DML = "dml";

	public static final String DQL = "dql";

	public static final String DDL = "ddl";

	public static final String BEGIN = "begin;";

	public static final String COMMIT = "commit;";

	public static final String ROLLBACK = "rollback;";

	public static final String FOREIGN = "foreign";

	public static final String PRIMARY = "primary";

}
