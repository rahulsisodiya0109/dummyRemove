package io.spaceandtime.routing.ignite;

import org.apache.ignite.cache.query.SqlFieldsQuery;

import io.spaceandtime.routing.ro.SqlDQLRequest;
import io.spaceandtime.routing.ro.SqlRequest;

public class IgniteSqlFieldsQuery extends SqlFieldsQuery {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	private String bearerToken;
	private String biscuit;
	private String sqlCommandType;
	private long rowCount;

	public IgniteSqlFieldsQuery(SqlRequest sqlRequest) {
		super(sqlRequest.getSqlText());
		this.sqlCommandType = sqlRequest.getSqlCommandType();
		this.bearerToken = sqlRequest.getBearerToken();
		this.biscuit = sqlRequest.getBiscuit();
	}

	public IgniteSqlFieldsQuery(SqlDQLRequest sqlQueryRequest) {
		super(sqlQueryRequest.getSqlText());
		this.sqlCommandType = sqlQueryRequest.getSqlCommandType();
		this.bearerToken = sqlQueryRequest.getBearerToken();
		this.biscuit = sqlQueryRequest.getBiscuit();
		this.rowCount = sqlQueryRequest.getRowCount();
	}

	public String getBearerToken() {
		return bearerToken;
	}

	public void setBearerToken(String bearerToken) {
		this.bearerToken = bearerToken;
	}

	public String getBiscuit() {
		return biscuit;
	}

	public void setBiscuit(String biscuit) {
		this.biscuit = biscuit;
	}

	public String getSqlCommandType() {
		return sqlCommandType;
	}

	public void setSqlCommandType(String sqlCommandType) {
		this.sqlCommandType = sqlCommandType;
	}

	public long getRowCount() {
		return rowCount;
	}

	public void setRowCount(long rowCount) {
		this.rowCount = rowCount;
	}

}