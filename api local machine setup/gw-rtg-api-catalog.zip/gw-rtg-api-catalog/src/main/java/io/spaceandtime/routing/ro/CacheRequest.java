package io.spaceandtime.routing.ro;

import io.spaceandtime.routing.utils.BaseRO;

public class CacheRequest extends BaseRO {

	private String resourceId;
	private String cacheName;

	public String getResourceId() {
		return resourceId;
	}

	public void setResourceId(String resourceId) {
		this.resourceId = resourceId;
	}

	public String getCacheName() {
		return cacheName;
	}

	public void setCacheName(String cacheName) {
		this.cacheName = cacheName;
	}

}
