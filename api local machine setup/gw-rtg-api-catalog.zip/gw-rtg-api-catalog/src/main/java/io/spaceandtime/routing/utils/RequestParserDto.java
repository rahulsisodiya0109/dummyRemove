package io.spaceandtime.routing.utils;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.calcite.sql.SqlNode;

import com.fasterxml.jackson.annotation.JsonIgnore;

public class RequestParserDto {

	private String resourceId;
	private List<String> tableNames = new ArrayList<>();
	
	@JsonIgnore
	private SqlNode sqlNode;
	
	@JsonIgnore
	private String sqlQuery;
	
	
	public String getSqlQuery() {
		return sqlQuery;
	}

	public void setSqlQuery(String sqlQuery) {
		this.sqlQuery = sqlQuery;
	}

	public SqlNode getSqlNode() {
		return sqlNode;
	}

	public void setSqlNode(SqlNode sqlNode) {
		this.sqlNode = sqlNode;
	}

	public List<String> getTableNames() {
		return tableNames;
	}

	public void setTableNames(List<String> tableNames) {
		this.tableNames = tableNames;
	}

	private String operation;
	private String operationType;
	
	public String getOperationType() {
		return operationType;
	}

	public void setOperationType(String operationType) {
		this.operationType = operationType;
	}

	private List<Object> recordValues = new ArrayList<>();
	private Map<String, Object> recordData = new HashMap<>();

	
	public String getResourceId() {
		return resourceId;
	}

	public void setResourceId(String resourceId) {
		this.resourceId = resourceId;
	}

	public String getOperation() {
		return operation;
	}

	public void setOperation(String operation) {
		this.operation = operation;
	}

	public List<Object> getRecordValues() {
		return recordValues;
	}

	public void setRecordValues(List<Object> recordValues) {
		this.recordValues = recordValues;
	}

	public Map<String, Object> getRecordData() {
		return recordData;
	}

	public void setRecordData(Map<String, Object> recordData) {
		this.recordData = recordData;
	}

	@Override
	public String toString() {
		return "RequestParserDto [resourceId=" + resourceId + ", tableNames=" + tableNames + ", sqlNode=" + sqlNode
				+ ", sqlQuery=" + sqlQuery + ", operation=" + operation + ", operationType=" + operationType
				+ ", recordValues=" + recordValues + ", recordData=" + recordData + "]";
	}

	

	
}
