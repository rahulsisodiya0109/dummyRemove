package io.spaceandtime.routing.model;

import java.sql.Timestamp;
import java.util.List;
import java.util.UUID;

import com.fasterxml.jackson.annotation.JsonProperty;

import io.spaceandtime.routing.modelignite.Tag;

public class QueryDto {

	@JsonProperty("id")
	private UUID id;

	@JsonProperty("viewId")
	private UUID viewId;

	@JsonProperty("queryName")
	private String queryName;

	@JsonProperty("ownerId")
	private String ownerId;

	@JsonProperty("resourceId")
	private String resourceId;

	@JsonProperty("queryText")
	private String queryText;

	@JsonProperty("description")
	private String description;

	@JsonProperty("parameters")
	private String parameters;

	@JsonProperty("modified")
	private Timestamp modified;

	@JsonProperty("tags")
	private List<Tag> tags;

	public UUID getId() {
		return id;
	}

	public void setId(UUID id) {
		this.id = id;
	}

	public UUID getViewId() {
		return viewId;
	}

	public void setViewId(UUID viewId) {
		this.viewId = viewId;
	}

	public String getQueryName() {
		return queryName;
	}

	public void setQueryName(String queryName) {
		this.queryName = queryName;
	}

	public String getOwnerId() {
		return ownerId;
	}

	public void setOwnerId(String ownerId) {
		this.ownerId = ownerId;
	}

	public String getResourceId() {
		return resourceId;
	}

	public void setResourceId(String resourceId) {
		this.resourceId = resourceId;
	}

	public String getQueryText() {
		return queryText;
	}

	public void setQueryText(String queryText) {
		this.queryText = queryText;
	}

	public String getParameters() {
		return parameters;
	}

	public void setParameters(String parameters) {
		this.parameters = parameters;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public Timestamp getModified() {
		return modified;
	}

	public void setModified(Timestamp modified) {
		this.modified = modified;
	}

	public List<Tag> getTags() {
		return tags;
	}

	public void setTags(List<Tag> tags) {
		this.tags = tags;
	}
}
