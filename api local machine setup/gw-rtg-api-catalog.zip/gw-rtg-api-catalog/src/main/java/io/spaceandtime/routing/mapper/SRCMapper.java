package io.spaceandtime.routing.mapper;

import java.sql.Timestamp;
import java.util.Arrays;
import java.util.List;
import java.util.Map;

import org.apache.commons.lang3.StringUtils;

import com.fasterxml.jackson.core.JsonProcessingException;

import io.spaceandtime.routing.constant.ColumnConstant;
import io.spaceandtime.routing.model.BlockChainDto;
import io.spaceandtime.routing.model.DashboardDto;
import io.spaceandtime.routing.model.DashboardWidgetDto;
import io.spaceandtime.routing.model.NamespacesDto;
import io.spaceandtime.routing.model.QueryHistoryDto;
import io.spaceandtime.routing.model.SRCViewDto;
import io.spaceandtime.routing.model.TagDto;
import io.spaceandtime.routing.model.UserProfile;
import io.spaceandtime.routing.model.WidgetDto;
import io.spaceandtime.routing.modelignite.Dashboard;
import io.spaceandtime.routing.modelignite.DashboardWidget;
import io.spaceandtime.routing.modelignite.SRCForeignKeys;
import io.spaceandtime.routing.modelignite.SRCIndex;
import io.spaceandtime.routing.modelignite.SRCSchema;
import io.spaceandtime.routing.modelignite.SRCTable;
import io.spaceandtime.routing.modelignite.SRCTableColumns;
import io.spaceandtime.routing.modelignite.SRCView;
import io.spaceandtime.routing.modelignite.Tag;
import io.spaceandtime.routing.modelignite.Widget;
import io.spaceandtime.routing.ro.DashboardRequest;
import io.spaceandtime.routing.ro.ParameterRequest;
import io.spaceandtime.routing.ro.ViewRequest;
import io.spaceandtime.routing.ro.WidgetRequest;
import io.spaceandtime.routing.utils.AppUtils;

public class SRCMapper {

	public static SRCSchema getSchemas(Map<String, Object> schemaMap) {
		SRCSchema srcSchema = new SRCSchema();
		srcSchema.setCatalogId((String) schemaMap.get(ColumnConstant.CATALOG_ID));
		srcSchema.setIsPublic((Boolean) schemaMap.get(ColumnConstant.ISPUBLIC));
		srcSchema.setOrgId((String) schemaMap.get(ColumnConstant.ORG_ID));
		srcSchema.setSchemaId((String) schemaMap.get(ColumnConstant.SCHEMA_ID));
		return srcSchema;
	}

	public static SRCTable getTables(Map<String, Object> tableMap) {
		SRCTable srcTable = new SRCTable();
		srcTable.setSchemaId((String) tableMap.get(ColumnConstant.SCHEMA_ID));
		srcTable.setTableId((String) tableMap.get(ColumnConstant.TABLE_ID));
		srcTable.setAccessType((String) tableMap.get(ColumnConstant.ACCESS_TYPE));
		srcTable.setCatalogId((String) tableMap.get(ColumnConstant.CATALOG_ID));
		srcTable.setImmutable((Boolean) tableMap.get(ColumnConstant.IMMUTABLE));
		srcTable.setEncrypted((Boolean) tableMap.get(ColumnConstant.ENCRYPTED));
		srcTable.setTamperproof((Boolean) tableMap.get(ColumnConstant.TAMPERPROOF));
		srcTable.setPublicKey((String) tableMap.get(ColumnConstant.PUBLIC_KEY));
		srcTable.setOrgId((String) tableMap.get(ColumnConstant.ORG_ID));
		srcTable.setCreated((Timestamp) tableMap.get(ColumnConstant.CREATED));
		srcTable.setSize((String) tableMap.get(ColumnConstant.SIZE));
		return srcTable;
	}

	public static SRCTableColumns getTableColumns(Map<String, Object> tableColumnMap) {
		SRCTableColumns srcColumns = new SRCTableColumns();
		srcColumns.setColumnId((String) tableColumnMap.get(ColumnConstant.COLUMN_ID));
		srcColumns.setTableId((String) tableColumnMap.get(ColumnConstant.TABLE_ID));
		srcColumns.setSchemaId((String) tableColumnMap.get(ColumnConstant.SCHEMA_ID));
		srcColumns.setCatalogId((String) tableColumnMap.get(ColumnConstant.CATALOG_ID));
		srcColumns.setAutoGenerate((Boolean) tableColumnMap.get(ColumnConstant.AUTOGENERATE));
		srcColumns.setAutoIncrement((Boolean) tableColumnMap.get(ColumnConstant.AUTOINCREMENT));
		srcColumns.setColumnSize((Integer) tableColumnMap.get(ColumnConstant.COLUMN_SIZE));
		srcColumns.setDataType((String) tableColumnMap.get(ColumnConstant.DATA_TYPE));
		srcColumns.setDefaultValue((String) tableColumnMap.get(ColumnConstant.DEFAULT_VALUE));
		srcColumns.setMaxBytes((Long) tableColumnMap.get(ColumnConstant.MAX_BYTES));
		srcColumns.setNullable((Boolean) tableColumnMap.get(ColumnConstant.NULLABLE));
		srcColumns.setPosition((Integer) tableColumnMap.get(ColumnConstant.POSITION));
		srcColumns.setPrimaryKeySequence((Integer) tableColumnMap.get(ColumnConstant.PRIMARY_KEY_SEQ));
		srcColumns.setRadix((Integer) tableColumnMap.get(ColumnConstant.RADIX));
		srcColumns.setOrgId((String) tableColumnMap.get(ColumnConstant.ORG_ID));
		srcColumns.setEncrypted((Boolean) tableColumnMap.get(ColumnConstant.ENCRYPTED));
		srcColumns.setEncType((String) tableColumnMap.get(ColumnConstant.ENC_TYPE));
		srcColumns.setEncOption((String) tableColumnMap.get(ColumnConstant.ENC_OPTION));
		return srcColumns;
	}

	public static SRCForeignKeys getForeignKeys(Map<String, Object> fKeyMap) {
		SRCForeignKeys foreignKeys = new SRCForeignKeys();
		foreignKeys.setPkColumnId((String) fKeyMap.get(ColumnConstant.PK_COLUMN_ID));
		foreignKeys.setPkTableId((String) fKeyMap.get(ColumnConstant.PK_TABLE_ID));
		foreignKeys.setPkSchemaId((String) fKeyMap.get(ColumnConstant.PK_SCHEMA_ID));
		foreignKeys.setPkCatalogId((String) fKeyMap.get(ColumnConstant.PK_CATALOG_ID));
		foreignKeys.setFkColumnId((String) fKeyMap.get(ColumnConstant.FK_COLUMN_ID));
		foreignKeys.setFkTableId((String) fKeyMap.get(ColumnConstant.FK_TABLE_ID));
		foreignKeys.setFkSchemaId((String) fKeyMap.get(ColumnConstant.FK_SCHEMA_ID));
		foreignKeys.setFkCatalogId((String) fKeyMap.get(ColumnConstant.FK_CATALOG_ID));
		foreignKeys.setSequence((Integer) fKeyMap.get(ColumnConstant.SEQUENCE));
		foreignKeys.setCardinality((String) fKeyMap.get(ColumnConstant.CARDINALITY));
		foreignKeys.setOrgId((String) fKeyMap.get(ColumnConstant.ORG_ID));
		return foreignKeys;
	}

	public static SRCIndex getTableIndexes(Map<String, Object> indexMap) {
		SRCIndex index = new SRCIndex();
		index.setIndexId((String) indexMap.get(ColumnConstant.INDEX_ID));
		index.setCatalogId((String) indexMap.get(ColumnConstant.CATALOG_ID));
		index.setTableId((String) indexMap.get(ColumnConstant.TABLE_ID));
		index.setIndexType((String) indexMap.get(ColumnConstant.INDEX_TYPE));
		index.setCollation((String) indexMap.get(ColumnConstant.COLLATION));
		index.setColumns((String) indexMap.get(ColumnConstant.COLUMNS));
		index.setSchemaId((String) indexMap.get(ColumnConstant.SCHEMA_ID));
		index.setNonUnique((Boolean) indexMap.get(ColumnConstant.NON_UNIQUE));
		index.setPositions((String) indexMap.get(ColumnConstant.POSITIONS));
		index.setOrgId((String) indexMap.get(ColumnConstant.ORG_ID));
		return index;
	}

	public static SRCView getView(Map<String, Object> viewMap) {
		SRCView srcView = new SRCView();
		srcView.setId((String) viewMap.get(ColumnConstant.ID));
		srcView.setSchemaId((String) viewMap.get(ColumnConstant.SCHEMA_ID));
		srcView.setCatalogId((String) viewMap.get(ColumnConstant.CATALOG_ID));
		srcView.setDescription((String) viewMap.get(ColumnConstant.DESCRIPTION));
		srcView.setOwnerId((String) viewMap.get(ColumnConstant.OWNER_ID));
		srcView.setResourceId((String) viewMap.get(ColumnConstant.RESOURCE_ID));
		srcView.setViewName((String) viewMap.get(ColumnConstant.VIEW_NAME));
		srcView.setViewText((String) viewMap.get(ColumnConstant.VIEW_TEXT));
		srcView.setIsPublic((Boolean) viewMap.get(ColumnConstant.ISPUBLIC));
		srcView.setParameters((String) viewMap.get(ColumnConstant.PARAMETERS));
		return srcView;
	}

	public static SRCView getView(ViewRequest viewRequest) throws JsonProcessingException {
		SRCView srcView = new SRCView();
		srcView.setDescription(viewRequest.getDescription());
		srcView.setOwnerId(viewRequest.getOwnerId());
		srcView.setResourceId(viewRequest.getResourceId());
		srcView.setViewName(viewRequest.getViewName());
		srcView.setViewText(viewRequest.getViewText());
		srcView.setIsPublic(viewRequest.getIsPublic());
		srcView.setSchemaId(viewRequest.getSchemaId());
		srcView.setIsPublic(viewRequest.getIsPublic());
		String parameterStr = AppUtils.convertObjectToJson(viewRequest.getParametersRequest());
		srcView.setParameters(parameterStr);
		return srcView;
	}

	public static UserProfile getUser(Map<String, Object> userMap) {
		UserProfile userprofile = new UserProfile();
		userprofile.setUserId((String) userMap.get(ColumnConstant.USERID));
		userprofile.setUserName((String) userMap.get(ColumnConstant.USERNAME));
		userprofile.setDisplayName((String) userMap.get(ColumnConstant.DISPLAYNAME));
		userprofile.setEmailAddr((String) userMap.get(ColumnConstant.EMAILADDR));
		userprofile.setBio((String) userMap.get(ColumnConstant.BIO));
		userprofile.setSettings((String) userMap.get(ColumnConstant.SETTINGS));
		return userprofile;
	}

	public static QueryHistoryDto getQueryHistory(Map<String, Object> queryHistoryMap) {
		QueryHistoryDto queryHistory = new QueryHistoryDto();
		return queryHistory.setQueryId((String) queryHistoryMap.get(ColumnConstant.QUERYID).toString())
				.setUserId((String) queryHistoryMap.get(ColumnConstant.USERID))
				.setSqlText((String) queryHistoryMap.get(ColumnConstant.SQLTEXT))
				.setGatewayId((String) queryHistoryMap.get(ColumnConstant.GATEWAYID))
				.setWarehouseId((String) queryHistoryMap.get(ColumnConstant.WAREHOUSEID))
				.setOrigin((String) queryHistoryMap.get(ColumnConstant.ORIGIN))
				.setRunTime((Long) queryHistoryMap.get(ColumnConstant.RUNTIME))
				.setExecTime((Timestamp) queryHistoryMap.get(ColumnConstant.EXECTIME))
				.setRowCount((Integer) queryHistoryMap.get(ColumnConstant.ROW_COUNT))
				.setResponseSize((Long) queryHistoryMap.get(ColumnConstant.RESPONSE_SIZE))
				.setCpuSec((String) queryHistoryMap.get(ColumnConstant.CPU_SECONDS) != null
						? (String) queryHistoryMap.get(ColumnConstant.CPU_SECONDS)
						: "PENDING")
				.setIo((String) queryHistoryMap.get(ColumnConstant.IO) != null
						? (String) queryHistoryMap.get(ColumnConstant.IO)
						: "PENDING")
				.setErrorDetails((String) queryHistoryMap.get(ColumnConstant.ERROR_DETAILS))
				.setMetadata((String) queryHistoryMap.get(ColumnConstant.METADATA));
	}


	public static WidgetDto mapWidgetData(Map<String, Object> widgetMap, List<Tag> tags) {
		WidgetDto widgetDto = new WidgetDto();
		widgetDto.setId((String) widgetMap.get(ColumnConstant.ID));
		widgetDto.setWidgetName((String) widgetMap.get(ColumnConstant.WIDGETNAME));
		widgetDto.setWidgetType((String) widgetMap.get(ColumnConstant.WIDGETTYPE));
		widgetDto.setOwnerId((String) widgetMap.get(ColumnConstant.OWNER_ID));
		widgetDto.setDescription((String) widgetMap.get(ColumnConstant.DESCRIPTION));
		widgetDto.setMetadata((String) widgetMap.get(ColumnConstant.METADATA));
		widgetDto.setModified((Timestamp) widgetMap.get(ColumnConstant.MODIFIED));
		widgetDto.setIsPublic((Boolean) widgetMap.get(ColumnConstant.ISPUBLIC));
		widgetDto.setViewId((String) widgetMap.get(ColumnConstant.VIEWID));
		widgetDto.setSlug((String) widgetMap.get(ColumnConstant.SLUG));
		widgetDto.setTags(tags);
		return widgetDto;
	}

	public static Widget getWidget(WidgetRequest widgetRequest) {
		Widget widget = new Widget();
		widget.setWidgetName(widgetRequest.getWidgetName());
		widget.setWidgetType(widgetRequest.getWidgetType());
		widget.setDescription(widgetRequest.getDescription());
		widget.setMetadata(widgetRequest.getMetadata());
		widget.setViewId(widgetRequest.getViewId());
		return widget;
	}

	public static DashboardDto mapDashboardData(Map<String, Object> dashboradMap, List<Tag> tags) {
		DashboardDto dashboardDto = new DashboardDto();
		dashboardDto.setId((String) dashboradMap.get(ColumnConstant.ID));
		dashboardDto.setDashName((String) dashboradMap.get(ColumnConstant.DASHBOARDNAME));
		dashboardDto.setDescription((String) dashboradMap.get(ColumnConstant.DESCRIPTION));
		dashboardDto.setOwnerId((String) dashboradMap.get(ColumnConstant.OWNER_ID));
		dashboardDto.setMetadata((String) dashboradMap.get(ColumnConstant.METADATA));
		dashboardDto.setModified((Timestamp) dashboradMap.get(ColumnConstant.MODIFIED));
		dashboardDto.setIsPublic((boolean) dashboradMap.get(ColumnConstant.ISPUBLIC));
		dashboardDto.setSlug((String) dashboradMap.get(ColumnConstant.SLUG));
		dashboardDto.setDescriptionTitle((String) dashboradMap.get(ColumnConstant.DESCRIPTION_TITLE));
		dashboardDto.setTags(tags);
		return dashboardDto;
	}

	public static DashboardWidgetDto getDashboardWidgetDto(Map<String, Object> dashboradWidgetMap) {
		DashboardWidgetDto dashboardWidget = new DashboardWidgetDto();
		dashboardWidget.setDashboardId((String) dashboradWidgetMap.get(ColumnConstant.DASHBOARD_ID));
		dashboardWidget.setWidgetId((String) dashboradWidgetMap.get(ColumnConstant.WIDGETID));
		dashboardWidget.setMetadata((String) dashboradWidgetMap.get(ColumnConstant.METADATA));
		return dashboardWidget;
	}

	public static DashboardWidget getDashboardWidget(Map<String, Object> dashboradWidgetMap) {
		DashboardWidget dashboardWidget = new DashboardWidget();
		dashboardWidget.setDashboardId((String) dashboradWidgetMap.get(ColumnConstant.DASHBOARD_ID));
		dashboardWidget.setWidgetId((String) dashboradWidgetMap.get(ColumnConstant.WIDGETID));
		dashboardWidget.setMetadata((String) dashboradWidgetMap.get(ColumnConstant.METADATA));
		return dashboardWidget;
	}

	public static Tag getTags(Map<String, Object> tagMap) {
		Tag tag = new Tag();
		tag.setId((String) tagMap.get(ColumnConstant.ID));
		tag.setTagId((String) tagMap.get(ColumnConstant.TAG_ID));
		tag.setMetadata((String) tagMap.get(ColumnConstant.METADATA));
		return tag;
	}

	public static TagDto mapAllPopularTags(Map<String, Object> tagMap) {
		TagDto tagDto = new TagDto();
		tagDto.setId((String) tagMap.get(ColumnConstant.ID));
		tagDto.setTagId((String) tagMap.get(ColumnConstant.TAG_ID));
		tagDto.setCount((Long) (tagMap.get(ColumnConstant.COUNT) != null ? tagMap.get(ColumnConstant.COUNT) : null));
		tagDto.setMetadata((String) tagMap.get(ColumnConstant.METADATA));
		return tagDto;
	}

	public static Dashboard getDashboard(DashboardRequest dashboardRequest) {
		Dashboard dashboard = new Dashboard();
		dashboard.setDashName(dashboardRequest.getDashName());
		dashboard.setDescription(dashboardRequest.getDescription());
		dashboard.setMetadata(dashboardRequest.getMetadata());
		dashboard.setDescriptionTitle(dashboardRequest.getDescriptionTitle());
		return dashboard;
	}

	public static Dashboard getDashboard(Map<String, Object> dashboradMap) {
		Dashboard dashboard = new Dashboard();
		dashboard.setId((String) dashboradMap.get(ColumnConstant.DASHBOARD_ID));
		dashboard.setDashName((String) dashboradMap.get(ColumnConstant.DASHBOARDNAME));
		dashboard.setDescription((String) dashboradMap.get(ColumnConstant.DESCRIPTION));
		dashboard.setOwnerId((String) dashboradMap.get(ColumnConstant.OWNER_ID));
		dashboard.setMetadata((String) dashboradMap.get(ColumnConstant.METADATA));
		dashboard.setModified((Timestamp) dashboradMap.get(ColumnConstant.MODIFIED));
		dashboard.setIsPublic((boolean) dashboradMap.get(ColumnConstant.ISPUBLIC));
		dashboard.setSlug((String) dashboradMap.get(ColumnConstant.SLUG));

		return dashboard;
	}

	public static Widget getwidget(Map<String, Object> widgetMap) {
		Widget widget = new Widget();
		widget.setId((String) widgetMap.get(ColumnConstant.ID));
		widget.setWidgetName((String) widgetMap.get(ColumnConstant.WIDGETNAME));
		widget.setWidgetType((String) widgetMap.get(ColumnConstant.WIDGETTYPE));
		widget.setOwnerId((String) widgetMap.get(ColumnConstant.OWNER_ID));
		widget.setDescription((String) widgetMap.get(ColumnConstant.DESCRIPTION));
		widget.setMetadata((String) widgetMap.get(ColumnConstant.METADATA));
		widget.setModified((Timestamp) widgetMap.get(ColumnConstant.MODIFIED));
		widget.setIsPublic((boolean) widgetMap.get(ColumnConstant.ISPUBLIC));
		widget.setViewId((String) widgetMap.get(ColumnConstant.VIEWID));
		widget.setSlug((String) widgetMap.get(ColumnConstant.SLUG));
		return widget;
	}

	public static ViewRequest getViewRequest(String id, String viewName, String userId, String queryText,
			String description, String resouceId, String parameters) {
		ViewRequest viewRequest = new ViewRequest();
		viewRequest.setId(id);
		viewRequest.setDescription(description);
		viewRequest.setIsPublic(true);
		viewRequest.setOwnerId(userId);
		viewRequest.setResourceId(resouceId);

		if (!StringUtils.isAllBlank(parameters)) {
			ParameterRequest[] parameterRequestArr = AppUtils.convertJsonToObject(ParameterRequest[].class, parameters);
			if (parameterRequestArr != null && parameterRequestArr.length != 0) {
				List<ParameterRequest> parameterRequestList = Arrays.asList(parameterRequestArr);
				viewRequest.setParametersRequest(parameterRequestList);
			}
		}
		viewRequest.setViewName(viewName.toLowerCase());
		viewRequest.setViewText(queryText);
		return viewRequest;
	}

	public static SRCView getUpdatedView(SRCView srcView, ViewRequest viewRequest) throws JsonProcessingException {
		srcView.setDescription(viewRequest.getDescription());
		srcView.setOwnerId(viewRequest.getOwnerId());
		srcView.setViewName(viewRequest.getViewName());
		srcView.setResourceId(viewRequest.getResourceId());
		srcView.setViewText(viewRequest.getViewText());
		srcView.setIsPublic(viewRequest.getIsPublic());
		srcView.setSchemaId(viewRequest.getSchemaId());
		srcView.setIsPublic(viewRequest.getIsPublic());
		String parameterStr = AppUtils.convertObjectToJson(viewRequest.getParametersRequest());
		srcView.setParameters(parameterStr);
		return srcView;
	}

	public static SRCViewDto mapSRCViewData(Map<String, Object> viewMap, List<Tag> tags) {
		SRCViewDto srcViewDto = new SRCViewDto();
		srcViewDto.setId((String) viewMap.get(ColumnConstant.ID));
		srcViewDto.setCatalogId((String) viewMap.get(ColumnConstant.CATALOG_ID));
		srcViewDto.setDescription((String) viewMap.get(ColumnConstant.DESCRIPTION));
		srcViewDto.setOwnerId((String) viewMap.get(ColumnConstant.OWNER_ID));
		srcViewDto.setModified((Timestamp) viewMap.get(ColumnConstant.MODIFIED));
		srcViewDto.setIsPublic((Boolean) viewMap.get(ColumnConstant.ISPUBLIC));
		srcViewDto.setParameters((String) viewMap.get(ColumnConstant.PARAMETERS));
		srcViewDto.setSchemaId((String) viewMap.get(ColumnConstant.SCHEMA_ID));
		srcViewDto.setViewName((String) viewMap.get(ColumnConstant.VIEW_NAME));
		srcViewDto.setViewText((String) viewMap.get(ColumnConstant.VIEW_TEXT));
		srcViewDto.setTags(tags);
		return srcViewDto;
	}

	public static NamespacesDto getNamespaceData(Map<String, Object> data) {
		NamespacesDto nameSpacesDto = new NamespacesDto();
		nameSpacesDto.setSchemaId((String) data.get(ColumnConstant.SCHEMA_ID));
		return nameSpacesDto;
	}

	public static BlockChainDto getChainIdData(Map<String, Object> data) {
		BlockChainDto chainIdDto = new BlockChainDto();
		chainIdDto.setChainId((String) data.get(ColumnConstant.CHAIN_ID));
		return chainIdDto;
	}
}
