package io.spaceandtime.routing.storage.impl;

import java.util.List;
import java.util.concurrent.TimeUnit;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import io.spaceandtime.routing.model.TableRelationDto;
import io.spaceandtime.routing.storage.IKeyDBProvider;
import io.spaceandtime.storage.core.IStorageProvider;
import io.spaceandtime.storage.core.Keys;
import io.spaceandtime.storage.core.StorageUtils;
import io.spaceandtime.storage.database.*;
import io.spaceandtime.storage.datawarehouse.*;
import io.spaceandtime.storage.state.RequestLog;
import io.spaceandtime.storage.subscription.Subscription;
import io.spaceandtime.storage.subscription.SubscriptionUserRoles;

/**
 * Implements {@link IKeyDBProvider}
 */
@Component
public class KeyDBProvider implements IKeyDBProvider {

	public static final Long TABLE_RELATION_CACHE_TTL = 1800000L; // 30 min TTL for cache data

	@Autowired
	private IStorageProvider _provider;

	@Override
	public DWAddress getClusterAddress(String clusterId) throws Exception {
		return _provider.hGet(DWAddress.KEY, clusterId, DWAddress.class);
	}

	@Override
	public boolean viewExists(String viewId) throws Exception {
		return _provider.sIsMember(Keys.Db.VIEW_ALL, viewId);
	}

	@Override
	public DbView getView(String viewId) throws Exception {
		return _provider.hGet(DbView.KEY, viewId, DbView.class);
	}

	@Override
	public void createView(String viewId, DbView view) throws Exception {
		setView(viewId, view);
		_provider.sAdd(Keys.Db.VIEW_ALL, viewId);
	}

	@Override
	public void setView(String viewId, DbView view) throws Exception {
		_provider.hPut(DbView.KEY, viewId, view);
	}

	@Override
	public void setViewIdToName(String viewUUID, String viewId) throws Exception {
		_provider.hPut(Keys.Db.VIEWID_MAP, viewUUID, viewId);
	}

	@Override
	public void removeViewIdMap(String viewUUID) throws Exception {
		_provider.hDelete(Keys.Db.VIEWID_MAP, viewUUID);
	}

	@Override
	public void deleteView(String viewId) throws Exception {
		_provider.hDelete(DbView.KEY, viewId);
		_provider.sDelete(Keys.Db.VIEW_ALL, viewId);
	}

	@Override
	public String getTableRelationCache(String relationKey) throws Exception {
		String cacheKey = Keys.Db.TABLE_RELATIONS_CACHE + Keys.SEPARATOR + relationKey;
		return _provider.vGet(cacheKey);
	}

	@Override
	public void setTableRelationCache(String relationKey, List<TableRelationDto> tableRelations) throws Exception {
		String cacheKey = Keys.Db.TABLE_RELATIONS_CACHE + Keys.SEPARATOR + relationKey;
		_provider.vSet(cacheKey, tableRelations);
		_provider.setTtl(cacheKey, TABLE_RELATION_CACHE_TTL, TimeUnit.MILLISECONDS);
	}

	@Override
	public DbTable getTable(String resourceId) throws Exception {
		String itemKey = StorageUtils.Db.resourceId(resourceId);
		return _provider.hGet(DbTable.KEY, itemKey, DbTable.class);
	}

	@Override
	public List<RequestLog> getRequestLogForUser(String userId) throws Exception {
		return _provider.lGetAll(Keys.User.queryLog(userId), RequestLog.class);
	}

	@Override
	public DbObjectLeaders getLeaders(String resourceId) throws Exception {
		String itemKey = StorageUtils.Db.resourceId(resourceId);
		return _provider.hGet(DbObjectLeaders.KEY, itemKey, DbObjectLeaders.class);
	}

	@Override
	public Subscription getSubscription(String subscriptionId) throws Exception {
		return _provider.hGet(Subscription.KEY, subscriptionId, Subscription.class);
	}

	@Override
	public SubscriptionUserRoles getSubscriptionUserRoles(String subscriptionId) throws Exception {
		return _provider.hGet(SubscriptionUserRoles.KEY, subscriptionId, SubscriptionUserRoles.class);
	}
}
