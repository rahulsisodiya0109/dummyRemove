package io.spaceandtime.routing.modelignite;

import com.fasterxml.jackson.annotation.JsonProperty;

public class Tag {

	@JsonProperty("id")
	private String id;

	@JsonProperty("tagId")
	private String tagId;

	@JsonProperty("metadata")
	private String metadata;

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public String getTagId() {
		return tagId;
	}

	public void setTagId(String tagId) {
		this.tagId = tagId;
	}

	public String getMetadata() {
		return metadata;
	}

	public void setMetadata(String metadata) {
		this.metadata = metadata;
	}

}
