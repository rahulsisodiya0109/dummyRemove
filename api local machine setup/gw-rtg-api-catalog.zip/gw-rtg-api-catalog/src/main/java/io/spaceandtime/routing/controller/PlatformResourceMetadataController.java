package io.spaceandtime.routing.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import io.spaceandtime.routing.constant.ScopeEnum;
import io.spaceandtime.routing.ignitedao.BlockChainDAO;
import io.spaceandtime.routing.ignitedao.IgniteClientDiscoveryDAO;
import io.spaceandtime.routing.model.BlockChainDto;
import io.spaceandtime.routing.model.NamespacesDto;
import io.spaceandtime.routing.model.TableRelationDto;
import io.spaceandtime.routing.modelignite.SRCForeignKeys;
import io.spaceandtime.routing.modelignite.SRCIndex;
import io.spaceandtime.routing.modelignite.SRCSchema;
import io.spaceandtime.routing.modelignite.SRCTable;
import io.spaceandtime.routing.modelignite.SRCTableColumns;
import io.spaceandtime.routing.utils.ErrorResponse;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.Parameter;
import io.swagger.v3.oas.annotations.media.ArraySchema;
import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.media.Schema;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.responses.ApiResponses;
import io.swagger.v3.oas.annotations.tags.Tag;

/**
 * 
 * @author Nilesh Sharma
 *
 */

@RestController
@RequestMapping("/v1/discover")
@Tag(name = "Resource Discovery")
public class PlatformResourceMetadataController {

	@Autowired
	IgniteClientDiscoveryDAO igniteClientDiscoveryDAO;
	
	@Autowired
	BlockChainDAO blockChainDAO;

	/**
	 * 
	 * Get Schemas
	 */
	@Operation(summary = "Get schemas", description = "Get schemas metadata")
	@ApiResponses(value = {
			@ApiResponse(responseCode = "200", description = "${api.response-codes.ok.desc}", content = @Content(array = @ArraySchema(schema = @Schema(implementation = SRCSchema.class)))),
			@ApiResponse(responseCode = "401", description = "${api.response-codes.unauthorized.desc}", content = @Content(schema = @Schema(implementation = ErrorResponse.class))),
			@ApiResponse(responseCode = "403", description = "${api.response-codes.forbidden.desc}", content = @Content(schema = @Schema(implementation = ErrorResponse.class))),
			@ApiResponse(responseCode = "404", description = "${api.response-codes.notFound.desc}", content = @Content(schema = @Schema(implementation = ErrorResponse.class))) })
	@GetMapping(value = "/namespace", produces = MediaType.APPLICATION_JSON_VALUE)
	public List<SRCSchema> getSchemas(@RequestParam(required = false) ScopeEnum scope) {
		return igniteClientDiscoveryDAO.getSchemas(scope);
	}

	/**
	 * 
	 * Get tables using namespace and Scope
	 */
	@Operation(summary = "Get tables", description = "Get table metadata")
	@ApiResponses(value = {
			@ApiResponse(responseCode = "200", description = "${api.response-codes.ok.desc}", content = @Content(array = @ArraySchema(schema = @Schema(implementation = SRCTable.class)))),
			@ApiResponse(responseCode = "401", description = "${api.response-codes.unauthorized.desc}", content = @Content(schema = @Schema(implementation = ErrorResponse.class))),
			@ApiResponse(responseCode = "403", description = "${api.response-codes.forbidden.desc}", content = @Content(schema = @Schema(implementation = ErrorResponse.class))),
			@ApiResponse(responseCode = "404", description = "${api.response-codes.notFound.desc}", content = @Content(schema = @Schema(implementation = ErrorResponse.class))) })
	@GetMapping(value = "/table", produces = MediaType.APPLICATION_JSON_VALUE)
	public List<SRCTable> getTables(
			@Parameter(required = true, description = "Defines the scope of what resource metadata to return (ALL = all resources, PUBLIC = non-permissioned tables, PRIVATE = tables created by the requesting user)") @RequestParam ScopeEnum scope,
			@Parameter(required = true, description = "The namespace for limiting scope") @RequestParam(value = "namespace", required = false) String namespace) {
		return igniteClientDiscoveryDAO.getTables(scope, namespace);
	}

	/**
	 * 
	 * Get table columns using table and namespace
	 */
	@Operation(summary = "Get table columns", description = "Get table column metadata")
	@ApiResponses(value = {
			@ApiResponse(responseCode = "200", description = "${api.response-codes.ok.desc}", content = @Content(array = @ArraySchema(schema = @Schema(implementation = SRCTableColumns.class)))),
			@ApiResponse(responseCode = "401", description = "${api.response-codes.unauthorized.desc}", content = @Content(schema = @Schema(implementation = ErrorResponse.class))),
			@ApiResponse(responseCode = "403", description = "${api.response-codes.forbidden.desc}", content = @Content(schema = @Schema(implementation = ErrorResponse.class))),
			@ApiResponse(responseCode = "404", description = "${api.response-codes.notFound.desc}", content = @Content(schema = @Schema(implementation = ErrorResponse.class))) })
	@GetMapping(value = "/table/column", produces = MediaType.APPLICATION_JSON_VALUE)
	public List<SRCTableColumns> getTableColumns(
			@Parameter(required = true, description = "The namespace for limiting scope") @RequestParam(value = "namespace", defaultValue = "PUBLIC") String namespace,
			@Parameter(required = true, description = "The table name for limiting scope") @RequestParam String table) {
		return igniteClientDiscoveryDAO.getTableColumns(namespace, table);
	}

	/**
	 * Get Index using table and namespace
	 */
	@Operation(summary = "Get table indexes", description = "Get table index metadata")
	@ApiResponses(value = {
			@ApiResponse(responseCode = "200", description = "${api.response-codes.ok.desc}", content = @Content(array = @ArraySchema(schema = @Schema(implementation = SRCIndex.class)))),
			@ApiResponse(responseCode = "401", description = "${api.response-codes.unauthorized.desc}", content = @Content(schema = @Schema(implementation = ErrorResponse.class))),
			@ApiResponse(responseCode = "403", description = "${api.response-codes.forbidden.desc}", content = @Content(schema = @Schema(implementation = ErrorResponse.class))),
			@ApiResponse(responseCode = "404", description = "${api.response-codes.notFound.desc}", content = @Content(schema = @Schema(implementation = ErrorResponse.class))) })
	@GetMapping(value = "/table/index", produces = MediaType.APPLICATION_JSON_VALUE)
	public List<SRCIndex> getIndex(
			@Parameter(required = true, description = "The namespace for limiting scope") @RequestParam(value = "namespace", defaultValue = "PUBLIC") String namespace,
			@Parameter(required = true, description = "The table name for limiting scope") @RequestParam String table) {
		return igniteClientDiscoveryDAO.getIndex(namespace, table);
	}

	/**
	 * Get PrimaryKey using table and namespace
	 */
	@Operation(summary = "Get table primary keys", description = "Get table primary key metadata")
	@ApiResponses(value = {
			@ApiResponse(responseCode = "200", description = "${api.response-codes.ok.desc}", content = @Content(array = @ArraySchema(schema = @Schema(implementation = SRCTableColumns.class)))),
			@ApiResponse(responseCode = "401", description = "${api.response-codes.unauthorized.desc}", content = @Content(schema = @Schema(implementation = ErrorResponse.class))),
			@ApiResponse(responseCode = "403", description = "${api.response-codes.forbidden.desc}", content = @Content(schema = @Schema(implementation = ErrorResponse.class))),
			@ApiResponse(responseCode = "404", description = "${api.response-codes.notFound.desc}", content = @Content(schema = @Schema(implementation = ErrorResponse.class))) })
	@GetMapping(value = "/table/primarykey", produces = MediaType.APPLICATION_JSON_VALUE)
	public List<SRCTableColumns> getTablesPrimaryKey(
			@Parameter(required = true, description = "The namespace for limiting scope") @RequestParam(value = "namespace", defaultValue = "PUBLIC") String namespace,
			@Parameter(required = true, description = "The table name for limiting scope") @RequestParam String table) {
		return igniteClientDiscoveryDAO.getTablesPrimarykey(namespace, table);
	}

	/**
	 * 
	 * Get Table Relationship using this namespace
	 */
	@Operation(summary = "Get table relationships", description = "Get table relationship metadata (including table, column, and primary key references) for all tables in a namespace")
	@ApiResponses(value = {
			@ApiResponse(responseCode = "200", description = "${api.response-codes.ok.desc}", content = @Content(array = @ArraySchema(schema = @Schema(implementation = TableRelationDto.class)))),
			@ApiResponse(responseCode = "401", description = "${api.response-codes.unauthorized.desc}", content = @Content(schema = @Schema(implementation = ErrorResponse.class))),
			@ApiResponse(responseCode = "403", description = "${api.response-codes.forbidden.desc}", content = @Content(schema = @Schema(implementation = ErrorResponse.class))),
			@ApiResponse(responseCode = "404", description = "${api.response-codes.notFound.desc}", content = @Content(schema = @Schema(implementation = ErrorResponse.class))) })
	@GetMapping(value = "/table/relations", produces = MediaType.APPLICATION_JSON_VALUE)
	public List<TableRelationDto> getTableRelations(
			@Parameter(required = true, description = "The namespace for limiting scope") @RequestParam String namespace,
			@Parameter(required = true, description = "Defines the scope of what resource metadata to return (ALL = all resources, PUBLIC = non-permissioned tables, PRIVATE = tables created by the requesting user)") @RequestParam ScopeEnum scope) {
		return igniteClientDiscoveryDAO.getTableRelations(namespace, scope);
	}

	/**
	 * Get Foreign Key using pkTable ,namespace and pkColumn
	 */
	@Operation(summary = "Get foreign key references", description = "Get all foreign keys referencing the provided primary key")
	@ApiResponses(value = {
			@ApiResponse(responseCode = "200", description = "${api.response-codes.ok.desc}", content = @Content(array = @ArraySchema(schema = @Schema(implementation = SRCForeignKeys.class)))),
			@ApiResponse(responseCode = "401", description = "${api.response-codes.unauthorized.desc}", content = @Content(schema = @Schema(implementation = ErrorResponse.class))),
			@ApiResponse(responseCode = "403", description = "${api.response-codes.forbidden.desc}", content = @Content(schema = @Schema(implementation = ErrorResponse.class))),
			@ApiResponse(responseCode = "404", description = "${api.response-codes.notFound.desc}", content = @Content(schema = @Schema(implementation = ErrorResponse.class))) })
	@GetMapping(value = "/refs/foreignkey", produces = MediaType.APPLICATION_JSON_VALUE)
	public List<SRCForeignKeys> getForeignKey(
			@Parameter(required = true, description = "The namespace for limiting scope") @RequestParam(value = "namespace", defaultValue = "PUBLIC") String namespace,
			@Parameter(required = true, description = "The table name for limiting scope") @RequestParam String table,
			@Parameter(required = true, description = "The primary key column identifier") @RequestParam String column) {
		return igniteClientDiscoveryDAO.getForeignKeyFromPrimarykey(namespace, table, column);
	}

	/**
	 * Get PrimaryKey using fkTable ,namespace and fkColumn
	 */
	@Operation(summary = "Get primary key references", description = "Get all primary keys referenced by the provided foreign key")
	@ApiResponses(value = {
			@ApiResponse(responseCode = "200", description = "${api.response-codes.ok.desc}", content = @Content(array = @ArraySchema(schema = @Schema(implementation = SRCForeignKeys.class)))),
			@ApiResponse(responseCode = "401", description = "${api.response-codes.unauthorized.desc}", content = @Content(schema = @Schema(implementation = ErrorResponse.class))),
			@ApiResponse(responseCode = "403", description = "${api.response-codes.forbidden.desc}", content = @Content(schema = @Schema(implementation = ErrorResponse.class))),
			@ApiResponse(responseCode = "404", description = "${api.response-codes.notFound.desc}", content = @Content(schema = @Schema(implementation = ErrorResponse.class))) })
	@GetMapping(value = "/refs/primarykey", produces = MediaType.APPLICATION_JSON_VALUE)
	public List<SRCForeignKeys> getPrimaryKey(
			@Parameter(required = true, description = "The namespace for limiting scope") @RequestParam(value = "namespace", defaultValue = "PUBLIC") String namespace,
			@Parameter(required = true, description = "The table name for limiting scope") @RequestParam String table,
			@Parameter(required = true, description = "The foreign key column identifier") @RequestParam String column) {
		return igniteClientDiscoveryDAO.getPrimarykeyFromForeignKey(namespace, table, column);
	}

	@Operation(summary = "Get authorization required", description = "Determine whether or not biscuit authorization is required for an operation-resource pair")
	@ApiResponses(value = {
			@ApiResponse(responseCode = "200", description = "${api.response-codes.ok.desc}", content = @Content(schema = @Schema(implementation = Boolean.class))) })
	@GetMapping(value = "/table/auth-required", produces = MediaType.APPLICATION_JSON_VALUE)
	public Boolean getIsAuthorizationRequired(
			@Parameter(required = true, description = "The requested resource (e.g. ETH.TRANSACTION)") @RequestParam(required = true) String resourceId,
			@Parameter(required = true, description = "The requested operation (e.g. DELETE)") @RequestParam(required = true) String operation) {
		return igniteClientDiscoveryDAO.isAuthorizationRequired(resourceId, operation);
	}
	
	@GetMapping("/blockchains")
	@Operation(summary = "Get blockchain", description = "Get list of blockchain")
	@ApiResponses(value = {
	@ApiResponse(responseCode = "200", description = "${api.response-codes.ok.desc}", content = @Content(schema = @Schema(implementation = BlockChainDto.class))),
	@ApiResponse(responseCode = "401", description = "${api.response-codes.unauthorized.desc}", content = @Content(schema = @Schema(implementation = ErrorResponse.class))), })
	public List<BlockChainDto> getBlockchains(){
		  return blockChainDAO.getBlockchains();
	}
	
	@GetMapping("/blockchains/{chainId}")
	@Operation(summary = "Get namespaces", description = "Get list of namespaces")
	@ApiResponses(value = {
	@ApiResponse(responseCode = "200", description = "${api.response-codes.ok.desc}", content = @Content(schema = @Schema(implementation = NamespacesDto.class))),
	@ApiResponse(responseCode = "400", description = "${api.response-codes.badRequest.desc}", content = @Content(schema = @Schema(implementation = ErrorResponse.class))),
	@ApiResponse(responseCode = "401", description = "${api.response-codes.unauthorized.desc}", content = @Content(schema = @Schema(implementation = ErrorResponse.class))), })
	public List<NamespacesDto> getNamespaces(@PathVariable String chainId){
		return blockChainDAO.getNamespaces(chainId);
	}
}
