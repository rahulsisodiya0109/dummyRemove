package io.spaceandtime.routing.mapper;

import java.util.Comparator;

import io.spaceandtime.routing.modelignite.Tag;

public class SortByTagIdAsc implements Comparator<Tag> {

	@Override
	public int compare(Tag tag1, Tag tag2) {
		return tag1.getTagId().compareTo(tag2.getTagId());
	}
}
