package io.spaceandtime.routing.mapper;

import java.sql.Timestamp;
import java.util.Map;

import io.spaceandtime.routing.constant.ColumnConstant;
import io.spaceandtime.routing.model.TableColumnDto;
import io.spaceandtime.routing.model.TableRelationDto;
import io.spaceandtime.routing.model.TableRelationTransitionDto;

public class TableRelationMapper {

	public static TableRelationTransitionDto getTableRelationTransitionDto(Map<String, Object> table) {
		TableRelationTransitionDto tableRelationTransitionDto = new TableRelationTransitionDto();
		tableRelationTransitionDto.setTablename((String) table.get(ColumnConstant.TABLE_ID));
		tableRelationTransitionDto.setNamespace((String) table.get(ColumnConstant.SCHEMA_ID));
		tableRelationTransitionDto.setPublicKey((String) table.get(ColumnConstant.PUBLIC_KEY));
		tableRelationTransitionDto.setImmutable((Boolean) table.get(ColumnConstant.IMMUTABLE));
		tableRelationTransitionDto.setAccessType((String) table.get(ColumnConstant.ACCESS_TYPE));
		tableRelationTransitionDto.setEncrypted((Boolean) table.get(ColumnConstant.ENCRYPTED));
		tableRelationTransitionDto.setTamperproof((Boolean) table.get(ColumnConstant.TAMPERPROOF));
		tableRelationTransitionDto.setSize((String) table.get(ColumnConstant.SIZE));
		tableRelationTransitionDto.setLastAnchored((Timestamp) table.get(ColumnConstant.CREATED));

		tableRelationTransitionDto.setColumnName((String) table.get(ColumnConstant.COLUMN_ID));
		tableRelationTransitionDto.setDataType((String) table.get(ColumnConstant.DATA_TYPE));
		tableRelationTransitionDto.setPrimaryKeySequence((Integer) table.get(ColumnConstant.PRIMARY_KEY_SEQ));
		tableRelationTransitionDto.setPkColumnName((String) table.get(ColumnConstant.PK_COLUMN_ID));
		tableRelationTransitionDto.setPkTableName((String) table.get(ColumnConstant.PK_TABLE_ID));
		tableRelationTransitionDto.setFkColumnName((String) table.get(ColumnConstant.FK_COLUMN_ID));
		tableRelationTransitionDto.setFkTableName((String) table.get(ColumnConstant.FK_TABLE_ID));
		tableRelationTransitionDto.setFkNameSpaceId((String) table.get(ColumnConstant.FK_SCHEMA_ID));
		tableRelationTransitionDto.setCardinality((String) table.get(ColumnConstant.CARDINALITY));
		return tableRelationTransitionDto;
	}

	public static void getTableColumnDto(TableColumnDto tableSchemaDto,
			TableRelationTransitionDto tableRelationTransitionDataFirstIndex) {
		tableSchemaDto.setColumn(tableRelationTransitionDataFirstIndex.getColumnName());
		tableSchemaDto.setTable(tableRelationTransitionDataFirstIndex.getTablename());
		tableSchemaDto.setNamespace(tableRelationTransitionDataFirstIndex.getNamespace());
		tableSchemaDto.setDataType(tableRelationTransitionDataFirstIndex.getDataType());
		tableSchemaDto.setPrimaryKeySequence(tableRelationTransitionDataFirstIndex.getPrimaryKeySequence());
	}

	public static void getTableRelationDto(TableRelationDto dto, TableRelationTransitionDto tableRelationDummyDto) {
		dto.setTable(tableRelationDummyDto.getTablename());
		dto.setNamespace(tableRelationDummyDto.getNamespace());
		dto.setPublicKey(tableRelationDummyDto.getPublicKey());
		dto.setImmutable(tableRelationDummyDto.getImmutable());
		dto.setAccessType(tableRelationDummyDto.getAccessType());
		dto.setEncrypted(tableRelationDummyDto.getEncrypted());
		dto.setLastAnchored(tableRelationDummyDto.getLastAnchored());
		dto.setSize(tableRelationDummyDto.getSize());
		dto.setTamperproof(tableRelationDummyDto.getTamperproof());
	}
}
