package io.spaceandtime.routing.ro;

import java.util.List;

public class DashboardRequest {

	private String dashName;

	private String descriptionTitle;
	
	private String description;

	private String metadata;

	private List<TagRequest> tags;

	public String getDescriptionTitle() {
		return descriptionTitle;
	}

	public void setDescriptionTitle(String descriptionTitle) {
		this.descriptionTitle = descriptionTitle;
	}

	public String getDashName() {
		return dashName;
	}

	public void setDashName(String dashName) {
		this.dashName = dashName;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public String getMetadata() {
		return metadata;
	}

	public void setMetadata(String metadata) {
		this.metadata = metadata;
	}

	public List<TagRequest> getTags() {
		return tags;
	}

	public void setTags(List<TagRequest> tags) {
		this.tags = tags;
	}
}
