package io.spaceandtime.routing.model;

import java.sql.Timestamp;

public class TableRelationTransitionDto {

	private String tablename;

	private String namespace;

	private String publicKey;

	private Boolean immutable;

	private String accessType;

	private Boolean encrypted;

	private Boolean tamperproof;

	private Timestamp lastAnchored;

	private String size;

	private String columnName;

	private String dataType;

	private Integer primaryKeySequence;

	private String pkColumnName;

	private String pkTableName;

	private String fkColumnName;

	private String fkTableName;

	private String fkNameSpaceId;

	private String cardinality;

	public Boolean getEncrypted() {
		return encrypted;
	}

	public void setEncrypted(Boolean encrypted) {
		this.encrypted = encrypted;
	}

	public Boolean getTamperproof() {
		return tamperproof;
	}

	public void setTamperproof(Boolean tamperproof) {
		this.tamperproof = tamperproof;
	}

	public Timestamp getLastAnchored() {
		return lastAnchored;
	}

	public void setLastAnchored(Timestamp lastAnchored) {
		this.lastAnchored = lastAnchored;
	}

	public String getSize() {
		return size;
	}

	public void setSize(String size) {
		this.size = size;
	}

	public String getTablename() {
		return tablename;
	}

	public void setTablename(String tablename) {
		this.tablename = tablename;
	}

	public String getNamespace() {
		return namespace;
	}

	public void setNamespace(String namespace) {
		this.namespace = namespace;
	}

	public String getPublicKey() {
		return publicKey;
	}

	public void setPublicKey(String publicKey) {
		this.publicKey = publicKey;
	}

	public Boolean getImmutable() {
		return immutable;
	}

	public void setImmutable(Boolean immutable) {
		this.immutable = immutable;
	}

	public String getAccessType() {
		return accessType;
	}

	public void setAccessType(String accessType) {
		this.accessType = accessType;
	}

	public String getColumnName() {
		return columnName;
	}

	public void setColumnName(String columnName) {
		this.columnName = columnName;
	}

	public String getDataType() {
		return dataType;
	}

	public void setDataType(String dataType) {
		this.dataType = dataType;
	}

	public Integer getPrimaryKeySequence() {
		return primaryKeySequence;
	}

	public void setPrimaryKeySequence(Integer primaryKeySequence) {
		this.primaryKeySequence = primaryKeySequence;
	}

	public String getPkColumnName() {
		return pkColumnName;
	}

	public void setPkColumnName(String pkColumnName) {
		this.pkColumnName = pkColumnName;
	}

	public String getPkTableName() {
		return pkTableName;
	}

	public void setPkTableName(String pkTableName) {
		this.pkTableName = pkTableName;
	}

	public String getFkColumnName() {
		return fkColumnName;
	}

	public void setFkColumnName(String fkColumnName) {
		this.fkColumnName = fkColumnName;
	}

	public String getFkTableName() {
		return fkTableName;
	}

	public void setFkTableName(String fkTableName) {
		this.fkTableName = fkTableName;
	}

	public String getCardinality() {
		return cardinality;
	}

	public void setCardinality(String cardinality) {
		this.cardinality = cardinality;
	}

	public String getFkNameSpaceId() {
		return fkNameSpaceId;
	}

	public void setFkNameSpaceId(String fkNameSpaceId) {
		this.fkNameSpaceId = fkNameSpaceId;
	}

}
