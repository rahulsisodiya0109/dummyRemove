package io.spaceandtime.routing.modelignite;

import com.fasterxml.jackson.annotation.JsonProperty;

public class TagRelation {

	@JsonProperty("id")
	private String tagId;

	@JsonProperty("entId")
	private String entId;

	@JsonProperty("metadata")
	private String entType;

	public String getTagId() {
		return tagId;
	}

	public void setTagId(String tagId) {
		this.tagId = tagId;
	}

	public String getEntId() {
		return entId;
	}

	public void setEntId(String entId) {
		this.entId = entId;
	}

	public String getEntType() {
		return entType;
	}

	public void setEntType(String entType) {
		this.entType = entType;
	}
}
