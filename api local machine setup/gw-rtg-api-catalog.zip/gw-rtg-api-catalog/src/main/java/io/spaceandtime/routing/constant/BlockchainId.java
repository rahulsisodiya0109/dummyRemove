package io.spaceandtime.routing.constant;

public enum BlockchainId {
	ETH,
	AVAX,
	BNB,
	MATIC,
	SUI;

	public static BlockchainId tryParse(String value) throws Exception {
		switch (value) {
			case ColumnConstant.ETH: 	return ETH;
			case ColumnConstant.AVAX: 	return AVAX;
			case ColumnConstant.BNB: 	return BNB;
			case ColumnConstant.MATIC: 	return MATIC;
			case ColumnConstant.SUI:    return SUI;
			default: throw new Exception();
		}
	}
}
