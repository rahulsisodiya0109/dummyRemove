package io.spaceandtime.routing.model;

import java.util.List;

import com.fasterxml.jackson.annotation.JsonProperty;

public class DBTableResource {

	@JsonProperty("object_name")
	private String objectName;

	@JsonProperty("namespace")
	private String namespace;

	@JsonProperty("owner")
	private String owner;

	@JsonProperty("public_key")
	private String publicKey;

	@JsonProperty("access_type")
	private String accessType;

	@JsonProperty("schema")
	private List<TableSchema> schema;

	@JsonProperty("immutable")
	private Boolean immutable;

	@JsonProperty("org_id")
	private String orgId;

	public String getObjectName() {
		return objectName;
	}

	public void setObjectName(String objectName) {
		this.objectName = objectName;
	}

	public String getNamespace() {
		return namespace;
	}

	public void setNamespace(String namespace) {
		this.namespace = namespace;
	}

	public String getOwner() {
		return owner;
	}

	public void setOwner(String owner) {
		this.owner = owner;
	}

	public String getPublicKey() {
		return publicKey;
	}

	public void setPublicKey(String publicKey) {
		this.publicKey = publicKey;
	}

	public String getAccessType() {
		return accessType;
	}

	public void setAccessType(String accessType) {
		this.accessType = accessType;
	}

	public List<TableSchema> getSchema() {
		return schema;
	}

	public void setSchema(List<TableSchema> schema) {
		this.schema = schema;
	}

	public Boolean getImmutable() {
		return immutable;
	}

	public void setImmutable(Boolean immutable) {
		this.immutable = immutable;
	}

	public String getOrgId() {
		return orgId;
	}

	public void setOrgId(String orgId) {
		this.orgId = orgId;
	}

}
