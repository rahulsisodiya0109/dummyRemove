package io.spaceandtime.routing.ignitedao;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.fasterxml.jackson.core.type.TypeReference;

import io.spaceandtime.routing.constant.ColumnConstant;
import io.spaceandtime.routing.constant.MessageEnum;
import io.spaceandtime.routing.constant.ScopeEnum;
import io.spaceandtime.routing.constant.SqlOperationEnum;
import io.spaceandtime.routing.errorHandler.AppException;
import io.spaceandtime.routing.ignite.IgniteThinClient;
import io.spaceandtime.routing.jdbcdao.BaseIgniteSqlDAOImpl;
import io.spaceandtime.routing.logging.AppLogger;
import io.spaceandtime.routing.logging.Log;
import io.spaceandtime.routing.mapper.SRCMapper;
import io.spaceandtime.routing.mapper.TableRelationMapper;
import io.spaceandtime.routing.model.TableColumnDto;
import io.spaceandtime.routing.model.TableForeignKeyDto;
import io.spaceandtime.routing.model.TableRelationDto;
import io.spaceandtime.routing.model.TableRelationTransitionDto;
import io.spaceandtime.routing.modelignite.SRCForeignKeys;
import io.spaceandtime.routing.modelignite.SRCIndex;
import io.spaceandtime.routing.modelignite.SRCSchema;
import io.spaceandtime.routing.modelignite.SRCTable;
import io.spaceandtime.routing.modelignite.SRCTableColumns;
import io.spaceandtime.routing.query.CatalogAPIQuery;
import io.spaceandtime.routing.storage.IKeyDBProvider;
import io.spaceandtime.routing.utils.AppUtils;
import io.spaceandtime.storage.database.DbTable;
import io.spaceandtime.storage.database.DbTable.AccessType;

/**
 * 
 * @author Nilesh Sharma
 *
 */
@Component
public class IgniteClientDiscoveryDAOImpl extends BaseIgniteSqlDAOImpl implements IgniteClientDiscoveryDAO {

	private static @Log AppLogger logger;

	public static final String COLON = ":";

	@Autowired
	IgniteThinClient srcIgniteClient;

	@Autowired
	private IKeyDBProvider _keydbProvider;

	@Override
	public List<SRCSchema> getSchemas(ScopeEnum scope) {
		String qryText = CatalogAPIQuery.GET_SCHEMAS;
		if (scope != null && scope.equals(ScopeEnum.PUBLIC))
			qryText += "WHERE ISPUBLIC = TRUE";
		else if (scope != null && scope.equals(ScopeEnum.SUBSCRIPTION)) {
			String orgId = getOrganizationIdByUserId();
			qryText += "WHERE ORG_ID = '" + orgId + "'";
		}
		List<Map<String, Object>> namespaceData = getDiscoveryMetadata(qryText);
		return getSchemaData(namespaceData);
	}

	private List<SRCSchema> getSchemaData(List<Map<String, Object>> namespaceData) {
		List<SRCSchema> schemaList = new ArrayList<>();
		for (Map<String, Object> namespaceMap : namespaceData) {
			SRCSchema srcSchema = SRCMapper.getSchemas(namespaceMap);
			schemaList.add(srcSchema);
		}
		return schemaList;
	}

	@Override
	public List<SRCTable> getTables(ScopeEnum scope, String namespace) {
		String orgId = getOrganizationIdByUserId();
		String qryText = CatalogAPIQuery.GET_TABLES;
		qryText = getQueryText(namespace, scope, qryText, orgId);
		List<Map<String, Object>> tableData = getDiscoveryMetadata(qryText);
		return getTableData(tableData);
	}

	@Override
	public List<SRCTableColumns> getTableColumns(String namespace, String table) {
		String orgId = getOrganizationIdByUserId();
		String qryText = CatalogAPIQuery.GET_TABLECOLUMNS + "where TABLE_ID = '" + table + "' and SCHEMA_ID = '"
				+ namespace + "' and (ORG_ID='" + orgId + "' or ORG_ID  IS NULL );";
		List<Map<String, Object>> tableColumnsData = getDiscoveryMetadata(qryText);
		return getTableColumnsData(tableColumnsData);
	}

	private List<SRCTableColumns> getTableColumnsData(List<Map<String, Object>> tableColumnsData) {
		List<SRCTableColumns> tableColumnsList = new ArrayList<>();
		for (Map<String, Object> tableColumnMap : tableColumnsData) {
			SRCTableColumns srcTableColumns = SRCMapper.getTableColumns(tableColumnMap);
			tableColumnsList.add(srcTableColumns);
		}
		return tableColumnsList;
	}

	@Override
	public List<SRCIndex> getIndex(String namespace, String table) {
		String orgId = getOrganizationIdByUserId();
		String qryText = CatalogAPIQuery.GET_INDEX + "where TABLE_ID = '" + table + "' and SCHEMA_ID = '" + namespace
				+ "' and (ORG_ID='" + orgId + "' or ORG_ID IS NULL );";
		List<Map<String, Object>> indexData = getDiscoveryMetadata(qryText);
		return getTableIndexesData(indexData);
	}

	private List<SRCIndex> getTableIndexesData(List<Map<String, Object>> indexData) {
		List<SRCIndex> indexList = new ArrayList<>();
		for (Map<String, Object> indexMap : indexData) {
			SRCIndex srcIndex = SRCMapper.getTableIndexes(indexMap);
			indexList.add(srcIndex);
		}
		return indexList;
	}

	@Override
	public List<SRCForeignKeys> getForeignKeyFromPrimarykey(String namespace, String table, String keyColumn) {
		String orgId = getOrganizationIdByUserId();
		String qryText = CatalogAPIQuery.GET_SXT_FKEY;
		qryText = qryText + "where PK_TABLE_ID = '" + table + "'" + " and PK_COLUMN_ID = '" + keyColumn
				+ "' and PK_SCHEMA_ID = '" + namespace + "' and ( ORG_ID='" + orgId + "' or ORG_ID IS NULL );";
		List<Map<String, Object>> fKeysData = getDiscoveryMetadata(qryText);
		return getForeignKeysData(fKeysData);
	}

	@Override
	public List<SRCForeignKeys> getPrimarykeyFromForeignKey(String namespace, String table, String keyColumn) {
		String orgId = getOrganizationIdByUserId();
		String qryText = CatalogAPIQuery.GET_SXT_FKEY;
		qryText = qryText + "where FK_TABLE_ID = '" + table + "'" + " and FK_COLUMN_ID = '" + keyColumn
				+ "' and FK_SCHEMA_ID = '" + namespace + "' and ( ORG_ID='" + orgId + "' or ORG_ID IS NULL );";
		List<Map<String, Object>> fKeysData = getDiscoveryMetadata(qryText);
		return getForeignKeysData(fKeysData);
	}

	private List<SRCForeignKeys> getForeignKeysData(List<Map<String, Object>> fKeysData) {
		List<SRCForeignKeys> foreignKeysList = new ArrayList<>();
		for (Map<String, Object> fKeyMap : fKeysData) {
			SRCForeignKeys srcForeignKeys = SRCMapper.getForeignKeys(fKeyMap);
			foreignKeysList.add(srcForeignKeys);
		}
		return foreignKeysList;
	}

	@Override
	public List<SRCTableColumns> getTablesPrimarykey(String namespace, String table) {
		String orgId = getOrganizationIdByUserId();
		String qryText = CatalogAPIQuery.GET_TABLECOLUMNS + "where TABLE_ID = '" + table
				+ "' and PRIMARY_KEY_SEQ != -1 and SCHEMA_ID = '" + namespace + "' and (ORG_ID='" + orgId
				+ "' or ORG_ID IS NULL );";
		List<Map<String, Object>> tableColumnsData = getDiscoveryMetadata(qryText);
		return getTableColumnsData(tableColumnsData);
	}

	@Override
	public List<TableRelationDto> getTableRelations(String namespace, ScopeEnum scope) {
		String relationsCacheKey = namespace + COLON + scope;
		List<TableRelationDto> tableRelationsCache = getTableRelationsCache(relationsCacheKey);
		if (tableRelationsCache != null)
			return tableRelationsCache;

		List<TableRelationDto> pkRelationList = extracted(CatalogAPIQuery.TABLE_RELATION_FOR_PK, namespace, scope,
				true);
		List<TableRelationDto> fkRelationList = extracted(CatalogAPIQuery.TABLE_RELATION_FOR_FK, namespace, scope,
				false);
		Map<String, TableRelationDto> pkRelationMap = pkRelationList.stream()
				.collect(Collectors.toMap(dto -> dto.getTable(), dto -> dto));

		for (TableRelationDto fkRelation : fkRelationList) {
			TableRelationDto pkRelation = pkRelationMap.get(fkRelation.getTable());
			if (pkRelation != null) {
				Map<String, TableColumnDto> pkTableColumnMap = pkRelation.getTableColumn().stream()
						.collect(Collectors.toMap(dto -> dto.getColumn(), dto -> dto));
				for (TableColumnDto fkTableColumnDto : fkRelation.getTableColumn()) {
					TableColumnDto pkTableColumnDto = pkTableColumnMap.get(fkTableColumnDto.getColumn());
					if (pkTableColumnDto != null) {
						pkTableColumnDto.getRelationship().addAll(fkTableColumnDto.getRelationship());
					}
				}
			}
		}
		if (scope.equals(ScopeEnum.ALL) || scope.equals(ScopeEnum.PUBLIC)) {
			addIntoTableRelationsCache(new ArrayList<>(pkRelationMap.values()), relationsCacheKey);
		}
		return new ArrayList<>(pkRelationMap.values());
	}

	private List<TableRelationDto> getTableRelationsCache(String relationsCacheKey) {
		try {
			String json = _keydbProvider.getTableRelationCache(relationsCacheKey);
			return AppUtils.convertJsonToObject(new TypeReference<List<TableRelationDto>>() {
			}, json);
		} catch (Exception ex) {
			return null;
		}
	}

	private void addIntoTableRelationsCache(List<TableRelationDto> values, String relationsCacheKey) {
		try {
			_keydbProvider.setTableRelationCache(relationsCacheKey, values);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}

	private List<TableRelationDto> extracted(String qryTextForPK, String namespace, ScopeEnum scope,
			Boolean isPKColumn) {
		qryTextForPK = setScope(namespace, scope, qryTextForPK);
		List<Map<String, Object>> fetchedTableRelationData = getDiscoveryMetadataLazy(qryTextForPK);
		List<TableRelationDto> tableRelationDto = new ArrayList<>();
		getTableRelationData(fetchedTableRelationData, tableRelationDto, isPKColumn);
		return tableRelationDto;
	}

	private String setScope(String namespace, ScopeEnum scope, String qryText) {
		String orgId;
		if (scope.equals(ScopeEnum.PUBLIC))
			orgId = null;
		else
			orgId = getOrganizationIdByUserId();
		return getQueryText(namespace, scope, qryText, orgId);
	}

	private String getQueryText(String namespace, ScopeEnum scope, String qryText, String orgId) {
		if (scope.equals(ScopeEnum.PRIVATE))
			qryText = qryText.concat(" WHERE tab.ORG_ID = '" + orgId + "' AND tab.ACCESS_TYPE = 'permissioned'");
		else if (scope.equals(ScopeEnum.SUBSCRIPTION))
			qryText = qryText.concat(" WHERE tab.ORG_ID = '" + orgId + "'");
		else if (scope.equals(ScopeEnum.PUBLIC))
			qryText = qryText.concat(" WHERE tab.ACCESS_TYPE != 'permissioned' ");

		if (namespace != null) {
			if (scope.equals(ScopeEnum.ALL))
				qryText = qryText + " where tab.SCHEMA_ID = '" + namespace + "' and ( tab.ORG_ID = '" + orgId
						+ "' or tab.ACCESS_TYPE != 'permissioned' );";
			else
				qryText = qryText + " and tab.SCHEMA_ID = '" + namespace + "';";
		}
		return qryText;
	}

	private void getTableRelationData(List<Map<String, Object>> fetchedTableRelationData,
			List<TableRelationDto> tableRelationDto, boolean isPKColumn) {
		Map<String, List<TableRelationTransitionDto>> tableWiseRelationDtoData = new HashMap<>();

		for (Map<String, Object> table : fetchedTableRelationData) {
			String tableId = (String) table.get(ColumnConstant.TABLE_ID);
			TableRelationTransitionDto tableRelationTransitionDto = TableRelationMapper
					.getTableRelationTransitionDto(table);
			if (tableWiseRelationDtoData.containsKey(tableId)) {
				List<TableRelationTransitionDto> tableRelationTransitionDtoList = tableWiseRelationDtoData.get(tableId);
				tableRelationTransitionDtoList.add(tableRelationTransitionDto);
			} else {
				List<TableRelationTransitionDto> tableRelationTransitionDtoList = new ArrayList<>();
				tableRelationTransitionDtoList.add(tableRelationTransitionDto);
				tableWiseRelationDtoData.put(tableId, tableRelationTransitionDtoList);
			}
		}
		for (String tableNameKey : tableWiseRelationDtoData.keySet()) {
			TableRelationDto dto = new TableRelationDto();

			List<TableRelationTransitionDto> tableRelationTransitionDtoList = tableWiseRelationDtoData
					.get(tableNameKey);
			Map<String, List<TableRelationTransitionDto>> columnWiseMap = tableRelationTransitionDtoList.stream()
					.collect(Collectors.groupingBy(TableRelationTransitionDto::getColumnName));
			List<TableColumnDto> tableSchemaList = new ArrayList<>();
			for (String columnName : columnWiseMap.keySet()) {
				TableColumnDto tableSchemaDto = new TableColumnDto();
				TableRelationTransitionDto tableRelationTransitionDataFirstIndex = columnWiseMap.get(columnName).get(0);
				TableRelationMapper.getTableColumnDto(tableSchemaDto, tableRelationTransitionDataFirstIndex);
				List<TableRelationTransitionDto> columnWiseTableRelationTransitionList = columnWiseMap.get(columnName);
				List<TableForeignKeyDto> relationShipList = new ArrayList<>();
				for (TableRelationTransitionDto columnData : columnWiseTableRelationTransitionList) {
					TableForeignKeyDto relationShipDto = new TableForeignKeyDto();
					relationShipDto.setColumn(isPKColumn ? columnData.getFkColumnName() : columnData.getPkColumnName());
					relationShipDto.setTable(isPKColumn ? columnData.getFkTableName() : columnData.getPkTableName());
					relationShipDto.setCardinality(columnData.getCardinality());
					relationShipDto.setNamespace(columnData.getFkNameSpaceId());
					if (!(relationShipDto.getColumn() == null && relationShipDto.getTable() == null)) {
						relationShipList.add(relationShipDto);
					}
//					if (!(columnData.getFkColumnName() == null && columnData.getFkTableName() == null)) {
//						relationShipList.add(relationShipDto);
//					}
				}
				tableSchemaDto.setRelationship(relationShipList);
				tableSchemaList.add(tableSchemaDto);
			}
			TableRelationTransitionDto tableRelationTransitionDto = tableRelationTransitionDtoList.get(0);
			dto.setTableColumn(tableSchemaList);
			TableRelationMapper.getTableRelationDto(dto, tableRelationTransitionDto);
			tableRelationDto.add(dto);
		}
	}

	@Override
	public Boolean isAuthorizationRequired(String resourceId, String operation) {
		SqlOperationEnum.checkValidOperationType(operation);
		if (operation.equalsIgnoreCase(SqlOperationEnum.CREATE.getOperationType())
				|| operation.equalsIgnoreCase(SqlOperationEnum.ALTER.getOperationType())
				|| operation.equalsIgnoreCase(SqlOperationEnum.DROP.getOperationType()))
			return true; // operation is one of the DDL operations
		DbTable tableInfo;
		try {
			tableInfo = _keydbProvider.getTable(resourceId);
		} catch (Exception ex) {
			tableInfo = null;
		}
		if (tableInfo == null) {
			throw new AppException(MessageEnum.INVALID_RESOURCEID);
		}
		// DBTableResource tableInfo = clusterDAO.findTableObject(resource);
		if (tableInfo.getAccessType().equals(AccessType.PERMISSIONED))
			return true; // it’s not DDL and it’s permissioned

		else if (operation.equalsIgnoreCase(SqlOperationEnum.SELECT.getOperationType()))
			return false; // it’s not DDL, not permissioned

		else if (tableInfo.getAccessType().equals(AccessType.PUBLIC_WRITE))
			return false; // it’s not DDL or DQL i.e. DML

		else if (tableInfo.getAccessType().equals(AccessType.PUBLIC_APPEND)
				&& operation.equalsIgnoreCase(SqlOperationEnum.INSERT.getOperationType()))
			return false; // it’s public_append and operation is insert

		else
			return true; // access type is public_read and this is a DML operation
	}
}
