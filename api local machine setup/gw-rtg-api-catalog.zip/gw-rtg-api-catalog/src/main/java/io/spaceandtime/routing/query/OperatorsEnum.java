package io.spaceandtime.routing.query;

import java.util.HashMap;
import java.util.Map;
/**
 * 
 * @author Aswanth Guvala
 *
 */
public enum OperatorsEnum {

	EQUALS("EQUALS","{0} = ''{1}''"), 
	NOT_EQUALS("NOT_EQUALS","{0} != ''{1}''"),
	BEGINS_WITH("BEGINS_WITH","{0} like ''{1}%''"),
	ENDS_WITH("ENDS_WITH","{0} like ''%{1}''"),
	CONTAINS("CONTAINS","{0} like ''%{1}%''"),
	GREATER_THAN("GREATER_THAN","{0} > ''{1}''"),
	LESS_THAN("LESS_THAN","{0} < ''{1}''"),
	GREATER_THAN_OR_EQUAL_TO("GREATER_THAN_OR_EQUAL_TO","{0} >= ''{1}''"),
	LESS_THAN_OR_EQUAL_TO("LESS_THAN_OR_EQUAL_TO","{0} <= ''{1}''");
	
	private static final Map<String, OperatorsEnum> operators = new HashMap<>();
	
	static {
		for (OperatorsEnum constant : OperatorsEnum.class.getEnumConstants()) {
			operators.put(constant.name, constant);			
		}
	}

	private String name;
	private String operator;

	OperatorsEnum(String name, String operator) {
		this.name = name;
		this.operator = operator;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getOperator() {
		return operator;
	}

	public void setOperator(String operator) {
		this.operator = operator;
	}
	
	public static OperatorsEnum getOperators(final String name) {
		return operators.get(name);
	}

}
