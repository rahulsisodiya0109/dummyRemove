package io.spaceandtime.routing.controller.userProfile;

import java.util.List;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import io.spaceandtime.routing.controller.userData.UserDataController;
import io.spaceandtime.routing.ignitedao.UserProfileDAO;
import io.spaceandtime.routing.model.UserProfile;
import io.spaceandtime.routing.utils.ErrorResponse;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.media.ArraySchema;
import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.media.Schema;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.responses.ApiResponses;

@RestController
public class UserProfileController extends UserDataController {

	@Autowired
	private UserProfileDAO userProfileDao;

	@GetMapping(value = "/{userId}/profile")
	@Operation(summary = "Get User", description = "Get user profile")
	@ApiResponses(value = {
			@ApiResponse(responseCode = "200", description = "${api.response-codes.ok.desc}", content = @Content(array = @ArraySchema(schema = @Schema(implementation = UserProfile.class)))),
			@ApiResponse(responseCode = "401", description = "${api.response-codes.unauthorized.desc}", content = @Content(schema = @Schema(implementation = ErrorResponse.class)))})
	public List<UserProfile> getUserProfile(@PathVariable(value = "userId", required = true) String userId) {
		return userProfileDao.getUser(userId);
	}

	@PutMapping(path = "/{userId}/profile", consumes = { MediaType.APPLICATION_JSON_VALUE })
	@Operation(summary = "Add/Update User", description = "Add or update user profile")
	@ApiResponses(value = { @ApiResponse(responseCode = "204", description = "${api.response-codes.noContent.desc}"),
			@ApiResponse(responseCode = "401", description = "${api.response-codes.unauthorized.desc}", content = @Content(schema = @Schema(implementation = ErrorResponse.class))),
			@ApiResponse(responseCode = "403", description = "${api.response-codes.forbidden.desc}", content = @Content(schema = @Schema(implementation = ErrorResponse.class))) })
	public ResponseEntity<String> updateUserProfile(@PathVariable("userId") String userId,
			@Valid @RequestBody UserProfile userProfile) {
		userProfileDao.updateUserProfile(userId, userProfile);
		return new ResponseEntity<>(userId, HttpStatus.NO_CONTENT);
	}

	@DeleteMapping(value = "/{userId}/profile")
	@Operation(summary = "Delete User", description = "Delete user profile")
	@ApiResponses(value = { @ApiResponse(responseCode = "204", description = "${api.response-codes.noContent.desc}"),
			@ApiResponse(responseCode = "401", description = "${api.response-codes.unauthorized.desc}", content = @Content(schema = @Schema(implementation = ErrorResponse.class))),
			@ApiResponse(responseCode = "403", description = "${api.response-codes.forbidden.desc}", content = @Content(schema = @Schema(implementation = ErrorResponse.class))) })
	public ResponseEntity<String> deleteUserProfile(@PathVariable(value = "userId", required = true) String userId) {
		userProfileDao.deleteByUserId(userId);
		return new ResponseEntity<>(userId, HttpStatus.NO_CONTENT);
	}

}
