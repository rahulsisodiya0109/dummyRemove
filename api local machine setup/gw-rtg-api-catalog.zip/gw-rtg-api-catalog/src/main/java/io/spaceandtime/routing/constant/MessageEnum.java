package io.spaceandtime.routing.constant;

import org.springframework.http.HttpStatus;

import io.spaceandtime.routing.utils.BasePropertyEnum;

/**
 * 
 * @author GUVALA
 *
 */
public enum MessageEnum implements BasePropertyEnum {
	SYSTEMEXCEPTION("system.exception", HttpStatus.INTERNAL_SERVER_ERROR),
	BADREQUEST("bad.request", HttpStatus.BAD_REQUEST), UNEXPECTEDFAILURE("failure", HttpStatus.INTERNAL_SERVER_ERROR),
	NO_CLUSTER_DEFINED("no.clusters.defined", HttpStatus.FORBIDDEN),
	INVALID_ACCESSTYPE("invalid.accesstype", HttpStatus.FORBIDDEN),
	INVALID_DDLOPERATION("invalid.ddloperation", HttpStatus.FORBIDDEN),
	RESOURCEID_NOTVALID("resourceId.notvalid", HttpStatus.FORBIDDEN),
	RESOURCEID_NOTMAPPED("resourceId.notmapped", HttpStatus.FORBIDDEN),
	RESOURCEID_EMPTY("resourceId.empty", HttpStatus.FORBIDDEN),
	RESOURCEID_READONLY("resourceId.readonly", HttpStatus.CONFLICT),
	INVALID_VIEW("invalid.view", HttpStatus.BAD_REQUEST),
	VIEW_ALREADY_EXIST("view.already.exist", HttpStatus.BAD_REQUEST),
	VIEW_NOT_FOUND("view.not.found", HttpStatus.NOT_FOUND),
	INVALID_OWNERSHIP("invalid.ownership", HttpStatus.FORBIDDEN),
	INVALID_RESOURCEID("invalid.resourceId", HttpStatus.BAD_REQUEST),
	INVALID_SQLOPERATION("invalid.sqloperation", HttpStatus.BAD_REQUEST),
	USER_NOTVALID("userId.notvalid", HttpStatus.FORBIDDEN), TABLE_NOT_FOUND("table.notfound", HttpStatus.FORBIDDEN),
	TABLE_PUBLIC_KEY_INVALID("table.publickey.invalid", HttpStatus.UNAUTHORIZED),
	FAILED_DDL("failedddl", HttpStatus.UNAUTHORIZED),
	BADREQUESTEXCEPTION("badrequest.exception", HttpStatus.BAD_REQUEST),
	BLOCKCHAIN_TABLE_NOT_EXIST("bctable.notfound", HttpStatus.NOT_FOUND),
	USERID_NOT_FOUND("user.notfound", HttpStatus.NOT_FOUND),
	SXT_CLUSTER_NOT_CONFIGURED("sxt.cluster.notconfigured", HttpStatus.INTERNAL_SERVER_ERROR),
	INVALID_HTTP_REQUEST("invalid.httprequest", HttpStatus.BAD_REQUEST),
	IGNITE_SQL_EXCEPTION("sxt.sql.exception", HttpStatus.BAD_REQUEST),
	KEYDB_EXCEPTION("keydb.exception", HttpStatus.INTERNAL_SERVER_ERROR),
	UNAUTHORIZED_ACCESS("unauthorized.access", HttpStatus.UNAUTHORIZED),
	IGNITE_CLIENT_EXCEPTION("sxt.client.exception", HttpStatus.INTERNAL_SERVER_ERROR),
	INVALID_JSON_EXCEPTION("invalid.json.exception", HttpStatus.BAD_REQUEST),
	SLUG_ALREADY_EXIST("slug.already.exist", HttpStatus.BAD_REQUEST),
	WIDGET_NOT_FOUND("widget.notfound", HttpStatus.NOT_FOUND),
	VIEW_NAME_NOT_FOUND("viewname.notfound", HttpStatus.NOT_FOUND),
	SLUG_NOT_FOUND("slug.notfound", HttpStatus.NOT_FOUND),
	QUERYID_NOT_FOUND("query.notfound", HttpStatus.NOT_FOUND),
	INVALID_WIDGETTYPE("invalid.widgettype", HttpStatus.BAD_REQUEST), 
	INVALID_SORT_ORDER("invalid.sortorder", HttpStatus.BAD_REQUEST),
	FAILED_VIEW_OPERATION("failed.view.operation", HttpStatus.BAD_REQUEST),
	FAILED_VIEW_DELETION("failed.view.deletion", HttpStatus.BAD_REQUEST),
	INVALID_CHAINID("invalid.chainid", HttpStatus.BAD_REQUEST),
	SUBSCRIPTION_NOT_FOUND("subscription.notfound", HttpStatus.NOT_FOUND),
	INVALID_TAG_TYPE("invalid.tagtype", HttpStatus.FORBIDDEN),
	DASHBOARD_NOT_FOUND("dashboard.not.found", HttpStatus.NOT_FOUND);


	public String messageCode;

	public final HttpStatus status;

	public String bundleName = "io.spaceandtime.routing.messages";

	MessageEnum(String messageCode, HttpStatus status) {
		this.messageCode = messageCode;
		this.status = status;
	}

	@Override
	public String getBundle() {
		return bundleName;
	}

	public String getMessageCode() {
		return messageCode;
	}

	public HttpStatus getStatus() {
		return status;
	}

}
