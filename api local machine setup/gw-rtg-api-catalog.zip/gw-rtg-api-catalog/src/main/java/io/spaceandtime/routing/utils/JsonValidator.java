package io.spaceandtime.routing.utils;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

public class JsonValidator {

	private JsonValidator() {

	}

	public static boolean isValidJson(String json) {
		try {
			new JSONObject(json);
		} catch (JSONException e) {
			try {
				new JSONArray(json);
			} catch (JSONException je) {
				return false;
			}
		}
		return true;
	}

}