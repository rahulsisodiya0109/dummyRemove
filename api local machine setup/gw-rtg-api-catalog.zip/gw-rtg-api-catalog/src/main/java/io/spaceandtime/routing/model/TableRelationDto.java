package io.spaceandtime.routing.model;

import java.sql.Timestamp;
import java.util.List;

public class TableRelationDto {

	private String table;

	private String namespace;

	private String publicKey;

	private Boolean immutable;

	private String accessType;

	private Boolean encrypted;

	private Boolean tamperproof;

	private Timestamp lastAnchored;

	private String size;

	private List<TableColumnDto> tableColumn;

	public String getTable() {
		return table;
	}

	public void setTable(String table) {
		this.table = table;
	}

	public String getNamespace() {
		return namespace;
	}

	public void setNamespace(String namespace) {
		this.namespace = namespace;
	}

	public String getPublicKey() {
		return publicKey;
	}

	public void setPublicKey(String publicKey) {
		this.publicKey = publicKey;
	}

	public Boolean getImmutable() {
		return immutable;
	}

	public void setImmutable(Boolean immutable) {
		this.immutable = immutable;
	}

	public String getAccessType() {
		return accessType;
	}

	public void setAccessType(String accessType) {
		this.accessType = accessType;
	}

	public Boolean getEncrypted() {
		return encrypted;
	}

	public void setEncrypted(Boolean encrypted) {
		this.encrypted = encrypted;
	}

	public Boolean getTamperproof() {
		return tamperproof;
	}

	public void setTamperproof(Boolean tamperproof) {
		this.tamperproof = tamperproof;
	}

	public Timestamp getLastAnchored() {
		return lastAnchored;
	}

	public void setLastAnchored(Timestamp lastAnchored) {
		this.lastAnchored = lastAnchored;
	}

	public String getSize() {
		return size;
	}

	public void setSize(String size) {
		this.size = size;
	}

	public List<TableColumnDto> getTableColumn() {
		return tableColumn;
	}

	public void setTableColumn(List<TableColumnDto> tableColumn) {
		this.tableColumn = tableColumn;
	}

}
