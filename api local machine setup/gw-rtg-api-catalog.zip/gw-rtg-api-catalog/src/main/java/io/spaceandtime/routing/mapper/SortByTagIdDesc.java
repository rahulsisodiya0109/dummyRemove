package io.spaceandtime.routing.mapper;

import java.util.Comparator;

import io.spaceandtime.routing.modelignite.Tag;

public class SortByTagIdDesc implements Comparator<Tag> {

	@Override
	public int compare(Tag tag1, Tag tag2) {
		return tag2.getTagId().compareTo(tag1.getTagId());
	}

}
