package io.spaceandtime.routing.ignitedao;

import java.util.List;
import java.util.Map;

import io.spaceandtime.routing.constant.SortOrderEnum;
import io.spaceandtime.routing.constant.StatusEnum;
import io.spaceandtime.routing.model.SRCViewDto;
import io.spaceandtime.routing.modelignite.SRCView;
import io.spaceandtime.routing.utils.Page;

public interface ViewDAO {

	void createViewSrc(SRCView srcView);

	List<Map<String, Object>> getViewSrc(String viewId, String viewName);

	void deleteViewSrc(String viewName);

	void updateViewSrc(SRCView srcView);

	void updateViewSrcById(SRCView srcView);

	List<SRCView> getViewById(String viewId);

	void executeUpdateView(SRCView srcView, String updatedViewName);

	void executeCreateView(SRCView srcView);

	Page<SRCViewDto> getViewList(String name, Boolean isPublic, int pageNo, int pageSize, SortOrderEnum sortOrder, String sortBy, String tagId, StatusEnum status);

	List<SRCView> getViewData(List<Map<String, Object>> srcViewMap);

	void checkViewAuthorization(String viewId);

	boolean isViewNameExist(String id, String requestedViewName);
}
