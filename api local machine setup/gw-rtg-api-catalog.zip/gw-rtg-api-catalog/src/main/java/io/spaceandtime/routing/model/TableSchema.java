package io.spaceandtime.routing.model;

import java.util.Objects;

import com.fasterxml.jackson.annotation.JsonIgnore;

public class TableSchema {

	private String name;

	private String dataType;
	
	@JsonIgnore
	private Boolean nullable;
	
	@JsonIgnore
	private String defaultValue;
	
	@JsonIgnore
	private Integer precision = -1;
	
	@JsonIgnore
	private Integer scale = -1;
	
	@JsonIgnore
	private Boolean primaryKey = false;
	
	@JsonIgnore
	private Integer primaryKeySeq = -1;

	public TableSchema() {

	}

	public TableSchema(String name, String dataType) {
		super();
		this.name = name;
		this.dataType = dataType;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getDataType() {
		return dataType;
	}

	public void setDataType(String dataType) {
		this.dataType = dataType;
	}
	
	public Boolean getNullable() {
		return nullable;
	}

	public void setNullable(Boolean nullable) {
		this.nullable = nullable;
	}

	public String getDefaultValue() {
		return defaultValue;
	}

	public void setDefaultValue(String defaultValue) {
		this.defaultValue = defaultValue;
	}
	
	public Integer getPrecision() {
		return precision;
	}

	public void setPrecision(Integer precision) {
		this.precision = precision;
	}

	public Integer getScale() {
		return scale;
	}

	public void setScale(Integer scale) {
		this.scale = scale;
	}
	
	public Boolean getPrimaryKey() {
		return primaryKey;
	}

	public void setPrimaryKey(Boolean primaryKey) {
		this.primaryKey = primaryKey;
	}

	public Integer getPrimaryKeySeq() {
		return primaryKeySeq;
	}

	public void setPrimaryKeySeq(Integer primaryKeySeq) {
		this.primaryKeySeq = primaryKeySeq;
	}

	@Override
	public int hashCode() {
		return Objects.hash(name);
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		TableSchema other = (TableSchema) obj;
		return Objects.equals(name, other.name);
	}

}
