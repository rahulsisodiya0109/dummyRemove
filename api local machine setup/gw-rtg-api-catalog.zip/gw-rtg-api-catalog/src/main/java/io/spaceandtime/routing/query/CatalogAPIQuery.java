package io.spaceandtime.routing.query;

/**
 * 
 * @author Nilesh Sharma
 *
 */
public class CatalogAPIQuery {

	public final static String INDEX = "index";
	public final static String NAMESPACE = "namespace";
	public final static String TABLE_NAME = "table";
	public final static String COLUMN_ID = "columnId";
	public final static String COLUMN = "column";
	public final static String POSITION = "position";
	public final static String COLUMNSCOUNT = "COLUMNSCOUNT";
	public final static String PK_COUNT = "PK_COUNT";
	public final static String VIEW_NAME = "viewName";
	public final static String VIEW_ID = "viewId";
	public final static String TABLE_COLUMN_COUNT = "TABLE_COLUMN_COUNT";

	public final static String GET_SCHEMAS = "SELECT * from SXT_PRM.SXT_SCHEMA ";

	public final static String GET_TABLES = "SELECT * from SXT_PRM.SXT_TABLE tab ";

	public final static String GET_TABLECOLUMNS = "SELECT * from SXT_PRM.SXT_TABLE_COLUMN ";

	public final static String GET_INDEX = "SELECT * from SXT_PRM.SXT_INDEX ";

	public final static String GET_SXT_FKEY = "SELECT * from SXT_PRM.SXT_FKEY ";

	public final static String TABLE_RELATION_FOR_PK = "SELECT tab.TABLE_ID,tab.SCHEMA_ID,tab.PUBLIC_KEY,tab.IMMUTABLE,tab.ACCESS_TYPE,tab.SIZE,tab.ENCRYPTED,tab.TAMPERPROOF,tab.CREATED,col.COLUMN_ID,col.DATA_TYPE,col.PRIMARY_KEY_SEQ,fkeys.PK_COLUMN_ID, fkeys.PK_TABLE_ID,fkeys.FK_COLUMN_ID,fkeys.FK_TABLE_ID,fkeys.FK_SCHEMA_ID, fkeys.CARDINALITY from SXT_PRM.SXT_TABLE tab join SXT_PRM.SXT_TABLE_COLUMN col on tab.TABLE_ID = col.TABLE_ID and tab.SCHEMA_ID= col.SCHEMA_ID left join SXT_PRM.SXT_FKEY fkeys on fkeys.PK_COLUMN_ID = col.COLUMN_ID and fkeys.PK_TABLE_ID = tab.TABLE_ID and fkeys.PK_SCHEMA_ID = tab.SCHEMA_ID";

	public final static String GET_VIEW_BY_ID = "SELECT * FROM  SXT_PRM.SXT_VIEW WHERE ID='${ID}'";

	public final static String TABLE_RELATION_FOR_FK = " SELECT tab.TABLE_ID, tab.SCHEMA_ID,tab.PUBLIC_KEY,tab.IMMUTABLE,tab.ACCESS_TYPE,tab.SIZE,tab.ENCRYPTED,tab.TAMPERPROOF,tab.CREATED,col.COLUMN_ID,col.DATA_TYPE,col.PRIMARY_KEY_SEQ,fkeys.PK_COLUMN_ID,fkeys.PK_TABLE_ID,fkeys.FK_COLUMN_ID,fkeys.FK_TABLE_ID,fkeys.FK_SCHEMA_ID, fkeys.CARDINALITY from SXT_PRM.SXT_TABLE tab join SXT_PRM.SXT_TABLE_COLUMN col on tab.TABLE_ID = col.TABLE_ID and tab.SCHEMA_ID= col.SCHEMA_ID left join SXT_PRM.SXT_FKEY fkeys on fkeys.FK_COLUMN_ID = col.COLUMN_ID and fkeys.FK_TABLE_ID = tab.TABLE_ID and fkeys.PK_SCHEMA_ID = tab.SCHEMA_ID";

	public final static String GET_USER = "SELECT * from SXT_USER.USER_PROFILE ";

	public final static String UPDATE_USER = "MERGE INTO SXT_USER.USER_PROFILE (USER_ID,USER_NAME, DISPLAY_NAME, EMAIL_ADDR, BIO, SETTINGS) VALUES(?,?,?, ?, ?, ?)";

	public final static String DELETE_USER = "DELETE FROM SXT_USER.USER_PROFILE ";

	public final static String GET_QUERY_HISTORY = "SELECT * FROM SXT_STATE.QUERY_HISTORY ";

	public final static String GET_QUERY_HISTORY_COUNT = "SELECT COUNT(*) AS COUNT FROM SXT_STATE.QUERY_HISTORY ";

	public final static String GET_SAVEDQUERY = "SELECT * from SXT_ENT.QUERY ";

	public final static String GET_SAVEDQUERY_COUNT = "SELECT COUNT(*) AS COUNT from SXT_ENT.QUERY ";

	public final static String GET_SAVEDQUERY_AND_TAGS = "SELECT * from SXT_ENT.QUERY query LEFT JOIN SXT_ENT.TAG_RELATION tag_relation on query.id = tag_relation.ENT_ID and tag_relation.ENT_TYPE = 'SAVEDQUERY' JOIN SXT_ENT.TAG tag on tag.ID = tag_relation.TAG_ID ";

	public final static String GET_TAGS = "SELECT * from SXT_ENT.TAG AS t ";

	public final static String GET_TAG_RELATION = "SELECT * from SXT_ENT.TAG_RELATION AS tr ";

	public final static String GET_TAGS_FOR_ENTITY = "SELECT tr.TAG_ID,tr.ENT_ID,tr.ENT_TYPE,t.ID,t.TAG_ID,t.METADATA FROM SXT_ENT.TAG_RELATION tr JOIN SXT_ENT.TAG t ON tr.TAG_ID = t.ID ";

	public static final String CREATE_SAVEDQUERY = "INSERT INTO SXT_ENT.QUERY (ID, VIEW_ID, QUERY_NAME, OWNER_ID, RESOURCE_ID, QUERY_TEXT, DESCRIPTION, PARAMETERS, MODIFIED) VALUES(${id}, ${viewId},${queryName},${ownerId},${resourceId},${queryText},${description},${parameters},${modified})";

	public static final String CREATE_TAG = "INSERT INTO SXT_ENT.TAG (ID, TAG_ID, METADATA) VALUES(${id}, ${tagId}, ${metadata})";

	public static final String CREATE_TAG_RELATION = "INSERT INTO SXT_ENT.TAG_RELATION (TAG_ID, ENT_ID, ENT_TYPE) VALUES(${tagId}, ${entId}, ${entType})";

	public static final String UPDATE_SAVEDQUERY = "UPDATE SXT_ENT.QUERY SET QUERY_NAME=${queryName},QUERY_TEXT=${queryText},DESCRIPTION=${description},RESOURCE_ID=${resourceId},PARAMETERS=${parameters},MODIFIED=${modified},VIEW_ID=${viewId} WHERE ID=${id}";

	public final static String CREATE_WIDGET = "INSERT INTO SXT_ENT.WIDGET (ID,WIDGET_NAME,WIDGET_TYPE,OWNER_ID,DESCRIPTION,METADATA,MODIFIED,ISPUBLIC,VIEW_ID,SLUG ) VALUES(${id},${widgetName}, ${widgetType}, ${ownerId}, ${description},${metadata},${modified},${isPublic},${viewId},${slug})";

	public final static String UPDATE_WIDGET = "UPDATE SXT_ENT.WIDGET SET WIDGET_NAME=${widgetName},WIDGET_TYPE=${widgetType},DESCRIPTION=${description},METADATA=${metadata},MODIFIED=${modified} WHERE ID=${id}";

	public final static String GET_WIDGET = "SELECT * from SXT_ENT.WIDGET AS w ";

	public final static String GET_WIDGET_COUNT = "SELECT COUNT(*) AS COUNT from SXT_ENT.WIDGET AS w ";

	public final static String DELETE_WIDGET = "DELETE FROM SXT_ENT.WIDGET ";

	public final static String GET_DASHBOARD = "SELECT * FROM SXT_ENT.DASHBOARD AS d ";

	public final static String GET_DASHBOARD_COUNT = "SELECT COUNT(*) AS COUNT FROM SXT_ENT.DASHBOARD AS d ";

	public final static String CREATE_DASHBOARD = "INSERT INTO SXT_ENT.DASHBOARD (ID, DASH_NAME, DESCRIPTION, OWNER_ID, METADATA, MODIFIED, ISPUBLIC, SLUG, DESCRIPTION_TITLE) VALUES(${id},${dashName}, ${description}, ${ownerId},${metadata},${modified},${isPublic},${slug},${descriptionTitle}) ";

	public final static String UPDATE_DASHBOARD = "UPDATE SXT_ENT.DASHBOARD SET DASH_NAME=${dashName},DESCRIPTION=${description},METADATA=${metadata},MODIFIED=${modified},DESCRIPTION_TITLE=${descriptionTitle} WHERE ID=${id} ";

	public final static String DELETE_DASHBOARD = "DELETE FROM SXT_ENT.DASHBOARD ";

	public final static String GET_DASHBOARDWIDGET = "SELECT * FROM SXT_ENT.DASHBOARD_WIDGET ";

	public final static String CREATE_DASHBOARD_WIDGET = "INSERT INTO SXT_ENT.DASHBOARD_WIDGET (DASHBOARD_ID, WIDGET_ID, METADATA) VALUES (${dashboardId},${widgetId},${metadata}) ";

	public final static String DELETE_DASHBOARD_WIDGET = "DELETE FROM SXT_ENT.DASHBOARD_WIDGET ";

	public final static String REMOVE_TAG_RELATION = "DELETE FROM SXT_ENT.TAG_RELATION ";

	public final static String DELETE_SAVEDQUERY = "DELETE FROM SXT_ENT.QUERY";

	public final static String GET_POPULAR_TAGS = "SELECT COUNT(*) AS COUNT,t.ID,t.TAG_ID,t.METADATA FROM SXT_ENT.TAG_RELATION tr JOIN SXT_ENT.TAG t ON tr.TAG_ID = t.ID ";

	public final static String INSERT_VIEW = "INSERT INTO SXT_PRM.SXT_VIEW (ID,CATALOG_ID,SCHEMA_ID,VIEW_NAME, OWNER_ID,RESOURCE_ID,VIEW_TEXT,DESCRIPTION,PARAMETERS,ISPUBLIC,MODIFIED) VALUES(?,?,?,?,?,?,?,?,?,?,?)";

	public final static String DELETE_VIEW = "DELETE FROM SXT_PRM.SXT_VIEW WHERE VIEW_NAME='${viewName}'";

	public final static String GET_ALL_VIEW = "SELECT * FROM  SXT_PRM.SXT_VIEW AS v ";

	public final static String COUNT_VIEW = "SELECT COUNT(*) AS COUNT FROM  SXT_PRM.SXT_VIEW AS v ";

	public final static String UPDATE_VIEW = "UPDATE SXT_PRM.SXT_VIEW SET  DESCRIPTION=${description}, VIEW_TEXT=${viewText}, RESOURCE_ID=${resourceId},ISPUBLIC=${isPublic}, PARAMETERS=${parameters},MODIFIED=${modified} WHERE VIEW_NAME=${viewName}";

	public final static String UPDATE_VIEW_BY_ID = "UPDATE SXT_PRM.SXT_VIEW SET VIEW_NAME=?, DESCRIPTION=?, VIEW_TEXT=?, RESOURCE_ID=?,ISPUBLIC=?, PARAMETERS=? ,MODIFIED=?,SCHEMA_ID=? WHERE ID=?";

	public final static String PUBLISH_DASHBOARD = "UPDATE SXT_ENT.DASHBOARD SET MODIFIED=${modified},ISPUBLIC=${isPublic},SLUG=${slug} WHERE ID=${id} ";

	public final static String PUBLISH_WIDGET = "UPDATE SXT_ENT.WIDGET SET MODIFIED=${modified},ISPUBLIC=${isPublic},SLUG=${slug},VIEW_ID=${viewId} WHERE ID=${id}";

	public final static String GET_BLOCKCHAINS = "SELECT DISTINCT CHAIN_ID FROM SXT_PRM.SXT_CHAINS";

	public static final String GET_NAMESPACES = "SELECT * FROM SXT_PRM.SXT_CHAINS";

	public static final String GET_DASHBOARD_BY_TAG = "SELECT d.ID, d.DASH_NAME, d.DESCRIPTION, d.OWNER_ID, d.METADATA, d.MODIFIED, d.ISPUBLIC, d.SLUG, d.DESCRIPTION_TITLE  FROM SXT_ENT.TAG_RELATION AS tr INNER JOIN SXT_ENT.TAG AS t ON tr.TAG_ID = t.ID INNER JOIN SXT_ENT.DASHBOARD AS d ON tr.ENT_ID = d.ID ";

	public static final String GET_DASHBOARD_COUNT_BY_TAG = "SELECT COUNT(*) AS COUNT FROM SXT_ENT.TAG_RELATION AS tr INNER JOIN SXT_ENT.TAG AS t ON tr.TAG_ID = t.ID INNER JOIN SXT_ENT.DASHBOARD AS d ON tr.ENT_ID = d.ID ";

	public static final String GET_WIDGET_BY_TAG = "SELECT w.ID, w.WIDGET_NAME, w.WIDGET_TYPE, w.OWNER_ID,w.DESCRIPTION, w.METADATA, w.MODIFIED, w.ISPUBLIC, w.VIEW_ID, w.SLUG  FROM SXT_ENT.TAG_RELATION AS tr INNER JOIN SXT_ENT.TAG AS t ON tr.TAG_ID = t.ID INNER JOIN SXT_ENT.WIDGET AS w ON tr.ENT_ID = w.ID ";

	public static final String GET_WIDGET_COUNT_BY_TAG = "SELECT COUNT(*) AS COUNT FROM SXT_ENT.TAG_RELATION AS tr INNER JOIN SXT_ENT.TAG AS t ON tr.TAG_ID = t.ID INNER JOIN SXT_ENT.WIDGET AS w ON tr.ENT_ID = w.ID ";

	public static final String GET_VIEW_BY_TAG = "SELECT v.ID, v.CATALOG_ID, v.SCHEMA_ID, v.VIEW_NAME, v.OWNER_ID, v.RESOURCE_ID, v.VIEW_TEXT, v.DESCRIPTION, v.PARAMETERS, v.ISPUBLIC FROM SXT_ENT.TAG_RELATION AS tr INNER JOIN SXT_ENT.TAG AS t ON tr.TAG_ID = t.ID INNER JOIN SXT_PRM.SXT_VIEW AS v ON tr.ENT_ID = v.ID ";

	public static final String GET_VIEW_COUNT_BY_TAG = "SELECT COUNT(*) AS COUNT FROM SXT_ENT.TAG_RELATION AS tr INNER JOIN SXT_ENT.TAG AS t ON tr.TAG_ID = t.ID INNER JOIN SXT_PRM.SXT_VIEW AS v ON tr.ENT_ID = v.ID ";

}
