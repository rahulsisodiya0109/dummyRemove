package io.spaceandtime.routing.ignitedao;

import static io.spaceandtime.routing.constant.ColumnConstant.CLONE;

import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Map;
import java.util.UUID;
import java.util.stream.Collectors;

import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import io.spaceandtime.routing.constant.ColumnConstant;
import io.spaceandtime.routing.constant.MessageEnum;
import io.spaceandtime.routing.constant.SortOrderEnum;
import io.spaceandtime.routing.constant.StatusEnum;
import io.spaceandtime.routing.constant.WidgetTypeEnum;
import io.spaceandtime.routing.errorHandler.AppException;
import io.spaceandtime.routing.jdbcdao.BaseIgniteSqlDAOImpl;
import io.spaceandtime.routing.logging.AppLogger;
import io.spaceandtime.routing.logging.Log;
import io.spaceandtime.routing.mapper.SRCMapper;
import io.spaceandtime.routing.mapper.SortByTagIdAsc;
import io.spaceandtime.routing.mapper.SortByTagIdDesc;
import io.spaceandtime.routing.model.WidgetDto;
import io.spaceandtime.routing.modelignite.SRCView;
import io.spaceandtime.routing.modelignite.Widget;
import io.spaceandtime.routing.query.CatalogAPIQuery;
import io.spaceandtime.routing.ro.TagRequest;
import io.spaceandtime.routing.ro.ViewRequest;
import io.spaceandtime.routing.ro.WidgetRequest;
import io.spaceandtime.routing.service.ViewService;
import io.spaceandtime.routing.utils.AppUtils;
import io.spaceandtime.routing.utils.Page;
import jodd.util.StringUtil;

/**
 * 
 * @author Nilesh Sharma
 *
 */
@Component
public class WidgetDAOImpl extends BaseIgniteSqlDAOImpl implements WidgetDAO {

	private static @Log AppLogger logger;

	@Autowired
	private ViewService viewService;

	@Override
	public Page<WidgetDto> getAllWidgets(Boolean isPublic, String viewId, String searchKeyword, int pageNo,
			int pageSize, SortOrderEnum sortOrder, String sortBy, WidgetTypeEnum widgetTypeEnum, String tagId,
			StatusEnum status) {

		String qryText = CatalogAPIQuery.GET_WIDGET;
		String qryCounts = CatalogAPIQuery.GET_WIDGET_COUNT;
		List<String> filters = new ArrayList<>();
		filters.add("WIDGET_TYPE = '" + widgetTypeEnum + "'");
		// filtering by queryId
		if (viewId != null)
			filters.add("VIEWID = '" + viewId + "'");
		if (!StringUtil.isAllBlank(searchKeyword))
			filters.add("LOWER(w.WIDGET_NAME) LIKE LOWER(CONCAT('%', '" + searchKeyword + "', '%'))");
		if (tagId != null) {
			qryText = CatalogAPIQuery.GET_WIDGET_BY_TAG;
			qryCounts = CatalogAPIQuery.GET_WIDGET_COUNT_BY_TAG;
			filters.add("t.TAG_ID = '" + tagId + "'");
		}
		// Filtering by isPublic
		if (isPublic) {
			filters.add(" ISPUBLIC = TRUE");
		} else {
			if (viewId != null)
				throw new AppException(MessageEnum.BADREQUEST);
			addStatusFilter(status, filters);
		}
		if (!filters.isEmpty()) {
			qryText += "WHERE " + String.join(" AND ", filters);
			qryCounts += "WHERE " + String.join(" AND ", filters);
		}
		int count = getTotalRecords(qryCounts);
		logger.info("total records: " + count);
		qryText = buildPaginatedQuery(pageNo, pageSize, sortOrder, buildSortByColumnName(sortBy), qryText);
		List<Map<String, Object>> widgetList = getPlatformEntitiesData(qryText);
		List<WidgetDto> widgetDtos = getWidgetData(widgetList);
		if (sortOrder.getSortOrder().equalsIgnoreCase(ColumnConstant.ASCENDING_ORDER)) {
			if (sortOrder.getSortOrder().equalsIgnoreCase(ColumnConstant.ASCENDING_ORDER)) {
				for (WidgetDto widgetDto : widgetDtos) {
					Collections.sort(widgetDto.getTags(), new SortByTagIdAsc());
				}
			} else {
				for (WidgetDto widgetDto : widgetDtos) {
					Collections.sort(widgetDto.getTags(), new SortByTagIdDesc());
				}
			}
		}
		return pageableContent(pageNo, pageSize, count, widgetDtos);
	}

	private List<WidgetDto> getWidgetData(List<Map<String, Object>> widgetList) {
		List<WidgetDto> widgetDto = widgetList.stream()
				.map(sq -> SRCMapper.mapWidgetData(sq,
						getTagRelationByEntityId((String) sq.get(ColumnConstant.ID), ColumnConstant.WIDGET)))
				.collect(Collectors.toList());
		return widgetDto;
	}

	@Override
	public String createWidget(WidgetRequest widgetRequest) {
		validateInput(widgetRequest);
		String userId = getUserId();
		Timestamp modified = new Timestamp(System.currentTimeMillis());
		checkValidJsonInMetadata(widgetRequest.getMetadata());
		Widget widget = SRCMapper.getWidget(widgetRequest);
		String id = UUID.randomUUID().toString();
		widget.setId(id);
		widget.setModified(modified);
		widget.setOwnerId(userId);
		widget.setIsPublic(false);
		String srcSql = parseQuery(Widget.class, widget, CatalogAPIQuery.CREATE_WIDGET);
		executeDML(srcSql);
		if (widgetRequest.getTags() != null)
			for (TagRequest tag : widgetRequest.getTags())
				saveNewTagAndTagRelation(tag, widget.getId(), ColumnConstant.WIDGET);
		return id;
	}

	private void validateInput(WidgetRequest widgetRequest) {
		if (widgetRequest.getViewId() == null)
			throw new AppException(MessageEnum.BADREQUEST);
	}

	@Override
	public void updateWidget(String widgetId, WidgetRequest widgetRequest) {
		validateInput(widgetRequest);
		String userId = getUserId();
		checkWidgetAuthorization(widgetId, userId);
		String qryText = CatalogAPIQuery.UPDATE_WIDGET;
		checkValidJsonInMetadata(widgetRequest.getMetadata());
		Widget widget = SRCMapper.getWidget(widgetRequest);
		Timestamp modified = new Timestamp(System.currentTimeMillis());
		widget.setModified(modified);
		widget.setId(widgetId);
		String srcSql = parseQuery(Widget.class, widget, qryText);
		executeDML(srcSql);
		if (widgetRequest.getTags() != null) {
			removeExistingTagsForEntity(widgetId, ColumnConstant.WIDGET);
			for (TagRequest tag : widgetRequest.getTags())
				saveNewTagAndTagRelation(tag, widget.getId(), ColumnConstant.WIDGET);
		}
	}

	@Override
	public void deleteWidget(String widgetId) {
		String userId = getUserId();
		checkWidgetAuthorization(widgetId, userId);
		String qryText = CatalogAPIQuery.DELETE_WIDGET;
		qryText = qryText + " WHERE ID='" + widgetId + "';";
		executeDML(qryText);
		// deleting widget from dashboard-widget mapping table
		deleteDashboardWidget(widgetId);
	}

	private void deleteDashboardWidget(String widgetId) {
		String qryText = CatalogAPIQuery.DELETE_DASHBOARD_WIDGET;
		qryText = qryText + " WHERE WIDGET_ID='" + widgetId + "';";
		executeDML(qryText);
	}

	@Override
	public void checkWidgetAuthorization(String widgetId, String userId) {
		String qryText = CatalogAPIQuery.GET_WIDGET_COUNT;
		List<String> filters = new ArrayList<>();
		filters.add("OWNER_ID = '" + userId + "'");
		filters.add("ID = '" + widgetId + "'");
		int totalRecords = getTotalRecords(qryText);
		if (totalRecords == 0)
			throw new AppException(MessageEnum.BADREQUEST);
	}

	@Override
	public List<WidgetDto> getWidgetById(String widgetId, Boolean isPublic) {
		checkUserAuthorization(isPublic);
		String qryText = CatalogAPIQuery.GET_WIDGET;
		qryText += " WHERE ID ='" + widgetId + "'";
		List<Map<String, Object>> widgetList = getPlatformEntitiesData(qryText);
		return getWidgetData(widgetList);
	}

	@Override
	public void publishWidget(String widgetId, String requestSlug) throws Exception {
		String userId = getUserId();
		checkWidgetAuthorization(widgetId, userId);

		WidgetDto widget = getWidgetById(widgetId, true).stream().findFirst().orElse(null);

		if (widget == null) {
			throw new AppException(MessageEnum.WIDGET_NOT_FOUND);
		}

		if (widget.getIsPublic()) {
			// Scenario 2 - Widget already published (ISPUBLICcolumn is true)
			logger.info("Widget is already published id=" + widget.getId());
		} else {
			// Scenario 1 - Widget never published before (ISPUBLIC column is false)
			// checking if slug not provided (in case of adding in to published dashboard)
			// then auto generate it.
			String slug = requestSlug != null ? requestSlug : AppUtils.getUUID();
			// slug parameter must not be null, else throw error
			// Validate first that the slug is not in use (i.e., is unique)
			validateSlugForWidget(slug);
			publishNewWidget(widget, slug);

		}
	}

	private void publishNewWidget(WidgetDto widget, String requestSlug) throws Exception {

		// Scenario 1 - Widget never published before (ISPUBLICcolumn is false)
		SRCView srcView = viewService.getViewById(widget.getViewId()).isEmpty() ? null
				: viewService.getViewById(widget.getViewId()).get(0);
		// if view is not public then publishing it
		if (srcView != null && !srcView.getIsPublic()) {
			viewService.publishView(widget.getViewId());
		}
		// publishing widget
		widget.setSlug(requestSlug);
		publishWidget(widget);
	}

	private void validateSlugForWidget(String requestSlug) {
		if (StringUtils.isAllBlank(requestSlug))
			throw new AppException(MessageEnum.BADREQUEST);

		String qryText = CatalogAPIQuery.GET_WIDGET_COUNT;
		qryText += " WHERE SLUG='" + requestSlug + "';";
		logger.info("Slug validation SQL=" + qryText);

		int totalRecords = getTotalRecords(qryText);
		if (totalRecords != 0)
			throw new AppException(MessageEnum.SLUG_ALREADY_EXIST);

	}

	private void publishWidget(WidgetDto widget) {
		String userId = getUserId();
		checkWidgetAuthorization(widget.getId(), userId);
		String qryText = CatalogAPIQuery.PUBLISH_WIDGET;
		Timestamp modified = new Timestamp(System.currentTimeMillis());
		widget.setIsPublic(true);
		widget.setModified(modified);
		String srcSql = parseQuery(WidgetDto.class, widget, qryText);
		executeDML(srcSql);
	}

	@Override
	public String forkWidget(String slug) throws Exception {
		WidgetDto widget = getWidgetBySlug(slug).isEmpty() ? null : getWidgetBySlug(slug).get(0);
		return processWidgetForking(widget);
	}

	@Override
	public String processWidgetForking(WidgetDto widget) throws Exception {
		String forkedWidgetId = null;
		// Authorization: fail if the ISPUBLIC flag is false (only publicly-available
		// widgets can be forked)
		if (widget.getIsPublic()) {

			String viewId = widget.getViewId();
			// First clone the backing View via already implemented APIs and hold on to the
			// Query ID

			SRCView srcView = viewService.getViewById(viewId).isEmpty() ? null : viewService.getViewById(viewId).get(0);
			if (srcView != null) {
				ViewRequest viewRequest = SRCMapper.getViewRequest(srcView.getId(), srcView.getViewName(),
						srcView.getOwnerId(), srcView.getViewText(), srcView.getDescription(), srcView.getResourceId(),
						srcView.getParameters());
				viewRequest.setViewName(viewRequest.getViewName() + CLONE);
				String forkedViewID = viewService.createView(viewRequest);
				widget.setViewId(forkedViewID);
			}
			forkedWidgetId = UUID.randomUUID().toString();
			forkWidget(forkedWidgetId, widget);
			// leave the VIEW_ID column empty (i.e. the fork shouldn’t map to the original)
			// and set the QUERY_ID = the returned Query ID

		} else {
			throw new AppException(MessageEnum.BADREQUEST);
		}
		return forkedWidgetId;
	}

	private List<WidgetDto> getWidgetBySlug(String requestSlug) {
		if (requestSlug.isBlank())
			throw new AppException(MessageEnum.BADREQUEST);

		String qryText = CatalogAPIQuery.GET_WIDGET;
		qryText += " WHERE SLUG='" + requestSlug + "';";
		List<Map<String, Object>> widgetList = getPlatformEntitiesData(qryText);
		return getWidgetData(widgetList);
	}

	private void forkWidget(String forkedWidgetId, WidgetDto widget) {
		widget.setId(forkedWidgetId);
		widget.setIsPublic(false);
		widget.setSlug(null);
		widget.setViewId(null);
		String srcSql = parseQuery(WidgetDto.class, widget, CatalogAPIQuery.CREATE_WIDGET);
		executeDML(srcSql);
	}
}
