package io.spaceandtime.routing.utils;

import java.util.List;

public class PaginationUtil {

	public static Pageable getPageableObject(int pageNo, int pageSize, int count, int numberOfElements) {
		Pageable pageable = new Pageable();
		pageable.setNumberOfElements(numberOfElements);
		pageable.setTotalElements(count);
		pageable.setNumber(pageNo);
		pageable.setSize(pageSize);
		pageable.setTotalPages((int) Math.ceil((float) count / (pageSize)));
		pageable.setFirst((pageNo - 1) * pageSize == 0 ? true : false);
		pageable.setLast(pageable.getTotalPages() == pageNo ? true : false);
		pageable.setEmpty(pageable.getNumberOfElements() == 0 ? true : false);
		return pageable;
	}
	
	public static <T> List<T> getSubList(List<T> list, int pageNo, int pageSize) {
	    int startIndex = (pageNo - 1) * pageSize;
	    int endIndex = Math.min(startIndex + pageSize, list.size());
	    return list.subList(startIndex, endIndex);
    }

}