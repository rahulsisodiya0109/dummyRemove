package io.spaceandtime.routing.utils;

public class ErrorResponse {

	private String title;

	private String detail;

	private String instance;

	private String type;

	public ErrorResponse(String title, String detail) {
		super();

		this.title = title;
		this.detail = detail;
	}

	public ErrorResponse() {
		super();
	}

	public String getTitle() {
		return title;
	}

	public void setTitle(String title) {
		this.title = title;
	}

	public String getDetail() {
		return detail;
	}

	public void setDetail(String detail) {
		this.detail = detail;
	}

	public String getInstance() {
		return instance;
	}

	public void setInstance(String instance) {
		this.instance = instance;
	}

	public String getType() {
		return type;
	}

	public void setType(String type) {
		this.type = type;
	}

}
