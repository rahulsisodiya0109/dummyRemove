package io.spaceandtime.routing.controller.platformEntities;

import java.util.List;
import java.util.UUID;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import io.spaceandtime.routing.constant.ColumnConstant;
import io.spaceandtime.routing.constant.EnvironmentConstant;
import io.spaceandtime.routing.constant.MessageEnum;
import io.spaceandtime.routing.constant.SortOrderEnum;
import io.spaceandtime.routing.constant.StatusEnum;
import io.spaceandtime.routing.errorHandler.AppException;
import io.spaceandtime.routing.model.SRCViewDto;
import io.spaceandtime.routing.modelignite.SRCView;
import io.spaceandtime.routing.ro.ViewRequest;
import io.spaceandtime.routing.service.ViewService;
import io.spaceandtime.routing.utils.ErrorResponse;
import io.spaceandtime.routing.utils.Page;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.Parameter;
import io.swagger.v3.oas.annotations.media.ArraySchema;
import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.media.Schema;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.responses.ApiResponses;
import io.swagger.v3.oas.annotations.tags.Tag;

@RestController
@Tag(name = "View API")
@RequestMapping("/v1/content")
public class ViewController {

	@Autowired
	private ViewService viewService;

	/**
	 * 
	 * Perform create operations on view using this API
	 * 
	 */
	@Operation(summary = "Create a new view", description = "Create a new view (named query) using this endpoint")
	@ApiResponses(value = {
			@ApiResponse(responseCode = "201", description = "${api.response-codes.created.desc}", content = @Content(schema = @Schema(implementation = UUID.class))),
			@ApiResponse(responseCode = "401", description = "${api.response-codes.unauthorized.desc}", content = @Content(schema = @Schema(implementation = ErrorResponse.class))),
			@ApiResponse(responseCode = "400", description = "${api.response-codes.badRequest.desc}", content = @Content(schema = @Schema(implementation = ErrorResponse.class))) })
	@PostMapping(value = "views", produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<String> createView(@RequestBody ViewRequest viewRequest) throws Exception {

		String id = viewService.createView(viewRequest);
		return new ResponseEntity<>(id, HttpStatus.CREATED);
	}

	/**
	 * 
	 * Perform delete operations on view using this API
	 * 
	 */
	@Operation(summary = "Delete a view", description = "Delete an existing view using this endpoint")
	@ApiResponses(value = {
			@ApiResponse(responseCode = "204", description = "${api.response-codes.noContent.desc}", content = @Content),
			@ApiResponse(responseCode = "401", description = "${api.response-codes.unauthorized.desc}", content = @Content(schema = @Schema(implementation = ErrorResponse.class))),
			@ApiResponse(responseCode = "403", description = "${api.response-codes.forbidden.desc}", content = @Content(schema = @Schema(implementation = ErrorResponse.class))),
			@ApiResponse(responseCode = "404", description = "${api.response-codes.notFound.desc}", content = @Content(schema = @Schema(implementation = ErrorResponse.class))) })
	@DeleteMapping(value = "views", produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<Void> deleteView(
			@Parameter(required = false, description = "The view id identifier") @RequestParam(required = false) String viewId,
			@Parameter(required = false, description = "The view name identifier") @RequestParam(required = false) String viewName
	) throws Exception {
		viewService.deleteView(viewName, viewId);
		return ResponseEntity.status(HttpStatus.NO_CONTENT).build();

	}

	@Operation(summary = "Update a view", description = "Update an existing view using this endpoint")
	@ApiResponses(value = {
			@ApiResponse(responseCode = "204", description = "${api.response-codes.noContent.desc}", content = @Content),
			@ApiResponse(responseCode = "400", description = "${api.response-codes.badRequest.desc}", content = @Content(schema = @Schema(implementation = ErrorResponse.class))),
			@ApiResponse(responseCode = "401", description = "${api.response-codes.unauthorized.desc}", content = @Content(schema = @Schema(implementation = ErrorResponse.class))),
			@ApiResponse(responseCode = "403", description = "${api.response-codes.forbidden.desc}", content = @Content(schema = @Schema(implementation = ErrorResponse.class))) })
	@PutMapping(value = "views", produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<Void> updateViews(@RequestBody ViewRequest viewRequest,
			@Parameter(required = false, description = "The view id identifier") @RequestParam(required = false) String viewId,
			@Parameter(required = false, description = "The view name identifier") @RequestParam(required = false) String viewName)
			throws Exception {
		viewService.updateView(viewRequest, viewId, viewName);
		return ResponseEntity.status(HttpStatus.NO_CONTENT).build();
	}

	@Operation(summary = "Get view by Id", description = "Get metadata about platform views by id.")
	@ApiResponses(value = {
			@ApiResponse(responseCode = "200", description = "${api.response-codes.ok.desc}", content = @Content(array = @ArraySchema(schema = @Schema(implementation = SRCView.class)))),
			@ApiResponse(responseCode = "401", description = "${api.response-codes.unauthorized.desc}", content = @Content(schema = @Schema(implementation = ErrorResponse.class))),
			@ApiResponse(responseCode = "403", description = "${api.response-codes.forbidden.desc}", content = @Content(schema = @Schema(implementation = ErrorResponse.class))),
			@ApiResponse(responseCode = "404", description = "${api.response-codes.notFound.desc}", content = @Content(schema = @Schema(implementation = ErrorResponse.class))) })
	@GetMapping(value = "/views/{id}", produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<List<SRCView>> discoverViewById(
			@Parameter(required = true, description = "The view name for limiting scope") @PathVariable String id) {
	    List<SRCView> viewById = viewService.getViewById(id);
	    if (viewById == null || viewById.isEmpty()) {
		throw new AppException(MessageEnum.VIEW_NOT_FOUND);
	    }
	    return ResponseEntity.ok().body(viewById);
	}

	@Operation(summary = "Get all views", description = "Get metadata about platform views.")
	@ApiResponses(value = {
			@ApiResponse(responseCode = "200", description = "${api.response-codes.ok.desc}", useReturnTypeSchema = true),
			@ApiResponse(responseCode = "401", description = "${api.response-codes.unauthorized.desc}", content = @Content(schema = @Schema(implementation = ErrorResponse.class))),
			@ApiResponse(responseCode = "403", description = "${api.response-codes.forbidden.desc}", content = @Content(schema = @Schema(implementation = ErrorResponse.class))),
			@ApiResponse(responseCode = "404", description = "${api.response-codes.notFound.desc}", content = @Content(schema = @Schema(implementation = ErrorResponse.class))) })
	@GetMapping(value = "/views", produces = MediaType.APPLICATION_JSON_VALUE)
	public Page<SRCViewDto> discoverAllViews(@RequestParam(value = "isPublic", defaultValue = "false") Boolean isPublic,
			@RequestParam(value = "searchKeyword", required = false) String searchKeyword,
			@RequestParam(value = "tagId", required = false) String tagId,
			@RequestParam(value = "pageNo", defaultValue = "1") int pageNo,
			@RequestParam(value = "pageSize", defaultValue = EnvironmentConstant.PAGE_SIZE) int pageSize,
			@RequestParam(value = "sortOrder") SortOrderEnum sortOrder,
			@RequestParam(value = "status", required = false, defaultValue = ColumnConstant.ALL) StatusEnum status,
			@RequestParam(value = "sortBy", defaultValue = ColumnConstant.MODIFIED) String sortBy) {
		return viewService.getViews(isPublic, searchKeyword, pageNo, pageSize, sortOrder, sortBy, tagId, status);
	}

	///////////////////// publish - fork view //////////////////////////////
	@PostMapping(value = "/views/{viewId}/publish")
	@Operation(summary = "publish view", description = "Publish view")
	@ApiResponses(value = { @ApiResponse(responseCode = "201", description = "${api.response-codes.created.desc}"),
			@ApiResponse(responseCode = "401", description = "${api.response-codes.unauthorized.desc}", content = @Content(schema = @Schema(implementation = ErrorResponse.class))),
			@ApiResponse(responseCode = "400", description = "${api.response-codes.badRequest.desc}", content = @Content(schema = @Schema(implementation = ErrorResponse.class))) })
	public ResponseEntity<Void> publishView(@PathVariable(required = true) String viewId)
			throws Exception {
		viewService.publishView(viewId);
		return ResponseEntity.status(HttpStatus.CREATED).build();
	}

	@PostMapping(value = "/views/{viewId}/fork")
	@Operation(summary = "fork view", description = "Fork view")
	@ApiResponses(value = {
			@ApiResponse(responseCode = "201", description = "${api.response-codes.created.desc}", content = @Content(array = @ArraySchema(schema = @Schema(implementation = String.class)))),
			@ApiResponse(responseCode = "401", description = "${api.response-codes.unauthorized.desc}", content = @Content(schema = @Schema(implementation = ErrorResponse.class))),
			@ApiResponse(responseCode = "400", description = "${api.response-codes.badRequest.desc}", content = @Content(schema = @Schema(implementation = ErrorResponse.class))) })
	public ResponseEntity<String> forkView(@PathVariable(required = true) String viewId) {
		String forkViewId = viewService.forkView(viewId);
		return new ResponseEntity<>(forkViewId, HttpStatus.CREATED);
	}

}