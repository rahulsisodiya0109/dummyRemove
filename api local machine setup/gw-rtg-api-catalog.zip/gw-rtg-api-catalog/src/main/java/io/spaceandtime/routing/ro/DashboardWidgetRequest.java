package io.spaceandtime.routing.ro;

public class DashboardWidgetRequest {

	private String widgetId;

	private String metadata;

	public String getWidgetId() {
		return widgetId;
	}

	public void setWidgetId(String widgetId) {
		this.widgetId = widgetId;
	}

	public String getMetadata() {
		return metadata;
	}

	public void setMetadata(String metada) {
		this.metadata = metada;
	}

}
