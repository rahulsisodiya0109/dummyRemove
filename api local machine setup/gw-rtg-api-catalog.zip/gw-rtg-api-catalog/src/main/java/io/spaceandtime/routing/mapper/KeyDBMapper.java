package io.spaceandtime.routing.mapper;

import java.util.ArrayList;
import java.util.List;

import io.spaceandtime.routing.constant.SQLCommandTypeEnum;
import io.spaceandtime.routing.modelignite.SRCView;
import io.spaceandtime.routing.ro.ParameterRequest;
import io.spaceandtime.routing.ro.SqlRequest;
import io.spaceandtime.routing.ro.ViewRequest;
import io.spaceandtime.storage.database.DbView;
import io.spaceandtime.storage.database.DbViewParameter;

public class KeyDBMapper {

	private KeyDBMapper() {
	}

	public static DbView getView(ViewRequest viewRequest) {
		DbView keyDBView = new DbView();
		keyDBView.setViewId(viewRequest.getViewName());
		keyDBView.setSqlText(viewRequest.getViewText());
		keyDBView.setResourceId(viewRequest.getResourceId());
		if (viewRequest.getParametersRequest() != null) {
			keyDBView.setParameters(getParameterList(viewRequest.getParametersRequest()));
		}
		return keyDBView;
	}

	private static List<DbViewParameter> getParameterList(List<ParameterRequest> parameterRequestList) {
		List<DbViewParameter> parameterList = new ArrayList<>();
		parameterRequestList.stream().forEach(parameterRequest -> {
			DbViewParameter viewParameter = getParameter(parameterRequest);
			parameterList.add(viewParameter);
		});
		return parameterList;
	}

	private static DbViewParameter getParameter(ParameterRequest parameterRequest) {
		DbViewParameter viewParameter = new DbViewParameter();
		viewParameter.setName(parameterRequest.getName());
		viewParameter.setType(parameterRequest.getType());
		return viewParameter;
	}

	public static SqlRequest getSQLRequest(SRCView srcView) {
		SqlRequest sqlRequest = new SqlRequest();
		sqlRequest.setResourceId(srcView.getResourceId());
		sqlRequest.setSqlCommandType(SQLCommandTypeEnum.DQL.name());
		sqlRequest.setSqlText(srcView.getViewText());
		return sqlRequest;
	}

	public static DbView getKeyDBView(SRCView srcView) {
		DbView keyDBView = new DbView();
		keyDBView.setResourceId(srcView.getResourceId());
		keyDBView.setViewId(srcView.getViewName());
		keyDBView.setSqlText(srcView.getViewText());
		return keyDBView;
	}

}
