package io.spaceandtime.routing.constant;

/**
 * 
 * @author Nilesh Sharma
 *
 */
public enum ScopeEnum {
	PRIVATE, SUBSCRIPTION, PUBLIC, ALL
}
