package io.spaceandtime.routing.modelignite;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonProperty;

public class SRCTableColumns {

	@JsonIgnore
	private String id;

	@JsonProperty("column")
	private String columnId;

	@JsonProperty("table")
	private String tableId;

	@JsonProperty("namespace")
	private String schemaId;

	@JsonIgnore
	private String catalogId;

	@JsonProperty("position")
	private Integer position;

	@JsonProperty("nullable")
	private Boolean nullable;

	@JsonProperty("radix")
	private Integer radix;

	@JsonProperty("autoGenerate")
	private Boolean autoGenerate = Boolean.FALSE;

	@JsonProperty("autoIncrement")
	private Boolean autoIncrement = Boolean.FALSE;

	@JsonProperty("dataType")
	private String dataType;

	@JsonProperty("defaultValue")
	private String defaultValue;

	@JsonProperty("columnSize")
	private Integer columnSize;

	@JsonProperty("primaryKeySequence")
	private Integer primaryKeySequence;

	@JsonProperty("maxBytes")
	private Long maxBytes;

	@JsonIgnore
	private String orgId;

	@JsonProperty("encrypted")
	private Boolean encrypted;

	@JsonProperty("encType")
	private String encType;

	@JsonProperty("encOption")
	private String encOption;

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public String getColumnId() {
		return columnId;
	}

	public void setColumnId(String columnId) {
		this.columnId = columnId;
	}

	public String getTableId() {
		return tableId;
	}

	public void setTableId(String tableId) {
		this.tableId = tableId;
	}

	public String getSchemaId() {
		return schemaId;
	}

	public void setSchemaId(String schemaId) {
		this.schemaId = schemaId;
	}

	public String getCatalogId() {
		return catalogId;
	}

	public void setCatalogId(String catalogId) {
		this.catalogId = catalogId;
	}

	public Integer getPosition() {
		return position;
	}

	public void setPosition(Integer position) {
		this.position = position;
	}

	public Boolean getNullable() {
		return nullable;
	}

	public void setNullable(Boolean nullable) {
		this.nullable = nullable;
	}

	public Integer getRadix() {
		return radix;
	}

	public void setRadix(Integer radix) {
		this.radix = radix;
	}

	public Boolean getAutoGenerate() {
		return autoGenerate;
	}

	public void setAutoGenerate(Boolean autoGenerate) {
		this.autoGenerate = autoGenerate;
	}

	public Boolean getAutoIncrement() {
		return autoIncrement;
	}

	public void setAutoIncrement(Boolean autoIncrement) {
		this.autoIncrement = autoIncrement;
	}

	public String getDataType() {
		return dataType;
	}

	public void setDataType(String dataType) {
		this.dataType = dataType;
	}

	public String getDefaultValue() {
		return defaultValue;
	}

	public void setDefaultValue(String defaultValue) {
		this.defaultValue = defaultValue;
	}

	public Integer getColumnSize() {
		return columnSize;
	}

	public void setColumnSize(Integer columnSize) {
		this.columnSize = columnSize;
	}

	public Integer getPrimaryKeySequence() {
		return primaryKeySequence;
	}

	public void setPrimaryKeySequence(Integer primaryKeySequence) {
		this.primaryKeySequence = primaryKeySequence;
	}

	public Long getMaxBytes() {
		return maxBytes;
	}

	public void setMaxBytes(Long maxBytes) {
		this.maxBytes = maxBytes;
	}

	public String getOrgId() {
		return orgId;
	}

	public void setOrgId(String orgId) {
		this.orgId = orgId;
	}

	public Boolean getEncrypted() {
		return encrypted;
	}

	public void setEncrypted(Boolean encrypted) {
		this.encrypted = encrypted;
	}

	public String getEncType() {
		return encType;
	}

	public void setEncType(String encType) {
		this.encType = encType;
	}

	public String getEncOption() {
		return encOption;
	}

	public void setEncOption(String encOption) {
		this.encOption = encOption;
	}

}
