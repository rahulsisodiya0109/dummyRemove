package io.spaceandtime.routing.utils;

import org.springframework.http.HttpStatus;

/**
 * 
 * @author Guvala
 * 
 *         All properties Enums should extend this interface which help for
 *         processing the messages
 *
 */
public interface BasePropertyEnum {

	public String getBundle();

	public String getMessageCode();

	public HttpStatus getStatus();

}
