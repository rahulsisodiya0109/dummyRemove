package io.spaceandtime.routing.model;

import com.fasterxml.jackson.annotation.JsonProperty;

public class BlockchainTableResource {

	@JsonProperty("table")
	private String table;
	
	@JsonProperty("count")
	private Integer count;

	public String getTable() {
	    return table;
	}

	public void setTable(String table) {
	    this.table = table;
	}

	public Integer getCount() {
	    return count;
	}

	public void setCount(Integer count) {
	    this.count = count;
	}

	public BlockchainTableResource() {
	    super();
	    // TODO Auto-generated constructor stub
	}

	public BlockchainTableResource(String table, Integer count) {
	    super();
	    this.table = table;
	    this.count = count;
	}
	
	
}
