package io.spaceandtime.routing.modelignite;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonProperty;

public class SRCIndex {

	@JsonIgnore
	private String id;

	@JsonProperty("index")
	private String indexId;

	@JsonProperty("table")
	private String tableId;

	@JsonProperty("namespace")
	private String schemaId;

	@JsonIgnore
	private String catalogId;

	@JsonProperty("nonUnique")
	private Boolean nonUnique = true;

	@JsonProperty("collation")
	private String collation = "A";

	@JsonProperty("columns")
	private String columns;

	@JsonProperty("positions")
	private String positions;

	@JsonProperty("indexType")
	private String indexType;

	@JsonIgnore
	private String orgId;

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public String getIndexId() {
		return indexId;
	}

	public void setIndexId(String indexId) {
		this.indexId = indexId;
	}

	public String getTableId() {
		return tableId;
	}

	public void setTableId(String tableId) {
		this.tableId = tableId;
	}

	public String getSchemaId() {
		return schemaId;
	}

	public void setSchemaId(String schemaId) {
		this.schemaId = schemaId;
	}

	public String getCatalogId() {
		return catalogId;
	}

	public void setCatalogId(String catalogId) {
		this.catalogId = catalogId;
	}

	public Boolean getNonUnique() {
		return nonUnique;
	}

	public void setNonUnique(Boolean nonUnique) {
		this.nonUnique = nonUnique;
	}

	public String getCollation() {
		return collation;
	}

	public void setCollation(String collation) {
		this.collation = collation;
	}

	public String getColumns() {
		return columns;
	}

	public void setColumns(String columns) {
		this.columns = columns;
	}

	public String getPositions() {
		return positions;
	}

	public void setPositions(String positions) {
		this.positions = positions;
	}

	public String getIndexType() {
		return indexType;
	}

	public void setIndexType(String indexType) {
		this.indexType = indexType;
	}

	public String getOrgId() {
		return orgId;
	}

	public void setOrgId(String orgId) {
		this.orgId = orgId;
	}

}
