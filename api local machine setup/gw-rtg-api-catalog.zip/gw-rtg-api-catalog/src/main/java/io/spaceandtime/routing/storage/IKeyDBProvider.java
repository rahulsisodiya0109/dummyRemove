package io.spaceandtime.routing.storage;

import java.util.List;

import io.spaceandtime.routing.model.TableRelationDto;
import io.spaceandtime.storage.database.*;
import io.spaceandtime.storage.datawarehouse.*;
import io.spaceandtime.storage.state.*;
import io.spaceandtime.storage.subscription.*;
import io.spaceandtime.storage.user.*;

/**
 * Defines the contract for the Gateway KeyDB provider
 */
public interface IKeyDBProvider {
	/**
	 * Get the address metadata for a given dw cluster identifier
	 * 
	 * @param clusterId - the cluster identifier
	 * @return
	 * @throws Exception
	 */
	DWAddress getClusterAddress(String clusterId) throws Exception;

	/**
	 * Check if a view exists
	 * 
	 * @param viewId - the view identifier
	 * @return
	 * @throws Exception if the operation fails
	 */
	boolean viewExists(String viewId) throws Exception;

	DbView getView(String viewId) throws Exception;

	void createView(String viewId, DbView view) throws Exception;

	void setView(String viewId, DbView view) throws Exception;

	void deleteView(String viewId) throws Exception;

	void setViewIdToName(String viewUUID, String viewId) throws Exception;

	void removeViewIdMap(String viewUUID) throws Exception;

	String getTableRelationCache(String relationKey) throws Exception;

	void setTableRelationCache(String relationKey, List<TableRelationDto> tableRelations) throws Exception;
	/**
	 * Retrieve table metadata
	 * @param tableId - the table identifier
	 * @return
	 * @throws Exception if the operation fails
	 */
	DbTable getTable(String tableId) throws Exception;

	List<RequestLog> getRequestLogForUser(String userId) throws Exception;

	/**
	 * Get the list of "leader" clusters for a given resource
	 * <p>
	 * A "leader" is defines as a cluster who can process a request
	 * 
	 * @param resourceId - the resource identifier
	 * @return
	 * @throws Exception if the operation fails
	 */
	DbObjectLeaders getLeaders(String resourceId) throws Exception;
	/**
	 * Retrieve a subscription by id
	 * @param subscriptionId - the subscription identifier
	 * @return
	 * @throws Exception if the operation fails
	 */
	Subscription getSubscription(String subscriptionId) throws Exception;
	/**
	 * Retrieve the subscription user roles
	 * @param subscriptionId - the subscription identifier
	 * @return
	 * @throws Exception if the operation fails
	 */
	SubscriptionUserRoles getSubscriptionUserRoles(String subscriptionId) throws Exception;
}
