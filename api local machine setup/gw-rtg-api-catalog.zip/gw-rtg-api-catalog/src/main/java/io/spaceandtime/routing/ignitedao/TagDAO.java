package io.spaceandtime.routing.ignitedao;

import java.util.List;

import io.spaceandtime.routing.model.TagDto;

/**
 * 
 * @author Nilesh Sharma
 *
 */

public interface TagDAO {

	List<TagDto> getAllTags(String tagId, Boolean popular, String tagType, Boolean isPublic);

}
