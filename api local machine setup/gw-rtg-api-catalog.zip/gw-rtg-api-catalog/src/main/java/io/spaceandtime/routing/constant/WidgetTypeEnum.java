package io.spaceandtime.routing.constant;

import java.util.ArrayList;
import java.util.List;

import io.spaceandtime.routing.errorHandler.AppException;
import io.spaceandtime.routing.utils.StringUtils;

/**
 * 
 * @author Nilesh Sharma
 *
 */
public enum WidgetTypeEnum {
	GRAPH("GRAPH"), 
	TABLE("TABLE"),
	MARKDOWNCARD("MARKDOWNCARD"), 
	COUNTERCARD("COUNTERCARD");

	private String widgetType;

	public static List<String> widgetTypeList = new ArrayList<>();

	WidgetTypeEnum(String string) {
		this.widgetType = string;
	}

	static {
		for (WidgetTypeEnum constant : WidgetTypeEnum.class.getEnumConstants()) {
			widgetTypeList.add(constant.getWidgetType());
		}
	}

	public String getWidgetType() {
		return widgetType;
	}

	public String toString() {
		return this.widgetType;
	}

	public static void checkValidWidgetType(String name) {
		if (StringUtils.isEmpty(name) || !widgetTypeList.contains(name)) {
			throw new AppException(MessageEnum.INVALID_WIDGETTYPE, name);

		}
	}

}
