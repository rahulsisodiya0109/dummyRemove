package io.spaceandtime.routing.ignite;

import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

/**
 * 
 * @author Aswanth Guvala
 *
 */
public class IgniteClusterPool {

	private static Map<String, IgniteThinClient> map = new ConcurrentHashMap<>();

	public void put(String resourceId, IgniteThinClient IgniteThinClient) {
		IgniteThinClient cacheTemplate = map.get(resourceId);
		if (cacheTemplate == null || !cacheTemplate.isActive()) {
			map.put(resourceId, IgniteThinClient);
			return;
		}
	}

	public IgniteThinClient get(String resourceId) {
		IgniteThinClient cacheTemplate = map.get(resourceId);
		if (cacheTemplate != null && cacheTemplate.isActive()) {
			return cacheTemplate;
		}
		return cacheTemplate;
	}

	public void inactivate(String resourceId) {
		IgniteThinClient cacheTemplate = map.get(resourceId);
		if (cacheTemplate != null && cacheTemplate.isActive()) {
			cacheTemplate.setActive(false);
		}
	}

	public void activate(String resourceId) {
		IgniteThinClient cacheTemplate = map.get(resourceId);
		if (cacheTemplate != null && !cacheTemplate.isActive()) {
			cacheTemplate.setActive(true);
		}
	}

	public IgniteThinClient findLocalIgniteThinClient(String clusterId) {
		return map.values().stream().filter(tc -> tc.getClusterId().equals(clusterId)).findFirst().orElse(null);

	}

}
