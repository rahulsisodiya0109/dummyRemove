package io.spaceandtime.routing.model;

import java.sql.Timestamp;

import io.spaceandtime.storage.state.RequestLog;

public class QueryHistoryDto {

    private String queryId;
    private String userId;
    private String sqlText;
    private String gatewayId;
    private String warehouseId;
    private Long runTime;
    private Timestamp execTime;
    private Integer rowCount;
    private Long responseSize;
    private String errorDetails;
    private String origin;
    private String metadata;
    private String io;
    private String cpuSec;

	public QueryHistoryDto(){}
	public QueryHistoryDto(RequestLog rl) {
		queryId = rl.getRequestId().toString();
		userId = rl.getUserId();
		sqlText = rl.getSqlText();
		gatewayId = rl.getGatewayId();
		warehouseId = rl.getWarehouseId();
		runTime = rl.getRuntime();
		execTime = Timestamp.from(rl.getExecutedTime());
		rowCount = rl.getRowCount();
		responseSize = rl.getResponseSize();
		errorDetails = rl.getErrorDetails();
		origin = rl.getOrigin();
		metadata = rl.getMetadata();
		io = "PENDING";
		cpuSec = "PENDING";
	}
	
    public String getQueryId() {
	return queryId;
    }

    public QueryHistoryDto setQueryId(String queryId) {
	this.queryId = queryId;
	return this;
    }

    public String getUserId() {
	return userId;
    }

    public QueryHistoryDto setUserId(String userId) {
	this.userId = userId;
	return this;
    }

    public String getSqlText() {
	return sqlText;
    }

    public QueryHistoryDto setSqlText(String sqlText) {
	this.sqlText = sqlText;
	return this;
    }

    public String getGatewayId() {
	return gatewayId;
    }

    public QueryHistoryDto setGatewayId(String gatewayId) {
	this.gatewayId = gatewayId;
	return this;
    }

    public String getWarehouseId() {
	return warehouseId;
    }

    public QueryHistoryDto setWarehouseId(String warehouseId) {
	this.warehouseId = warehouseId;
	return this;
    }

    public Long getRunTime() {
	return runTime;
    }

    public QueryHistoryDto setRunTime(Long runTime) {
	this.runTime = runTime;
	return this;
    }

    public Timestamp getExecTime() {
	return execTime;
    }

    public QueryHistoryDto setExecTime(Timestamp execTime) {
	this.execTime = execTime;
	return this;
    }

    public Integer getRowCount() {
	return rowCount;
    }

    public QueryHistoryDto setRowCount(Integer rowCount) {
	this.rowCount = rowCount;
	return this;
    }

    public Long getResponseSize() {
	return responseSize;
    }

    public QueryHistoryDto setResponseSize(Long responseSize) {
	this.responseSize = responseSize;
	return this;
    }

    public String getErrorDetails() {
	return errorDetails;
    }

    public QueryHistoryDto setErrorDetails(String errorDetails) {
	this.errorDetails = errorDetails;
	return this;
    }

    public String getOrigin() {
	return origin;
    }

    public QueryHistoryDto setOrigin(String origin) {
	this.origin = origin;
	return this;
    }

    public String getMetadata() {
	return metadata;
    }

    public QueryHistoryDto setMetadata(String metadata) {
	this.metadata = metadata;
	return this;
    }

    public String getIo() {
	return io;
    }

    public QueryHistoryDto setIo(String io) {
	this.io = io;
	return this;
    }

    public String getCpuSec() {
	return cpuSec;
    }

    public QueryHistoryDto setCpuSec(String cpuSec) {
	this.cpuSec = cpuSec;
	return this;
    }

    @Override
    public String toString() {
	return "QueryHistoryDto [queryId=" + queryId + ", userId=" + userId + ", sqlText=" + sqlText + ", gatewayId="
		+ gatewayId + ", warehouseId=" + warehouseId + ", runTime=" + runTime + ", execTime=" + execTime
		+ ", rowCount=" + rowCount + ", responseSize=" + responseSize + ", errorDetails=" + errorDetails
		+ ", origin=" + origin + ", metadata=" + metadata + ", io=" + io + ", cpuSec=" + cpuSec + "]";
    }
    
    
}
