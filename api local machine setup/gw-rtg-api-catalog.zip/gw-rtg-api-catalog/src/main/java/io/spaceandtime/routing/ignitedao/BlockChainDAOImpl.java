package io.spaceandtime.routing.ignitedao;

import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

import org.springframework.stereotype.Component;

import io.spaceandtime.routing.constant.BlockchainId;
import io.spaceandtime.routing.constant.MessageEnum;
import io.spaceandtime.routing.errorHandler.AppException;
import io.spaceandtime.routing.jdbcdao.BaseIgniteSqlDAOImpl;
import io.spaceandtime.routing.mapper.SRCMapper;
import io.spaceandtime.routing.model.BlockChainDto;
import io.spaceandtime.routing.model.NamespacesDto;
import io.spaceandtime.routing.query.CatalogAPIQuery;

@Component
public class BlockChainDAOImpl extends BaseIgniteSqlDAOImpl implements BlockChainDAO {

	@Override
	public List<BlockChainDto> getBlockchains() {
		String qryText = CatalogAPIQuery.GET_BLOCKCHAINS;
		List<Map<String, Object>> chainIdList = getPlatformEntitiesData(qryText);
		return getChainIdData(chainIdList);
	}

	@Override
	public List<NamespacesDto> getNamespaces(String chainId) {
		chainId = chainId.toUpperCase();
		try {
			chainId = BlockchainId.tryParse(chainId).toString();
		} catch (Exception e) {
			throw new AppException(MessageEnum.INVALID_CHAINID, chainId);
		}
		String qryText = CatalogAPIQuery.GET_NAMESPACES;
		qryText += " WHERE CHAIN_ID ='" + chainId + "';";
		List<Map<String, Object>> namespaceList = getPlatformEntitiesData(qryText);
		return getNamespaceData(namespaceList);
	}

	public List<NamespacesDto> getNamespaceData(List<Map<String, Object>> namespaceList) {
		return namespaceList.stream().map(SRCMapper::getNamespaceData).collect(Collectors.toList());
	}

	public List<BlockChainDto> getChainIdData(List<Map<String, Object>> chainIdList) {
		return chainIdList.stream().map(SRCMapper::getChainIdData).collect(Collectors.toList());
	}
}