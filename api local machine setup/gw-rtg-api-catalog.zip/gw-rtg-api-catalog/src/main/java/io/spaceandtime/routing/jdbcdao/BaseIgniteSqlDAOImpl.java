package io.spaceandtime.routing.jdbcdao;

import java.lang.reflect.Field;
import java.lang.reflect.InvocationTargetException;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;
import java.util.stream.Collectors;

import org.apache.commons.beanutils.PropertyUtils;
import org.apache.ignite.cache.query.FieldsQueryCursor;
import org.apache.ignite.cache.query.SxTSqlFieldsQuery;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;

import io.spaceandtime.routing.constant.ColumnConstant;
import io.spaceandtime.routing.constant.EnvironmentConstant;
import io.spaceandtime.routing.constant.MessageEnum;
import io.spaceandtime.routing.constant.SQLCommandTypeEnum;
import io.spaceandtime.routing.constant.SortOrderEnum;
import io.spaceandtime.routing.constant.StatusEnum;
import io.spaceandtime.routing.errorHandler.AppException;
import io.spaceandtime.routing.ignite.IgniteThinClient;
import io.spaceandtime.routing.logging.AppLogger;
import io.spaceandtime.routing.logging.Log;
import io.spaceandtime.routing.mapper.SRCMapper;
import io.spaceandtime.routing.model.UserProfile;
import io.spaceandtime.routing.modelignite.SRCTable;
import io.spaceandtime.routing.modelignite.SRCView;
import io.spaceandtime.routing.modelignite.Tag;
import io.spaceandtime.routing.modelignite.TagRelation;
import io.spaceandtime.routing.query.CatalogAPIQuery;
import io.spaceandtime.routing.ro.TagRequest;
import io.spaceandtime.routing.utils.AppUtils;
import io.spaceandtime.routing.utils.JsonValidator;
import io.spaceandtime.routing.utils.JwtUtils;
import io.spaceandtime.routing.utils.Page;
import io.spaceandtime.routing.utils.Pageable;
import io.spaceandtime.routing.utils.PaginationUtil;
import io.spaceandtime.routing.utils.StringUtils;
import io.spaceandtime.routing.utils.ThreadLocalUtil;
import jodd.util.StringUtil;

/**
 * 
 * @author Nilesh Sharma
 *
 */
public abstract class BaseIgniteSqlDAOImpl {

	private static @Log AppLogger logger;

	@Value(EnvironmentConstant.DISCOVERY_BISCUIT)
	private String discoveryBiscuit;

	@Value(EnvironmentConstant.PLATFORM_ENTITIES_BISCUIT)
	private String platformEntitiesBiscuit;

	@Autowired
	private IgniteThinClient srcIgniteClient;

	@Autowired
	private JwtUtils jwtUtils;

	public static final Object COUNT_VALUE = "COUNT";
	public static final String QUERYNAME = "QUERYNAME";
	public static final String RESOURCEID = "RESOURCEID";
	public static final String QUERYTEXT = "QUERYTEXT";
	public static final String WIDGETNAME = "WIDGETNAME";
	public static final String WIDGETTYPE = "WIDGETTYPE";
	public static final String QUERYID = "QUERYID";
	public static final String VIEWID = "VIEWID";
	public static final String DASHNAME = "DASHNAME";
	public static final String OWNERID = "OWNERID";
	public static final String VIEWNAME = "VIEWNAME";
	public static final String SCHEMAID = "SCHEMAID";
	public static final String VIEWTEXT = "VIEWTEXT";

	public static final String USERID = "USERID";
	public static final String GATEWAYID = "GATEWAYID";
	public static final String WAREHOUSEID = "WAREHOUSEID";
	public static final String RUNTIME = "RUNTIME";
	public static final String EXECTIME = "EXECTIME";
	public static final String RESPONSESIZE = "RESPONSESIZE";
	public static final String ORIGIN = "ORIGIN";

	/**
	 * To get the data from the results set.
	 * 
	 * @param data
	 * @return sql data
	 */
	protected List<Map<String, Object>> buildResults(FieldsQueryCursor<List<?>> data) {
		List<Map<String, Object>> results = new ArrayList<>();
		List<List<?>> dataList = data.getAll();
		int countCol = data.getColumnsCount();
		dataList.forEach(row -> {
			Map<String, Object> rowData = new LinkedHashMap<>();
			for (int i = 0; i < countCol; i++) {
				rowData.put(data.getFieldName(i), row.get(i));
			}
			results.add(rowData);
		});
		data.close();
		return results;
	}

	protected List<Map<String, Object>> getDiscoveryMetadata(String queryText) {
		SxTSqlFieldsQuery qry = new SxTSqlFieldsQuery(queryText);
		qry.setSqlCommandType(SQLCommandTypeEnum.DQL.name());
		qry.setBiscuit(discoveryBiscuit);
		addSecurityToken(qry);
		FieldsQueryCursor<List<?>> data = srcIgniteClient.query(qry);
		return buildResults(data);
	}

	protected List<Map<String, Object>> getDiscoveryMetadataLazy(String queryText) {
		SxTSqlFieldsQuery qry = new SxTSqlFieldsQuery(queryText);
		qry.setSqlCommandType(SQLCommandTypeEnum.DQL.name());
		qry.setBiscuit(discoveryBiscuit);
		qry.setDistributedJoins(true);
		qry.setLazy(true);
		addSecurityToken(qry);
		FieldsQueryCursor<List<?>> data = srcIgniteClient.query(qry);
		return buildResults(data);
	}

	protected List<Map<String, Object>> getPlatformEntitiesData(String queryText) {
		SxTSqlFieldsQuery qry = new SxTSqlFieldsQuery(queryText);
		qry.setDistributedJoins(true);
		qry.setSqlCommandType(SQLCommandTypeEnum.DQL.name());
		qry.setBiscuit(platformEntitiesBiscuit);
		addSecurityToken(qry);
		FieldsQueryCursor<List<?>> data = srcIgniteClient.query(qry);
		return buildResults(data);
	}

	private void addSecurityToken(SxTSqlFieldsQuery qry) {
		qry.setBearerToken(ThreadLocalUtil.getContext().getBearerToken());
		qry.setPublicKey(ThreadLocalUtil.getContext().getPublicKey());
		qry.setDistributedJoins(true);
	}

	protected List<Map<String, Object>> executeDML(String queryText) {
		SxTSqlFieldsQuery qry = new SxTSqlFieldsQuery(queryText);
		qry.setSqlCommandType(SQLCommandTypeEnum.DML.name());
		qry.setBiscuit(platformEntitiesBiscuit);
		addSecurityToken(qry);
		FieldsQueryCursor<List<?>> data = srcIgniteClient.query(qry);
		return buildResults(data);
	}

	protected List<Map<String, Object>> executeDML(String queryText, UserProfile userProfile) {
		SxTSqlFieldsQuery qry = new SxTSqlFieldsQuery(queryText);
		qry.setSqlCommandType(SQLCommandTypeEnum.DML.name());
		qry.setBiscuit(platformEntitiesBiscuit);
		qry.setArgs(userProfile.getUserId(), userProfile.getUserName(), userProfile.getDisplayName(),
				userProfile.getEmailAddr(), userProfile.getBio(), userProfile.getSettings());
		addSecurityToken(qry);
		FieldsQueryCursor<List<?>> data = srcIgniteClient.query(qry);
		return buildResults(data);
	}

	protected List<Map<String, Object>> executeDML(String queryText, SRCView srcView, String operation) {
		SxTSqlFieldsQuery qry = new SxTSqlFieldsQuery(queryText);
		qry.setSqlCommandType(SQLCommandTypeEnum.DML.name());
		qry.setBiscuit(platformEntitiesBiscuit);
		if (operation.equals("INSERT"))
			qry.setArgs(srcView.getId(), srcView.getCatalogId(), srcView.getSchemaId(), srcView.getViewName(),
					srcView.getOwnerId(), srcView.getResourceId(), srcView.getViewText(), srcView.getDescription(),
					srcView.getParameters(), srcView.getIsPublic(), srcView.getModified());
		else
			qry.setArgs(srcView.getViewName(), srcView.getDescription(), srcView.getViewText(), srcView.getResourceId(),srcView.getIsPublic(), srcView.getParameters(), srcView.getModified(),srcView.getSchemaId(), srcView.getId());

		addSecurityToken(qry);
		FieldsQueryCursor<List<?>> data = srcIgniteClient.query(qry);
		return buildResults(data);
	}

	protected String parseQuery(Class entity, Object dataObject, String sql) {
		Map<String, Object> columnValuesMap = getColumnDataMap(entity, dataObject);
		return AppUtils.format(sql, columnValuesMap);
	}

	private Map<String, Object> getColumnDataMap(Class entity, Object dataObject) {
		Map<String, Object> columnValuesMap = new HashMap<>();
		Field[] fields = entity.getDeclaredFields();
		for (Field field : fields) {
			try {
				Object value = PropertyUtils.getProperty(dataObject, field.getName());
				if (PropertyUtils.getPropertyType(dataObject, field.getName()) == String.class) {
					if (value != null) {
						value = "'" + value + "'";
					}
				} else if (PropertyUtils.getPropertyType(dataObject, field.getName()) == Timestamp.class) {
					if (value != null) {
						value = "'" + value + "'";
					}
				} else if (PropertyUtils.getPropertyType(dataObject, field.getName()) == Boolean.class) {
					if (value != null) {
						value = "'" + value + "'";
					}
				}
				columnValuesMap.put(field.getName(), value);
			} catch (IllegalAccessException | InvocationTargetException | NoSuchMethodException e) {
				e.printStackTrace();
			}
		}
		return columnValuesMap;
	}

	private Map<String, Object> getColumnDataMapTEST(Class entity, Object dataObject) {
		Map<String, Object> columnValuesMap = new HashMap<>();
		Field[] fields = entity.getDeclaredFields();
		for (Field field : fields) {
			try {
				Object value = PropertyUtils.getProperty(dataObject, field.getName());
				if (PropertyUtils.getPropertyType(dataObject, field.getName()) == String.class) {
					if (value != null) {
						value = "'" + value + "'";
					}
				} else if (PropertyUtils.getPropertyType(dataObject, field.getName()) == Timestamp.class) {
					if (value != null) {
						value = "'" + value + "'";
					}
				} else if (PropertyUtils.getPropertyType(dataObject, field.getName()) == String.class) {
					if (value != null) {
						value = "'" + value + "'";
					}
				} else if (PropertyUtils.getPropertyType(dataObject, field.getName()) == Boolean.class) {
					if (value != null) {
						value = "'" + value + "'";
					}
				}
				columnValuesMap.put(field.getName(), value);
			} catch (IllegalAccessException | InvocationTargetException | NoSuchMethodException e) {
				e.printStackTrace();
			}
		}
		return columnValuesMap;
	}

	protected void saveNewTagAndTagRelation(TagRequest tag, String entityId, String entityType) {
		String qry = CatalogAPIQuery.GET_TAGS + "where TAG_ID = '" + tag.getTagId() + "'";
		List<Map<String, Object>> addedTag = getPlatformEntitiesData(qry);
		if (addedTag.isEmpty()) {
			Tag newTag = new Tag();
			String id = UUID.randomUUID().toString();
			newTag.setId(id);
			newTag.setTagId(tag.getTagId());
			checkValidJsonInMetadata(tag.getMetadata());
			newTag.setMetadata(tag.getMetadata());
			String srcSql = parseQuery(Tag.class, newTag, CatalogAPIQuery.CREATE_TAG);
			executeDML(srcSql);
			createTagRelation(newTag, entityId, entityType);
		} else {
			Tag existingTag = SRCMapper.getTags(addedTag.get(0));
			createTagRelation(existingTag, entityId, entityType);
		}
	}

	protected void checkValidJsonInMetadata(String metadata) {
		if (!StringUtil.isAllBlank(metadata) && !JsonValidator.isValidJson(metadata))
			throw new AppException(MessageEnum.INVALID_JSON_EXCEPTION, metadata);
	}

	private void createTagRelation(Tag tag, String entityId, String entityType) {
		TagRelation newRelation = new TagRelation();
		newRelation.setTagId(tag.getId());
		newRelation.setEntId(entityId);
		newRelation.setEntType(entityType);
		String srcSql = parseQuery(TagRelation.class, newRelation, CatalogAPIQuery.CREATE_TAG_RELATION);
		executeDML(srcSql);
	}

	protected void removeExistingTagsForEntity(String id, String savedquery) {
		String qryText = CatalogAPIQuery.REMOVE_TAG_RELATION;
		List<String> filters = new ArrayList<>();
		filters.add("ENT_ID = '" + id + "'");
		qryText += " WHERE " + String.join(" AND ", filters);
		executeDML(qryText);
	}

	protected List<Tag> getTagRelationByEntityId(String entityId, String entityType) {
		String qryText = CatalogAPIQuery.GET_TAGS_FOR_ENTITY;
		qryText = qryText + " WHERE  tr.ENT_TYPE= '" + entityType + "' and tr.ENT_ID = '" + entityId + "' ;";
		List<Map<String, Object>> tagMapList = getPlatformEntitiesData(qryText);
		return getTagRelationList(tagMapList);
	}

	private List<Tag> getTagRelationList(List<Map<String, Object>> tagMapList) {
		List<Tag> tagList = tagMapList.stream().map(tagMap -> SRCMapper.getTags(tagMap)).collect(Collectors.toList());
		return tagList;
	}

	protected String buildPaginatedQuery(int pageNo, int pageSize, SortOrderEnum sortOrder, String sortBy,
			String qryText) {
		pageNo = validatePageNumber(pageNo);
		pageSize = validatePageSize(pageSize);
		if (sortBy.equalsIgnoreCase(ColumnConstant.TAG)) {
			qryText += " LIMIT " + pageSize + " OFFSET " + (pageNo - 1) * pageSize;
		} else {
			qryText += " ORDER BY " + sortBy + " " + sortOrder + " LIMIT " + pageSize + " OFFSET "
					+ (pageNo - 1) * pageSize;
		}
		return qryText;
	}

	protected String buildSortByColumnName(String sortBy) {
		String columnName;
		switch (sortBy.toUpperCase()) {
		case QUERYNAME:
			columnName = ColumnConstant.QUERY_NAME;
			break;
		case RESOURCEID:
			columnName = ColumnConstant.RESOURCE_ID;
			break;
		case QUERYTEXT:
			columnName = ColumnConstant.QUERY_TEXT;
			break;
		case WIDGETNAME:
			columnName = ColumnConstant.WIDGETNAME;
			break;
		case WIDGETTYPE:
			columnName = ColumnConstant.WIDGETTYPE;
			break;
		case QUERYID:
			columnName = ColumnConstant.QUERYID;
			break;
		case VIEWID:
			columnName = ColumnConstant.VIEW_ID;
			break;
		case DASHNAME:
			columnName = ColumnConstant.DASHBOARDNAME;
			break;
		case OWNERID:
			columnName = ColumnConstant.OWNER_ID;
			break;
		case VIEWNAME:
			columnName = ColumnConstant.VIEW_NAME;
			break;
		case SCHEMAID:
			columnName = ColumnConstant.SCHEMA_ID;
			break;
		case VIEWTEXT:
			columnName = ColumnConstant.VIEW_TEXT;
			break;
		case USERID:
			columnName = ColumnConstant.USERID;
			break;
		case GATEWAYID:
			columnName = ColumnConstant.GATEWAYID;
			break;
		case WAREHOUSEID:
			columnName = ColumnConstant.WAREHOUSEID;
			break;
		case RUNTIME:
			columnName = ColumnConstant.RUNTIME;
			break;
		case EXECTIME:
			columnName = ColumnConstant.EXECTIME;
			break;
		case RESPONSESIZE:
			columnName = ColumnConstant.RESPONSE_SIZE;
			break;
		case ORIGIN:
			columnName = ColumnConstant.ORIGIN;
			break;
		default:
			columnName = sortBy;
		}
		return columnName;
	}

	protected int validatePageSize(int pageSize) {
		return (pageSize < 1 ? pageSize = Integer.parseInt(EnvironmentConstant.PAGE_SIZE) : pageSize);
	}

	protected int validatePageNumber(int pageNo) {
		return (pageNo < 1 ? pageNo = 1 : pageNo);
	}

	protected int getTotalRecords(String qryTextToCountTotalRecords) {
		List<Map<String, Object>> list = getPlatformEntitiesData(qryTextToCountTotalRecords);
		Object object = list.get(0).get(COUNT_VALUE);
		return Integer.parseInt(object.toString());
	}

	protected <T> Page<T> pageableContent(int pageNo, int pageSize, int count, List<T> contentDto) {
		Pageable page = PaginationUtil.getPageableObject(pageNo, pageSize, count, contentDto.size());
		Page<T> dashboardPage = new Page<T>();
		dashboardPage.setContent(contentDto);
		dashboardPage.setPageable(page);
		return dashboardPage;
	}

	protected String getUserId() {
		return jwtUtils.parseJwt().getUserId();
	}

	protected Boolean checkUserAuthorization(Boolean isPublic) {
		if (!isPublic) {
			if (!StringUtil.isAllBlank(getUserId()))
				return true;
			return false;
		}
		return true;
	}

	protected String getOrganizationIdByUserId() {
		return jwtUtils.parseJwt().getSubscriptionId();
	}

	protected String parseQuery(Map<String, Object> columnValuesMap, String sql) {
		return AppUtils.format(sql, columnValuesMap);
	}

	protected List<SRCTable> getSRCTableByName(String schemaName, String tableName) {
		String qryText = CatalogAPIQuery.GET_TABLES;
		qryText = qryText + " WHERE  tab.TABLE_ID= '" + tableName + "' AND tab.SCHEMA_ID='" + schemaName + "'";
		List<Map<String, Object>> tableList = getDiscoveryMetadata(qryText);
		return getTableData(tableList);
	}

	protected List<SRCTable> getTableData(List<Map<String, Object>> tableData) {
		List<SRCTable> tableList = new ArrayList<>();
		for (Map<String, Object> tableMap : tableData) {
			SRCTable srcTable = SRCMapper.getTables(tableMap);
			tableList.add(srcTable);
		}
		return tableList;
	}

	protected void addStatusFilter(StatusEnum status, List<String> filters) {
		String requestStatus = status.getStatus();
		String userId = getUserId();
		filters.add(" OWNER_ID= '" + userId + "'");
		if (requestStatus.equals(ColumnConstant.PUBLISHED))
			filters.add(" ISPUBLIC = TRUE");
		else if (requestStatus.equals(ColumnConstant.UNPUBLISHED))
			filters.add(" ISPUBLIC = FALSE");
	}
}
