package io.spaceandtime.routing.configs.providers;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import io.spaceandtime.api.jwt.IJwkConfig;
import io.spaceandtime.routing.constant.EnvironmentConstant;

@Component
public class JwkConfigProvider implements IJwkConfig {

	@Value(EnvironmentConstant.GATEWAY_SECURITY_PUBLICKEY)
	private String GATEWAY_PUBLIC_KEY;

	@Override
	public String getIdentifier() { return null; }

	@Override
	public String getPrivateKey() { return null; }

	@Override
	public String getPublicKey() { return GATEWAY_PUBLIC_KEY; }
}
