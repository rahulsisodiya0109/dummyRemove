package io.spaceandtime.routing.ignitedao;

import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import io.spaceandtime.routing.constant.ColumnConstant;
import io.spaceandtime.routing.constant.MessageEnum;
import io.spaceandtime.routing.constant.SortOrderEnum;
import io.spaceandtime.routing.constant.StatusEnum;
import io.spaceandtime.routing.errorHandler.AppException;
import io.spaceandtime.routing.jdbcdao.BaseIgniteSqlDAOImpl;
import io.spaceandtime.routing.logging.AppLogger;
import io.spaceandtime.routing.logging.Log;
import io.spaceandtime.routing.mapper.KeyDBMapper;
import io.spaceandtime.routing.mapper.SRCMapper;
import io.spaceandtime.routing.mapper.SortByTagIdAsc;
import io.spaceandtime.routing.mapper.SortByTagIdDesc;
import io.spaceandtime.routing.model.SRCViewDto;
import io.spaceandtime.routing.modelignite.SRCView;
import io.spaceandtime.routing.query.CatalogAPIQuery;
import io.spaceandtime.routing.storage.IKeyDBProvider;
import io.spaceandtime.routing.utils.AppUtils;
import io.spaceandtime.routing.utils.Page;
import io.spaceandtime.storage.database.DbView;
import jodd.util.StringUtil;

@Component
public class ViewDAOImpl extends BaseIgniteSqlDAOImpl implements ViewDAO {

	private static @Log AppLogger logger;

	private static final String SELECT = "select";
	private static final String DEFAULT_CATALOG_ID = "SXT";
	private static final String OWNERID = "OWNER_ID";

	@Autowired
	private IKeyDBProvider _keydbProvider;

	/**
	 * To create SXT_VIEWS information
	 * 
	 * @param srcView
	 */
	public void createViewSrc(SRCView srcView) {
		executeDML(CatalogAPIQuery.INSERT_VIEW, srcView,"INSERT");
	}

	/**
	 * To get SXT_VIEWS information
	 * 
	 * @param viewName
	 */
	public List<Map<String, Object>> getViewSrc(String viewId, String viewName) {
		String qryText = CatalogAPIQuery.GET_ALL_VIEW;
		// Filtering by view name
		if (!StringUtils.isAllBlank(viewId)) {
			qryText += " WHERE ID='" + viewId + "';";
		} else {
			qryText += " WHERE VIEW_NAME='" + viewName + "';";
		}
		return getPlatformEntitiesData(qryText);
	}

	/**
	 * To delete SXT_VIEWS information
	 * 
	 * @param viewName
	 */

	public void deleteViewSrc(String viewName) {
		Map<String, Object> params = new HashMap<>();
		params.put(CatalogAPIQuery.VIEW_NAME, viewName);
		String query = parseQuery(params, CatalogAPIQuery.DELETE_VIEW);
		executeDML(query);
	}

	public void updateViewSrc(SRCView srcView) {
		executeDML(CatalogAPIQuery.UPDATE_VIEW_BY_ID,srcView,"UPDATE");
	}

	@Override
	public void updateViewSrcById(SRCView srcView) {
		executeDML(CatalogAPIQuery.UPDATE_VIEW_BY_ID,srcView,"UPDATE");
	}

	@Override
	public List<SRCView> getViewData(List<Map<String, Object>> srcViewMap) {
		List<SRCView> viewList = new ArrayList<>();
		for (Map<String, Object> srcMap : srcViewMap) {
			SRCView srcView = SRCMapper.getView(srcMap);
			viewList.add(srcView);
		}
		return viewList;
	}

	private List<SRCViewDto> getSRCViewDtoData(List<Map<String, Object>> srcViewMap) {
		List<SRCViewDto> srcViewDto = srcViewMap.stream()
				.map(sq -> SRCMapper.mapSRCViewData(sq,
						getTagRelationByEntityId((String) sq.get(ColumnConstant.ID), ColumnConstant.VIEW)))
				.collect(Collectors.toList());
		return srcViewDto;
	}

	@Override
	public List<SRCView> getViewById(String viewId) {
		String qryText = CatalogAPIQuery.GET_ALL_VIEW;
		qryText += " WHERE ID='" + viewId + "'";
		List<Map<String, Object>> srcViewMap = getPlatformEntitiesData(qryText);
		return getViewData(srcViewMap);
	}

	@Override
	public void executeUpdateView(SRCView srcView, String updatedViewName) {
		logger.info("inside update view");
		DbView keyDBView;
		try {
			keyDBView = _keydbProvider.getView(srcView.getViewName());
		} catch (Exception ex) {
			keyDBView = null;
		}
		if (keyDBView == null)
			throw new AppException(MessageEnum.VIEW_NOT_FOUND, srcView.getViewName());

		List<Map<String, Object>> viewSrcList = getViewSrc(null, srcView.getViewName().toLowerCase());
		Map<String, Object> mapView = viewSrcList.get(0);

		if (!mapView.get(OWNERID).equals(getUserId())) {
			throw new AppException(MessageEnum.INVALID_OWNERSHIP, srcView.getViewName());
		}
		if (!StringUtils.isAllBlank(updatedViewName)) {
			srcView.setViewName(updatedViewName);
			keyDBView.setViewId(updatedViewName);
			// updating entry in the View object in KeyDB and SXT_META.SXT_VIEWS table in
			// the SRC cluster
			try {
				_keydbProvider.setView(keyDBView.getViewId(), keyDBView);
				_keydbProvider.setViewIdToName(srcView.getId(), keyDBView.getViewId());
			} catch (Exception e) {
				logger.error(e);
			}
		}
		updateViewSrcById(srcView);
	}

	@Override
	public void executeCreateView(SRCView srcView) {

		String viewTextContent = srcView.getViewText();
		String viewText = AppUtils.extractViewText(viewTextContent);

		if (!(viewText.toLowerCase().startsWith(SELECT))) {
			throw new AppException(MessageEnum.INVALID_VIEW, srcView.getViewName());
		}
		boolean viewExists = false;
		try {
			viewExists = _keydbProvider.viewExists(srcView.getViewName());
		} catch (Exception ex) {
		}
		if (viewExists) {
			throw new AppException(MessageEnum.VIEW_ALREADY_EXIST, srcView.getViewName());
		}

		srcView.setCatalogId(DEFAULT_CATALOG_ID);

		DbView keyDBView = KeyDBMapper.getKeyDBView(srcView);

		// creating a new entry in the SRC cluster
		createViewSrc(srcView);
		// creating a new entry in the View object in KeyDB
		try {
			_keydbProvider.createView(keyDBView.getViewId(), keyDBView);
			_keydbProvider.setViewIdToName(srcView.getId(), keyDBView.getViewId());
		} catch (Exception e) {
			logger.error(e);
		}
	}

	@Override
	public Page<SRCViewDto> getViewList(String searchKeyword, Boolean isPublic, int pageNo, int pageSize,
			SortOrderEnum sortOrder, String sortBy, String tagId, StatusEnum status) {

		String qryText = CatalogAPIQuery.GET_ALL_VIEW;
		String qryCounts = CatalogAPIQuery.COUNT_VIEW;
		List<String> filters = new ArrayList<>();

		if (!StringUtil.isAllBlank(searchKeyword))
			filters.add("LOWER(v.VIEW_NAME) LIKE LOWER(CONCAT('%', '" + searchKeyword + "', '%'))");

		if (!StringUtil.isAllBlank(tagId)) {
			qryText = CatalogAPIQuery.GET_VIEW_BY_TAG;
			filters.add(" t.TAG_ID = '" + tagId + "'");
			qryCounts = CatalogAPIQuery.GET_VIEW_COUNT_BY_TAG;
		}
		// Filtering by isPublic
		if (isPublic) {
			filters.add(" ISPUBLIC = TRUE");
		} else {
			addStatusFilter(status, filters);
		}

		if (!filters.isEmpty()) {
			qryText += " WHERE " + String.join(" AND ", filters);
			qryCounts += " WHERE " + String.join(" AND ", filters);
		}

		int count = getTotalRecords(qryCounts);
		logger.info("total records: " + count);
		qryText = buildPaginatedQuery(pageNo, pageSize, sortOrder, buildSortByColumnName(sortBy), qryText);
		List<Map<String, Object>> viewList = getPlatformEntitiesData(qryText);
		List<SRCViewDto> srcViewList = getSRCViewDtoData(viewList);
		if (sortBy.equalsIgnoreCase(ColumnConstant.TAG)) {
			if (sortOrder.getSortOrder().equalsIgnoreCase(ColumnConstant.ASCENDING_ORDER)) {
				for (SRCViewDto srcViewDto : srcViewList) {
					Collections.sort(srcViewDto.getTags(), new SortByTagIdAsc());
				}
			} else {
				for (SRCViewDto srcViewDto : srcViewList) {
					Collections.sort(srcViewDto.getTags(), new SortByTagIdDesc());
				}
			}
		}
		return pageableContent(pageNo, pageSize, count, srcViewList);
	}

	@Override
	public void checkViewAuthorization(String id) {
		String userId = getUserId();
		String qryText = CatalogAPIQuery.COUNT_VIEW;
		List<String> filters = new ArrayList<>();
		filters.add("OWNER_ID = '" + userId + "'");
		filters.add("ID = '" + id + "'");
		qryText += " WHERE " + String.join(" AND ", filters);
		int totalRecords = getTotalRecords(qryText);
		if (totalRecords == 0)
			throw new AppException(MessageEnum.BADREQUEST);
	}

	public boolean isViewNameExist(String viewId, String requestedViewName) {
		String qryText = CatalogAPIQuery.COUNT_VIEW;
		qryText += " WHERE ID!='" + viewId + "' AND VIEW_NAME='" + requestedViewName + "'";
		int count = getTotalRecords(qryText);
		return count != 0;
	}
}
