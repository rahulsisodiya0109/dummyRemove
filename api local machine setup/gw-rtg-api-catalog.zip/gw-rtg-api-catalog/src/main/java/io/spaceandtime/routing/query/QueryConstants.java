package io.spaceandtime.routing.query;
/**
 * 
 * @author Aswanth Guvala
 *
 */
public class QueryConstants {

	public final static String SELECT_ALL = "SELECT * FROM {0}{1}";

	public final static String SELECT_BY_COLUMNS = "SELECT {0} FROM {1}{2}";

	public final static String SELECT_PAGINATE = " OFFSET {0} ROWS FETCH NEXT {1}  ROWS ONLY";

	public final static String SELECT_PAGINATE_MYSQL = " limit {0}, {1}";

	public final static String SELECT_COUNT_ALL = "SELECT COUNT(*) FROM {0}{1}";

	public final static String SELECT_ALL_LIMIT = " ORDER BY {0} OFFSET {1} ROWS FETCH NEXT {2}  ROWS ONLY";

	public final static String SELECT_ALL_LIMIT_MYSQL = " ORDER BY {0} LIMIT {1},{2}";

	public final static String FIND_HIERARCHY_ALL = "SELECT * FROM {0}{1} where {2}=''{3}''";

	public final static String WHERE = " where ";

	public final static String AND = " and ";

	public final static String EMPTY = " ";

	public final static String SINGLE_QUOTE = "\'";

	public final static String COMMA = ",";

	public final static String VALUES_DELIMITER = "\',\'";

	public final static String INSERT = "INSERT INTO {0}{1} ({2}) VALUES ({3})";

	public final static String UPDATE = "UPDATE {0}{1} SET {2}";

	public final static String DELETE = "DELETE FROM {0}{1}";

	public final static String ORDER_BY = "ORDER BY {0} {1}";

}
