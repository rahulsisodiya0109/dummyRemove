package io.spaceandtime.routing.model;

import java.util.List;

public class OrganizationGroup {

	private String orgId;
	private List<String> userIdList;

	public String getOrgId() {
		return orgId;
	}

	public void setOrgId(String orgId) {
		this.orgId = orgId;
	}

	public List<String> getUserIdList() {
		return userIdList;
	}

	public void setUserIdList(List<String> userIdList) {
		this.userIdList = userIdList;
	}

}
