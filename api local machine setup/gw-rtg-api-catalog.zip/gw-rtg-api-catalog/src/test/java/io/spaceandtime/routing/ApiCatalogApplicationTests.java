package io.spaceandtime.routing;

import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ApiCatalogApplicationTests {

}
