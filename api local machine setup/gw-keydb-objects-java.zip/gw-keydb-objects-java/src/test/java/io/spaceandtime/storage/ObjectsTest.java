package io.spaceandtime.storage;

import java.util.Set;

import org.junit.jupiter.api.Test;

import io.spaceandtime.storage.database.*;
import io.spaceandtime.storage.management.*;
import io.spaceandtime.storage.operator.*;
import io.spaceandtime.storage.state.*;
import io.spaceandtime.storage.streaming.*;
import io.spaceandtime.storage.subscription.*;
import io.spaceandtime.storage.user.*;

public class ObjectsTest {
	@Test public void testDatabase() throws Exception {
		Set<String> props = ReflectionHelper.findAllPropertyNames(DbProps.class);
		ReflectionHelper.testClass(DbIndex.class, props);
		ReflectionHelper.testClass(DbObjectHosts.class, props);
		ReflectionHelper.testClass(DbObjectLeaders.class, props);
		ReflectionHelper.testClass(DbSchema.class, props);
		ReflectionHelper.testClass(DbSchemaAssets.class, props);
		ReflectionHelper.testClass(DbSchemaAssets.class, props);
		ReflectionHelper.testClass(DbTable.class, props);
		ReflectionHelper.testClass(DbTableColumn.class, props);
		ReflectionHelper.testClass(DbView.class, props);
		ReflectionHelper.testClass(DbViewParameter.class, props);
	}

	@Test public void testOperator() throws Exception {
		Set<String> props = ReflectionHelper.findAllPropertyNames(OperatorProps.class);
		ReflectionHelper.testClass(ClusterGroup.class, props);
		ReflectionHelper.testClass(DataWarehouse.class, props);
		ReflectionHelper.testClass(Gateway.class, props);
		ReflectionHelper.testClass(ServiceOperator.class, props);
	}

	@Test public void testState() throws Exception {
		Set<String> props = ReflectionHelper.findAllPropertyNames(StateProps.class);
		ReflectionHelper.testClass(RequestLog.class, props);
	}

	@Test public void testStreaming() throws Exception {
		Set<String> props = ReflectionHelper.findAllPropertyNames(StreamingProps.class);
		ReflectionHelper.testClass(ClusterCredentials.class, props);
		ReflectionHelper.testClass(ClusterDITasks.class, props);
		ReflectionHelper.testClass(DITask.class, props); 
		ReflectionHelper.testClass(IGAcls.class, props);
		ReflectionHelper.testClass(IGTopics.class, props);
		ReflectionHelper.testClass(IGUsers.class, props);
		ReflectionHelper.testClass(InfrastructureGroup.class, props);
		ReflectionHelper.testClass(KafkaAcl.class, props);
	}

	@Test public void testUser() throws Exception {
		Set<String> props = ReflectionHelper.findAllPropertyNames(UserProps.class);
		ReflectionHelper.testClass(AuthKey.class, props);
		ReflectionHelper.testClass(User.class, props);
		ReflectionHelper.testClass(UserChallenge.class, props);
		ReflectionHelper.testClass(UserSession.class, props);
	}

	@Test public void testSubscription() throws Exception {
		Set<String> props = ReflectionHelper.findAllPropertyNames(SubscriptionProps.class);
		ReflectionHelper.testClass(Subscription.class, props);
		ReflectionHelper.testClass(SubscriptionBlockTime.class, props);
		ReflectionHelper.testClass(SubscriptionClusterAssignment.class, props);
		ReflectionHelper.testClass(SubscriptionInvite.class, props);
		ReflectionHelper.testClass(SubscriptionPayment.class, props);
		ReflectionHelper.testClass(SubscriptionUserRoles.class, props);
	}

	@Test public void testManagement() throws Exception {
		Set<String> props = ReflectionHelper.findAllPropertyNames(ManagementProps.class);
		ReflectionHelper.testClass(BlockTime.class, props);
		ReflectionHelper.testClass(KrakendConfig.class, props);
		ReflectionHelper.testClass(SubscriptionProvider.class, props);
	}
}
