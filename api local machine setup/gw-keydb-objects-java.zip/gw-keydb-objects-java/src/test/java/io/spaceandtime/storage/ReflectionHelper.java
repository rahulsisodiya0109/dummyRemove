package io.spaceandtime.storage;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertTrue;

import java.lang.reflect.Constructor;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.lang.reflect.Modifier;
import java.lang.reflect.ParameterizedType;
import java.math.BigDecimal;
import java.math.MathContext;
import java.time.Instant;
import java.time.temporal.ChronoUnit;
import java.util.*;

import org.apache.logging.log4j.util.Strings;

import com.fasterxml.jackson.annotation.JsonProperty;
import io.spaceandtime.storage.core.JsonHelper;

public class ReflectionHelper {
	// NOTE: using all uppercase because some of the identifiers will auto-cast to
	// upper on setter (which would break getter/setter roundtrip)
	private static final String CHARACTERS = "ABCDEFGHIJKLMNOPQRSTUVWXYZ1234567890";
	private static final int STRING_LENGTH = 24;
	private static final Random _random = new Random();
	
	/** Defines the metadata about a given field */
	private static class FieldData {
		/** The reflection field reference */
		public final Field Field;
		/** The field type */
		public final Class<?> Type;
		/** The field getter method */
		public final Method Getter;
		/** The field setter method */
		public final Method Setter;

		public FieldData(Field field, Class<?> type, Method getter, Method setter) {
			Field = field;
			Type = type;
			Getter = getter;
			Setter = setter;
		}
	}
	
	/** Defines the test state object */
	private static class TestState<T> {
		/** Defines the test class type */
		public final Class<T> ClassType;
		/** Defines the field map for a given test object */
		public final Map<String, FieldData> FieldMap = new HashMap<>();
		/** Defines all available JSON property names for the object */
		public final Set<String> AllProperties;
		/** The original object instance */
		public T Instance;

		public TestState(Class<T> clazz, Set<String> allProperties) {
			ClassType = clazz;
			AllProperties = allProperties;
		}
		/** Find fields of the test class */
		public void findFields() throws Exception {
			for (Field classField : ClassType.getDeclaredFields()) {
				addField(classField);
			}
			Class<?> testClassType = ClassType;
			while (true) {
				Class<?> superClassType = testClassType.getSuperclass();
				if (superClassType == null)
					break;

				testClassType = superClassType;
				for (Field classField : testClassType.getDeclaredFields()) {
					addField(classField);
				}
			}
		}
		/** Add a new field to the field map */
		private void addField(Field field) throws Exception {
			// Skip static fields
			if (Modifier.isStatic(field.getModifiers())) return;

			Class<?> fieldType = field.getType();
			String actualFieldName = field.getName();

			// Validate JsonProperty annotation exists
			JsonProperty jsonPropertyAnnotation = field.getDeclaredAnnotation(JsonProperty.class);
			assertNotNull(jsonPropertyAnnotation, "JsonProperty does not exist on field '" + actualFieldName + "'");
			assertTrue(AllProperties.contains(jsonPropertyAnnotation.value()), "JsonProperty value is not part of the defined property set");

			// Field name should have underscore prefix
			assertTrue(actualFieldName.startsWith("_"), "Field '" + actualFieldName + "' does not have underscore prefix");
			String fieldName = actualFieldName.replace("_", "");
			// Build a capitalized field name to find getter/setter
			String fieldMethodBaseName = fieldName.substring(0, 1).toUpperCase() + fieldName.substring(1);
			Method getter;
			if (fieldType == Boolean.class ||
					(fieldType.isPrimitive() && fieldType.getName().equals("boolean"))) {
				getter = ClassType.getMethod("is" + fieldMethodBaseName);
			} else {
				getter = ClassType.getMethod("get" + fieldMethodBaseName);
			}
			Method setter = ClassType.getMethod("set" + fieldMethodBaseName, field.getType());
			FieldMap.put(actualFieldName, new FieldData(field, fieldType, getter, setter));
		}
		/** Construct a new instance of the class */
		public T newInstance() throws Exception {
			Instance = ClassType.getDeclaredConstructor().newInstance();
			return Instance;
		}
		/** Test getters and setters */
		public void testGettersSetters() throws Exception {
			for (FieldData field : FieldMap.values()) {
				Object value = getRandomValue(field.Type, field.Field);
				field.Setter.invoke(Instance, value);
				Object result = field.Getter.invoke(Instance);
				assertEquals(value, result, "Getter/Setter roundtrip does not result in same value");
			}
		}
		/** Test serializing then deserializing object and validate values still the same */
		public void testJsonSerdes() throws Exception {
			String serialized = JsonHelper.serialize(Instance);
			System.out.println(serialized);
			T deserialized = JsonHelper.deserialize(serialized, ClassType);
			for (Map.Entry<String, FieldData> entry : FieldMap.entrySet()) {
				FieldData field = entry.getValue();
				Object originalValue = field.Getter.invoke(Instance);
				Object deserializedValue = field.Getter.invoke(deserialized);
				compareFields(originalValue, deserializedValue, field.Type, entry.getKey());
			}
		}
	}


	public static <T> Set<String> findAllPropertyNames(Class<T> clazz) throws Exception {
		Set<String> properties = new HashSet<>();
		for (Field classField : clazz.getDeclaredFields()) {
			assertTrue(Modifier.isStatic(classField.getModifiers()), "Property class " + clazz.getSimpleName() + " has non-static field");
			Class<?> fieldType = classField.getType();
			assertTrue(fieldType == String.class, "Non-string property in property class " + clazz.getSimpleName());
			properties.add((String)classField.get(null));
		}

		return properties;
	}

	public static <T> void testClass(Class<T> clazz, Set<String> allProperties) throws Exception {
		System.out.println("Testing class " + clazz.getSimpleName());
		TestState<T> state = new TestState<>(clazz, allProperties);
		
		System.out.println("\n\nTesting default constructor");
		state.newInstance();

		System.out.println("\n\nFinding fields");
		state.findFields();
		System.out.println("Found fields: " + Strings.join(state.FieldMap.keySet(), ','));

		System.out.println("\n\nTesting getters/setters");
		state.testGettersSetters();

		System.out.println("\n\nTesting JSON serdes");
		state.testJsonSerdes();
	}


	private static void compareFields(Object fieldOne, Object fieldTwo, Class<?> fieldType, String fieldName) throws Exception {
		String errorMessage = "Field '" + fieldName + "' value comparison failed";
		if (fieldType.isPrimitive() ||
			fieldType == Boolean.class ||
			fieldType == String.class ||
			fieldType == Long.class ||
			fieldType == Integer.class ||
			fieldType == BigDecimal.class ||
			fieldType.isEnum()
		) {
			assertEquals(fieldOne, fieldTwo, errorMessage);
		} else if (fieldType == UUID.class || fieldType == Instant.class) {
			assertTrue(fieldOne.equals(fieldTwo), errorMessage);
		} else if (fieldType == List.class) {
			Collection<?> originalColl = (Collection<?>) fieldOne;
			Collection<?> deserializedColl = (Collection<?>) fieldOne;
			assertTrue(!originalColl.retainAll(deserializedColl), errorMessage);
		} else {
			for (Field childFieldDef : fieldType.getDeclaredFields()) {
				childFieldDef.setAccessible(true);
				Object childFieldOne = childFieldDef.get(fieldOne);
				Object childFieldTwo = childFieldDef.get(fieldTwo);
				compareFields(childFieldOne, childFieldTwo, childFieldDef.getType(), childFieldDef.getName());
			}
		}
	}

	private static Object getRandomValue(Class<?> valueType, Field field) throws Exception {
		if (valueType == Boolean.class ||
			(valueType.isPrimitive() && valueType.getName().equals("boolean"))
		) {
			return _random.nextBoolean();
		} else if (valueType == Long.class ||
			(valueType.isPrimitive() && valueType.getName().equals("long"))
		) {
			return _random.nextLong();
		} else if (valueType == Integer.class ||
			(valueType.isPrimitive() && valueType.getName().equals("int"))
		) {
			return _random.nextInt();
		} else if (valueType == BigDecimal.class) {
			return new BigDecimal(_random.nextDouble(), MathContext.UNLIMITED);
		} else if (valueType == String.class) {
			char[] cArr = new char[STRING_LENGTH];
			for (int i = 0; i < STRING_LENGTH; ++i) {
				cArr[i] = CHARACTERS.charAt(_random.nextInt(CHARACTERS.length()));
			}
			return new String(cArr);
		} else if (valueType.isEnum()) {
			return valueType.getEnumConstants()[0];
		} else if (valueType == Instant.class) {
			ChronoUnit units;
			switch (_random.nextInt(3)) {
				case 0:
					units = ChronoUnit.SECONDS;
				case 1:
					units = ChronoUnit.MILLIS;
				default:
					units = ChronoUnit.HOURS;
			}
			return Instant.now().plus(_random.nextInt(1000), units);
		} else if (valueType == UUID.class) {
			return UUID.randomUUID();
		} else if (valueType == List.class) {
			ParameterizedType listType = (ParameterizedType) field.getGenericType();
			Class<?> listElementType = (Class<?>) listType.getActualTypeArguments()[0];
			return constructGenericList(listElementType);
		} else if (valueType == Map.class) {
			ParameterizedType mapType = (ParameterizedType)field.getGenericType();
			Class<?> keyElementType = (Class<?>)mapType.getActualTypeArguments()[0];
			Class<?> valueElementType = (Class<?>) mapType.getActualTypeArguments()[1];
			return constructGenericMap(keyElementType, valueElementType);
		} else {
			for (Constructor<?> constructor : valueType.getConstructors()) {
				if (constructor.getParameterCount() == 0) {
					return constructor.newInstance();
				}
			}
		}
		throw new Exception("value type " + valueType.getSimpleName() + " not supported");
	}

	@SuppressWarnings("unchecked")
	private static <T> List<T> constructGenericList(Class<T> clazz) throws Exception {
		List<T> list = new ArrayList<>();
		for (int i = 0; i < _random.nextInt(5); ++i) {
			list.add((T)getRandomValue(clazz, null));
		}
		return list;
	}

	@SuppressWarnings("unchecked")
	private static <K,V> Map<K,V> constructGenericMap(Class<K> keyClazz, Class<V> valueClazz) throws Exception {
		Map<K,V> map = new HashMap<>();
		for (int i = 0; i < _random.nextInt(5); ++i) {
			K key = (K)getRandomValue(keyClazz, null);
			V value = (V)getRandomValue(valueClazz, null);
			map.put(key, value);
		}
		return map;
	}
}
