package io.spaceandtime.storage;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertTrue;

import java.util.*;
import java.util.concurrent.TimeUnit;

import org.junit.jupiter.api.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.DynamicPropertyRegistry;
import org.springframework.test.context.DynamicPropertySource;
import org.springframework.test.context.TestPropertySource;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.util.StringUtils;
import org.testcontainers.containers.GenericContainer;
import org.testcontainers.junit.jupiter.Container;
import org.testcontainers.junit.jupiter.Testcontainers;
import org.testcontainers.utility.DockerImageName;

import io.spaceandtime.storage.core.IStorageProvider;
import io.spaceandtime.storage.database.DbIndex;

@SpringBootTest
@RunWith(SpringRunner.class)
@TestPropertySource(locations = "classpath:application-test.properties")
@Testcontainers
public class ProviderTest {
	
	@Container
	public static GenericContainer keydb = new GenericContainer(DockerImageName.parse("redis:5.0.3-alpine"))
		.withExposedPorts(6379);

	@DynamicPropertySource
	static void dataSourceProperties(DynamicPropertyRegistry registry) {
		registry.add("keydb_host", keydb::getHost);
		registry.add("keydb_port", keydb::getFirstMappedPort);
	}

	@Autowired
	private IStorageProvider _provider;

	@Test public void testConnect() throws Exception {
		assertEquals("PONG", _provider.ping());
	}


	@Test public void testBasicOps() throws Exception {
		// Test key set
		final String KEY = "testKey";
		_provider.vSet(KEY, "hello");
		// Test key get
		String result1 = _provider.vGet(KEY);
		assertEquals("hello", result1);

		// Test delete
		_provider.delete(KEY);
		String result2 = _provider.vGet(KEY);
		assertTrue(!StringUtils.hasLength(result2));

		// Test expire
		_provider.vSet(KEY, "world");
		_provider.setTtl(KEY, 10L, TimeUnit.MILLISECONDS);
		Thread.sleep(13L);
		String result3 = _provider.vGet(KEY);
		assertTrue(!StringUtils.hasLength(result3));
	}

	@Test public void testAtomic() throws Exception {
		final String KEY = "atomicInt";
		Long value = _provider.vIncrement(KEY);
		assertEquals(1L, value);

		value = _provider.vIncrementBy(KEY, 10);
		assertEquals(11L, value);

		value = _provider.vDecrement(KEY);
		assertEquals(10L, value);

		value = _provider.vDecrementBy(KEY, 10L);
		assertEquals(0L, value);
	}

	@Test public void testHash() throws Exception {
		final String KEY = "my:separated:key";

		final String HKEY1 = "hello";
		final String HVAL1 = "world";
		assertTrue(!_provider.hExists(KEY, HKEY1));
		_provider.hPut(KEY, HKEY1, HVAL1);
		assertTrue(_provider.hExists(KEY, HKEY1));
		assertEquals(HVAL1, _provider.hGet(KEY, HKEY1));

		final String HKEY2 = "index";
		final DbIndex HVAL2 = new DbIndex("index_1", "SXT", "ETHEREUM", "TRANSACTIONS");
		_provider.hPut(KEY, HKEY2, HVAL2);
		Set<String> keys = _provider.hKeys(KEY);
		assertTrue(keys.contains(HKEY1));
		assertTrue(keys.contains(HKEY2));

		DbIndex out = _provider.hGet(KEY, HKEY2, DbIndex.class);
		assertEquals(HVAL2.getCatalogId(), out.getCatalogId());
		_provider.hDelete(KEY, HKEY2);
		assertTrue(_provider.hKeys(KEY).size() == 1);
	}

	@Test public void testSet() throws Exception {
		final String KEY = "set";

		_provider.sAdd(KEY, "one");
		_provider.sAdd(KEY, "two");
		_provider.sAdd(KEY, "three");
		_provider.sAdd(KEY, "one");

		Set<String> values = _provider.sGetAll(KEY);
		assertEquals(3, values.size());
		assertTrue(_provider.sIsMember(KEY, "one"));

		_provider.sDelete(KEY, "three");
		assertTrue(!_provider.sIsMember(KEY, "three"));
	}

	@Test public void testList() throws Exception {
		final String KEY = "list";

		_provider.lPushHead(KEY, "one");
		_provider.lPushTail(KEY, "two");
		_provider.lPushHead(KEY, "three");

		List<String> values = _provider.lGetAll(KEY);
		assertEquals(3, values.size());
		assertEquals("three", values.get(0));
		assertEquals("one", values.get(1));
		assertEquals("two", values.get(2));

		values = _provider.lGetBetween(KEY, 1, -1);
		assertEquals(2, values.size());

		String middle = _provider.lGetAtIndex(KEY, 1);
		assertEquals("one", middle);

		String end = _provider.lPopTail(KEY);
		assertEquals(2, _provider.lGetAll(KEY).size());
		assertEquals("two", end);
	}
}
