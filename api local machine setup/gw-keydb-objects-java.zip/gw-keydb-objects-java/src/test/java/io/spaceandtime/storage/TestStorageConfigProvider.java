package io.spaceandtime.storage;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import io.spaceandtime.storage.core.IStorageConfigProvider;

@Component
public class TestStorageConfigProvider implements IStorageConfigProvider {
	
	@Value("${keydb_port}")
	private int KEYDB_PORT;
	@Value("${keydb_host}")
	private String KEYDB_HOST;
	@Value("${keydb_password}")
	private String KEYDB_PASSWORD;

	@Override
	public String getHost() { return KEYDB_HOST; }
	@Override
	public int getPort() { return KEYDB_PORT; }
	@Override
	public String getPassword() { return KEYDB_PASSWORD; }
	
}
