package io.spaceandtime.storage.user;

import io.spaceandtime.storage.core.JsonDefaultSerdesConfig;

import org.springframework.lang.Nullable;

import com.fasterxml.jackson.annotation.JsonProperty;

/**
 * Defines the base implementation of a user object
 */
@JsonDefaultSerdesConfig
public abstract class UserBase {
	
	/** The user identifier */
	@JsonProperty(UserProps.USER_ID)
	private String _userId = null;

	public UserBase(){}
	public UserBase(String userId) {
		_userId = userId;
	}
	
	@Nullable public String getUserId() { return _userId; }
	public void setUserId(String value) { _userId = value; }
}
