package io.spaceandtime.storage.user;

import io.spaceandtime.storage.core.StorageConstants.*;
import io.spaceandtime.storage.subscription.SubscriptionProps;

/**
 * Defines user property constants
 */
public final class UserProps {
	public static final String USER_ID = CommonProps.USER_ID;
	public static final String SUBSCRIPTION_ID = SubscriptionProps.SUBSCRIPTION_ID;
	public static final String KEYCHAIN = "keychain";
	public static final String PUBLIC_KEY = CommonProps.PUBLIC_KEY;
	public static final String ALGORITHM = "algorithm";
	public static final String CHAIN_ID = "chainId";
	public static final String AUTH_CODE = "authCode";
	public static final String PREFIX = "prefix";
	public static final String IS_REGISTRATION = "isRegistration";
	public static final String ITERATION_ID = "iterationId";
	public static final String SESSION_ID = "sessionId";
	public static final String SESSION_START = "sessionStart";
	public static final String SESSION_EXPIRES = "sessionExpires";
	public static final String JOIN_CODE = SubscriptionProps.JOIN_CODE;
	

	public static final String ALG_ED25519 = "ed25519";
	public static final String ALG_ETHEREUM = "eth";
}
