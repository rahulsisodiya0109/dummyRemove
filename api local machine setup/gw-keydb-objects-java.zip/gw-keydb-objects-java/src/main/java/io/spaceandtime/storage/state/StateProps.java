package io.spaceandtime.storage.state;

import io.spaceandtime.storage.core.StorageConstants.CommonProps;

public final class StateProps {
	public static final String REQUEST_ID = "requestId";
	public static final String USER_ID = CommonProps.USER_ID;
	public static final String SQL_TEXT = "sqlText";
	public static final String GATEWAY_ID = CommonProps.GATEWAY_ID;
	public static final String DATA_WAREHOUSE_ID = CommonProps.DATA_WAREHOUSE_ID;
	public static final String RUNTIME = "runtime";
	public static final String EXEC_TIME = "execTime";
	public static final String ROW_COUNT = "rowCount";
	public static final String RESPONSE_SIZE = "responseSize";
	public static final String ERROR_DETAILS = "errorDetails";
	public static final String ORIGIN = "origin";
	public static final String METADATA = "metadata";
}
