package io.spaceandtime.storage.datawarehouse;

import io.spaceandtime.storage.core.StorageConstants.*;

/**
 * Defines data warehouse property constants
 */
public final class DWProps {
	public static final String DATA_WAREHOUSE_ID = CommonProps.DATA_WAREHOUSE_ID;
	public static final String SCHEMAS = CommonProps.SCHEMAS;
	public static final String TABLES = CommonProps.TABLES;
	public static final String VIEWS = CommonProps.VIEWS;
	public static final String INDICES = CommonProps.INDICES;
	public static final String SQL_CONNECTION = "sqlConnection";
	public static final String KAFKA_BROKERS = "kafkaBrokers";
	public static final String MANAGEMENT = "management";
	public static final String ADDR = "address";
	public static final String USERNAME = CommonProps.USERNAME;
	public static final String PASSWORD = CommonProps.PASSWORD;
	public static final String STATUS = "status";
	public static final String SENT_TIME = "sentTime";
	public static final String RECEIVED_TIME = "receivedTime";
	public static final String SUCCESSFUL_PINGS = "successfulPings";
	public static final String FAILED_PINGS = "failedPings";

	public static final String STATUS_UNKNOWN = "UNKNOWN";
	public static final String STATUS_AVAILABLE = "AVAILABLE";
	public static final String STATUS_UNAVAILABLE = "UNAVAILABLE";
}
