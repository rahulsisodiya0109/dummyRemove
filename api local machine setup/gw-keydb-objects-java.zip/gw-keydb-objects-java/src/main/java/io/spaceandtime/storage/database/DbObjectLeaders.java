package io.spaceandtime.storage.database;

import java.util.List;

import io.spaceandtime.storage.core.*;
import io.spaceandtime.storage.operator.ClusterGroup;

/**
 * Stores metadata about the leaders of a data warehouse object (i.e., the
 * data warehouse clusters that are responsible for processing user requests)
 * <p>
 * NOTE: this object will always be a subset of {@linkplain DbObjectHosts},
 * storing only those clusters where requests should currently be routed. In
 * addition, there can be multiple leaders for certain resources (typically
 * those that are read-only from the user perspective and highly replicated -
 * i.e. blockchain tables)
 */
@JsonDefaultSerdesConfig
public class DbObjectLeaders extends ClusterGroup {
	public static final String KEY = Keys.Db.OBJECT_LEADERS;
	
	public DbObjectLeaders() { super(); }
	public DbObjectLeaders(List<String> clusters) {
		super(clusters);
	}
}
