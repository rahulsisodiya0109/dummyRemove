package io.spaceandtime.storage.core;

/**
 * Defines the contract for the storage library configuration provider
 */
public interface IStorageConfigProvider {
	/**
	 * Get the storage endpoint hostname
	 * @return
	 */
	String getHost();
	/**
	 * Get the storage endpoint port
	 * @return
	 */
	int getPort();
	/**
	 * Get the storage endpoint password for authentication
	 * @return
	 */
	String getPassword();
}
