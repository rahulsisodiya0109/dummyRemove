package io.spaceandtime.storage.operator;

import org.springframework.lang.Nullable;

import com.fasterxml.jackson.annotation.JsonProperty;

import io.spaceandtime.storage.core.*;

/**
 * Stores data warehouse cluster information
 */
@JsonDefaultSerdesConfig
public class DataWarehouse extends OperatedCluster {
	public static final String KEY = Keys.Operator.DATA_WAREHOUSE;

	/** Defines the data warehouse cluster type */
	public enum ClusterType {
		/** Denotes the preferred cluster for handling user requests */
		@JsonProperty(OperatorProps.CLUSTER_TYPE_PRIMARY) PRIMARY(OperatorProps.CLUSTER_TYPE_PRIMARY),
		/** Denotes the backup cluster to handle user requests in case of primary failure */
		@JsonProperty(OperatorProps.CLUSTER_TYPE_SECONDARY) SECONDARY(OperatorProps.CLUSTER_TYPE_SECONDARY);

		/** The cluster type string value */
		public final String Value;
		ClusterType(String value) {
			Value = value;
		}

		/**
		 * Try to convert a string into it's corresponding cluster type
		 * @param value - the string value
		 * @return
		 * @throws Exception
		 */
		public static ClusterType tryConvert(String value) throws Exception {
			switch (value) {
				case OperatorProps.CLUSTER_TYPE_PRIMARY:
					return PRIMARY;
				case OperatorProps.CLUSTER_TYPE_SECONDARY:
					return SECONDARY;
				default: throw new Exception("Provided value is invalid for ClusterType (" + value +")");
			}
		}
	}

	/** The data warehouse identifier */
	@JsonProperty(OperatorProps.DATA_WAREHOUSE_ID)
	private String _id = null;
	/** The cluster type */
	@JsonProperty(OperatorProps.DW_CLUSTER_TYPE)
	private ClusterType _type;
	/** Defines whether or not this data warehouse is a default primary for new subscriptions */
	@JsonProperty(OperatorProps.DEFAULT_PRIMARY)
	private Boolean _defaultPrimary = null;
	/** Defines whether or not this data warehouse is a default secondary for new subscriptions */
	@JsonProperty(OperatorProps.DEFAULT_SECONDARY)
	private Boolean _defaultSecondary = null;

	public DataWarehouse() { super(); }
	public DataWarehouse(String warehouseId, String operatorId, String hardware, Long stakedBounty, ClusterType type, Boolean isDefaultPrimary, Boolean isDefaultSecondary) {
		super(operatorId, hardware, stakedBounty);
		_id = warehouseId;
		_type = type;
		_defaultPrimary = isDefaultPrimary;
		_defaultSecondary = isDefaultSecondary;
	}

	@Override
	public String getId() { return _id; }
	public ClusterType getType() { return _type; }
	@Nullable public Boolean isDefaultPrimary() { return _defaultPrimary; }
	@Nullable public Boolean isDefaultSecondary() { return _defaultSecondary; }
	
	@Override
	public void setId(String value) { _id = value; }
	public void setType(ClusterType value) { _type = value; }
	public void setDefaultPrimary(Boolean value) { _defaultPrimary = value; }
	public void setDefaultSecondary(Boolean value) { _defaultSecondary = value; }
}
