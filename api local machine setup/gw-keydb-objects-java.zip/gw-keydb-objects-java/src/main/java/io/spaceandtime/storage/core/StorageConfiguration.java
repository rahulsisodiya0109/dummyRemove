package io.spaceandtime.storage.core;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.data.redis.connection.*;
import org.springframework.data.redis.connection.jedis.JedisConnectionFactory;
import org.springframework.data.redis.core.RedisTemplate;
import org.springframework.data.redis.serializer.StringRedisSerializer;
import org.springframework.util.StringUtils;

/**
 * Provides the storage configuration for the application
 */
@Configuration
public class StorageConfiguration {

	@Autowired
	private IStorageConfigProvider _configProvider;

	@Bean
	public RedisConnectionFactory connectionFactory() {
		RedisStandaloneConfiguration config = new RedisStandaloneConfiguration();
		config.setHostName(_configProvider.getHost());
		config.setPort(_configProvider.getPort());
		String password = _configProvider.getPassword();
		if (StringUtils.hasLength(password)) {
			config.setPassword(RedisPassword.of(password));
		}
		return new JedisConnectionFactory(config);
	}

	@Bean
	public RedisTemplate<String, String> redisTemplate() {
		RedisTemplate<String, String> template = new RedisTemplate<>();
		template.setConnectionFactory(connectionFactory());
		template.setDefaultSerializer(new StringRedisSerializer());
		template.afterPropertiesSet();
		return template;
	}
}