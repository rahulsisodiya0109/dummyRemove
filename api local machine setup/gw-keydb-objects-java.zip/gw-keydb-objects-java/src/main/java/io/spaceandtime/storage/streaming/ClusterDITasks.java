package io.spaceandtime.storage.streaming;

import java.util.List;

import org.springframework.lang.Nullable;

import com.fasterxml.jackson.annotation.JsonProperty;

import io.spaceandtime.storage.core.JsonDefaultSerdesConfig;

/**
 * Stores metadata about a cluster's assigned ingestion
 * tasks ({@linkplain DITask}) 
 */
@JsonDefaultSerdesConfig
public class ClusterDITasks {
	
	/** The list of tasks assigned to the cluster */
	@JsonProperty(StreamingProps.TASKS)
	private List<String> _tasks = null;

	public ClusterDITasks(){}
	public ClusterDITasks(List<String> tasks) {
		_tasks = tasks;
	}

	@Nullable public List<String> getTasks() { return _tasks; }
	public void setTasks(List<String> value) { _tasks = value; }
}
