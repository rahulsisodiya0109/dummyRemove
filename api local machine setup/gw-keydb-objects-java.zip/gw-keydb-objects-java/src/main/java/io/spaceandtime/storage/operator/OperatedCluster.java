package io.spaceandtime.storage.operator;

import com.fasterxml.jackson.annotation.JsonProperty;

import io.spaceandtime.storage.core.*;

/**
 * Represents a cluster in the network operated by some service provider
 */
@JsonDefaultSerdesConfig
public abstract class OperatedCluster {
	
	/** The owning operator's identifier */
	@JsonProperty(OperatorProps.OPERATOR_ID)
	private String _operatorId = null;
	/** The cluster hardware details */
	@JsonProperty(OperatorProps.HARDWARE)
	private String _hardware = null;
	/** The cluster's staked bounty */
	@JsonProperty(OperatorProps.STAKED_BOUNTY)
	private Long _stakedBounty = null;

	public OperatedCluster(){}
	public OperatedCluster(String operatorId, String hardware, Long stakedBounty) {
		_operatorId = operatorId;
		_hardware = hardware;
		_stakedBounty = stakedBounty;
	}

	public abstract String getId();
	public String getOperatorId() { return _operatorId; }
	public String getHardware() { return _hardware; }
	public Long getStakedBounty() { return _stakedBounty; }
	
	public abstract void setId(String value);
	public void setOperatorId(String value) { _operatorId = value; }
	public void setHardware(String value) { _hardware = value; }
	public void setStakedBounty(Long value) { _stakedBounty = value; }
}
