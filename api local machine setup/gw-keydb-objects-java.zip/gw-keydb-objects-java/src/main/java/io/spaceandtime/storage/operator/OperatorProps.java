package io.spaceandtime.storage.operator;

import io.spaceandtime.storage.core.StorageConstants.*;

/**
 * Defines operator property constants
 */
public final class OperatorProps {
	public static final String OPERATOR_ID = "operatorId";
	public static final String HARDWARE = "hardware";
	public static final String STAKED_BOUNTY = "stakedBounty";
	public static final String WALLET_ADDR = CommonProps.WALLET_ADDR;
	public static final String GATEWAY_ID = CommonProps.GATEWAY_ID;
	public static final String DATA_WAREHOUSE_ID = CommonProps.DATA_WAREHOUSE_ID;
	public static final String DW_CLUSTER_TYPE = "clusterType";
	public static final String CLUSTERS = "clusters";
	public static final String DEFAULT_PRIMARY = "defaultPrimary";
	public static final String DEFAULT_SECONDARY = "defaultSecondary";

	public static final String CLUSTER_TYPE_PRIMARY = CommonProps.CLUSTER_TYPE_PRIMARY;
	public static final String CLUSTER_TYPE_SECONDARY = CommonProps.CLUSTER_TYPE_SECONDARY;
}
