package io.spaceandtime.storage.database;

import java.util.List;

import org.springframework.lang.Nullable;

import com.fasterxml.jackson.annotation.JsonProperty;

import io.spaceandtime.storage.core.*;

/**
 * Stores metadata about a database table
 */
@JsonDefaultSerdesConfig
public class DbTable {
	public static final String KEY = Keys.Db.TABLE;

	public enum AccessType {
		@JsonProperty(DbProps.ACCESS_TYPE_PERMISSIONED)  PERMISSIONED(DbProps.ACCESS_TYPE_PERMISSIONED),
		@JsonProperty(DbProps.ACCESS_TYPE_PUBLIC_READ)   PUBLIC_READ(DbProps.ACCESS_TYPE_PUBLIC_READ),
		@JsonProperty(DbProps.ACCESS_TYPE_PUBLIC_APPEND) PUBLIC_APPEND(DbProps.ACCESS_TYPE_PUBLIC_APPEND),
		@JsonProperty(DbProps.ACCESS_TYPE_PUBLIC_WRITE)  PUBLIC_WRITE(DbProps.ACCESS_TYPE_PUBLIC_WRITE);

		/** The access type string value */
		public final String Value;
		AccessType(String value) {
			Value = value;
		}

		/**
		 * Try to convert a string into its corresponding access type
		 * @param value - the string value
		 * @return
		 * @throws Exception
		 */
		public static AccessType tryConvert(String value) throws Exception {
			switch (value) {
				case DbProps.ACCESS_TYPE_PERMISSIONED:
					return PERMISSIONED;
				case DbProps.ACCESS_TYPE_PUBLIC_READ:
					return PUBLIC_READ;
				case DbProps.ACCESS_TYPE_PUBLIC_APPEND:
					return PUBLIC_APPEND;
				case DbProps.ACCESS_TYPE_PUBLIC_WRITE:
					return PUBLIC_WRITE;
				default: throw new Exception("Provided value is invalid for AccessType (" + value + ")");
			}
		}
	}

	/** The table identifier */
	@JsonProperty(DbProps.TABLE_ID)
	private String _tableId = null;
	/** The schema identifier */
	@JsonProperty(DbProps.SCHEMA_ID)
	private String _schemaId = null;
	/** The catalog identifier */
	@JsonProperty(DbProps.CATALOG_ID)
	private String _catalogId = null;
	/** The public key */
	@JsonProperty(DbProps.PUBLIC_KEY)
	private String _publicKey = null;
	/** The access type */
	@JsonProperty(DbProps.ACCESS_TYPE)
	private AccessType _accessType;
	/** Whether or not the table is immutable */
	@JsonProperty(DbProps.IMMUTABLE)
	private boolean _immutable = false;
	/** Whether or not the table is tamperproof */
	@JsonProperty(DbProps.TAMPERPROOF)
	private boolean _tamperproof = false;
	/** The list of columns in the table */
	@JsonProperty(DbProps.COLUMNS)
	private List<DbTableColumn> _columns = null;

	public DbTable(){}
	public DbTable(String tableId, String schemaId, String catalogId, String publicKey, AccessType accessType, boolean immutable, boolean tamperproof, List<DbTableColumn> columns) {
		setTableId(tableId);
		setSchemaId(schemaId);
		setCatalogId(catalogId);
		_publicKey = publicKey;
		_accessType = accessType;
		_immutable = immutable;
		_tamperproof = tamperproof;
		_columns = columns;
	}

	@Nullable public String getTableId() { return _tableId; }
	@Nullable public String getSchemaId() { return _schemaId; }
	@Nullable public String getCatalogId() { return _catalogId; }
	@Nullable public String getPublicKey() { return _publicKey; }
	@Nullable public AccessType getAccessType() { return _accessType; }
	@Nullable public String getAccessTypeString() { return getAccessType().Value; }
	@Nullable public boolean isImmutable() { return _immutable; }
	@Nullable public boolean isTamperproof() { return _tamperproof; }
	@Nullable public List<DbTableColumn> getColumns() { return _columns; }

	
	public void setTableId(String value) { _tableId = StorageUtils.toUpper(value); }
	public void setSchemaId(String value) { _schemaId = StorageUtils.toUpper(value); }
	public void setCatalogId(String value) { _catalogId = StorageUtils.toUpper(value); }
	public void setPublicKey(String value) { _publicKey = value; }
	public void setAccessType(AccessType value) { _accessType = value; }
	public void setImmutable(boolean value) { _immutable = value; }
	public void setTamperproof(boolean value) { _tamperproof = value; }
	public void setColumns(List<DbTableColumn> value) { _columns = value; }
}
