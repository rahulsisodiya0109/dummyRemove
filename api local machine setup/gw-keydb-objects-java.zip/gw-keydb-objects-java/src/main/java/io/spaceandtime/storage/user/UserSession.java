package io.spaceandtime.storage.user;

import java.time.Instant;

import org.springframework.lang.Nullable;

import com.fasterxml.jackson.annotation.JsonProperty;

import io.spaceandtime.storage.core.JsonDefaultSerdesConfig;

/**
 * Stores metadata about an active user session
 */
@JsonDefaultSerdesConfig
public class UserSession extends UserBase {
	
	/** The iteration identifier */
	@JsonProperty(UserProps.ITERATION_ID)
	private String _iterationId = null;
	/** The session identifier */
	@JsonProperty(UserProps.SESSION_ID)
	private String _sessionId = null;
	/** The session start time */
	@JsonProperty(UserProps.SESSION_START)
	private Instant _sessionStart = null;
	/** The session expiration time */
	@JsonProperty(UserProps.SESSION_EXPIRES)
	private Instant _sessionExpires = null;

	public UserSession() { super(); }
	public UserSession(String userId, String iterationId, String sessionId, Instant sessionStart, Instant sessionExpires) {
		super(userId);
		_iterationId = iterationId;
		_sessionId = sessionId;
		_sessionStart = sessionStart;
		_sessionExpires = sessionExpires;
	}

	@Nullable public String getIterationId() { return _iterationId; }
	@Nullable public String getSessionId() { return _sessionId; }
	@Nullable public Instant getSessionStart() { return _sessionStart; }
	@Nullable public Instant getSessionExpires() { return _sessionExpires; }

	public void setIterationId(String value) { _iterationId = value; }
	public void setSessionId(String value) { _sessionId = value; }
	public void setSessionStart(Instant value) { _sessionStart = value; }
	public void setSessionExpires(Instant value) { _sessionExpires = value; }
}
