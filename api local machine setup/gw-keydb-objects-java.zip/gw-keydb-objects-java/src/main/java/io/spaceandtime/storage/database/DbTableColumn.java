package io.spaceandtime.storage.database;

import org.springframework.lang.Nullable;

import com.fasterxml.jackson.annotation.JsonProperty;

import io.spaceandtime.storage.core.*;

/**
 * Stores metadata about a database table column
 */
@JsonDefaultSerdesConfig
public class DbTableColumn {
	
	/** The column identifier */
	@JsonProperty(DbProps.COLUMN_ID)
	private String _columnId = null;
	/** The column data type */
	@JsonProperty(DbProps.DATA_TYPE)
	private String _dataType = null;

	public DbTableColumn(){}
	public DbTableColumn(String columnId, String dataType) {
		setColumnId(columnId);
		setDataType(dataType);
	}
	
	@Nullable public String getColumnId() { return _columnId; }
	@Nullable public String getDataType() { return _dataType; }

	public void setColumnId(String value) { _columnId = StorageUtils.toUpper(value); }
	public void setDataType(String value) { _dataType = value; }
}
