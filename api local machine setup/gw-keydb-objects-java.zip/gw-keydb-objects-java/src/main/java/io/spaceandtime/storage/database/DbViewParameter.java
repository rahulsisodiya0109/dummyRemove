package io.spaceandtime.storage.database;

import org.springframework.lang.Nullable;

import com.fasterxml.jackson.annotation.JsonProperty;

import io.spaceandtime.storage.core.JsonDefaultSerdesConfig;

/**
 * Stores metadata about a database view parameter
 */
@JsonDefaultSerdesConfig
public class DbViewParameter {
	
	/** The parameter name */
	@JsonProperty(DbProps.VIEW_PARAM_NAME)
	private String _name = null;
	/** The parameter data type */
	@JsonProperty(DbProps.VIEW_PARAM_TYPE)
	private String _type = null;

	public DbViewParameter(){}
	public DbViewParameter(String name, String type) {
		_name = name;
		_type = type;
	}

	@Nullable public String getName() { return _name; }
	@Nullable public String getType() { return _type; }

	public void setName(String value) { _name = value; }
	public void setType(String value) { _type = value; }
}
