package io.spaceandtime.storage.user;

import java.util.List;

import org.springframework.lang.Nullable;

import com.fasterxml.jackson.annotation.JsonProperty;

import io.spaceandtime.storage.core.*;

/**
 * Stores metadata about platform users
 */
@JsonDefaultSerdesConfig
public class User extends UserBase {
	public static final String KEY = Keys.User.USER;

	/** The subscription identifier */
	@JsonProperty(UserProps.SUBSCRIPTION_ID)
	private String _subscriptionId = null;
	/** The user keychain */
	@JsonProperty(UserProps.KEYCHAIN)
	private List<AuthKey> _keychain = null;

	public User() { super(); }
	public User(String userId, String subscriptionId, List<AuthKey> keychain) {
		super(userId);
		_subscriptionId = subscriptionId;
		_keychain = keychain;
	}

	@Nullable public String getSubscriptionId() { return _subscriptionId; }
	@Nullable public List<AuthKey> getKeychain() { return _keychain; }
	public boolean hasKeychain() { return _keychain != null && !_keychain.isEmpty(); }
	
	public void setSubscriptionId(String value) { _subscriptionId = value; }
	public void setKeychain(List<AuthKey> value) { _keychain = value; }
}
