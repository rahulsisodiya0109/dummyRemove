package io.spaceandtime.storage.operator;

import com.fasterxml.jackson.annotation.JsonProperty;

import io.spaceandtime.storage.core.*;

/**
 * Stores gateway cluster information
 */
@JsonDefaultSerdesConfig
public class Gateway extends OperatedCluster {
	public static final String KEY = Keys.Operator.GATEWAY;

	/** The gateway identifier */
	@JsonProperty(OperatorProps.GATEWAY_ID)
	private String _id = null;
	
	public Gateway() { super(); }
	public Gateway(String gatewayId, String operatorId, String hardware, Long stakedBounty) {
		super(operatorId, hardware, stakedBounty);
		_id = gatewayId;
	}

	@Override
	public String getId() { return _id; }
	@Override
	public void setId(String value) { _id = value; }
}
