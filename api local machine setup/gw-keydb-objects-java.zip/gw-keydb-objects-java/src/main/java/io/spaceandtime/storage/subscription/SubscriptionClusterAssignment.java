package io.spaceandtime.storage.subscription;

import org.springframework.lang.Nullable;

import com.fasterxml.jackson.annotation.JsonProperty;

import io.spaceandtime.storage.core.*;

/**
 * Stores metadata about a subscription's cluster assignment
 * <p>
 * The cluster assignment for a subscription affects where new
 * tables created by subscription users are assigned
 */
@JsonDefaultSerdesConfig
public class SubscriptionClusterAssignment {
	public static final String KEY = Keys.Subscription.CLUSTER_ASSIGNMENT;
	
	/** The primary data warehouse cluster */
	@JsonProperty(SubscriptionProps.PRIMARY)
	private String _primary = null;
	/** The secondary data warehouse cluster */
	@JsonProperty(SubscriptionProps.SECONDARY)
	private String _secondary = null;

	public SubscriptionClusterAssignment(){}
	public SubscriptionClusterAssignment(String primary, String secondary) {
		_primary = primary;
		_secondary = secondary;
	}

	@Nullable public String getPrimary() { return _primary; }
	@Nullable public String getSecondary() { return _secondary; }
	
	public void setPrimary(String value) { _primary = value; }
	public void setSecondary(String value) { _secondary = value; }
}
