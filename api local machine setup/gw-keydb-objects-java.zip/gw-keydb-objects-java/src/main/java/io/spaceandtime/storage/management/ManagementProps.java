package io.spaceandtime.storage.management;

import io.spaceandtime.storage.core.StorageConstants.CommonProps;

/**
 * Defines management property constants
 */
public final class ManagementProps {
	public static final String BLOCK_TIME_ID = "bt";
	public static final String INCREMENT_BY = "incrby";
	public static final String CAPACITY = "capacity";
	public static final String DURATION_VALUE = "durationvalue";
	public static final String DURATION_UNITS = "durationunits";
	public static final String TRIAL_LIMIT = "trialLimit";
	public static final String RESTRICTED_APIS = "restrictedApis";
	public static final String PROVIDER_ID = "providerId";
	public static final String PROVIDER_NAME = "name";
	public static final String PUBLIC_KEY = CommonProps.PUBLIC_KEY;
	public static final String METADATA = "metadata";

	public static final String BTUNIT_SECOND = "s";
	public static final String BTUNIT_MINUTE = "m";
	public static final String BTUNIT_HOUR = "h";
}
