package io.spaceandtime.storage.database;

import java.util.List;

import org.springframework.lang.Nullable;

import com.fasterxml.jackson.annotation.JsonProperty;

import io.spaceandtime.storage.core.*;

/**
 * Stores metadata on database resources within a given schema
 */
@JsonDefaultSerdesConfig
public class DbSchemaAssets {
	public static final String KEY = Keys.Db.SCHEMA_ASSETS;

	/** The list of tables */
	@JsonProperty(DbProps.TABLES)
	private List<String> _tables = null;
	/** The list of views */
	@JsonProperty(DbProps.VIEWS)
	private List<String> _views = null;
	/** The list of indices */
	@JsonProperty(DbProps.INDICES)
	private List<String> _indices = null;

	public DbSchemaAssets(){}
	public DbSchemaAssets(List<String> tables, List<String> views, List<String> indices) {
		_tables = tables;
		_views = views;
		_indices = indices;
	}

	@Nullable public List<String> getTables() { return _tables; }
	@Nullable public List<String> getViews() { return _views; }
	@Nullable public List<String> getIndices(){ return _indices; }

	public void setTables(List<String> value) { _tables = value; }
	public void setViews(List<String> value) { _views = value; }
	public void setIndices(List<String> value){ _indices = value; }
}
