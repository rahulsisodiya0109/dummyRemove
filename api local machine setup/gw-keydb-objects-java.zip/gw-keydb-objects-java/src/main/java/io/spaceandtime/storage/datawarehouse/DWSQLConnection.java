package io.spaceandtime.storage.datawarehouse;

import org.springframework.lang.Nullable;

import com.fasterxml.jackson.annotation.JsonProperty;

import io.spaceandtime.storage.core.JsonDefaultSerdesConfig;

/**
 * Stores the data warehouse SQL connection information
 */
@JsonDefaultSerdesConfig
public class DWSQLConnection {
	
	/** The endpoint address (IP:PORT) */
	@JsonProperty(DWProps.ADDR)
	private String _address = null;
	/** The username (for authentication) */
	@JsonProperty(DWProps.USERNAME)
	private String _username = null;
	/** The password (for authentication) */
	@JsonProperty(DWProps.PASSWORD)
	private String _password = null;

	public DWSQLConnection(){}
	public DWSQLConnection(String address, String username, String password) {
		_address = address;
		_username = username;
		_password = password;
	}

	@Nullable public String getAddress() { return _address; }
	@Nullable public String getUsername() { return _username; }
	@Nullable public String getPassword() { return _password; }

	public void setAddress(String value) { _address = value; }
	public void setUsername(String value) { _username = value; }
	public void setPassword(String value) { _password = value; }
}
