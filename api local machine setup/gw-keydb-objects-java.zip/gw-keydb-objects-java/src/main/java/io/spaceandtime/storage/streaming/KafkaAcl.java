package io.spaceandtime.storage.streaming;

import org.springframework.lang.Nullable;

import com.fasterxml.jackson.annotation.JsonProperty;

import io.spaceandtime.storage.core.JsonDefaultSerdesConfig;

/**
 * Represents a Kafka ACL
 */
@JsonDefaultSerdesConfig
public class KafkaAcl {
	
	/** Defines ACL permission types */
	public enum PermissionType {

		@JsonProperty(StreamingProps.PERM_ALLOW) ALLOW(StreamingProps.PERM_ALLOW),
		@JsonProperty(StreamingProps.PERM_DENY)  DENY(StreamingProps.PERM_DENY);

		/** The string value */
		public final String Value;
		PermissionType(String value) {
			Value = value;
		}

		/**
		 * Try to convert the string value into a permission type
		 * @param value - the string value
		 * @return
		 * @throws Exception
		 */
		public static PermissionType tryConvert(String value) throws Exception {
			switch (value) {
				case StreamingProps.PERM_ALLOW:
					return ALLOW;
				case StreamingProps.PERM_DENY:
					return DENY;
				default: throw new Exception("Provided value is invalid for PermissionType (" + value + ")");
			}
		}
	}

	/** The topic that this ACL applies to */
	@JsonProperty(StreamingProps.TOPIC_ID)
	private String _topicId = null;
	/** The principal (i.e., user) that this ACL applies to */
	@JsonProperty(StreamingProps.PRINCIPAL)
	private String _principal = null;
	/** The permission type */
	@JsonProperty(StreamingProps.PERMISSION)
	private PermissionType _permission = PermissionType.ALLOW;

	public KafkaAcl(){}
	public KafkaAcl(String topicId, String principal, PermissionType permission) {
		_topicId = topicId;
		_principal = principal;
		_permission = permission;
	}

	@Nullable public String getTopicId() { return _topicId; }
	@Nullable public String getPrincipal() { return _principal; }
	@Nullable public PermissionType getPermission() { return _permission; }
	
	public void setTopicId(String value) { _topicId = value; }
	public void setPrincipal(String value) { _principal = value; }
	public void setPermission(PermissionType value) { _permission = value; }
}
