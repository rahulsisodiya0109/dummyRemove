package io.spaceandtime.storage.database;

import java.util.List;

import org.springframework.lang.Nullable;

import com.fasterxml.jackson.annotation.JsonProperty;

import io.spaceandtime.storage.core.*;

/**
 * Stores metadata about a database view
 */
@JsonDefaultSerdesConfig
public class DbView {
	public static final String KEY = Keys.Db.VIEW;
	
	/** The view identifier */
	@JsonProperty(DbProps.VIEW_ID)
	private String _viewId = null;
	/** The catalog identifier */
	@JsonProperty(DbProps.CATALOG_ID)
	private String _catalogId = null;
	/** The schema identifier */
	@JsonProperty(DbProps.SCHEMA_ID)
	private String _schemaId = null;
	/** The underlying view SQL text */
	@JsonProperty(DbProps.VIEW_SQL_TEXT)
	private String _sqlText = null;
	/** The view resource identifier */
	@JsonProperty(DbProps.RESOURCE_ID)
	private String _resourceId = null;
	/** The view parameters */
	@JsonProperty(DbProps.VIEW_PARAMS)
	private List<DbViewParameter> _parameters = null;

	public DbView(){}
	public DbView(String viewId, String catalogId, String schemaId, String sqlText, String resourceId, List<DbViewParameter> parameters) {
		setViewId(viewId);
		setCatalogId(catalogId);
		setSchemaId(schemaId);
		_sqlText = sqlText;
		_resourceId = resourceId;
		_parameters = parameters;
	}

	@Nullable public String getViewId() { return _viewId; }
	@Nullable public String getCatalogId() { return _catalogId; }
	@Nullable public String getSchemaId() { return _schemaId; }
	@Nullable public String getSqlText() { return _sqlText; }
	@Nullable public String getResourceId() { return _resourceId; }
	@Nullable public List<DbViewParameter> getParameters() { return _parameters; }
	public boolean hasParameters() { return _parameters != null && !_parameters.isEmpty(); }
	
	public void setViewId(String value) { _viewId = value; }
	public void setCatalogId(String value) { _catalogId = StorageUtils.toUpper(value); }
	public void setSchemaId(String value) { _schemaId = StorageUtils.toUpper(value); }
	public void setSqlText(String value) { _sqlText = value; }
	public void setResourceId(String value) { _resourceId = value; }
	public void setParameters(List<DbViewParameter> value) { _parameters = value; }
}
