package io.spaceandtime.storage.subscription;

import org.springframework.lang.Nullable;

import com.fasterxml.jackson.annotation.JsonProperty;

import io.spaceandtime.storage.core.*;

/**
 * Stores metadata about a subscription invite
 */
@JsonDefaultSerdesConfig
public class SubscriptionInvite extends SubscriptionBase {
	
	/** The join code */
	@JsonProperty(SubscriptionProps.JOIN_CODE)
	private String _joinCode = null;
	/** The role with which the user will join the subscription */
	@JsonProperty(SubscriptionProps.ROLE)
	private SubscriptionRole _role = null;

	public SubscriptionInvite() { super(); }
	public SubscriptionInvite(String subscriptionId, String joinCode, SubscriptionRole role) {
		super(subscriptionId);
		_joinCode = joinCode;
		_role = role;
	}
	
	@Nullable public String getJoinCode() { return _joinCode; }
	@Nullable public SubscriptionRole getRole() { return _role; }

	public void setJoinCode(String value) { _joinCode = value; }
	public void setRole(SubscriptionRole value) { _role = value; }
}
