package io.spaceandtime.storage.database;

import org.springframework.lang.Nullable;

import com.fasterxml.jackson.annotation.JsonProperty;

import io.spaceandtime.storage.core.*;

/**
 * Stores metadata about a database schema
 */
@JsonDefaultSerdesConfig
public class DbSchema {
	public static final String KEY = Keys.Db.SCHEMA;

	/** The schema identifier */
	@JsonProperty(DbProps.SCHEMA_ID)
	private String _schemaId = null;
	/** The catalog identifier */
	@JsonProperty(DbProps.CATALOG_ID)
	private String _catalogId = null;

	public DbSchema(){}
	public DbSchema(String schemaId, String catalogId) {
		setSchemaId(schemaId);
		setCatalogId(catalogId);
	}

	@Nullable public String getSchemaId() { return _schemaId; }
	@Nullable public String getCatalogId() { return _catalogId; }

	public void setSchemaId(String value) { _schemaId = StorageUtils.toUpper(value); }
	public void setCatalogId(String value) { _catalogId = StorageUtils.toUpper(value); }
}
