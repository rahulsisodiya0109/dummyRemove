package io.spaceandtime.storage.streaming;

import java.util.List;

import org.springframework.lang.Nullable;

import com.fasterxml.jackson.annotation.JsonProperty;

import io.spaceandtime.storage.core.JsonDefaultSerdesConfig;

/**
 * Stores metadata about a streaming infrastructure group topics
 */
@JsonDefaultSerdesConfig
public class IGTopics extends IGObject {
	
	/** The list of topic names */
	@JsonProperty(StreamingProps.TOPICS)
	private List<String> _topics = null;

	public IGTopics() { super(); }
	public IGTopics(String groupId, List<String> topics) {
		super(groupId);
		_topics = topics;
	}

	@Nullable public List<String> getTopics() { return _topics; }
	public void setTopics(List<String> value) { _topics = value; }
}
