package io.spaceandtime.storage.user;

import java.util.Arrays;
import java.util.HashSet;
import java.util.Set;

import org.springframework.lang.Nullable;

import com.fasterxml.jackson.annotation.JsonProperty;

import io.spaceandtime.storage.core.JsonDefaultSerdesConfig;

/**
 * Stores metadata about an authentication key
 */
@JsonDefaultSerdesConfig
public class AuthKey {
	public static final Set<String> ETH_CHAIN_IDS = new HashSet<>(Arrays.asList("1", "2", "3", "4", "42", "1337"));
	
	/** Defines the valid authentication key algorithms */
	public enum KeyAlgorithm {
		@JsonProperty(UserProps.ALG_ED25519) ED25519(UserProps.ALG_ED25519),
		@JsonProperty(UserProps.ALG_ETHEREUM) ETHEREUM(UserProps.ALG_ETHEREUM);

		/** The string value */
		public final String Value;
		KeyAlgorithm(String value) {
			Value = value;
		}

		/**
		 * Try to convert a string value to a key algorithm
		 * @param value - the value
		 * @return
		 * @throws Exception
		 */
		public static KeyAlgorithm tryConvert(String value) throws Exception {
			if (value.equals(UserProps.ALG_ED25519)) {
				return ED25519;
			} else if (value.equals(UserProps.ALG_ETHEREUM) || ETH_CHAIN_IDS.contains(value)) {
				return ETHEREUM;
			} else {
				throw new Exception("Provided value is invalid for KeyAlgorithm(" + value + ")");
			}
		}
	}

	/** The public key */
	@JsonProperty(UserProps.PUBLIC_KEY)
	private String _publicKey = null;
	/** The key algorithm */
	@JsonProperty(UserProps.ALGORITHM)
	private KeyAlgorithm _algorithm = KeyAlgorithm.ED25519;
	/** The chain id (for {@linkplain KeyAlgorithm.ETHEREUM}) */
	@JsonProperty(UserProps.CHAIN_ID)
	private String _chainId = null;

	public AuthKey(){}
	public AuthKey(String publicKey, KeyAlgorithm algorithm, String chainId) {
		_publicKey = publicKey;
		_algorithm = algorithm;
		if (algorithm == KeyAlgorithm.ETHEREUM) {
			_chainId = chainId;
		}
	}

	@Nullable public String getPublicKey() { return _publicKey; }
	@Nullable public KeyAlgorithm getAlgorithm() { return _algorithm; }
	@Nullable public String getChainId() { return _chainId; }
	
	public void setPublicKey(String value) { _publicKey = value; }
	public void setAlgorithm(KeyAlgorithm value) { _algorithm = value; }
	public void setChainId(String value) { _chainId = value; }
}
