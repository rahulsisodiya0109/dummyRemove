package io.spaceandtime.storage.subscription;

import io.spaceandtime.storage.core.StorageConstants.CommonProps;
import io.spaceandtime.storage.management.ManagementProps;

/**
 * Defines subscription property constants
 */
public final class SubscriptionProps {
	public static final String SUBSCRIPTION_ID = "subscriptionId";
	public static final String NAME = "name";
	public static final String STATE = "state";
	public static final String ACTIVE = "active";
	public static final String PLAN_NAME = "plan";
	public static final String LAST_PAYMENT = "lastPayment";
	public static final String JOIN_CODE = "joinCode";
	public static final String PRIMARY = CommonProps.CLUSTER_TYPE_PRIMARY;
	public static final String SECONDARY = CommonProps.CLUSTER_TYPE_SECONDARY;
	public static final String BLOCK_TIME_ID = ManagementProps.BLOCK_TIME_ID;
	public static final String USER_ROLE_MAP = "userRoleMap";
	public static final String ROLE = "role";
	public static final String PROVIDER_ID = ManagementProps.PROVIDER_ID;
	public static final String AMOUNT = "amount";
	public static final String CURRENCY = "currency";
	public static final String TIMESTAMP = "timestamp";

	public static final String SR_OWNER = "owner";
	public static final String SR_ADMIN = "admin";
	public static final String SR_MEMBER = "member";

	public static final String SS_ACTIVE = "active";
	public static final String SS_SUSPENDED = "suspended";
	public static final String SS_CANCELED = "canceled";
}
