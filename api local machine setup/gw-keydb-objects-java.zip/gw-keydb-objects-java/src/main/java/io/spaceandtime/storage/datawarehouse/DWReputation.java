package io.spaceandtime.storage.datawarehouse;

import io.spaceandtime.storage.core.JsonDefaultSerdesConfig;
import io.spaceandtime.storage.core.Keys;

/**
 * Stores data warehouse reputation information
 */
@JsonDefaultSerdesConfig
public class DWReputation {
	public static final String KEY = Keys.DataWarehouse.REPUTATION;
}
