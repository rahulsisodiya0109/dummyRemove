package io.spaceandtime.storage.operator;

import org.springframework.lang.Nullable;

import com.fasterxml.jackson.annotation.JsonProperty;

import io.spaceandtime.storage.core.*;

/**
 * Represents a service operator, providing resources to the network
 */
@JsonDefaultSerdesConfig
public class ServiceOperator {
	public static final String KEY = Keys.Operator.OPERATOR;

	/** The operator's identifier */
	@JsonProperty(OperatorProps.OPERATOR_ID)
	private String _operatorId = null;
	/** The operator's wallet address */
	@JsonProperty(OperatorProps.WALLET_ADDR)
	private String _walletAddress = null;

	public ServiceOperator(){}
	public ServiceOperator(String operatorId, String walletAddress) {
		_operatorId = operatorId;
		_walletAddress = walletAddress;
	}

	@Nullable public String getOperatorId() { return _operatorId; }
	@Nullable public String getWalletAddress() { return _walletAddress; }

	public void setOperatorId(String value) { _operatorId = value; }
	public void setWalletAddress(String value) { _walletAddress = value; }
}
