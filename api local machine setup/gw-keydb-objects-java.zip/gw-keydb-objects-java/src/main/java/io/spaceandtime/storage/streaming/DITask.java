package io.spaceandtime.storage.streaming;

import org.springframework.lang.Nullable;
import org.springframework.util.StringUtils;

import com.fasterxml.jackson.annotation.JsonProperty;

import io.spaceandtime.storage.core.JsonDefaultSerdesConfig;
import io.spaceandtime.storage.core.Keys;

/**
 * Stores metadata about a data ingestion task
 */
@JsonDefaultSerdesConfig
public class DITask extends IGObject {

	/** The consumer group */
	@JsonProperty(StreamingProps.CONSUMER_GROUP)
	private String _consumerGroup = null;
	/** The topic indentifier */
	@JsonProperty(StreamingProps.TOPIC_ID)
	private String _topicId = null;
	/** The mapping identifier */
	@JsonProperty(StreamingProps.MAPPING_ID)
	private String _mappingId = null;
	/** The assigned data warehouse cluster id */
	@JsonProperty(StreamingProps.ASSIGNED_CLUSTER_ID)
	private String _assignedClusterId = null;

	public DITask() { super(); }
	public DITask(String consumerGroup, String groupId, String topicId, String mappingId, String assignedClusterId) {
		super(groupId);
		_consumerGroup = consumerGroup;
		_topicId = topicId;
		_mappingId = mappingId;
		_assignedClusterId = assignedClusterId;
	}

	@Nullable public String getConsumerGroup() { return _consumerGroup; }
	@Nullable public String getTopicId() { return _topicId; }
	@Nullable public String getMappingId() { return _mappingId; }
	@Nullable public String getAssignedClusterId() { return _assignedClusterId; }
	@Nullable public String getTaskIdentifier() {
		if (!StringUtils.hasLength(getGroupId()) || !StringUtils.hasLength(_topicId) || !StringUtils.hasLength(_mappingId)) {
			return null;
		}
		return Keys.Kafka.tmcIdentifier(getGroupId(), _topicId, _mappingId);
	}
	
	public void setConsumerGroup(String value) { _consumerGroup = value; }
	public void setTopicId(String value) { _topicId = value; }
	public void setMappingId(String value) { _mappingId = value; }
	public void setAssignedClusterId(String value) { _assignedClusterId = value; }
}
