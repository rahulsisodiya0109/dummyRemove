package io.spaceandtime.storage.database;

import org.springframework.lang.Nullable;

import com.fasterxml.jackson.annotation.JsonProperty;

import io.spaceandtime.storage.core.*;

/**
 * Stores metadata about a database index
 */
@JsonDefaultSerdesConfig
public class DbIndex {
	public static final String KEY = Keys.Db.INDEX;

	/** The index identifier */
	@JsonProperty(DbProps.INDEX_ID)
	private String _indexId = null;
	/** The catalog identifier */
	@JsonProperty(DbProps.CATALOG_ID)
	private String _catalogId = null;
	/** The schema identifier */
	@JsonProperty(DbProps.SCHEMA_ID)
	private String _schemaId = null;
	/** The table identifier */
	@JsonProperty(DbProps.TABLE_ID)
	private String _tableId = null;

	public DbIndex(){}
	public DbIndex(String indexId, String catalogId, String schemaId, String tableId) {
		setIndexId(indexId);
		setCatalogId(catalogId);
		setSchemaId(schemaId);
		setTableId(tableId);
	}

	@Nullable public String getIndexId() { return _indexId; }
	@Nullable public String getCatalogId() { return _catalogId; }
	@Nullable public String getSchemaId() { return _schemaId; }
	@Nullable public String getTableId() { return _tableId; }
	
	public void setIndexId(String value) { _indexId = StorageUtils.toUpper(value); }
	public void setCatalogId(String value) { _catalogId = StorageUtils.toUpper(value); }
	public void setSchemaId(String value) { _schemaId = StorageUtils.toUpper(value); }
	public void setTableId(String value) { _tableId = StorageUtils.toUpper(value); }
}
