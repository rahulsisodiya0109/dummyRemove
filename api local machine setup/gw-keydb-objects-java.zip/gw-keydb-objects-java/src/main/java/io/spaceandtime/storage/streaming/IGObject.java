package io.spaceandtime.storage.streaming;

import org.springframework.lang.Nullable;

import com.fasterxml.jackson.annotation.JsonProperty;

import io.spaceandtime.storage.core.*;

/**
 * Stores metadata about streaming infrastructure group child objects
 */
@JsonDefaultSerdesConfig
public abstract class IGObject {
	
	/** The group identifier */
	@JsonProperty(StreamingProps.GROUP_ID)
	private String _groupId = null;

	
	public IGObject(){}
	public IGObject(String groupId) {
		_groupId = groupId;
	}
	
	@Nullable public String getGroupId() { return _groupId; }
	public void setGroupId(String value) { _groupId = value; }
}
