package io.spaceandtime.storage.streaming;

import org.springframework.lang.Nullable;

import com.fasterxml.jackson.annotation.JsonProperty;

import io.spaceandtime.storage.core.JsonDefaultSerdesConfig;

/**
 * Stores metadata about the kafka credentials
 * assigned to a data warehouse cluster
 */
@JsonDefaultSerdesConfig
public class ClusterCredentials {
	
	/** The username (for authentication) */
	@JsonProperty(StreamingProps.USERNAME)
	private String _username = null;
	/** The password (for authentication) */
	@JsonProperty(StreamingProps.PASSWORD)
	private String _password = null;

	public ClusterCredentials(){}
	public ClusterCredentials(String username, String password) {
		_username = username;
		_password = password;
	}
	
	@Nullable public String getUsername() { return _username; }
	@Nullable public String getPassword() { return _password; }

	public void setUsername(String value) { _username = value; }
	public void setPassword(String value) { _password = value; }
}
