package io.spaceandtime.storage.core;

import java.lang.annotation.*;

import com.fasterxml.jackson.annotation.*;
import com.fasterxml.jackson.annotation.JsonAutoDetect.*;
import com.fasterxml.jackson.annotation.JsonInclude.*;

/**
 * Defines an annotation bundle for JSON object serialization via Jackson.
 * <p>
 * This annotation tells Jackson to only serialize object components with
 * an explicit JsonProperty annotation. For fields whose value
 * is default, the property will not be serialized to save space.
 */
@Retention(RetentionPolicy.RUNTIME)
@Target({ElementType.ANNOTATION_TYPE, ElementType.METHOD, ElementType.FIELD, ElementType.TYPE, ElementType.PARAMETER})
@JsonInclude(Include.NON_DEFAULT)
@JsonAutoDetect(
	fieldVisibility = Visibility.NONE,
	setterVisibility = Visibility.NONE,
	getterVisibility = Visibility.NONE,
	isGetterVisibility = Visibility.NONE,
	creatorVisibility = Visibility.NONE
)
@JacksonAnnotationsInside
public @interface JsonDefaultSerdesConfig {
	
}
