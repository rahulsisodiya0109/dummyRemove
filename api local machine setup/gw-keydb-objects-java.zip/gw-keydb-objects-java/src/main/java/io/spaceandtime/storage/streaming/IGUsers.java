package io.spaceandtime.storage.streaming;

import java.util.List;

import org.springframework.lang.Nullable;

import com.fasterxml.jackson.annotation.JsonProperty;

import io.spaceandtime.storage.core.JsonDefaultSerdesConfig;

/**
 * Stores metadata about streaming infrastucture group users
 */
@JsonDefaultSerdesConfig
public class IGUsers extends IGObject {
	
	/** The list of Kafka users */
	@JsonProperty(StreamingProps.USERS)
	private List<String> _users = null;

	public IGUsers() { super(); }
	public IGUsers(String groupId, List<String> users) {
		super(groupId);
		_users = users;
	}

	@Nullable public List<String> getUsers() { return _users; }
	public void setUsers(List<String> value) { _users = value; }
}
