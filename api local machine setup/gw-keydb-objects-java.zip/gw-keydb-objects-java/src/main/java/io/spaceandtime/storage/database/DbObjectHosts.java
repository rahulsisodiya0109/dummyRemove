package io.spaceandtime.storage.database;

import java.util.List;

import io.spaceandtime.storage.core.*;
import io.spaceandtime.storage.operator.ClusterGroup;

/**
 * Stores metadata about the hosts of a database object (i.e., the data
 * warehouse clusters that store the object)
 */
@JsonDefaultSerdesConfig
public class DbObjectHosts extends ClusterGroup {
	public static final String KEY = Keys.Db.OBJECT_HOSTS;
	
	public DbObjectHosts() { super(); }
	public DbObjectHosts(List<String> clusters) {
		super(clusters);
	}
}
