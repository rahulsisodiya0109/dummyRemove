package io.spaceandtime.storage.datawarehouse;

import org.springframework.lang.Nullable;

import com.fasterxml.jackson.annotation.JsonProperty;

import io.spaceandtime.storage.core.*;

/**
 * Stores the current data warehouse status information
 */
@JsonDefaultSerdesConfig
public class DWStatus {
	public static final String KEY = Keys.DataWarehouse.STATUS;
	
	/** Defines the data warehouse status */
	public enum Status {
		@JsonProperty(DWProps.STATUS_UNKNOWN) UNKNOWN(DWProps.STATUS_UNKNOWN),
		@JsonProperty(DWProps.STATUS_AVAILABLE) AVAILABLE(DWProps.STATUS_AVAILABLE),
		@JsonProperty(DWProps.STATUS_UNAVAILABLE) UNAVAILABLE(DWProps.STATUS_UNAVAILABLE);

		/** The Status string value */
		public final String Value;
		Status(String value) {
			Value = value;
		}

		/**
		 * Try to convert a string into it's corresponding status
		 * @param value - the string value
		 * @return
		 * @throws Exception
		 */
		public static Status tryConvert(String value) throws Exception {
			switch (value) {
				case DWProps.STATUS_UNKNOWN:
					return UNKNOWN;
				case DWProps.STATUS_AVAILABLE:
					return AVAILABLE;
				case DWProps.STATUS_UNAVAILABLE:
					return UNAVAILABLE;
				default: throw new Exception("Provided value is invalid for Status (" + value + ")");
			}
		}
	}

	/** The latest status */
	@JsonProperty(DWProps.STATUS)
	private Status _status = Status.UNKNOWN;
	/** The data warehouse id */
	@JsonProperty(DWProps.DATA_WAREHOUSE_ID)
	private String _warehouseId = null;
	/** The last time a status check was sent */
	@JsonProperty(DWProps.SENT_TIME)
	private Long _sentTime = null;
	/** The last time a status check was received */
	@JsonProperty(DWProps.RECEIVED_TIME)
	private Long _receivedTime = null;
	/** The number of successful status checks */
	@JsonProperty(DWProps.SUCCESSFUL_PINGS)
	private Long _successfulPings = null;
	/** The number of failed status checks */
	@JsonProperty(DWProps.FAILED_PINGS)
	private Long _failedPings = null;

	public DWStatus(){}
	public DWStatus(String warehouseId, Status status, Long sentTime, Long receivedTime, Long successfulPings, Long failedPings) {
		_warehouseId = warehouseId;
		_status = status;
		_sentTime = sentTime;
		_receivedTime = receivedTime;
		_successfulPings = successfulPings;
		_failedPings = failedPings;
	}

	public Status getStatus() { return _status; }
	@Nullable public String getWarehouseId() { return _warehouseId; }
	@Nullable public Long getLastSent() { return _sentTime; }
	@Nullable public Long getLastReceived() { return _receivedTime; }
	@Nullable public Long getSuccessfulPings() { return _successfulPings; }
	@Nullable public Long getFailedPings() { return _failedPings; }

	public void setStatus(Status value) { _status = value; }
	public void setWarehouseId(String value) { _warehouseId = value; }
	public void setLastSent(Long value) { _sentTime = value; }
	public void setLastReceived(Long value) { _receivedTime = value; }
	public void setSuccessfulPings(Long value) { _successfulPings = value; }
	public void setFailedPings(Long value) { _failedPings = value; }

	public void setAvailable() { _status = Status.AVAILABLE; }
	public void setUnavailable() { _status = Status.UNAVAILABLE; }
	public void resetSucceededPings() { _successfulPings = null; }
	public void resetFailedPings() { _failedPings = null; }
	public void sentNow() { _sentTime = System.currentTimeMillis(); }
	public void receivedNow() { _receivedTime = System.currentTimeMillis(); }
}
