package io.spaceandtime.storage.database;

import io.spaceandtime.storage.core.StorageConstants.*;

/**
 * Defines database resource property constants
 */
public final class DbProps {
	public static final String CATALOG_ID = "catalogId";
	public static final String SCHEMA_ID = "schemaId";
	public static final String TABLE_ID = "tableId";
	public static final String COLUMN_ID = "columnId";
	public static final String INDEX_ID = "indexId";
	public static final String VIEW_ID = "viewId";
	public static final String RESOURCE_ID = "resourceId";
	public static final String PUBLIC_KEY = CommonProps.PUBLIC_KEY;
	public static final String ACCESS_TYPE = "accessType";
	public static final String IMMUTABLE = "immutable";
	public static final String TAMPERPROOF = "tamperproof";
	public static final String COLUMNS = "columns";
	public static final String DATA_TYPE = "dataType";
	public static final String CLUSTERS = "clusters";
	public static final String TABLES = CommonProps.TABLES;
	public static final String VIEWS = CommonProps.VIEWS;
	public static final String INDICES = CommonProps.INDICES;
	public static final String VIEW_SQL_TEXT = "sqlText";
	public static final String VIEW_PARAMS = "parameters";
	public static final String VIEW_PARAM_NAME = "name";
	public static final String VIEW_PARAM_TYPE = "type";


	public static final String ACCESS_TYPE_PERMISSIONED = "permissioned";
	public static final String ACCESS_TYPE_PUBLIC_READ = "public_read";
	public static final String ACCESS_TYPE_PUBLIC_APPEND = "public_append";
	public static final String ACCESS_TYPE_PUBLIC_WRITE = "public_write";

}
