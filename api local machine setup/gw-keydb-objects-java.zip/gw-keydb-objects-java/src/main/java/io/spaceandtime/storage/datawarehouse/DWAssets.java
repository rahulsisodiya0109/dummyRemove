package io.spaceandtime.storage.datawarehouse;

import java.util.ArrayList;
import java.util.List;

import org.springframework.lang.Nullable;

import com.fasterxml.jackson.annotation.JsonProperty;

import io.spaceandtime.storage.core.*;
/**
 * Stores information about database resources (assets) hosted by a given data warehouse
 */
@JsonDefaultSerdesConfig
public class DWAssets {
	public static final String KEY = Keys.DataWarehouse.ASSETS;

	/** The list of schemas */
	@JsonProperty(DWProps.SCHEMAS)
	private List<String> _schemas = null;
	/** The list of tables */
	@JsonProperty(DWProps.TABLES)
	private List<String> _tables = null;
	/** The list of views */
	@JsonProperty(DWProps.VIEWS)
	private List<String> _views = null;
	/** The list of indices */
	@JsonProperty(DWProps.INDICES)
	private List<String> _indices = null;

	public DWAssets(){}
	public DWAssets(List<String> schemas, List<String> tables, List<String> views, List<String> indices) {
		_schemas = schemas;
		_tables = tables;
		_views = views;
		_indices = indices;
	}

	@Nullable public List<String> getSchemas() { return _schemas; }
	@Nullable public List<String> getTables() { return _tables; }
	@Nullable public List<String> getViews() { return _views; }
	@Nullable public List<String> getIndices() { return _indices; }

	public void setSchemas(List<String> value) { _schemas = value; }
	public void setTables(List<String> value) { _tables = value; }
	public void setViews(List<String> value) { _views = value; }
	public void setIndices(List<String> value) { _indices = value; }

	public void addSchema(String schemaName) {
		if (_schemas == null) {
			_schemas = new ArrayList<>();
		}
		_schemas.add(schemaName);
	}
	public void addTable(String tableId) {
		if (_tables == null) {
			_tables = new ArrayList<>();
		}
		_tables.add(tableId);
	}
	public void addView(String viewId) {
		if (_views == null) {
			_views = new ArrayList<>();
		}
		_views.add(viewId);
	}
	public void addIndex(String indexId) {
		if (_indices == null) {
			_indices = new ArrayList<>();
		}
		_indices.add(indexId);
	}
}
