package io.spaceandtime.storage.management;

import java.util.Map;

import org.springframework.lang.Nullable;

import com.fasterxml.jackson.annotation.JsonProperty;

import io.spaceandtime.storage.core.*;
import io.spaceandtime.storage.subscription.SubscriptionBase;

/**
 * Represents the additional subscription metadata a provider might need to store
 */
@JsonDefaultSerdesConfig
public class SubscriptionMetadata extends SubscriptionBase {
	public static final String KEY = Keys.Management.SUBSCRIPTION_METADATA;

	/** The subscription metadata */
	@JsonProperty(ManagementProps.METADATA)
	private Map<String, Object> _metadata = null;

	public SubscriptionMetadata() { super(); }
	public SubscriptionMetadata(String subscriptionId, Map<String, Object> metadata) {
		super(subscriptionId);
		_metadata = metadata;
	}
	
	@Nullable public Map<String, Object> getMetadata() { return _metadata; }
	public void setMetadata(Map<String, Object> value) { _metadata = value; }
}
