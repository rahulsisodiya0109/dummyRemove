package io.spaceandtime.storage.subscription;

import org.springframework.lang.Nullable;

import com.fasterxml.jackson.annotation.JsonProperty;

import io.spaceandtime.storage.core.*;
import io.spaceandtime.storage.management.*;

/**
 * Stores metadata about a subscription's block time configuration
 * <p>
 * This object stores the assignment of a given subscription to
 * the {@link BlockTime} the KrakenD rate limiter should use against
 * users in the subscription
 */
@JsonDefaultSerdesConfig
public class SubscriptionBlockTime {
	public static final String KEY = Keys.Subscription.SUBSCRIPTION_BLOCK_TIME;

	/** The subscription identifier */
	@JsonProperty(SubscriptionProps.SUBSCRIPTION_ID)
	private String _subscriptionId = null;
	/** The configured block time identifier for this subscription */
	@JsonProperty(SubscriptionProps.BLOCK_TIME_ID)
	private String _blockTimeId = null;

	public SubscriptionBlockTime() { super(); }
	public SubscriptionBlockTime(String subscriptionId, String blockTimeId) {
		_subscriptionId = subscriptionId;
		_blockTimeId = blockTimeId;
	}

	@Nullable public String getSubscriptionId() { return _subscriptionId; }
	@Nullable public String getBlockTimeId() { return _blockTimeId; }
	public void setSubscriptionId(String value) { _subscriptionId = value; }
	public void setBlockTimeId(String value) { _blockTimeId = value; }
}
