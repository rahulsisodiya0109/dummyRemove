package io.spaceandtime.storage.core;

import java.util.Date;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.TimeUnit;

/**
 * Defines the Redis storage provider
 */
public interface IStorageProvider {
	// Common operations
	/**
	 * Attempt to ping the server
	 * @return "pong"
	 */
	String ping();
	/**
	 * Delete the structure
	 * @param key - the structure key
	 * @return
	 */
	Boolean delete(String key);
	/**
	 * Get the time-to-live of the structure
	 * @param key - the structure key
	 * @param units - the desired TTL units
	 * @return
	 */
	Long getTtl(String key, TimeUnit units);
	/**
	 * Set the time-to-live of the structure
	 * @param key - the structure key
	 * @param duration - the TTL duration
	 * @param units - the TTL units
	 */
	Boolean setTtl(String key, Long duration, TimeUnit units);
	/**
	 * Set the expiration date of the structure
	 * @param key - the structure key
	 * @param expireDate - the date/time stamp of when to expire the structure
	 * @return
	 */
	Boolean setExpireDate(String key, Date expireDate);

	// String operations
	/**
	 * Determine if a value exists at the provided key
	 * @param key - the structure key
	 * @return
	 */
	Boolean vExists(String key);
	/**
	 * Get the value of the string
	 * @param key - the string structure key
	 * @return
	 */
	String vGet(String key);
	/**
	 * Get the value of the string
	 * @param <T> T - the object type
	 * @param key - the string structure key
	 * @param clazz - the desired result class type
	 * @return
	 * @throws Exception when JSON serdes fails
	 */
	<T> T vGet(String key, Class<T> clazz) throws Exception;
	/**
	 * Set the value of the string
	 * @param key - the string structure key
	 * @param value - the value to set
	 */
	void vSet(String key, String value);
	/**
	 * Set the value of the string
	 * @param <T> T - the object type
	 * @param key - the string structure key
	 * @param value - the value to set
	 * @throws Exception when JSON serdes fails
	 */
	<T> void vSet(String key, T value) throws Exception;
	/**
	 * Atomically increment the string by one
	 * @param key - the string structure key
	 * @return
	 */
	Long vIncrement(String key);
	/**
	 * Atomically increment the string by the provided delta
	 * @param key - the string structure key
	 * @param delta - the value to increment by
	 * @return
	 */
	Long vIncrementBy(String key, long delta);
	/**
	 * Atomically decrement the string by one
	 * @param key - the string structure key
	 * @return
	 */
	Long vDecrement(String key);
	/**
	 * Atomically decrement the string by the provided delta
	 * @param key - the string structure key
	 * @param delta - the value to increment by
	 * @return
	 */
	Long vDecrementBy(String key, long delta);
	/**
	 * Get the size of the string
	 * @param key - the string structure key
	 * @return
	 */
	Long vSize(String key);
	
	// Hash operations
	/**
	 * Determine if a value exists in the hash at the provided hash key
	 * @param key - the hash structure key
	 * @param hashKey - the hash field key
	 * @return
	 */
	Boolean hExists(String key, String hashKey);
	/**
	 * Delete the value in the hash at the provided hash key
	 * @param key - the hash structure key
	 * @param hashKey - the hash field key
	 * @return
	 */
	Boolean hDelete(String key, String hashKey);
	/**
	 * Get the value in the hash at the provided hash key
	 * @param key - the hash structure key
	 * @param hashKey - the hash field key
	 * @return
	 */
	String hGet(String key, String hashKey);
	/**
	 * Get the value in the hash at the provided hash key
	 * @param <T> T - the object type
	 * @param key - the hash structure key
	 * @param hashKey - the hash field key
	 * @param clazz - the desired result class type
	 * @return
	 * @throws Exception when JSON serdes fails
	 */
	<T> T hGet(String key, String hashKey, Class<T> clazz) throws Exception;
	/**
	 * Get all entries in the hash
	 * @param key - the hash structure key
	 * @return
	 */
	Map<String, String> hGetAll(String key);
	/**
	 * Get all entries in the hash
	 * @param <T> T - the object type
	 * @param key - the hash structure key
	 * @param clazz - the desired result class type
	 * @return
	 * @throws Exception when JSON serdes fails
	 */
	<T> Map<String, T> hGetAll(String key, Class<T> clazz) throws Exception;
	/**
	 * Set the value in the hash at the provided hash key
	 * @param key - the hash structure key
	 * @param hashKey - the hash field key
	 * @param value - the value to set
	 */
	void hPut(String key, String hashKey, String value);
	/**
	 * Set the value in the hash at the provided hash key
	 * @param <T> T - the object type
	 * @param key - the hash structure key
	 * @param hashKey - the hash field key
	 * @param value - the value to set
	 * @throws Exception when JSON serdes fails
	 */
	<T> void hPut(String key, String hashKey, T value) throws Exception;
	/**
	 * Set multiple hash fields in the hash
	 * @param key - the hash structure key
	 * @param entries - the entries to set
	 */
	void hPutAllSimple(String key, Map<String, String> entries);
	/**
	 * Set multiple hash fields in the hash
	 * @param <T> T - the object type
	 * @param key - the hash structure key
	 * @param entries - the entries to set
	 * @throws Exception when JSON serdes fails
	 */
	<T> void hPutAll(String key, Map<String, T> entries) throws Exception;
	/**
	 * Get all hash keys in the hash
	 * @param key - the hash structure key
	 * @return
	 * @throws Exception
	 */
	Set<String> hKeys(String key) throws Exception;
	/**
	 * Get the size of the hash
	 * @param key - the hash structure key
	 * @return
	 */
	Long hSize(String key);

	// Set operations
	/**
	 * Determine if the value exists in the set
	 * @param key - the set structure key
	 * @param value - the value to check
	 * @return
	 */
	Boolean sIsMember(String key, String value);
	/**
	 * Determine if the value exists in the set
	 * @param <T> T - the object type
	 * @param key - the set structure key
	 * @param value - the value to check
	 * @return
	 * @throws Exception when JSON serdes fails
	 */
	<T> Boolean sIsMember(String key, T value) throws Exception;
	/**
	 * Add the provided value to the set
	 * @param key - the set structure key
	 * @param value - the value to add
	 */
	Boolean sAdd(String key, String value);
	/**
	 * Add the provided value to the set
	 * @param <T> T - the object type
	 * @param key - the set structure key
	 * @param value - the value to add
	 * @throws Exception when JSON serdes fails
	 */
	<T> Boolean sAdd(String key, T value) throws Exception;
	/**
	 * Add the provided values to the set
	 * @param key - the set structure key
	 * @param values - the values to add
	 * @return
	 */
	Long sAddMany(String key, String[] values);
	/**
	 * Add the provided values to the set
	 * @param <T> T - the object type
	 * @param key - the set structure key
	 * @param values - the values to add
	 * @throws Exception when JSON serdes fails
	 * @return
	 */
	<T> Long sAddMany(String key, T[] values) throws Exception;
	/**
	 * Get all values in the set
	 * @param key - the set structure key
	 * @return
	 */
	Set<String> sGetAll(String key);
	/**
	 * Get all values in the set
	 * @param <T> T - the object type
	 * @param key - the set structure key
	 * @param clazz - the desired result class type
	 * @return
	 * @throws Exception when JSON serdes fails
	 */
	<T> Set<T> sGetAll(String key, Class<T> clazz) throws Exception;
	/**
	 * Delete the provided value from the set
	 * @param key - the set structure key
	 * @param value - the value to remove
	 * @return
	 */
	Boolean sDelete(String key, String value);
	/**
	 * Delete the provided value from the set
	 * @param <T> T - the object type
	 * @param key - the set structure key
	 * @param value - the value to remove
	 * @return
	 * @throws Exception when JSON serdes fails
	 */
	<T> Boolean sDelete(String key, T value) throws Exception;
	/**
	 * Delete the provided values from the set
	 * @param key - the set structure key
	 * @param values - the values to remove
	 * @return
	 */
	Long sDeleteMany(String key, Object[] values);
	/**
	 * Get the size of the set
	 * @param key - the set structure key
	 * @return
	 */
	Long sSize(String key);

	// List operations
	/**
	 * Get all entries in the list
	 * @param key - the list structure key
	 * @return
	 */
	List<String> lGetAll(String key);
	/**
	 * Get all entries in the list
	 * @param <T> T - the object type
	 * @param key - the list structure key
	 * @param clazz - the desired result class type
	 * @return
	 * @throws Exception when JSON serdes fails
	 */
	<T> List<T> lGetAll(String key, Class<T> clazz) throws Exception;
	/**
	 * Get all entries in the list between the provided start and end indices
	 * @param key - the list structure key
	 * @param startIndex - the start index
	 * @param endIndex - the end index
	 * @return
	 */
	List<String> lGetBetween(String key, long startIndex, long endIndex);
	/**
	 * Get all entries in the list between the provided start and end indices
	 * @param <T> T - the object type
	 * @param key - the list structure key
	 * @param startIndex - the start index
	 * @param endIndex - the end index
	 * @param clazz - the desired result class type
	 * @return
	 * @throws Exception when JSON serdes fails
	 */
	<T> List<T> lGetBetween(String key, long startIndex, long endIndex, Class<T> clazz) throws Exception;
	/**
	 * Get the value in the list at the provided index
	 * @param key - the list structure key
	 * @param index - the index
	 * @return
	 */
	String lGetAtIndex(String key, long index);
	/**
	 * Get the value in the list at the provided index
	 * @param <T> T - the object type
	 * @param key - the list structure key
	 * @param index - the index
	 * @param clazz - the desired result class type
	 * @return
	 * @throws Exception when JSON serdes fails
	 */
	<T> T lGetAtIndex(String key, long index, Class<T> clazz) throws Exception;
	/**
	 * Set the value in the list at the provided index
	 * @param key - the list structure key
	 * @param index - the index
	 * @param value - the value to set
	 */
	void lSetAtIndex(String key, long index, String value);
	/**
	 * Set the value in the list at the provided index
	 * @param <T> T - the object type
	 * @param key - the list structure key
	 * @param index - the index
	 * @param value - the value to set
	 * @throws Exception when JSON serdes fails
	 */
	<T> void lSetAtIndex(String key, long index, T value) throws Exception;
	/**
	 * Get the index in the list of the provided value
	 * @param key - the list structure key
	 * @param value - the value to index
	 * @return
	 */
	Long lIndexOf(String key, String value);
	/**
	 * Get the index in the list of the provided value
	 * @param <T> T - the object type
	 * @param key - the list structure key
	 * @param value - the value to index
	 * @return
	 * @throws Exception when JSON serdes fails
	 */
	<T> Long lIndexOf(String key, T value) throws Exception;
	/**
	 * Add the value to the head of the list
	 * @param key - the list structure key
	 * @param value - the value to add
	 */
	void lPushHead(String key, String value);
	/**
	 * Add the value to the head of the list
	 * @param <T> T - the object type
	 * @param key - the list structure key
	 * @param value - the value to add
	 * @throws Exception when JSON serdes fails
	 */
	<T> void lPushHead(String key, T value) throws Exception;
	/**
	 * Add the value to the tail of the list
	 * @param key - the list structure key
	 * @param value - the value to add
	 */
	void lPushTail(String key, String value);
	/**
	 * Add the value to the tail of the list
	 * @param <T> T - the object type
	 * @param key - the list structure key
	 * @param value - the value to add
	 * @throws Exception when JSON serdes fails
	 */
	<T> void lPushTail(String key, T value) throws Exception;
	/**
	 * Remove the value at the head of the list
	 * @param key - the list structure key
	 * @return
	 */
	String lPopHead(String key);
	/**
	 * Remove the value at the head of the list
	 * @param <T> T - the object type
	 * @param key - the list structure key
	 * @param clazz - the desired result class type
	 * @return
	 * @throws Exception when JSON serdes fails
	 */
	<T> T lPopHead(String key, Class<T> clazz) throws Exception;
	/**
	 * Remove the value at the tail of the list
	 * @param key - the list structure key
	 * @return
	 */
	String lPopTail(String key);
	/**
	 * Remove the value at the tail of the list
	 * @param <T> T - the object type
	 * @param key - the list structure key
	 * @param clazz - the desired result class type
	 * @return
	 * @throws Exception when JSON serdes fails
	 */
	<T> T lPopTail(String key, Class<T> clazz) throws Exception;
	/**
	 * Get the size of the list
	 * @param key - the list structure key
	 * @return
	 */
	Long lSize(String key);
}
