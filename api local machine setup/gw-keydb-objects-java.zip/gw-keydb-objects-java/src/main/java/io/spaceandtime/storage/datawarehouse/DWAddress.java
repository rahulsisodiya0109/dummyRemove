package io.spaceandtime.storage.datawarehouse;

import org.springframework.lang.Nullable;

import com.fasterxml.jackson.annotation.JsonProperty;

import io.spaceandtime.storage.core.*;

/**
 * Stores all information about a data warehouse's addresses
 */
@JsonDefaultSerdesConfig
public class DWAddress {
	public static final String KEY = Keys.DataWarehouse.ADDRESS;
	
	/** The SQL connection information */
	@JsonProperty(DWProps.SQL_CONNECTION)
	private DWSQLConnection _sqlConnection = null;
	/** The Kafka broker addresses (as comma-separated string) */
	@JsonProperty(DWProps.KAFKA_BROKERS)
	private String _kafkaBrokers = null;
	/** The management address (IP:PORT) */
	@JsonProperty(DWProps.MANAGEMENT)
	private String _managementAddr = null;

	public DWAddress() {}
	public DWAddress(DWSQLConnection sqlConnection, String kafkaBrokers, String managementAddr) {
		_sqlConnection = sqlConnection;
		_kafkaBrokers = kafkaBrokers;
		_managementAddr = managementAddr;
	}

	@Nullable public DWSQLConnection getSqlConnection() { return _sqlConnection; }
	@Nullable public String getKafkaBrokers() { return _kafkaBrokers; }
	@Nullable public String getManagementAddr() { return _managementAddr; }

	public void setSqlConnection(DWSQLConnection value) { _sqlConnection = value; }
	public void setKafkaBrokers(String value) { _kafkaBrokers = value; }
	public void setManagementAddr(String value) { _managementAddr = value; }
}
