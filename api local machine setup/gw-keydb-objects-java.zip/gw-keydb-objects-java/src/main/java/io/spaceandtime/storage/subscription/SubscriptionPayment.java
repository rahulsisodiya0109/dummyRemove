package io.spaceandtime.storage.subscription;

import java.math.BigDecimal;

import com.fasterxml.jackson.annotation.JsonProperty;

import io.spaceandtime.storage.core.*;

/**
 * Stores metadata about a subscription payment
 */
@JsonDefaultSerdesConfig
public class SubscriptionPayment extends SubscriptionBase {

	/** The provider identifier */
	@JsonProperty(SubscriptionProps.PROVIDER_ID)
	private String _providerId = null;
	/** The payment amount */
	@JsonProperty(SubscriptionProps.AMOUNT)
	private BigDecimal _amount = null;
	/** The payment currency */
	@JsonProperty(SubscriptionProps.CURRENCY)
	private String _currency = null;
	/** The payment timestamp */
	@JsonProperty(SubscriptionProps.TIMESTAMP)
	private Long _timestamp = null;

	public SubscriptionPayment() { super(); }
	public SubscriptionPayment(String subscriptionId, String providerId, BigDecimal amount, String currency, Long timestamp) {
		super(subscriptionId);
		_providerId = providerId;
		_amount = amount;
		_currency = currency;
		_timestamp = timestamp;
	}

	public String getProviderId() { return _providerId; }
	public BigDecimal getAmount() { return _amount; }
	public String getCurrency() { return _currency; }
	public Long getTimestamp() { return _timestamp; }

	public void setProviderId(String value) { _providerId = value; }
	public void setAmount(BigDecimal value) { _amount = value; }
	public void setCurrency(String value) { _currency = value; }
	public void setTimestamp(Long value) { _timestamp = value; }
}
