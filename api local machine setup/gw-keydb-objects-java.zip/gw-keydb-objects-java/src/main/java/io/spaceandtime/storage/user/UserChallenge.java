package io.spaceandtime.storage.user;

import org.springframework.lang.Nullable;

import com.fasterxml.jackson.annotation.JsonProperty;

import io.spaceandtime.storage.core.JsonDefaultSerdesConfig;

/**
 * Stores metadata about a user authentication challenge
 */
@JsonDefaultSerdesConfig
public class UserChallenge extends UserBase {

	/** The generated authentication code */
	@JsonProperty(UserProps.AUTH_CODE)
	private String _authCode = null;
	/** The message prefix (to support enhanced UX) */
	@JsonProperty(UserProps.PREFIX)
	private String _prefix = null;
	/** The join code */
	@JsonProperty(UserProps.JOIN_CODE)
	private String _joinCode = null;
	/** Defines whether or not this is a challenge for a registration flow */
	@JsonProperty(UserProps.IS_REGISTRATION)
	private boolean _registration = false;

	public UserChallenge() { super(); }
	public UserChallenge(String userId, String authCode, String prefix, String joinCode, boolean isRegistration) {
		super(userId);
		_authCode = authCode;
		_prefix = prefix;
		_joinCode = joinCode;
		_registration = isRegistration;
	}

	@Nullable public String getAuthCode() { return _authCode; }
	@Nullable public String getPrefix() { return _prefix; }
	@Nullable public String getJoinCode() { return _joinCode; }
	@Nullable public boolean isRegistration() { return _registration; }
	
	public void setAuthCode(String value) { _authCode = value; }
	public void setPrefix(String value) { _prefix = value; }
	public void setJoinCode(String value) { _joinCode = value; }
	public void setRegistration(boolean value) { _registration = value; }
}
