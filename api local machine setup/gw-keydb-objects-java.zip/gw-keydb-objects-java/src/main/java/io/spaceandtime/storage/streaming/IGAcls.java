package io.spaceandtime.storage.streaming;

import java.util.List;

import org.springframework.lang.Nullable;

import com.fasterxml.jackson.annotation.JsonProperty;

import io.spaceandtime.storage.core.JsonDefaultSerdesConfig;

/**
 * Stores metadata about streaming infrastructure group ACLs
 */
@JsonDefaultSerdesConfig
public class IGAcls extends IGObject {
	
	/** The list of Kafka ACLs */
	@JsonProperty(StreamingProps.ACLS)
	private List<KafkaAcl> _acls = null;

	public IGAcls() { super(); }
	public IGAcls(String groupId, List<KafkaAcl> acls) {
		super(groupId);
		_acls = acls;
	}

	@Nullable public List<KafkaAcl> getAcls() { return _acls; }
	public void setAcls(List<KafkaAcl> value) { _acls = value; }
}
