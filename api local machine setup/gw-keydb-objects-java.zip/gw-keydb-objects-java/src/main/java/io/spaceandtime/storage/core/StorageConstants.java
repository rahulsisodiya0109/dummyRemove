package io.spaceandtime.storage.core;

/**
 * Defines core storage constants
 */
public final class StorageConstants {
	/** Defines the KeyDB key component separator */
	public static final String KEY_SEPARATOR = ":";

	/**
	 * Defines common property values
	 */
	public static final class CommonProps {
		public static final String USER_ID = "userId";
		public static final String GATEWAY_ID = "gatewayId";
		public static final String DATA_WAREHOUSE_ID = "warehouseId";
		public static final String WALLET_ADDR = "walletAddr";
		public static final String SCHEMAS = "schemas";
		public static final String TABLES = "tables";
		public static final String VIEWS = "views";
		public static final String INDICES = "indices";
		public static final String PUBLIC_KEY = "publicKey";
		public static final String USERNAME = "username";
		public static final String PASSWORD = "password";
		public static final String USERS = "users";
		public static final String CLUSTER_TYPE_PRIMARY = "primary";
		public static final String CLUSTER_TYPE_SECONDARY = "secondary";
	}
}
