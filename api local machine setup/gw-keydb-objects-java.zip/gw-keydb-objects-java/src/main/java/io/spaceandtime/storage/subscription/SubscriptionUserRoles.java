package io.spaceandtime.storage.subscription;

import java.util.HashMap;
import java.util.Map;

import org.springframework.lang.Nullable;

import com.fasterxml.jackson.annotation.JsonProperty;

import io.spaceandtime.storage.core.*;

/**
 * Stores metadata about users in a subscription
 */
@JsonDefaultSerdesConfig
public class SubscriptionUserRoles extends SubscriptionBase {
	public static final String KEY = Keys.Subscription.USER_ROLES;

	/** The users role map: key=userId, value=role */
	@JsonProperty(SubscriptionProps.USER_ROLE_MAP)
	private Map<String, SubscriptionRole> _map = null;

	public SubscriptionUserRoles() { super(); }
	public SubscriptionUserRoles(String subscriptionId, Map<String, SubscriptionRole> map) {
		super(subscriptionId);
		_map = map;
	}

	@Nullable public Map<String, SubscriptionRole> getMap() { return _map; }
	public boolean isEmpty() { return _map == null || _map.isEmpty(); }
	public void setMap(Map<String, SubscriptionRole> value) { _map = value; }
	
	public void set(String userId, SubscriptionRole role) {
		if (_map == null) {
			_map = new HashMap<>();
		}
		_map.put(userId, role);
	}
	public boolean hasRole(String userId, SubscriptionRole role) {
		return !isEmpty() && role.equals(_map.get(userId));
	}
	public SubscriptionRole get(String userId) {
		if (isEmpty()) return null;
		return _map.get(userId);
	}
	public void remove(String userId) {
		if (isEmpty()) return;
		_map.remove(userId);
	}
}
