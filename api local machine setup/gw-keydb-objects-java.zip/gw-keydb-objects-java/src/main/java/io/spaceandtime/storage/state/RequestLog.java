package io.spaceandtime.storage.state;

import java.time.Instant;
import java.util.UUID;

import org.springframework.lang.Nullable;

import com.fasterxml.jackson.annotation.JsonProperty;

import io.spaceandtime.storage.core.*;

/**
 * Stores metadata about a user request
 */
@JsonDefaultSerdesConfig
public class RequestLog {
	
	/** The request unique identifier */
	@JsonProperty(StateProps.REQUEST_ID)
	private UUID _requestId = null;
	/** The user identifier */
	@JsonProperty(StateProps.USER_ID)
	private String _userId = null;
	/** The SQL text executed */
	@JsonProperty(StateProps.SQL_TEXT)
	private String _sqlText = null;
	/** The identifier of the gateway processing the request */
	@JsonProperty(StateProps.GATEWAY_ID)
	private String _gatewayId = null;
	/** The identifier of the data warehouse processing the request */
	@JsonProperty(StateProps.DATA_WAREHOUSE_ID)
	private String _warehouseId = null;
	/** The request runtime */
	@JsonProperty(StateProps.RUNTIME)
	private Long _runtime = null;
	/** When the request was executed */
	@JsonProperty(StateProps.EXEC_TIME)
	private Instant _executedTime = null;
	/** The number of rows returned */
	@JsonProperty(StateProps.ROW_COUNT)
	private Integer _rowCount = null;
	/** The response packet size */
	@JsonProperty(StateProps.RESPONSE_SIZE)
	private Long _responseSize = null;
	/** The error details (in case the request failed) */
	@JsonProperty(StateProps.ERROR_DETAILS)
	private String _errorDetails = null;
	/** The request origin */
	@JsonProperty(StateProps.ORIGIN)
	private String _origin = null;
	/** Additional request metadata */
	@JsonProperty(StateProps.METADATA)
	private String _metadata = null;
	
	public RequestLog(){}
	public RequestLog(UUID requestId, String userId, String sqlText, String gatewayId, String warehouseId, Long runtime, Instant executedTime, Integer rowCount, Long responseSize, String errorDetails, String origin, String metadata) {
		_requestId = requestId;
		_userId = userId;
		_sqlText = sqlText;
		_gatewayId = gatewayId;
		_warehouseId = warehouseId;
		_runtime = runtime;
		_executedTime = executedTime;
		_rowCount = rowCount;
		_responseSize = responseSize;
		_errorDetails = errorDetails;
		_origin = origin;
		_metadata = metadata;
	}

	@Nullable public UUID getRequestId() { return _requestId; }
	@Nullable public String getUserId() { return _userId; }
	@Nullable public String getSqlText() { return _sqlText; }
	@Nullable public String getGatewayId() { return _gatewayId; }
	@Nullable public String getWarehouseId() { return _warehouseId; }
	@Nullable public Long getRuntime() { return _runtime; }
	@Nullable public Instant getExecutedTime() { return _executedTime; }
	@Nullable public Integer getRowCount() { return _rowCount; }
	@Nullable public Long getResponseSize() { return _responseSize; }
	@Nullable public String getErrorDetails() { return _errorDetails; }
	@Nullable public String getOrigin() { return _origin; }
	@Nullable public String getMetadata() { return _metadata; }

	public void setRequestId(UUID value) { _requestId = value; }
	public void setUserId(String value) { _userId = value; }
	public void setSqlText(String value) { _sqlText = value; }
	public void setGatewayId(String value) { _gatewayId = value; }
	public void setWarehouseId(String value) { _warehouseId = value; }
	public void setRuntime(Long value) { _runtime = value; }
	public void setExecutedTime(Instant value) { _executedTime = value; }
	public void setRowCount(Integer value) { _rowCount = value; }
	public void setResponseSize(Long value) { _responseSize = value; }
	public void setErrorDetails(String value) { _errorDetails = value; }
	public void setOrigin(String value) { _origin = value; }
	public void setMetadata(String value) { _metadata = value; }
}
