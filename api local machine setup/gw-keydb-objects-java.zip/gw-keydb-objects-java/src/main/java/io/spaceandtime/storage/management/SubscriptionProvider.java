package io.spaceandtime.storage.management;

import org.springframework.lang.Nullable;

import com.fasterxml.jackson.annotation.JsonProperty;

import io.spaceandtime.storage.core.*;

/**
 * Stores metadata about a subscription provider
 */
@JsonDefaultSerdesConfig
public class SubscriptionProvider {
	public static final String KEY = Keys.Management.SUBSCRIPTION_PROVIDER;
	
	/** The provider unique identifier */
	@JsonProperty(ManagementProps.PROVIDER_ID)
	private String _id = null;
	/** The provider display name */
	@JsonProperty(ManagementProps.PROVIDER_NAME)
	private String _name = null;
	/** The provider public key (used to validate requests from the provider) */
	@JsonProperty(ManagementProps.PUBLIC_KEY)
	private String _publicKey = null;

	public SubscriptionProvider(){}
	public SubscriptionProvider(String id, String name, String publicKey) {
		_id = id;
		_name = name;
		_publicKey = publicKey;
	}

	@Nullable public String getId() { return _id; }
	@Nullable public String getName() { return _name; }
	@Nullable public String getPublicKey() { return _publicKey; }

	public void setId(String value) { _id = value; }
	public void setName(String value) { _name = value; }
	public void setPublicKey(String value) { _publicKey = value; }
}
