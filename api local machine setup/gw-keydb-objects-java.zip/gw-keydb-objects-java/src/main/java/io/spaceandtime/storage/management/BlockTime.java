package io.spaceandtime.storage.management;

import org.springframework.lang.Nullable;

import com.fasterxml.jackson.annotation.JsonProperty;

import io.spaceandtime.storage.core.*;

/**
 * Stores metadata about block time configuration
 * <p>
 * In this context, block time represents the configuration necessary to rate-limit
 * subscriptions. A block time object defines how rate limiting should be implemented
 */
@JsonDefaultSerdesConfig
public class BlockTime {
	public static final String KEY = Keys.Management.BLOCK_TIME;

	/** Defines the valid units for block time duration */
	public enum BTUnits {
		@JsonProperty(ManagementProps.BTUNIT_SECOND) SECONDS(ManagementProps.BTUNIT_SECOND),
		@JsonProperty(ManagementProps.BTUNIT_MINUTE) MINUTES(ManagementProps.BTUNIT_MINUTE),
		@JsonProperty(ManagementProps.BTUNIT_HOUR) HOURS(ManagementProps.BTUNIT_HOUR),
		;

		public final String Value;
		BTUnits(String value) {
			Value = value;
		}
	}

	/** The unique block time identifier */
	@JsonProperty(ManagementProps.BLOCK_TIME_ID)
	private String _id = null;
	/** Defines the capacity of the bucket (i.e., the total number of requests allowed at a time) */
	@JsonProperty(ManagementProps.CAPACITY)
	private Long _capacity = null;
	/** Defines the number of tokens added to the bucket per duration */
	@JsonProperty(ManagementProps.INCREMENT_BY)
	private Integer _incrementBy = null;
	/** Defines the time period over which to add tokens back to the bucket */
	@JsonProperty(ManagementProps.DURATION_VALUE)
	private Integer _durationValue = null;
	/** Defines the units of the duration */
	@JsonProperty(ManagementProps.DURATION_UNITS)
	private BTUnits _durationUnits;

	public BlockTime(){}
	public BlockTime(String id, Long capacity, Integer incrementBy, Integer durationValue, BTUnits durationUnits) {
		_id = id;
		_capacity = capacity;
		_incrementBy = incrementBy;
		_durationValue = durationValue;
		_durationUnits = durationUnits;
	}

	@Nullable public String getId() { return _id; }
	@Nullable public Long getCapacity() { return _capacity; }
	@Nullable public Integer getIncrementBy() { return _incrementBy; }
	@Nullable public Integer getDurationValue() { return _durationValue; }
	public BTUnits getDurationUnits() { return _durationUnits; }

	public void setId(String value) { _id = value; }
	public void setCapacity(Long value) { _capacity = value; }
	public void setIncrementBy(Integer value) { _incrementBy = value; }
	public void setDurationValue(Integer value) { _durationValue = value; }
	public void setDurationUnits(BTUnits value) { _durationUnits = value; }
}
