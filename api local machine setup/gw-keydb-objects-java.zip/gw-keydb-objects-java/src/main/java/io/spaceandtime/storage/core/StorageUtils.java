package io.spaceandtime.storage.core;

import org.springframework.lang.Nullable;
import org.springframework.util.StringUtils;

/**
 * Provides various storage library utility methods
 */
public class StorageUtils {
	public static final String DB_SEPARATOR = ".";

	/**
	 * Convert a given identifier to uppercase safely
	 * @param identifier - the identifier
	 * @return
	 */
	@Nullable public static String toUpper(String identifier) {
		return StringUtils.hasLength(identifier)
			? identifier.toUpperCase()
			: null;
	}

	public static final class Db {
		/**
		 * Build a resource identifier for indexing into KeyDB
		 * @param resourceId - the original resource identifier
		 * @return the standard resource identifier for indexing into KeyDB, or null
		 */
		@Nullable public static String resourceId(String resourceId) {
			return StringUtils.hasLength(resourceId)
				? resourceId.toUpperCase().replace(DB_SEPARATOR, Keys.SEPARATOR)
				: null;
		}
		/**
		 * Build a resource identifier for indexing into KeyDB
		 * @param schemaId - the schema identifier
		 * @param tableId - the table identifier
		 * @return the standard resource identifier for indexing into KeyDB, or null
		 */
		@Nullable public static String resourceId(String schemaId, String tableId) {
			return StringUtils.hasLength(schemaId) && StringUtils.hasLength(tableId)
				? schemaId.toUpperCase() + Keys.SEPARATOR + tableId.toUpperCase()
				: null;
		}
	}
}
