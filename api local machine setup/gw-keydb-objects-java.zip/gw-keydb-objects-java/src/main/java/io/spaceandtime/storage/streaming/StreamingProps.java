package io.spaceandtime.storage.streaming;

import io.spaceandtime.storage.core.StorageConstants.*;

/**
 * Defines streaming resource property constants
 */
public final class StreamingProps {
	public static final String PUBLIC_KEY = CommonProps.PUBLIC_KEY;
	public static final String GROUP_ID = "groupId";
	public static final String TOPIC_ID = "topicId";
	public static final String MAPPING_ID = "mappingId";
	public static final String USERS = CommonProps.USERS;
	public static final String TOPICS = "topics";
	public static final String ACLS = "acls";
	public static final String PRINCIPAL = "principal";
	public static final String PERMISSION = "permission";
	public static final String CONSUMER_GROUP = "consumerGroup";
	public static final String ASSIGNED_CLUSTER_ID = CommonProps.DATA_WAREHOUSE_ID;
	public static final String TASKS = "tasks";
	public static final String USERNAME = CommonProps.USERNAME;
	public static final String PASSWORD = CommonProps.PASSWORD;

	public static final String PERM_ALLOW = "ALLOW";
	public static final String PERM_DENY = "DENY";
}
