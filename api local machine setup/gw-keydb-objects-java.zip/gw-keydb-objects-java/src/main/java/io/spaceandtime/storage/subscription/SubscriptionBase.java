package io.spaceandtime.storage.subscription;

import io.spaceandtime.storage.core.JsonDefaultSerdesConfig;

import org.springframework.lang.Nullable;

import com.fasterxml.jackson.annotation.JsonProperty;

/**
 * Defines the base implementation of a subscription object
 */
@JsonDefaultSerdesConfig
public abstract class SubscriptionBase {
	
	/** The subscription identifier */
	@JsonProperty(SubscriptionProps.SUBSCRIPTION_ID)
	private String _subscriptionId = null;

	public SubscriptionBase(){}
	public SubscriptionBase(String subscriptionId) {
		_subscriptionId = subscriptionId;
	}
	
	@Nullable public String getSubscriptionId() { return _subscriptionId; }
	public void setSubscriptionId(String value) { _subscriptionId = value; }
}
