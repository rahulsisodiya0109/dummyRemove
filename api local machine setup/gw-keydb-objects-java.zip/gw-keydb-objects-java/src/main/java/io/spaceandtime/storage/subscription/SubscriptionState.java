package io.spaceandtime.storage.subscription;

import com.fasterxml.jackson.annotation.JsonProperty;

/**
 * Defines the possible states of a subscription
 */
public enum SubscriptionState {
	/** Denotes a subscription who is actively paying and using the platform */
	@JsonProperty(SubscriptionProps.SS_ACTIVE)ACTIVE(SubscriptionProps.SS_ACTIVE),
	/** Denotes a subscription whose provider has suspended the subscription for not paying or having a negative balance */
	@JsonProperty(SubscriptionProps.SS_SUSPENDED)SUSPENDED(SubscriptionProps.SS_SUSPENDED),
	/** Denotes a subscription that has been canceled by an owner */
	@JsonProperty(SubscriptionProps.SS_CANCELED)CANCELED(SubscriptionProps.SS_CANCELED),
	;

	public final String Value;
	SubscriptionState(String value) {
		Value = value;
	}
}
