package io.spaceandtime.storage.streaming;

import org.springframework.lang.Nullable;

import com.fasterxml.jackson.annotation.JsonProperty;

import io.spaceandtime.storage.core.JsonDefaultSerdesConfig;

/**
 * Stores metadata about a streaming infrastructure group
 */
@JsonDefaultSerdesConfig
public class InfrastructureGroup {
	
	/** The group identifier */
	@JsonProperty(StreamingProps.GROUP_ID)
	private String _groupId = null;
	/** The public key */
	@JsonProperty(StreamingProps.PUBLIC_KEY)
	private String _publicKey = null;

	public InfrastructureGroup(){}
	public InfrastructureGroup(String groupId, String publicKey) {
		_groupId = groupId;
		_publicKey = publicKey;
	}

	@Nullable public String getGroupId() { return _groupId; }
	@Nullable public String getPublicKey() { return _publicKey; }

	public void setGroupId(String value) { _groupId = value; }
	public void setPublicKey(String value) { _publicKey = value; }
}
