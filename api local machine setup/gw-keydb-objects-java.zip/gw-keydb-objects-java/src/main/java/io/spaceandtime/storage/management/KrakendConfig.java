package io.spaceandtime.storage.management;

import java.util.List;

import org.springframework.lang.Nullable;

import com.fasterxml.jackson.annotation.JsonProperty;

import io.spaceandtime.storage.core.*;

/**
 * Stores metadata about general KrakenD configuration
 * <p>
 * This object, in combination with the {@link BlockTime} object,
 * define practically everything KrakenD needs to support our
 * custom rate-limiter plugin
 */
@JsonDefaultSerdesConfig
public class KrakendConfig {
	public static final String KEY = Keys.Management.KRAKEND;

	/**
	 * Defines the trial limit - i.e., the total # of requests a user
	 * can make before getting paywalled and needing to configure a subscription
	 */
	@JsonProperty(ManagementProps.TRIAL_LIMIT)
	private Integer _trialLimit = null;
	/**
	 * Defines the list of restricted APIs (each entry should be a valid
	 * regex). Restricted APIs are not allowed to be performed by users
	 * with a delinquent subscription
	 */
	@JsonProperty(ManagementProps.RESTRICTED_APIS)
	private List<String> _restrictedApis = null;

	public KrakendConfig(){}
	public KrakendConfig(Integer trialLimit, List<String> restrictedApis) {
		_trialLimit = trialLimit;
		_restrictedApis = restrictedApis;
	}

	@Nullable public Integer getTrialLimit() { return _trialLimit; }
	@Nullable public List<String> getRestrictedApis() { return _restrictedApis; }
	
	public void setTrialLimit(Integer value) { _trialLimit = value; }
	public void setRestrictedApis(List<String> value) { _restrictedApis = value; }
}
