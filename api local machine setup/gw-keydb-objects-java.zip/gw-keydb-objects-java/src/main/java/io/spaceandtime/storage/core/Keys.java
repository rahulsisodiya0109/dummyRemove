package io.spaceandtime.storage.core;

/**
 * Defines all storage structure keys
 */
public final class Keys {
	/** The key separator */
	public static final String SEPARATOR = StorageConstants.KEY_SEPARATOR;
	
	/**
	 * Holds common values
	 */
	private static final class Common {
		/** Represents the resource key prefix */
		public static final String RESOURCE = "rsrc";
		/** Represents the participant key prefix */
		public static final String PARTICIPANT = "ptcp";

		public static final String PROVIDER = "prov";
		public static final String USER = "user";
		public static final String GROUP = "grp";
		public static final String TABLE = "tbl";
		public static final String ASSET = "asst";
		public static final String ALL = "all";
		public static final String DATA_INGESTION_TASK = "dit";
		public static final String DATA_WAREHOUSE = "dw";
		public static final String GATEWAY = "gw";
		public static final String ADDRESS = "addr";
		public static final String NETWORK = "ntwk";
		public static final String STATUS = "stat";
		public static final String REPUTATION = "rep";
		public static final String LOG = "log";
		public static final String BLOCK_TIME = "bt";
		public static final String SUBSCRIPTION = "sbsc";
		public static final String UNAVAILABLE = "unav";
	}

	/**
	 * Defines all database resource structure keys
	 */
	public static final class Db {
		private static final String PREFIX = Common.RESOURCE + SEPARATOR + "db" + SEPARATOR;
		private static final String ALL_PREFIX = PREFIX + Common.ALL + SEPARATOR;
		private static final String INDEX_KEY = "idx";
		private static final String SCHEMA_KEY = "schm";
		private static final String VIEW_KEY = "view";

		public static final String TABLE = PREFIX + Common.TABLE;
		public static final String TABLE_ALL = ALL_PREFIX + Common.TABLE;
		public static final String SCHEMA = PREFIX + SCHEMA_KEY;
		public static final String SCHEMA_ALL = ALL_PREFIX + SCHEMA_KEY;
		public static final String SCHEMA_ASSETS = PREFIX + Common.ASSET + SEPARATOR + SCHEMA_KEY;
		public static final String INDEX = PREFIX + INDEX_KEY;
		public static final String INDEX_ALL = ALL_PREFIX + INDEX_KEY;
		public static final String VIEW = PREFIX + VIEW_KEY;
		public static final String VIEW_ALL = ALL_PREFIX + VIEW_KEY;
		public static final String VIEWID_MAP = VIEW + SEPARATOR + "map";

		public static final String OBJECT_HOSTS = PREFIX + "host";
		public static final String OBJECT_LEADERS = PREFIX + "ledr";
		public static final String OBJECT_UNAVAILABLE = PREFIX + Common.UNAVAILABLE;
		public static final String TABLE_ANCHOR_STAMP = TABLE + SEPARATOR + "stmp";
		public static final String TABLE_RELATIONS_CACHE = TABLE + SEPARATOR + "rlch";
	}

	/**
	 * Defines all kafka resource structure keys
	 */
	public static final class Kafka {
		private static final String PREFIX = Common.RESOURCE + SEPARATOR + "kfk" + SEPARATOR;

		public static final String INFRA_GROUP = PREFIX + Common.GROUP;
		public static final String INFRA_GROUP_ALL = INFRA_GROUP + SEPARATOR + Common.ALL;
		public static final String TOPIC = PREFIX + "topc";
		public static final String USER = PREFIX + Common.USER;
		public static final String ACL = PREFIX + "acl";
		public static final String INGEST_TASK = PREFIX + Common.DATA_INGESTION_TASK;
		public static final String CLUSTER_TASK_ASSIGNMENT = PREFIX + Common.DATA_WAREHOUSE + SEPARATOR + Common.DATA_INGESTION_TASK;
		public static final String CLUSTER_CREDENTIAL = PREFIX + Common.DATA_WAREHOUSE + SEPARATOR + "cred";

		/**
		 * Get the identifier of an infrastructure group topic
		 * @param groupId - the group identifier
		 * @param topicName - the topic name
		 * @return
		 */
		public static String groupTopicId(String groupId, String topicName) {
			return groupId.toUpperCase() + SEPARATOR + topicName;
		}
		/**
		 * Get the structure key for a topic mapping configuration object
		 * @param groupId - the infrastructure group id
		 * @param topicName - the topic name
		 * @return
		 */
		public static String mappingConfig(String groupId, String topicName) {
			return PREFIX + "tmap" + SEPARATOR + groupTopicId(groupId, topicName);
		}
		/**
		 * Get the full identifier for a topic mapping configuration object
		 * @param groupId - the infrastructure group id
		 * @param topicName - the topic name
		 * @param mappingId - the mapping config identifier
		 * @return
		 */
		public static String tmcIdentifier(String groupId, String topicName, String mappingId) {
			return groupTopicId(groupId, topicName) + SEPARATOR + mappingId;
		}
	}

	/**
	 * Defines all operator structure keys
	 */
	public static final class Operator {
		private static final String PREFIX = Common.PARTICIPANT + SEPARATOR + Common.PROVIDER + SEPARATOR;

		public static final String OPERATOR = PREFIX + "opr";
		public static final String GATEWAY = PREFIX + Common.GATEWAY;
		public static final String DATA_WAREHOUSE = PREFIX + Common.DATA_WAREHOUSE;
	}

	/**
	 * Defines all data warehouse structure keys
	 */
	public static final class DataWarehouse {
		private static final String PREFIX = Common.PARTICIPANT + SEPARATOR + Common.DATA_WAREHOUSE + SEPARATOR;

		public static final String ADDRESS = PREFIX + Common.ADDRESS;
		public static final String ASSETS = PREFIX + Common.ASSET;
		public static final String NETWORK = PREFIX + Common.NETWORK;
		public static final String STATUS = PREFIX + Common.STATUS;
		public static final String REPUTATION = PREFIX + Common.REPUTATION;
		public static final String UNAVAILABLE = PREFIX + Common.UNAVAILABLE;
	}

	/**
	 * Defines all user structure keys
	 */
	public static final class User {
		public static final String USER = Common.PARTICIPANT + SEPARATOR + Common.USER;
		private static final String PREFIX = USER + SEPARATOR;

		/**
		 * Get the unique user challenge key
		 * @param userId - the user identifier
		 * @return
		 */
		public static String challenge(String userId) {
			return PREFIX + "chl" + SEPARATOR + userId;
		}
		/**
		 * Get the unique user session key
		 * @param userId - the user identifier
		 * @return
		 */
		public static String session(String userId) {
			return PREFIX + "ssn" + SEPARATOR + userId;
		}
		/**
		 * Get the unique user query log key
		 * @param userId - the user identifier
		 * @return
		 */
		public static String queryLog(String userId) {
			return PREFIX + Common.LOG + SEPARATOR + userId;
		}
	}

	/**
	 * Defines all subscription structure keys
	 */
	public static final class Subscription {
		public static final String SUBSCRIPTION = Common.PARTICIPANT + SEPARATOR + Common.SUBSCRIPTION;
		private static final String PREFIX = SUBSCRIPTION + SEPARATOR;

		public static final String USER_ROLES = PREFIX + Common.USER + SEPARATOR + "role";
		public static final String CLUSTER_ASSIGNMENT = PREFIX + Common.DATA_WAREHOUSE;
		public static final String SUBSCRIPTION_BLOCK_TIME = PREFIX + Common.BLOCK_TIME;

		/**
		 * Get the unique join code key
		 * @param joinCode - the join code
		 * @return
		 */
		public static String invite(String joinCode) {
			return PREFIX + "invt" + SEPARATOR + joinCode;
		}
		/**
		 * Get the unique key for the subscription payment history
		 * @param subscriptionId - the subscription identifier
		 * @return
		 */
		public static String payment(String subscriptionId) {
			return PREFIX + "pymt" + SEPARATOR + subscriptionId;
		}
	}

	/**
	 * Defines all management structure keys
	 */
	public static final class Management {
		private static final String PREFIX = "mgmt" + SEPARATOR;
		private static final String SBSC = PREFIX + Common.PROVIDER + SEPARATOR + Common.SUBSCRIPTION;

		public static final String BLOCK_TIME = PREFIX + Common.BLOCK_TIME;
		public static final String KRAKEND = PREFIX + "kknd";
		public static final String SUBSCRIPTION_PROVIDER = SBSC;
		public static final String SUBSCRIPTION_METADATA = SBSC + SEPARATOR + "meta";

		/**
		 * Get the unique provider-subscription metadata key
		 * @param providerId - the provider identifier
		 * @param subscriptionId - the subscription identifier
		 * @return
		 */
		public static String subscriptionMetadata(String providerId, String subscriptionId) {
			return providerId + SEPARATOR + subscriptionId;
		}
	}
}
