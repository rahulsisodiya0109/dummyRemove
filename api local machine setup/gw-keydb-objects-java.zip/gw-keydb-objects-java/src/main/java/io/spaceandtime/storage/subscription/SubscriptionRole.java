package io.spaceandtime.storage.subscription;

import com.fasterxml.jackson.annotation.JsonProperty;

/**
 * Defines the possible roles a user can have within a subscription
 */
public enum SubscriptionRole {
	/**
	 * Defines a user who can manage the subscription */
	@JsonProperty(SubscriptionProps.SR_OWNER)OWNER(SubscriptionProps.SR_OWNER),
	/** Defines a user who can manage the subscription users */
	@JsonProperty(SubscriptionProps.SR_ADMIN)ADMIN(SubscriptionProps.SR_ADMIN),
	/** Defines a user who only exists within the subscription */
	@JsonProperty(SubscriptionProps.SR_MEMBER)MEMBER(SubscriptionProps.SR_MEMBER),
	;

	/** The string value of the role */
	public final String Value;
	SubscriptionRole(String value) {
		Value = value;
	}
}
