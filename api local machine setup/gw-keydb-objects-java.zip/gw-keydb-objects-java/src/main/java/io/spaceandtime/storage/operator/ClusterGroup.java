package io.spaceandtime.storage.operator;

import java.util.List;

import org.springframework.lang.Nullable;

import com.fasterxml.jackson.annotation.JsonProperty;

import io.spaceandtime.storage.core.JsonDefaultSerdesConfig;

/**
 * Stores metadata about a group of clusters
 */
@JsonDefaultSerdesConfig
public class ClusterGroup {
	/** The list of clusters hosting the object */
	@JsonProperty(OperatorProps.CLUSTERS)
	private List<String> _clusters = null;

	public ClusterGroup(){}
	public ClusterGroup(List<String> clusters) {
		_clusters = clusters;
	}

	@Nullable public List<String> getClusters() { return _clusters; }
	public void setClusters(List<String> value) { _clusters = value; }
}
