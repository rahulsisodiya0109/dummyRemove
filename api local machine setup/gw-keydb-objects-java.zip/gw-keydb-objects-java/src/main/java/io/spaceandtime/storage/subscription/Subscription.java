package io.spaceandtime.storage.subscription;

import org.springframework.lang.Nullable;

import com.fasterxml.jackson.annotation.JsonProperty;

import io.spaceandtime.storage.core.*;

/**
 * Stores metadata about a subscription
 */
@JsonDefaultSerdesConfig
public class Subscription extends SubscriptionBase {
	public static final String KEY = Keys.Subscription.SUBSCRIPTION;

	/** Defines the subscription name */
	@JsonProperty(SubscriptionProps.NAME)
	private String _name = null;
	/** Defines whether or not the subscription is currently active (i.e., valid) */
	@JsonProperty(SubscriptionProps.STATE)
	private SubscriptionState _state = null;
	/** The subscription provider identifier */
	@JsonProperty(SubscriptionProps.PROVIDER_ID)
	private String _providerId = null;
	/** The subscription plan name */
	@JsonProperty(SubscriptionProps.PLAN_NAME)
	private String _planName = null;
	/** The last payment date (in ms since unix epoch) */
	@JsonProperty(SubscriptionProps.LAST_PAYMENT)
	private String _lastPayment = null;

	public Subscription() { super(); }
	public Subscription(String subscriptionId, String name, SubscriptionState state, String providerId, String planName, String lastPayment) {
		super(subscriptionId);
		_state = state;
		_name = name;
		_providerId = providerId;
		_planName = planName;
		_lastPayment = lastPayment;
	}

	@Nullable public String getName() { return _name; }
	@Nullable public SubscriptionState getState() { return _state; }
	@Nullable public String getProviderId() { return _providerId; }
	@Nullable public String getPlanName() { return _planName; }
	@Nullable public String getLastPayment() { return _lastPayment; }
	
	public void setName(String value) { _name = value; }
	public void setState(SubscriptionState value) { _state = value; }
	public void setProviderId(String value) { _providerId = value; }
	public void setPlanName(String value) { _planName = value; }
	public void setLastPayment(String value) { _lastPayment = value; }
}
