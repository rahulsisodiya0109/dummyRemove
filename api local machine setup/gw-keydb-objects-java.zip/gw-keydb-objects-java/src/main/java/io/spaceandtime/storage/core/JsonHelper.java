package io.spaceandtime.storage.core;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.datatype.jsr310.JavaTimeModule;

/**
 * A utility class providing JSON serdes helper methods
 */
public class JsonHelper {
	// NOTE: we explicitly register the time module to support Java 8 time objects
	/** The Jackson JSON object mapper */
	private static ObjectMapper MAPPER = new ObjectMapper().registerModule(new JavaTimeModule());


	/**
	 * Serialize an object to JSON string
	 * @param <T> - the object type
	 * @param object - the object value
	 * @return
	 * @throws Exception when JSON serialization fails
	 */
	public static <T> String serialize(T object) throws Exception {
		return MAPPER.writeValueAsString(object);
	}
	/**
	 * Deserialize a JSON string into an object
	 * @param <T> - the object type
	 * @param json - the JSON string
	 * @param clazz - the object class type
	 * @return
	 * @throws Exception when JSON deserialization fails
	 */
	public static <T> T deserialize(String json, Class<T> clazz) throws Exception {
		return MAPPER.readValue(json, clazz);
	}
}
