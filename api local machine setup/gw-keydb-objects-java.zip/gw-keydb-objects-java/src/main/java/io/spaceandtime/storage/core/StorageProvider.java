package io.spaceandtime.storage.core;

import java.util.*;
import java.util.concurrent.TimeUnit;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.data.redis.core.*;
import org.springframework.stereotype.Component;

@Component
public class StorageProvider implements IStorageProvider {

	/** Used to convert single operation long results to boolean true/falses */
	private static final long ONE = 1L;
	/** Used to refer to the minimum index (i.e., first element) in a list */
	private static final long LIST_IDX_MIN = 0L;
	/** Used to refer to the maximum index (i.e., last element) in a list */
	private static final long LIST_IDX_MAX = -1L;
	
	@Autowired
	@Qualifier("redisTemplate")
	protected RedisTemplate<String, String> _template;

	// Common operations
	@Override
	public String ping() {
		return Objects.requireNonNull(_template.getConnectionFactory()).getConnection().ping();
	}

	@Override
	public Boolean delete(String key) {
		return _template.delete(key);
	}

	@Override
	public Long getTtl(String key, TimeUnit units) {
		return _template.getExpire(key, units);
	}

	@Override
	public Boolean setTtl(String key, Long duration, TimeUnit units) {
		return _template.expire(key, duration, units);
	}

	@Override
	public Boolean setExpireDate(String key, Date expireDate) {
		return _template.expireAt(key, expireDate);
	}

	// String operations
	private ValueOperations<String, String> string() { return _template.opsForValue(); }
	@Override
	public Boolean vExists(String key) {
		return _template.hasKey(key);
	}

	@Override
	public String vGet(String key) {
		return string().get(key);
	}

	@Override
	public <T> T vGet(String key, Class<T> clazz) throws Exception {
		String json = vGet(key);
		return JsonHelper.deserialize(json, clazz);
	}

	@Override
	public void vSet(String key, String value) {
		string().set(key, value);
	}

	@Override
	public <T> void vSet(String key, T value) throws Exception {
		String json = JsonHelper.serialize(value);
		vSet(key, json);
	}

	@Override
	public Long vIncrement(String key) {
		return string().increment(key);
	}

	@Override
	public Long vIncrementBy(String key, long delta) {
		return string().increment(key, delta);
	}

	@Override
	public Long vDecrement(String key) {
		return string().decrement(key);
	}

	@Override
	public Long vDecrementBy(String key, long delta) {
		return string().decrement(key, delta);
	}

	@Override
	public Long vSize(String key) {
		return string().size(key);
	}

	// Hash operations
	HashOperations<String, String, String> hash() { return _template.opsForHash(); }
	@Override
	public Boolean hExists(String key, String hashKey) {
		return hash().hasKey(key, hashKey);
	}

	@Override
	public Boolean hDelete(String key, String hashKey) {
		return hash().delete(key, hashKey) == ONE;
	}

	@Override
	public String hGet(String key, String hashKey) {
		return hash().get(key, hashKey);
	}

	@Override
	public <T> T hGet(String key, String hashKey, Class<T> clazz) throws Exception {
		String json = hGet(key, hashKey);
		return JsonHelper.deserialize(json, clazz);
	}

	@Override
	public Map<String, String> hGetAll(String key) {
		return hash().entries(key);
	}

	@Override
	public <T> Map<String, T> hGetAll(String key, Class<T> clazz) throws Exception {
		Map<String, String> jsonMap = hGetAll(key);
		Map<String, T> results = new HashMap<>();
		for (Map.Entry<String, String> entry : jsonMap.entrySet()) {
			results.put(entry.getKey(), JsonHelper.deserialize(entry.getValue(), clazz));
		}
		return results;
	}

	@Override
	public void hPut(String key, String hashKey, String value) {
		hash().put(key, hashKey, value);
	}

	@Override
	public <T> void hPut(String key, String hashKey, T value) throws Exception {
		String json = JsonHelper.serialize(value);
		hPut(key, hashKey, json);
	}

	@Override
	public void hPutAllSimple(String key, Map<String, String> entries) {
		hash().putAll(key, entries);
	}

	@Override
	public <T> void hPutAll(String key, Map<String, T> entries) throws Exception {
		Map<String, String> jsonMap = new HashMap<>();
		for (Map.Entry<String, T> entry : entries.entrySet()) {
			jsonMap.put(entry.getKey(), JsonHelper.serialize(entry.getValue()));
		}
		hPutAllSimple(key, jsonMap);
	}

	@Override
	public Set<String> hKeys(String key) throws Exception {
		return hash().keys(key);
	}

	@Override
	public Long hSize(String key) {
		return hash().size(key);
	}

	// Set operations
	private SetOperations<String, String> set() { return _template.opsForSet(); }
	@Override
	public Boolean sIsMember(String key, String value) {
		return set().isMember(key, value);
	}

	@Override
	public <T> Boolean sIsMember(String key, T value) throws Exception {
		String json = JsonHelper.serialize(value);
		return sIsMember(key, json);
	}

	@Override
	public Boolean sAdd(String key, String value) {
		return set().add(key, value) == ONE;
	}

	@Override
	public <T> Boolean sAdd(String key, T value) throws Exception {
		String json = JsonHelper.serialize(value);
		return sAdd(key, json);
	}

	@Override
	public Long sAddMany(String key, String[] values) {
		return set().add(key, values);
	}

	@Override
	public <T> Long sAddMany(String key, T[] values) throws Exception {
		String[] jsonArr = new String[values.length];
		for(int i = 0; i < values.length; ++i) {
			jsonArr[i] = JsonHelper.serialize(values[i]);
		}
		return sAddMany(key, jsonArr);
	}

	@Override
	public Set<String> sGetAll(String key) {
		return set().members(key);
	}

	@Override
	public <T> Set<T> sGetAll(String key, Class<T> clazz) throws Exception {
		Set<String> jsonSet = sGetAll(key);
		Set<T> results = new HashSet<>();
		for (String json : jsonSet) {
			results.add(JsonHelper.deserialize(json, clazz));
		}
		return results;
	}

	@Override
	public Boolean sDelete(String key, String value) {
		return set().remove(key, value) == ONE;
	}

	@Override
	public <T> Boolean sDelete(String key, T value) throws Exception {
		String json = JsonHelper.serialize(value);
		return sDelete(key, json);
	}

	@Override
	public Long sDeleteMany(String key, Object[] values) {
		return set().remove(key, values);
	}

	@Override
	public Long sSize(String key) {
		return set().size(key);
	}

	// List operations
	private ListOperations<String, String> list() { return _template.opsForList(); }
	@Override
	public List<String> lGetAll(String key) {
		return lGetBetween(key, LIST_IDX_MIN, LIST_IDX_MAX);
	}

	@Override
	public <T> List<T> lGetAll(String key, Class<T> clazz) throws Exception {
		return lGetBetween(key, LIST_IDX_MIN, LIST_IDX_MAX, clazz);
	}

	@Override
	public List<String> lGetBetween(String key, long startIndex, long endIndex) {
		return list().range(key, startIndex, endIndex);
	}

	@Override
	public <T> List<T> lGetBetween(String key, long startIndex, long endIndex, Class<T> clazz) throws Exception {
		List<String> jsonList = lGetBetween(key, startIndex, endIndex);
		List<T> results = new ArrayList<>(jsonList.size());
		for (String json : jsonList) {
			results.add(JsonHelper.deserialize(json, clazz));
		}
		return results;
	}

	@Override
	public String lGetAtIndex(String key, long index) {
		return list().index(key, index);
	}

	@Override
	public <T> T lGetAtIndex(String key, long index, Class<T> clazz) throws Exception {
		String json = lGetAtIndex(key, index);
		return JsonHelper.deserialize(json, clazz);
	}

	@Override
	public void lSetAtIndex(String key, long index, String value) {
		list().set(key, index, value);
	}

	@Override
	public <T> void lSetAtIndex(String key, long index, T value) throws Exception {
		String json = JsonHelper.serialize(value);
		lSetAtIndex(key, index, json);
	}

	@Override
	public Long lIndexOf(String key, String value) {
		return list().indexOf(key, value);
	}

	@Override
	public <T> Long lIndexOf(String key, T value) throws Exception {
		String json = JsonHelper.serialize(value);
		return lIndexOf(key, json);
	}

	@Override
	public void lPushHead(String key, String value) {
		list().leftPush(key, value);
	}

	@Override
	public <T> void lPushHead(String key, T value) throws Exception {
		String json = JsonHelper.serialize(value);
		lPushHead(key, json);
	}

	@Override
	public void lPushTail(String key, String value) {
		list().rightPush(key, value);
	}

	@Override
	public <T> void lPushTail(String key, T value) throws Exception {
		String json = JsonHelper.serialize(value);
		lPushTail(key, json);
	}

	@Override
	public String lPopHead(String key) {
		return list().leftPop(key);
	}

	@Override
	public <T> T lPopHead(String key, Class<T> clazz) throws Exception {
		String json = lPopHead(key);
		return JsonHelper.deserialize(json, clazz);
	}

	@Override
	public String lPopTail(String key) {
		return list().rightPop(key);
	}

	@Override
	public <T> T lPopTail(String key, Class<T> clazz) throws Exception {
		String json = lPopTail(key);
		return JsonHelper.deserialize(json, clazz);
	}

	@Override
	public Long lSize(String key) {
		return list().size(key);
	}
}
