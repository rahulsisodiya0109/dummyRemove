package io.spaceandtime.security.config.providers;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import io.spaceandtime.api.jwt.IJwkConfig;
import io.spaceandtime.security.config.EnvVars;

@Component
public class JwkConfigProvider implements IJwkConfig {

	@Value(EnvVars.Security.GATEWAY_PUBLIC_KEY)
	private String GATEWAY_PUBLIC_KEY;
	@Value(EnvVars.Security.GATEWAY_PRIVATE_KEY)
	private String GATEWAY_PRIVATE_KEY;
	@Value(EnvVars.Security.GATEWAY_KEY_ID)
	private String GATEWAY_KEY_ID;

	@Override
	public String getIdentifier() { return GATEWAY_KEY_ID; }

	@Override
	public String getPrivateKey() { return GATEWAY_PRIVATE_KEY; }

	@Override
	public String getPublicKey() { return GATEWAY_PUBLIC_KEY; }
}
