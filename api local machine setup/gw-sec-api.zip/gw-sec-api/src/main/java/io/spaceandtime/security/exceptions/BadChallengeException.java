package io.spaceandtime.security.exceptions;

import io.spaceandtime.api.errors.CommonErrors;
import io.spaceandtime.api.errors.common.BadRequestException;

/**
 * Defines a 400 Bad Request exception due to a user challenge either already existing or not existing
 */
public class BadChallengeException extends BadRequestException {
	private static final String ALREADY_EXISTS = CommonErrors.RESOURCE_ALREADY_EXISTS;
	private static final String DOES_NOT_EXIST = CommonErrors.RESOURCE_DNE;
	private static final String TITLE_EXISTS = "Challenge already exists";
	private static final String TITLE_DNE = "Challenge does not exist";
	private static final String DETAILS_DNE = "Challenge with provided authCode does not exist";
	private static final String DETAILS_EXISTS = "Cannot generate a new auth code challenge when one already exists";

	public BadChallengeException(boolean exists) {
		super(getCode(exists), getTitle(exists), getDetails(exists));
	}

	private static String getCode(boolean exists) {
		return exists ? ALREADY_EXISTS : DOES_NOT_EXIST;
	}

	private static String getTitle(boolean exists) {
		return exists ? TITLE_EXISTS : TITLE_DNE;
	}

	private static String getDetails(boolean exists) {
		return exists ? DETAILS_EXISTS : DETAILS_DNE;
	}
}
