package io.spaceandtime.security.utils;

public class Encoder {
	public static class Base64 {
		private static final java.util.Base64.Encoder _encoder = java.util.Base64.getEncoder();
		private static final java.util.Base64.Decoder _decoder = java.util.Base64.getDecoder();
	
		public static byte[] toBytes(String str) {
			return _decoder.decode(str);
		}
		public static String toString(byte[] bytes) {
			return _encoder.encodeToString(bytes);
		}
	}

	public static final class Hex {
		public static final int HEX_RADIX = 16;
		private static final int BITS_PER_HEX = 4;
		private static final int BYTE_MASK = 0xF;
		
		public static byte[] toBytes(String str) {
			if (str.length() % 2 == 1) {
				throw new IllegalArgumentException("Hex string doesn't have an even number of characters");
			}
			byte[] bytes = new byte[str.length() / 2];
			for (int i = 0; i < str.length(); i += 2) {
				int upper = Character.digit(str.charAt(i), HEX_RADIX);
				int lower = Character.digit(str.charAt(i + 1), HEX_RADIX);
				if (upper == -1 || lower == -1) {
					throw new IllegalArgumentException("Hex string has an invalid character");
				}
				bytes[i / 2] = (byte)((upper << BITS_PER_HEX) + lower);
			}
			return bytes;
		}
		public static String toString(byte[] bytes) {
			StringBuffer sb = new StringBuffer();
			for (int i = 0; i < bytes.length; i++) {
				byte b = bytes[i];
				int upper = (b >> BITS_PER_HEX) & BYTE_MASK;
				int lower = b & BYTE_MASK;
				sb.append(Character.forDigit(upper, HEX_RADIX));
				sb.append(Character.forDigit(lower, HEX_RADIX));
			}
			return sb.toString();
		}
	}
}
