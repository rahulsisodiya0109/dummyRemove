package io.spaceandtime.security.services;

import io.spaceandtime.storage.user.*;

/**
 * Defines the contract for the signature validation service
 */
public interface ISignatureValidatorService {
	/**
	 * Validate an ED25519 signature
	 * @param message - the original message
	 * @param signature - the signature
	 * @param publicKey - the ED25519 public key
	 * @throws Exception if signature validation fails for any reason
	 */
	void validateEd25519Signature(String message, String signature, String publicKey) throws Exception;
	/**
	 * Validate the provided signature against the challenge and return the Auth Key used for signature validation
	 * @param challenge - the user challenge
	 * @param signature - the signature
	 * @param publicKey - the public key
	 * @param keyScheme - the public key scheme
	 * @param isNewKey - Defines whether or not this is a new key provided
	 * @return
	 * @throws Exception if signature validation fails for any reason
	 */
	AuthKey validateChallenge(UserChallenge challenge, String signature, String publicKey, String keyScheme, boolean isNewKey) throws Exception;
}
