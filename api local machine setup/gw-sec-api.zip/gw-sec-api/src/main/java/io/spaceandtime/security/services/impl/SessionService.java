package io.spaceandtime.security.services.impl;

import java.time.Instant;
import java.util.Arrays;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;
import org.springframework.util.StringUtils;

import io.spaceandtime.api.core.RandomGenerator;
import io.spaceandtime.api.errors.CommonErrors;
import io.spaceandtime.api.errors.common.NotFoundException;
import io.spaceandtime.api.jwt.JwtPayload;
import io.spaceandtime.security.config.EnvVars;
import io.spaceandtime.security.exceptions.*;
import io.spaceandtime.security.exceptions.RefreshForbiddenException.SessionErrorType;
import io.spaceandtime.security.models.SecurityApiContext;
import io.spaceandtime.security.services.*;
import io.spaceandtime.security.storage.IKeyDBProvider;
import io.spaceandtime.storage.user.*;
import io.spaceandtime.storage.subscription.*;

/**
 * Implements {@link ISessionService}
 */
@Component
public class SessionService implements ISessionService {
	private static final org.slf4j.Logger LOG = org.slf4j.LoggerFactory.getLogger(SessionService.class);

	@Value(EnvVars.Core.SESSION_EXPIRATION_MS)
	private Long SESSION_EXPIRATION_MS;

	@Autowired
	private IIdentifierBloomService _identifierBloom;
	@Autowired
	private IKeyDBProvider _keydbProvider;
	@Autowired
	private ISubscriptionInviteService _inviteService;
	@Autowired
	private ISubscriptionRoleService _roleService;

	@Override
	public JwtPayload refresh(SecurityApiContext ctxt) throws Exception {
		JwtPayload jwt = ctxt.getJwtPayload();
		String iterationId = jwt.getIterationId();
		String userId = jwt.getUserId();

		// Validate that the iteration of this token matches the user session iteration
		UserSession session;
		try {
			session = _keydbProvider.getUserSession(userId);
		} catch (Exception ex) {
			LOG.info("Unable to retrieve user session. Reason: " + ex.getMessage());
			session = null;
		}
		// Validate that the session has not expired
		if (session == null || session.getSessionExpires() == null || Instant.now().isAfter(session.getSessionExpires())) {
			throw new RefreshForbiddenException(SessionErrorType.SESSION_EXPIRED);
		}

		// Validate that the provided JWT and stored session have valid (i.e., non-null) values
		if (iterationId == null || session.getIterationId() == null || 
			jwt.getSessionId() == null || session.getSessionId() == null || !jwt.getSessionId().equals(session.getSessionId())) {
			throw new RefreshForbiddenException(SessionErrorType.SESSION_INVALID);
		}
		// Check iteration claim against session to detect refresh token hijacks
		if (!iterationId.equals(session.getIterationId())) {
			_identifierBloom.add(iterationId);
			_identifierBloom.add(session.getIterationId());
			_keydbProvider.deleteUserSession(userId);

			throw new RefreshForbiddenException(SessionErrorType.ITERATION_MISMATCH);
		}
		
		// Validate that the iteration of this token has not already been revoked
		if (_identifierBloom.exists(iterationId)) {
			throw new RefreshForbiddenException(SessionErrorType.ITERATION_REVOKED);
		}

		// If we get here - we have a valid scenario for session refresh
		String newIteration = RandomGenerator.newString();
		// Update the stored session state
		try {
			session.setIterationId(newIteration);
			_keydbProvider.updateUserSession(userId, session);
		} catch (Exception ex) {
			throw new FailedOperationException("Session refresh failed", "Unable to update session state");
		}

		// Update the payload iteration claim and build new tokens
		jwt.setIterationId(newIteration);
		return jwt;
	}

	@Override
	public void end(SecurityApiContext ctxt) {
		try {
			JwtPayload jwt = ctxt.getJwtPayload();
			_identifierBloom.add(jwt.getIterationId());
			_keydbProvider.deleteUserSession(jwt.getUserId());
		} catch (Exception ex) {
			LOG.warn("Failed to end session. Reason: " + ex.getMessage(), ex);
		}
	}

	@Override
	public JwtPayload create(UserChallenge challenge, AuthKey key) throws Exception {
		String userId = challenge.getUserId();
		User user;
		if (challenge.isRegistration()) {
			// For registration workflows, we also need to create a new user
			user = registerNewUser(userId, challenge.getJoinCode(), key);
			
		} else {
			// For existing user authentication, we need to determine subscription information
			try {
				user = _keydbProvider.getUser(userId);
			} catch (Exception ex) {
				LOG.warn("Failed to retrieve user during authentication workflow. Reason: " + ex.getMessage());
				throw new NotFoundException(CommonErrors.RESOURCE_DNE, "Invalid userId", "Failed to retrieve user information during authentication workflow");
			}
		}

		// Construct the new session and JWT payload
		String sessionId = RandomGenerator.newString();
		String iterationId = RandomGenerator.newString();
		JwtPayload jwt = new JwtPayload();
		configureJwtForSubscription(jwt, user.getSubscriptionId());
		jwt.setUserId(userId);
		jwt.setIterationId(iterationId);
		jwt.setSessionId(sessionId);

		// Delay setting session start/end until the absolute latest
		Instant sessionStart = Instant.now();
		Instant sessionEnd = sessionStart.plusMillis(SESSION_EXPIRATION_MS);
		jwt.setSessionExpiration(sessionEnd.toEpochMilli());
		UserSession newSession = new UserSession(userId, iterationId, sessionId, sessionStart, sessionEnd);

		try {
			_keydbProvider.createUserSession(userId, newSession, SESSION_EXPIRATION_MS);
		} catch (Exception ex) {
			throw new FailedOperationException("Create session failed", "Unable to create a new user session", ex);
		}
		return jwt;
	}

	/**
	 * Register a new user
	 * @param userId - the user identifier
	 * @param joinCode - the join code
	 * @param publicKey - the public key
	 * @param scheme - the key scheme
	 * @throws Exception if user registration fails
	 */
	private User registerNewUser(String userId, String joinCode, AuthKey key) throws Exception {
		User user = new User();
		user.setUserId(userId);
		user.setKeychain(Arrays.asList(key));

		if (StringUtils.hasLength(joinCode)) {
			// If a join code was provided, add the user to the subscription
			SubscriptionInvite invite = _inviteService.getAndDelete(joinCode);
			String subscriptionId = invite.getSubscriptionId();
			user.setSubscriptionId(subscriptionId);
			try {
				_roleService.setUserRole(subscriptionId, userId, invite.getRole());
			} catch (Exception ex) {
				throw new FailedOperationException("Registration failed", ex.getMessage());
			}
		}

		try {
			// Save the user
			_keydbProvider.setUser(userId, user);
		} catch (Exception ex) {
			throw new FailedOperationException("Registration failed", "Unable to register new user during authentication");
		}
		return user;
	}

	/**
	 * Configure the JWT payload for the given subscription
	 * @param jwt - the JWT payload
	 * @param subscriptionId - the subscription identifier
	 */
	private void configureJwtForSubscription(JwtPayload jwt, String subscriptionId) {
		if (subscriptionId == null) {
			// If the user doesn't have a subscription, set trial mode in their access token
			jwt.setTrial(true);
		} else {
			// Otherwise configure subscription id and additional subscription configuration
			jwt.setSubscriptionId(subscriptionId);
			try {
				Subscription subscription = _keydbProvider.getSubscription(subscriptionId);
				if (!subscription.getState().equals(SubscriptionState.ACTIVE)) {
					jwt.setRestricted(true);
				} else if (_keydbProvider.subscriptionBlockTimeExists(subscriptionId)) {
					jwt.setRateLimited(true);
				}
			} catch (Exception ex) {
				LOG.warn("Failed to retrieve subscription metadata for JWT configuration. Reason: " + ex.getMessage(), ex);
			}
		}
	}
}
