package io.spaceandtime.security.controllers;

import javax.servlet.http.HttpServletRequest;

import io.spaceandtime.api.core.BaseApiController;
import io.spaceandtime.api.errors.CommonErrors;
import io.spaceandtime.api.errors.common.UnauthorizedException;
import io.spaceandtime.security.models.SecurityApiContext;

public class BaseSecurityController extends BaseApiController {
	
	/**
	 * Get a valid authenticated API context
	 * @param httpRequest - the HTTP request object
	 * @return
	 * @throws Exception when the context cannot be loaded
	 */
	protected SecurityApiContext getAuthenticatedContext(HttpServletRequest httpRequest) throws Exception {
		SecurityApiContext ctxt = initContext(httpRequest, new SecurityApiContext());
		if (ctxt.getJwtPayload() == null) {
			throw new UnauthorizedException(CommonErrors.INVALID_JWT, "JWT not provided", "JWT was not found in request header");
		}
		return ctxt;
	}
}
