package io.spaceandtime.security.requests;

import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotNull;

import io.spaceandtime.security.models.InternalTokenType;

// Note: not documented as this is not a public API
public class InternalTokenRequest {
	
	@NotNull(message = "The token claim type must be provided")
	private InternalTokenType claimType;
	@NotBlank(message = "The token claim value must be provided")
	private String claimValue;

	public InternalTokenType getClaimType() { return claimType; }
	public String getClaimValue() { return claimValue; }

	public void setClaimType(InternalTokenType value) { claimType = value; }
	public void setClaimValue(String value) { claimValue = value; }
}
