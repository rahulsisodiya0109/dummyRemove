package io.spaceandtime.security.requests;

import java.math.BigDecimal;

import javax.validation.constraints.DecimalMin;
import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotNull;

import io.spaceandtime.api.annotations.*;
import io.spaceandtime.security.apis.ApiConstants.Params;

@ApiModels.Object(name = "SubscriptionRenewRequest")
public class SubscriptionRenewRequest extends SubscriptionReferenceRequest {
	
	@ApiModels.Property(
		name = Params.PAIDAMOUNT_NAME,
		description = Params.PAIDAMOUNT_DESC
	)
	@DecimalMin(value = "0.0", inclusive = false, message = Params.PAIDAMOUNT_VALID)
	private BigDecimal amount;

	@ApiModels.Property(
		name = Params.PAIDCURRENCY_NAME,
		description = Params.PAIDCURRENCY_DESC
	)
	@NotBlank(message = Params.PAIDCURRENCY_VALID)
	private String currency;

	@ApiModels.Property(
		name = Params.PAIDSTAMP_NAME,
		description = Params.PAIDSTAMP_DESC
	)
	@NotNull(message = Params.PAIDSTAMP_VALID)
	private Long timestamp;

	public BigDecimal getAmount() { return amount; }
	public String getCurrency() { return currency; }
	public Long getTimestamp() { return timestamp; }

	public String buildPayload() {
		return super.buildPayload() + SEP + amount + SEP + currency + SEP + timestamp;
	}
}
