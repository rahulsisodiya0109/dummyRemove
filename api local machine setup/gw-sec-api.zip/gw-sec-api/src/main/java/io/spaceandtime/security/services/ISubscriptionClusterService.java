package io.spaceandtime.security.services;

/**
 * Defines the contract for the subscription cluster assignment service
 */
public interface ISubscriptionClusterService {
	/**
	 * Configure the subscription's cluster assignment
	 * <p>
	 * NOTE: This service will swallow any encountered errors
	 * @param subscriptionId - the subscription identifier
	 */
	void configureClusterAssignment(String subscriptionId);
}
