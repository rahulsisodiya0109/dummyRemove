package io.spaceandtime.security.responses;

import java.util.Map;

import io.spaceandtime.api.annotations.*;
import io.spaceandtime.security.apis.ApiConstants.Params;
import io.spaceandtime.storage.management.SubscriptionMetadata;
import io.spaceandtime.storage.subscription.Subscription;
import io.spaceandtime.storage.subscription.SubscriptionState;

@ApiModels.Object(name = "SubscriptionProviderInfoResponse")
public class SubscriptionProviderInfoResponse extends SubscriptionBaseInfoResponse {

	@ApiModels.PropertyOptional(
		name = Params.METADATA_NAME,
		description = Params.METADATA_DESC
	)
	private Map<String, Object> metadata;

	public SubscriptionProviderInfoResponse() { super(); }
	public SubscriptionProviderInfoResponse(String subscriptionIdValue, SubscriptionState stateValue, String planNameValue, String lastPaymentValue, Map<String, Object> metadataValue) {
		super(subscriptionIdValue, stateValue, planNameValue, lastPaymentValue);
		metadata = metadataValue;
	}
	public SubscriptionProviderInfoResponse(Subscription subscription, SubscriptionMetadata subscriptionMetadata) {
		super(subscription);
		if (subscriptionMetadata != null) {
			metadata = subscriptionMetadata.getMetadata();
		}
	}

	public Map<String, Object> getMetadata() { return metadata; }
	public void setMetadata(Map<String, Object> value) { metadata = value; }
}
