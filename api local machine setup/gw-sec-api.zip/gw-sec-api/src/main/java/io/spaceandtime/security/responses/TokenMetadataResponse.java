package io.spaceandtime.security.responses;

import io.spaceandtime.api.annotations.*;
import io.spaceandtime.api.jwt.JwtPayload;
import io.spaceandtime.security.apis.ApiConstants.*;

@ApiModels.Object(name = "TokenMetadataResponse")
public class TokenMetadataResponse {

	@ApiModels.Property(
		name = Params.USERID_NAME,
		description = Params.USERID_DESC
	)
	private String userId;

	@ApiModels.PropertyOptional(
		name = Params.SUBSCRIPTIONID_NAME,
		description = Params.SUBSCRIPTIONID_DESC
	)
	private String subscriptionId;

	@ApiModels.PropertyOptional(
		name = Params.RESTRICTED_NAME,
		description = Params.RESTRICTED_DESC
	)
	private boolean restricted;

	@ApiModels.PropertyOptional(
		name = Params.TRIAL_NAME,
		description = Params.TRIAL_DESC
	)
	private boolean trial;

	public TokenMetadataResponse(){}
	public TokenMetadataResponse(String userIdValue, String subscriptionValue, boolean restrictedValue, boolean trialValue) {
		userId = userIdValue;
		subscriptionId = subscriptionValue;
		restricted = restrictedValue;
		trial = trialValue;
	}
	public TokenMetadataResponse(JwtPayload jwt) {
		userId = jwt.getUserId();
		subscriptionId = jwt.getSubscriptionId();
		Boolean restrictedValue = jwt.getRestricted();
		restricted = restrictedValue != null && restrictedValue == true;
		Boolean trialValue = jwt.getTrial();
		trial = trialValue != null && trialValue == true;
		if (trial) {
			subscriptionId = "";
		}
	}

	public String getUserId() { return userId; }
	public String getSubscriptionId() { return subscriptionId; }
	public boolean getRestricted() { return restricted; }
	public boolean getTrial() { return trial; }

	public void setUserId(String value) { userId = value; }
	public void setSubscriptionId(String value) { subscriptionId = value; }
	public void setRestricted(boolean value) { restricted = value; }
	public void setTrial(boolean value) { trial = value; }
}
