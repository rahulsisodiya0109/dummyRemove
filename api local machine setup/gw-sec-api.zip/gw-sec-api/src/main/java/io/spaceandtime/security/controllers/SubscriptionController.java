package io.spaceandtime.security.controllers;

import java.util.Map;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.util.StringUtils;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import io.spaceandtime.api.core.RandomGenerator;
import io.spaceandtime.api.errors.CommonErrors;
import io.spaceandtime.api.errors.common.*;
import io.spaceandtime.api.jwt.JwtPayload;
import io.spaceandtime.security.apis.SubscriptionApi;
import io.spaceandtime.security.apis.ApiConstants.Params;
import io.spaceandtime.security.exceptions.FailedOperationException;
import io.spaceandtime.security.models.*;
import io.spaceandtime.security.responses.*;
import io.spaceandtime.security.services.*;
import io.spaceandtime.security.storage.IKeyDBProvider;
import io.spaceandtime.storage.management.SubscriptionProvider;
import io.spaceandtime.storage.subscription.*;
import io.spaceandtime.storage.user.User;

@Validated
@RestController
public class SubscriptionController extends BaseSecurityController implements SubscriptionApi {

	@Autowired
	private IKeyDBProvider _keydbProvider;
	@Autowired
	private ISubscriptionInviteService _inviteService;
	@Autowired
	private ISubscriptionRoleService _roleService;
	@Autowired
	private ITokenBuilderService _tokenBuilder;

	@Override
	public ResponseEntity<Void> setName(
		@RequestParam(name = Params.SUBSCRIPTIONNAME_NAME, required = true) String subscriptionName,
		HttpServletRequest httpRequest
	) throws Exception {
		final String ERROR_TITLE = "Set subscription name failed";

		// Load the request context
		SecurityApiContext ctxt = getAuthenticatedContext(httpRequest);
		Subscription subscription = getSubscriptionForContext(ctxt, ERROR_TITLE);
		SubscriptionUserRoles userRoles = getSubscriptionUserRoles(subscription.getSubscriptionId(), ERROR_TITLE);
		SubscriptionRole requestingUserRole = (userRoles != null && !userRoles.isEmpty())
			? userRoles.getMap().get(ctxt.getJwtPayload().getUserId()) : null;
		
		// Authorize the request
		// Do not permit subscription members from creating invites
		if (requestingUserRole == null || !requestingUserRole.equals(SubscriptionRole.OWNER)) {
			throw new ForbiddenException(CommonErrors.INSUFFICIENT_PRIVILEGES, "Set subscription name", "You do not have privileges to set the subscription name");
		}

		try {
			subscription.setName(subscriptionName);
			_keydbProvider.setSubscription(subscription.getSubscriptionId(), subscription);
		} catch (Exception ex) {
			throw new FailedOperationException(ERROR_TITLE, "Unable to save subscription name", ex);
		}
		return NoContent();
	}

	@Override
	public ResponseEntity<String> createInvite(
		@RequestParam(name = Params.ROLE_NAME, required = true) SubscriptionRole role,
		HttpServletRequest httpRequest
	) throws Exception {
		final String ERROR_TITLE = "Create subscription invite failed";
		
		// Load the request context
		SecurityApiContext ctxt = getAuthenticatedContext(httpRequest);
		Subscription subscription = getSubscriptionForContext(ctxt, ERROR_TITLE);
		SubscriptionUserRoles userRoles = getSubscriptionUserRoles(subscription.getSubscriptionId(), ERROR_TITLE);
		SubscriptionRole requestingUserRole = (userRoles != null && !userRoles.isEmpty())
			? userRoles.getMap().get(ctxt.getJwtPayload().getUserId()) : null;
		
		// Authorize the request
		// Do not permit subscription members from creating invites
		if (requestingUserRole == null || requestingUserRole.equals(SubscriptionRole.MEMBER)) {
			throw new ForbiddenException(CommonErrors.INSUFFICIENT_PRIVILEGES, "Create invite forbidden", "You do not have privileges to create subscription invites");
		}
		// Do not permit admins from creating invites with owner role
		if (requestingUserRole.equals(SubscriptionRole.ADMIN) && role.equals(SubscriptionRole.OWNER)) {
			throw new ForbiddenException(CommonErrors.INSUFFICIENT_PRIVILEGES, "Create invite forbidden", "Admins cannot create invites with owner role");
		}

		// Create and save the new invite
		String joinCode = RandomGenerator.newString();
		try {
			SubscriptionInvite invite = new SubscriptionInvite(subscription.getSubscriptionId(), joinCode, role);
			_inviteService.save(invite);
		} catch (Exception ex) {
			throw new FailedOperationException(ERROR_TITLE, "Unable to create subscription", ex);
		}
		return Created(joinCode);
	}

	@Override
	public ResponseEntity<TokenResponse> joinInvite(
		@PathVariable(name = Params.JOIN_CODE_NAME, required = true) String joinCode,
		HttpServletRequest httpRequest
	) throws Exception {
		final String ERROR_TITLE = "Join subscription invite failed";
		
		// Load the request context
		SecurityApiContext ctxt = getAuthenticatedContext(httpRequest);
		JwtPayload jwt = ctxt.getJwtPayload();

		// Authorize the request
		if (StringUtils.hasLength(jwt.getSubscriptionId())) {
			throw new ForbiddenException("Not allowed", "Join invite forbidden", "You cannot join a subscription when you already have one");
		}
		
		// Retrieve the invite and join the subscription
		SubscriptionInvite invite = _inviteService.getAndDelete(joinCode);
		String subscriptionId = invite.getSubscriptionId();
		// Update the user's subscription reference
		User user;
		try {
			user = _keydbProvider.getUser(jwt.getUserId());
		} catch (Exception ex) {
			throw new FailedOperationException(ERROR_TITLE, "Unable to retrieve user details", ex);
		}
		user.setSubscriptionId(subscriptionId);
		try {
			_keydbProvider.setUser(user.getUserId(), user);
		} catch (Exception ex) {
			throw new FailedOperationException(ERROR_TITLE, "Unable to set user subscription", ex);
		}
		// Set the user role in the subscription
		try {
			_roleService.setUserRole(subscriptionId, user.getUserId(), invite.getRole());
		} catch (Exception ex) {
			throw new FailedOperationException(ERROR_TITLE, "Unable to set user role in subscription", ex);
		}

		// Update user tokens with new subscription details
		jwt.setSubscriptionId(subscriptionId);
		jwt.setTrial(false);
		TokenResponse tokens = _tokenBuilder.buildTokens(jwt);
		return OK(tokens);
	}

	@Override
	public ResponseEntity<Void> removeUser(
		@PathVariable(name = Params.USERID_NAME, required = true) String userId,
		HttpServletRequest httpRequest
	) throws Exception {
		final String ERROR_TITLE = "Remove user role failed";
		final String FORBIDDEN_TITLE = "Remove user role forbidden";

		// Load the request context
		SecurityApiContext ctxt = getAuthenticatedContext(httpRequest);
		Subscription subscription = getSubscriptionForContext(ctxt, ERROR_TITLE);
		SubscriptionUserRoles userRoles = getSubscriptionUserRoles(subscription.getSubscriptionId(), ERROR_TITLE);

		// Authorize the request
		authorizeRoleAlterRequest(ctxt.getJwtPayload().getUserId(), userId, userRoles.getMap(), null, FORBIDDEN_TITLE);
		
		// Remove the user role
		try {
			_roleService.removeUserRole(userRoles, userId);
		} catch (Exception ex) {
			throw new FailedOperationException(ERROR_TITLE, "Unable to remove user role", ex);
		}
		return NoContent();
	}

	@Override
	public ResponseEntity<Void> setUserRole(
		@PathVariable(name = Params.USERID_NAME, required = true) String userId,
		@RequestParam(name = Params.ROLE_NAME, required = true) SubscriptionRole newRole,
		HttpServletRequest httpRequest
	) throws Exception {
		final String ERROR_TITLE = "Set user role failed";
		final String FORBIDDEN_TITLE = "Set user role forbidden";
		
		// Load the request context
		SecurityApiContext ctxt = getAuthenticatedContext(httpRequest);
		Subscription subscription = getSubscriptionForContext(ctxt, ERROR_TITLE);
		SubscriptionUserRoles userRoles = getSubscriptionUserRoles(subscription.getSubscriptionId(), ERROR_TITLE);
		
		// Authorize the request
		authorizeRoleAlterRequest(ctxt.getJwtPayload().getUserId(), userId, userRoles.getMap(), newRole, FORBIDDEN_TITLE);

		// Update the user role
		try {
			_roleService.setUserRole(userRoles, userId, newRole);
		} catch (Exception ex) {
			throw new FailedOperationException(ERROR_TITLE, "Unable to update user role", ex);
		}
		return NoContent();
	}

	@Override
	public ResponseEntity<SubscriptionUserInfoResponse> getSubscriptionInfo(
		HttpServletRequest httpRequest
	) throws Exception {
		final String ERROR_TITLE = "Get subscription info failed";
		SecurityApiContext ctxt = getAuthenticatedContext(httpRequest);
		Subscription subscription = getSubscriptionForContext(ctxt, ERROR_TITLE);
		SubscriptionProvider provider;
		try {
			provider = _keydbProvider.getSubscriptionProvider(subscription.getProviderId());
		} catch (Exception ex) {
			throw new FailedOperationException(ERROR_TITLE, "Unable to retrieve subscription provider details", ex);
		}
		SubscriptionUserInfoResponse response = new SubscriptionUserInfoResponse(subscription, provider);
		return OK(response);
	}

	@Override
	public ResponseEntity<SubscriptionUsersResponse> getSubscriptionUsers(
		HttpServletRequest httpRequest
	) throws Exception {
		final String ERROR_TITLE = "Get subscription users failed";
		SecurityApiContext ctxt = getAuthenticatedContext(httpRequest);
		Subscription subscription = getSubscriptionForContext(ctxt, ERROR_TITLE);
		SubscriptionUserRoles userRoles = getSubscriptionUserRoles(subscription.getSubscriptionId(), ERROR_TITLE);
		SubscriptionUsersResponse response = new SubscriptionUsersResponse(userRoles);
		return OK(response);
	}

	/**
	 * Authorize a request to alter a user role
	 * @param requestingUserId - the requesting user identifier
	 * @param targetUserId - the target user identifier (i.e., whose role is being altered)
	 * @param roleMap - the user role map
	 * @param newRole - the desired new role
	 * @param forbiddenTitle - the title of the forbidden error message
	 * @throws ForbiddenException if the request is not authorized
	 */
	private void authorizeRoleAlterRequest(String requestingUserId, String targetUserId, Map<String, SubscriptionRole> roleMap, SubscriptionRole newRole, String forbiddenTitle) throws ForbiddenException {
		SubscriptionRole requestingUserRole = roleMap.containsKey(requestingUserId) ? roleMap.get(requestingUserId) : null;
		SubscriptionRole currentUserRole = roleMap.containsKey(targetUserId) ? roleMap.get(targetUserId) : null;
		// Do not permit subscription member alteration of roles
		if (requestingUserRole == null || requestingUserRole.equals(SubscriptionRole.MEMBER)) {
			throw new ForbiddenException(CommonErrors.INSUFFICIENT_PRIVILEGES, forbiddenTitle, "You do not have privileges to change user roles");
		}
		// Do not permit setting role for user who doesn't already have a role (invite required)
		if (currentUserRole == null) {
			String errorDetails = newRole != null ? "Send them an invite to configure their role" : "Cannot remove a non-existant role";
			throw new ForbiddenException(CommonErrors.INSUFFICIENT_PRIVILEGES, forbiddenTitle, "Provided user (" + targetUserId + ") is not part of the subscription. " + errorDetails);
		}
		// Do not permit admin granting owner role for someone else or altering the role of an owner
		if (requestingUserRole.equals(SubscriptionRole.ADMIN)) {
			if (newRole != null && newRole.equals(SubscriptionRole.OWNER)) {
				throw new ForbiddenException(CommonErrors.INSUFFICIENT_PRIVILEGES, forbiddenTitle, "Admins cannot grant the owner role");
			}
			if (currentUserRole.equals(SubscriptionRole.OWNER)) {
				throw new ForbiddenException(CommonErrors.INSUFFICIENT_PRIVILEGES, forbiddenTitle, "Admins cannot alter an owner's role");
			}
		}
		// Do not permit users from altering their own role
		if (requestingUserId.equals(targetUserId)) {
			throw new ForbiddenException(CommonErrors.INSUFFICIENT_PRIVILEGES, forbiddenTitle, "You cannot alter your own role");
		}
	}

	/**
	 * Retrieve the subscription user roles
	 * @param subscriptionId
	 * @param failTitle
	 * @return
	 * @throws FailedOperationException
	 */
	private SubscriptionUserRoles getSubscriptionUserRoles(String subscriptionId, String failTitle) throws FailedOperationException {
		SubscriptionUserRoles userRoles = _roleService.getAllRoles(subscriptionId);
		if (userRoles == null) {
			throw new FailedOperationException(failTitle, "Unable to retrieve subscription user roles");
		}
		return userRoles;
	}

	/**
	 * Retrieve the subscription for the current request context
	 * @param ctxt - the request context
	 * @param failTitle = The error title in case of failure
	 * @return
	 * @throws NotFoundException if the referenced subscription doesn't exist
	 * @throws FailedOperationException if the referenced subscription exists but cannot be retrieved
	 */
	private Subscription getSubscriptionForContext(SecurityApiContext ctxt, String failTitle) throws NotFoundException, FailedOperationException {
		Subscription subscription = null;
		String subscriptionId = ctxt.getJwtPayload().getSubscriptionId();
		if (StringUtils.hasLength(subscriptionId)) {
			try {
				subscription = _keydbProvider.getSubscription(subscriptionId);
			} catch (Exception ex) {
				throw new FailedOperationException(failTitle, "Unable to retrieve subscription for user", ex);
			}
		}
		if (subscription == null) {
			throw new NotFoundException(CommonErrors.RESOURCE_DNE, "Invalid subscriptionId", "No subscription exists with the provided identifier");
		}
		return subscription;
	}
}
