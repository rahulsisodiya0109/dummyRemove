package io.spaceandtime.security.exceptions;

import io.spaceandtime.api.errors.CommonErrors;
import io.spaceandtime.api.errors.common.ServerErrorException;

/**
 * Defines a 500 Internal Server Error exception due to an operation failing for
 * some reason
 */
public class FailedOperationException extends ServerErrorException {

	public FailedOperationException(String title, String details) {
		this(title, details, null);
	}

	public FailedOperationException(String title, String details, Exception baseException) {
		super(CommonErrors.FAILED_OPERATION, title, details, baseException);
	}
}
