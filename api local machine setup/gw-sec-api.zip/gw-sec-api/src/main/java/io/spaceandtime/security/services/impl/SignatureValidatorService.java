package io.spaceandtime.security.services.impl;

import java.math.BigInteger;
import java.nio.charset.StandardCharsets;

import org.apache.commons.lang.NotImplementedException;
import org.bouncycastle.crypto.Signer;
import org.bouncycastle.crypto.params.Ed25519PublicKeyParameters;
import org.bouncycastle.crypto.signers.Ed25519Signer;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.util.StringUtils;
import org.web3j.crypto.Keys;
import org.web3j.crypto.Sign;
import org.web3j.utils.Numeric;

import io.spaceandtime.api.errors.CommonErrors;
import io.spaceandtime.api.errors.common.BadRequestException;
import io.spaceandtime.api.errors.common.NotFoundException;
import io.spaceandtime.security.services.ISignatureValidatorService;
import io.spaceandtime.security.storage.IKeyDBProvider;
import io.spaceandtime.security.utils.Encoder;
import io.spaceandtime.storage.user.AuthKey;
import io.spaceandtime.storage.user.User;
import io.spaceandtime.storage.user.UserChallenge;
import io.spaceandtime.storage.user.AuthKey.KeyAlgorithm;

/**
 * Implements {@link ISignatureValidatorService}
 */
@Component
public class SignatureValidatorService implements ISignatureValidatorService {
	private static final org.slf4j.Logger LOG = org.slf4j.LoggerFactory.getLogger(SignatureValidatorService.class);
	
	@Autowired
	private IKeyDBProvider _keydbProvider;

	@Override
	public void validateEd25519Signature(String message, String signature, String publicKey) throws Exception {
		validateEd25519Signature(toBytes(message), signature, publicKey);
	}

	@Override
	public AuthKey validateChallenge(UserChallenge challenge, String signature, String publicKey, String keyScheme, boolean isNewKey) throws Exception {
		AuthKey key = new AuthKey();
		key.setPublicKey(publicKey);
		// Build the full message to validate
		String message = challenge.getAuthCode();
		if (StringUtils.hasLength(challenge.getPrefix())) {
			message = challenge.getPrefix() + challenge.getAuthCode();
		}
		byte[] messageBytes = toBytes(message);

		// Determine the appropriate signature validation algorithm
		KeyAlgorithm algorithm = getAlgorithm(isNewKey, challenge.getUserId(), publicKey, keyScheme);
		key.setAlgorithm(algorithm);
		if (algorithm == KeyAlgorithm.ETHEREUM) {
			key.setChainId(keyScheme);
		}

		// Validate the signature
		switch (algorithm) {
			case ED25519:
				validateEd25519Signature(messageBytes, signature, publicKey);
				break;
			case ETHEREUM:
				validateEthereumSignature(messageBytes, signature, publicKey);
				break;
			default:
				throw new NotImplementedException("Key algorithm (" + algorithm + ") does not have a validation implementation");
		}
		return key;
	}

	/**
	 * Validate an ED25519 signature against the provided public key
	 * @param message - the message bytes
	 * @param signature - the signature
	 * @param publicKey - the ED25519 public key
	 * @throws Exception if signature validation fails
	 */
	private void validateEd25519Signature(byte[] message, String signature, String publicKey) throws Exception {
		Ed25519PublicKeyParameters ed25519PublicKey;
		try {
			ed25519PublicKey = new Ed25519PublicKeyParameters(Encoder.Base64.toBytes(publicKey));
		} catch (Exception ex) {
			throw new BadRequestException(CommonErrors.BAD_INPUT, "Invalid public key", "Provided public key (" + publicKey + ") is not a base64 encoded ED25519 public key");
		}

		byte[] hexSignature;
		try {
			hexSignature = Encoder.Hex.toBytes(signature);
		} catch (Exception ex) {
			throw new BadRequestException(CommonErrors.BAD_INPUT, "Invalid signature", "Provided ED25519 signature (" + signature + ") is not a valid hex string");
		}

		boolean verified;
		try {
			Signer ed25519Signer = new Ed25519Signer();
			ed25519Signer.init(false, ed25519PublicKey);
			ed25519Signer.update(message, 0, message.length);
			verified = ed25519Signer.verifySignature(hexSignature);
		} catch (Exception ex) {
			verified = false;
		}

		if (!verified) {
			throw new BadRequestException(CommonErrors.BAD_INPUT, "Invalid signature", "Provided ED25519 signature was not validated against the public key");
		}
	}

	/**
	 * Validate an ethereum signature against the provided public key
	 * <p>
	 * NOTE: Ethereum signature validation is executed by attempting to recover a public key
	 * that signed the message, then checking if that public key matches the expected
	 * @param message - the message bytes
	 * @param signature - the signature
	 * @param publicKey - the Ethereum public key (i.e., wallet address)
	 * @throws Exception if signature validation fails
	 */
	private void validateEthereumSignature(byte[] message, String signature, String publicKey) throws Exception {
		// REFERENCE: https://gist.github.com/megamattron/94c05789e5ff410296e74dad3b528613
		final String HEX_PREFIX = "0x";

		byte[] r;
		byte[] s;
		byte[] v;
		try {
			String rStr = signature.substring(0, 66);
			r = Numeric.hexStringToByteArray(rStr);

			String sStr = HEX_PREFIX + signature.substring(66, 130);
			s = Numeric.hexStringToByteArray(sStr);

			String vStr = HEX_PREFIX + signature.substring(130, 132);
			v = Numeric.hexStringToByteArray(vStr);
		} catch (Exception ex) {
			throw new BadRequestException(CommonErrors.BAD_INPUT, "Invalid signature", "Provided Ethereum signature (" + signature + ") is not a valid hex string");
		}

		String decodedPublicKey;
		try {
			BigInteger pkNumeric = Sign.signedPrefixedMessageToKey(message, new Sign.SignatureData(v[0], r, s));
			decodedPublicKey = HEX_PREFIX + Keys.getAddress(pkNumeric.toString(Encoder.Hex.HEX_RADIX));
		} catch (Exception ex) {
			throw new BadRequestException(CommonErrors.BAD_INPUT, "Invalid signature", "Ethereum public key could not be recovered from signature");
		}

		if (!publicKey.equalsIgnoreCase(decodedPublicKey)) {
			throw new BadRequestException(CommonErrors.BAD_INPUT, "Invalid signature", "Provided Ethereum signature was not validated against the public key");
		}
	}

	/**
	 * Get the appropriate key algorithm for signature validation
	 * @param isNewKey - determines whether or not this is a new key being added
	 * @param userId - the user identifier
	 * @param publicKey - the provided public key
	 * @param keyScheme - the provided key scheme
	 * @return
	 * @throws Exception if the algorithm cannot be determined due to invalid input
	 */
	private KeyAlgorithm getAlgorithm(boolean isNewKey, String userId, String publicKey, String keyScheme) throws Exception {
		if (isNewKey) {
			// For registration, validate the provided scheme
			if (!StringUtils.hasLength(keyScheme)) {
				throw new BadRequestException(CommonErrors.BAD_INPUT, "Invalid scheme", "The scheme property is required for registration");
			}
			try {
				return KeyAlgorithm.tryConvert(keyScheme);
			} catch (Exception ex) {
				throw new BadRequestException(CommonErrors.BAD_INPUT, "Invalid scheme", "The provided scheme (" + keyScheme + ") is invalid");
			}
		} else {
			// For authentication, validate the the public key is part of the keychain
			AuthKey authKey = null;
			try {
				User user = _keydbProvider.getUser(userId);
				if (user != null && user.hasKeychain()) {
					for (AuthKey key : user.getKeychain()) {
						if (key.getPublicKey().equals(publicKey)) {
							authKey = key;
							break;
						}
					}
				}
			} catch (Exception ex) {
				LOG.warn("Unable to retrieve key from user's keychain. Reason: " + ex.getMessage());
				authKey = null;
			}
			if (authKey == null) {
				throw new NotFoundException(CommonErrors.RESOURCE_DNE, "Invalid public key", "Provided public key (" + publicKey + ") is not part of your keychain");
			}
			return authKey.getAlgorithm();
		}
	}

	/**
	 * Convert a UTF8 string into it's underlying byte array
	 * @param string - the string
	 * @return
	 */
	private static byte[] toBytes(String string) {
		return string.getBytes(StandardCharsets.UTF_8);
	}
}
