package io.spaceandtime.security.requests;

import javax.validation.constraints.NotBlank;

import io.spaceandtime.api.annotations.*;
import io.spaceandtime.security.apis.ApiConstants.*;

@ApiModels.Object(name = "AddKeyRequest")
public class AddKeyRequest {

	@ApiModels.Property(
		name = Params.AUTH_CODE_NAME,
		description = Params.AUTH_CODE_DESC_REQ
	)
	@NotBlank(message = Params.AUTH_CODE_VALID)
	private String authCode;

	@ApiModels.Property(
		name = Params.SIGNATURE_AUTH_NAME,
		description = Params.SIGNATURE_AUTH_DESC
	)
	@NotBlank(message = Params.SIGNATURE_VALID)
	private String signature;

	@ApiModels.Property(
		name = Params.KEY_NAME,
		description = Params.KEY_DESC
	)
	@NotBlank(message = Params.KEY_VALID)
	private String key;

	@ApiModels.Property(
		name = Params.SCHEME_NAME,
		description = Params.SCHEME_DESC_REQ
	)
	private String scheme;

	public String getAuthCode() { return authCode; }
	public String getSignature() { return signature; }
	public String getKey() { return key; }
	public String getScheme() { return scheme; }

	public void setAuthCode(String value) { authCode = value; }
	public void setSignature(String value) { signature = value; }
	public void setKey(String value) { key = value; }
	public void setScheme(String value) { scheme = value; }

	@Override
	public String toString() {
		return "AddKeyRequest [authCode=" + authCode + ",signature=" + signature + ",key=" + key
			+ ",scheme=" + scheme + "]";
	}
}
