package io.spaceandtime.security.responses;

import io.spaceandtime.api.annotations.*;
import io.spaceandtime.security.apis.ApiConstants.*;

@ApiModels.Object(name = "AuthCodeResponse")
public class AuthCodeResponse {
	
	@ApiModels.Property(
		name = Params.AUTH_CODE_NAME,
		description = Params.AUTH_CODE_DESC_RESP
	)
	private String authCode;

	public AuthCodeResponse(){}
	public AuthCodeResponse(String authCodeValue) {
		authCode = authCodeValue;
	}

	public String getAuthCode() { return authCode; }
	public void setAuthCode(String value) { authCode = value; }
}
