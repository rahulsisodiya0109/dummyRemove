package io.spaceandtime.security.config;

/**
 * Provides application environment variable constants
 */
public class EnvVars {
	
	/** Defines core environment variable */
	public static final class Core {
		/** Defines the challenge expiration time in ms */
		public static final String CHALLENGE_EXPIRATION_MS = "${common.expiration-ms.challenge}";
		/** Defines the session expiration time in ms */
		public static final String SESSION_EXPIRATION_MS = "${common.expiration-ms.session}";
		/** Defines the access token expiration time in ms */
		public static final String ACCESS_TOKEN_EXPIRATION_MS = "${common.expiration-ms.access}";
		/** Defines the refresh token expiration time in ms */
		public static final String REFESH_TOKEN_EXPIRATION_MS = "${common.expiration-ms.refresh}";
		/** Defines the internal token expiration time in ms */
		public static final String INTERNAL_TOKEN_EXPIRATION_MS = "${common.expiration-ms.internal}";
		/** Defines the subscription invite expiration time in ms */
		public static final String SUBSCRIPTION_INVITE_EXPIRATION_MS = "${common.expiration-ms.invite}";
	}

	/** Defines KeyDB environment variables */
	public static final class KeyDB {
		public static final String HOST = "${keydb.host}";
		public static final String PORT = "${keydb.port}";
		public static final String PASSWORD = "${keydb.password}";
	}

	/** Defines security environment variables */
	public static final class Security {
		/** Defines the gateway public key */
		public static final String GATEWAY_PUBLIC_KEY = "${security.keys.gateway-public}";
		/** Defines the gateway private key */
		public static final String GATEWAY_PRIVATE_KEY = "${security.keys.gateway-private}";
		/** Defines the gateway key identifier */
		public static final String GATEWAY_KEY_ID = "${security.keys.gateway-kid}";
	}

	/** Defines identifier bloom filter environment variables */
	public static final class IdentifierBloom {
		/** Defines the underlying identifier bloom filter implementation */
		// NOTE: the Spring "${}" notation has been removed as this is used
		// for the @ConditionalOnProperty and won't work if it's set
		public static final String IMPLEMENTATION = "idbloom.implementation";
		/** Defines the URL for the krakend bloom filter endpoint */
		public static final String KRAKEND_URL = "${idbloom.krakend-url}";
	}
}
