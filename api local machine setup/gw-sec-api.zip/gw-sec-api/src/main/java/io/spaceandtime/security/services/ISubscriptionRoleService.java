package io.spaceandtime.security.services;

import io.spaceandtime.storage.subscription.SubscriptionRole;
import io.spaceandtime.storage.subscription.SubscriptionUserRoles;

/**
 * Defines the contract for the subscription role management service
 */
public interface ISubscriptionRoleService {
	/**
	 * Set a user role in a subscription
	 * @param subscriptionId - the subscription identifier
	 * @param userId - the user identifier
	 * @param role - the user role in the subscription
	 * @throws Exception if the operation fails
	 */
	void setUserRole(String subscriptionId, String userId, SubscriptionRole role) throws Exception;
	/**
	 * Set a user role in the role map
	 * @param userRoles - the user role map
	 * @param userId - the user identifier
	 * @param role - the role in the subscription
	 * @throws Exception if the operation fails
	 */
	void setUserRole(SubscriptionUserRoles userRoles, String userId, SubscriptionRole role) throws Exception;
	/**
	 * Remove a user role from the role map
	 * @param userRoles - the user role map
	 * @param userId - the user identifier
	 * @throws Exception if the operation failse
	 */
	void removeUserRole(SubscriptionUserRoles userRoles, String userId) throws Exception;
	/**
	 * Retrieve all user roles for a given subscription
	 * <p>
	 * NOTE: does not throw an exception, will swallow and return null
	 * @param subscriptionId - the subscription identifier
	 * @return
	 */
	SubscriptionUserRoles getAllRoles(String subscriptionId);
}
