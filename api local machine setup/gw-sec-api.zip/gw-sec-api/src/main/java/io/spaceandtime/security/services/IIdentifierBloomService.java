package io.spaceandtime.security.services;

/**
 * Defines the contract for the session iteration bloom filter service
 */
public interface IIdentifierBloomService {
	/**
	 * Add the iteration identifier to the bloom filter
	 * @param iterationId - the iteration identifier
	 */
	void add(String iterationId);
	/**
	 * Check to see if the iteration identifier is in the bloom filter
	 * @param iterationId
	 * @return
	 */
	boolean exists(String iterationId);
}
