package io.spaceandtime.security.requests;

import java.util.Map;
import java.util.TreeMap;

import org.springframework.lang.Nullable;

import io.spaceandtime.api.annotations.*;
import io.spaceandtime.security.apis.ApiConstants.Params;

@ApiModels.Object(name = "SubscriptionAlterRequest")
public class SubscriptionAlterRequest extends SubscriptionReferenceRequest {
	
	@ApiModels.PropertyOptional(
		name = Params.PLANNAME_NAME,
		description = Params.PLANNAME_DESC
	)
	private String planName;

	@ApiModels.PropertyOptional(
		name = Params.METADATA_NAME,
		description = Params.METADATA_DESC
	)
	private Map<String, Object> metadata;

	@Nullable public String getPlanName() { return planName; }
	@Nullable public Map<String, Object> getMetadata() { return metadata; }

	public String buildPayload() {
		String payload = super.buildPayload() + SEP + planName + SEP;
		TreeMap<String, Object> sortedMetadata = new TreeMap<>(metadata);
		int i = 0;
		int capacity = sortedMetadata.size();
		for (Map.Entry<String, Object> entry : sortedMetadata.entrySet()) {
			payload += entry.getKey() + ":" + entry.getValue();
			if (i++ != capacity - 1) {
				payload += ",";
			}
		}
		return payload;
	}
}
