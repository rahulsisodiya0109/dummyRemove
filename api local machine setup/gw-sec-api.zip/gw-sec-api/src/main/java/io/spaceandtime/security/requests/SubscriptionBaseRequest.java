package io.spaceandtime.security.requests;

import javax.validation.constraints.NotBlank;

import io.spaceandtime.api.annotations.*;
import io.spaceandtime.security.apis.ApiConstants.Params;

/**
 * Defines the base class for a subscription request
 */
public abstract class SubscriptionBaseRequest {
	protected static final String SEP = "|";
	
	@ApiModels.Property(
		name = Params.PROVIDERID_NAME,
		description = Params.PROVIDERID_DESC
	)
	@NotBlank(message = Params.PROVIDERID_VALID)
	private String providerId;

	@ApiModels.Property(
		name = Params.SIGNATURE_SBSC_NAME,
		description = Params.SIGNATURE_SBSC_DESC
	)
	@NotBlank(message = Params.SIGNATURE_VALID)
	private String signature;

	public SubscriptionBaseRequest(){}
	public SubscriptionBaseRequest(String providerIdValue, String signatureValue) {
		providerId = providerIdValue;
		signature = signatureValue;
	}

	public String getProviderId() { return providerId; }
	public String getSignature() { return signature; }

	public void setProviderId(String value) { providerId = value; }
	public void setSignature(String value) { signature = value; }

	public String buildPayload() {
		return providerId;
	}
}
