package io.spaceandtime.security.exceptions;

import io.spaceandtime.api.errors.CommonErrors;
import io.spaceandtime.api.errors.common.BadRequestException;

/**
 * Defines a 400 Bad Request exception due to invalid join code provided
 */
public class BadJoinCodeException extends BadRequestException {

	public BadJoinCodeException(String joinCode) {
		super(CommonErrors.BAD_INPUT, "Invalid joinCode", getDetails(joinCode));
	}
	
	private static String getDetails(String joinCode) {
		return "The provided joinCode (" + joinCode + ") does not exist";
	}
}
