package io.spaceandtime.security.controllers;

import java.util.Objects;
import java.util.UUID;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.util.StringUtils;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import io.spaceandtime.api.core.RandomGenerator;
import io.spaceandtime.api.errors.CommonErrors;
import io.spaceandtime.api.errors.common.*;
import io.spaceandtime.api.jwt.*;
import io.spaceandtime.security.apis.SubscriptionProviderApi;
import io.spaceandtime.security.exceptions.FailedOperationException;
import io.spaceandtime.security.requests.*;
import io.spaceandtime.security.responses.*;
import io.spaceandtime.security.services.*;
import io.spaceandtime.security.storage.IKeyDBProvider;
import io.spaceandtime.storage.management.*;
import io.spaceandtime.storage.subscription.*;
import io.spaceandtime.storage.user.*;

@Validated
@RestController
public class SubscriptionProviderController extends BaseSecurityController implements SubscriptionProviderApi {
	private static final org.slf4j.Logger LOG = org.slf4j.LoggerFactory.getLogger(SubscriptionProviderController.class);

	@Autowired
	protected IJwtProvider _jwtProvider;
	@Autowired
	private IKeyDBProvider _keydbProvider;
	@Autowired
	private ISignatureValidatorService _signatureValidator;
	@Autowired
	private ISubscriptionRoleService _roleManager;
	@Autowired
	private ISubscriptionInviteService _inviteService;
	@Autowired
	private ISubscriptionClusterService _clusterService;

	@Override
	public ResponseEntity<NewSubscriptionResponse> create(
		@RequestBody(required = true) SubscriptionCreateRequest createRequest,
		HttpServletRequest httpRequest
	) throws Exception {
		authenticateProviderRequest(createRequest);
		String userId = null;
		String joinCode = null;

		if (StringUtils.hasLength(createRequest.getAccessToken())) {
			// If an access token was requested, validate it and make sure the underlying user
			// doesn't already have a subscription
			JwtPayload jwt = _jwtProvider.parse(createRequest.getAccessToken());
			if (StringUtils.hasLength(jwt.getSubscriptionId())) {
				throw new ForbiddenException(CommonErrors.BAD_INPUT, "Invalid userId", "The user whose JWT you've provided already has a subscription");
			}
			userId = jwt.getUserId();
		}

		String subscriptionId = UUID.randomUUID().toString();
		try {
			Subscription subscription = new Subscription(
				subscriptionId,
				"",
				SubscriptionState.ACTIVE,
				createRequest.getProviderId(),
				createRequest.getPlanName(),
				createRequest.getTimestamp().toString()
			);
			_keydbProvider.setSubscription(subscriptionId, subscription);
		} catch (Exception ex) {
			throw new FailedOperationException("Create subscription failed", "Unable to save new subscription", ex);
		}
		
		// Configure the new subscription's cluster assignment
		_clusterService.configureClusterAssignment(subscriptionId);

		if (StringUtils.hasLength(userId)) {
			// If we have an existing userId, also add the user to the subscription
			try {
				User user = _keydbProvider.getUser(userId);
				user.setSubscriptionId(subscriptionId);
				_keydbProvider.setUser(userId, user);
			} catch (Exception ex) {
				throw new FailedOperationException("Create subscription failed", "Unable to update user subscription", ex);
			}
			try {
				_roleManager.setUserRole(subscriptionId, userId, SubscriptionRole.OWNER);
			} catch (Exception ex) {
				throw new FailedOperationException("Create subscription failed", "Unable to configure user role", ex);
			}
		} else {
			try {
				joinCode = RandomGenerator.newString();
				_inviteService.save(new SubscriptionInvite(subscriptionId, joinCode, SubscriptionRole.OWNER));
			} catch (Exception ex) {
				throw new FailedOperationException("Create subscription failed", "Unable to save new subscription join code", ex);
			}
		}

		NewSubscriptionResponse response = new NewSubscriptionResponse(subscriptionId, joinCode);
		return Created(response);
	}

	@Override
	public ResponseEntity<SubscriptionProviderInfoResponse> get(
		@RequestBody(required = true) SubscriptionReferenceRequest subscriptionRequest,
		HttpServletRequest httpRequest
	) throws Exception {
		authenticateProviderRequest(subscriptionRequest);
		Subscription subscription = authorizeSubscriptionReference(subscriptionRequest);

		SubscriptionMetadata subscriptionMetadata;
		try {
			subscriptionMetadata = _keydbProvider.getSubscriptionMetadata(subscriptionRequest.getProviderId(), subscriptionRequest.getSubscriptionId());
		} catch (Exception ex) {
			LOG.info("Failed to retrieve subscription metadata. Reason: " + ex.getMessage());
			subscriptionMetadata = null;
		}

		SubscriptionProviderInfoResponse response = new SubscriptionProviderInfoResponse(subscription, subscriptionMetadata);
		return OK(response);
	}

	@Override
	public ResponseEntity<Void> alter(
		@RequestBody(required = true) SubscriptionAlterRequest alterRequest,
		HttpServletRequest httpRequest
	) throws Exception {
		authenticateProviderRequest(alterRequest);
		Subscription subscription = authorizeSubscriptionReference(alterRequest);
		if (StringUtils.hasLength(alterRequest.getPlanName())) {
			try {
				subscription.setPlanName(alterRequest.getPlanName());
				_keydbProvider.setSubscription(alterRequest.getSubscriptionId(), subscription);
			} catch (Exception ex) {
				throw new FailedOperationException("Alter subscription failed", "Unable to update subscription plan name", ex);
			}
		}
		if (!Objects.isNull(alterRequest.getMetadata())) {
			try {
				SubscriptionMetadata metadata = new SubscriptionMetadata(alterRequest.getSubscriptionId(), alterRequest.getMetadata());
				_keydbProvider.setSubscriptionMetadata(alterRequest.getProviderId(), alterRequest.getSubscriptionId(), metadata);
			} catch (Exception ex) {
				throw new FailedOperationException("Alter subscription failed", "Unable to update subscription metadata", ex);
			}
		}
		return NoContent();
	}

	@Override
	public ResponseEntity<Void> cancel(
		@RequestBody(required = true) SubscriptionReferenceRequest subscriptionRequest,
		HttpServletRequest httpRequest
	) throws Exception {
		authenticateProviderRequest(subscriptionRequest);
		Subscription subscription = authorizeSubscriptionReference(subscriptionRequest);
		try {
			subscription.setState(SubscriptionState.CANCELED);
			_keydbProvider.setSubscription(subscriptionRequest.getSubscriptionId(), subscription);
		} catch (Exception ex) {
			throw new FailedOperationException("Cancel subscription failed", "Unable to update subscription state", ex);
		}
		return NoContent();
	}

	@Override
	public ResponseEntity<Void> suspend(
		@RequestBody(required = true) SubscriptionReferenceRequest subscriptionRequest,
		HttpServletRequest httpRequest
	) throws Exception {
		authenticateProviderRequest(subscriptionRequest);
		Subscription subscription = authorizeSubscriptionReference(subscriptionRequest);
		SubscriptionState currentState = subscription.getState();
		if (!currentState.equals(SubscriptionState.ACTIVE)) {
			throw new ForbiddenException(CommonErrors.BAD_INPUT, "Invalid subscription state change", "Cannot suspend a subscription that is " + currentState.Value);
		}
		try {
			subscription.setState(SubscriptionState.SUSPENDED);
			_keydbProvider.setSubscription(subscriptionRequest.getSubscriptionId(), subscription);
		} catch (Exception ex) {
			throw new FailedOperationException("Suspend subscription failed", "Unable to update subscription state", ex);
		}
		return NoContent();
	}

	@Override
	public ResponseEntity<Void> reinstate(
		@RequestBody(required = true) SubscriptionReferenceRequest subscriptionRequest,
		HttpServletRequest httpRequest
	) throws Exception {
		authenticateProviderRequest(subscriptionRequest);
		Subscription subscription = authorizeSubscriptionReference(subscriptionRequest);
		SubscriptionState currentState = subscription.getState();
		if (!currentState.equals(SubscriptionState.SUSPENDED)) {
			throw new ForbiddenException(CommonErrors.BAD_INPUT, "Invalid subscription state change", "Cannot reinstate a subscription that is " + currentState.Value);
		}
		try {
			subscription.setState(SubscriptionState.ACTIVE);
			_keydbProvider.setSubscription(subscriptionRequest.getSubscriptionId(), subscription);
		} catch (Exception ex) {
			throw new FailedOperationException("Reinstate subscription failed", "Unable to update subscription state", ex);
		}
		return NoContent();
	}

	@Override
	public ResponseEntity<Void> renew(
		@RequestBody(required = true) SubscriptionRenewRequest renewRequest,
		HttpServletRequest httpRequest
	) throws Exception {
		authenticateProviderRequest(renewRequest);
		Subscription subscription = authorizeSubscriptionReference(renewRequest);SubscriptionState currentState = subscription.getState();
		if (!currentState.equals(SubscriptionState.ACTIVE)) {
			throw new ForbiddenException(CommonErrors.BAD_INPUT, "Invalid subscription state change", "Cannot renew a subscription that is " + currentState);
		}
		try {
			SubscriptionPayment payment = new SubscriptionPayment(
				renewRequest.getSubscriptionId(),
				renewRequest.getProviderId(),
				renewRequest.getAmount(),
				renewRequest.getCurrency(),
				renewRequest.getTimestamp()
			);
			_keydbProvider.addSubscriptionPayment(renewRequest.getSubscriptionId(), payment);
			subscription.setLastPayment(renewRequest.getTimestamp().toString());
			_keydbProvider.setSubscription(renewRequest.getSubscriptionId(), subscription);
		} catch (Exception ex) {
			throw new FailedOperationException("Renew subscription failed", "Unable to save subscription payment", ex);
		}
		return NoContent();
	}
	
	/**
	 * Authorize that the given provider has authority to interact with the referenced subscription
	 * @param <T> T - the subscription reference request type
	 * @param request - the request
	 * @return
	 * @throws ForbiddenException if the provider is not authorized to interact with the provided subscription
	 * @throws NotFoundException if the referenced subscription doesn't exist
	 */
	private <T extends SubscriptionReferenceRequest> Subscription authorizeSubscriptionReference(T request) throws ForbiddenException, NotFoundException {
		Subscription subscription;
		try {
			subscription = _keydbProvider.getSubscription(request.getSubscriptionId());
		} catch (Exception ex) {
			LOG.info("Unable to retrieve subscription. Reason: " + ex.getMessage());
			subscription = null;
		}
		if (subscription == null) {
			throw new NotFoundException(CommonErrors.RESOURCE_DNE, "Invalid subscriptionId", "No subscription exists with the provided identifier");
		}
		if (!request.getProviderId().equals(subscription.getProviderId())) {
			throw new ForbiddenException(CommonErrors.INSUFFICIENT_PRIVILEGES, "Invalid subscriptionId", "You are not authorized to perform operations on this subscription");
		}
		return subscription;
	}

	/**
	 * Authenticate a provider against their request payload
	 * @param <T> T - the request payload type
	 * @param request - the request
	 * @throws UnauthorizedException if authentication fails
	 */
	private <T extends SubscriptionBaseRequest> void authenticateProviderRequest(T request) throws Exception {
		SubscriptionProvider provider;
		try {
			provider = _keydbProvider.getSubscriptionProvider(request.getProviderId());
		} catch (Exception ex) {
			LOG.info("Failed to retrieve subscription provider. Reason: " + ex.getMessage());
			provider = null;
		}
		if (provider == null) {
			throw new UnauthorizedException(CommonErrors.BAD_INPUT, "Invalid providerId", "Could not retrieve a subscription provider for the provided identifier");
		}

		try {
			String publicKey = provider.getPublicKey();
			_signatureValidator.validateEd25519Signature(request.buildPayload(), request.getSignature(), publicKey);
		} catch (Exception ex) {
			throw new UnauthorizedException(CommonErrors.BAD_INPUT, "Invalid signature", "Signature validation failed against provided message");
		}
	}
}
