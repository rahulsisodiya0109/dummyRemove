package io.spaceandtime.security.services;

import io.spaceandtime.api.jwt.JwtPayload;
import io.spaceandtime.security.models.SecurityApiContext;
import io.spaceandtime.storage.user.*;

/**
 * Defines the contract for the session management service
 */
public interface ISessionService {
	/**
	 * Refresh a session and return an updated JWT payload for the new session iteration
	 * @param ctxt - the request context
	 * @return
	 * @throws Exception if session refresh fails for any reason
	 */
	JwtPayload refresh(SecurityApiContext ctxt) throws Exception;
	/**
	 * End a session
	 * @param ctxt - the request context
	 */
	void end(SecurityApiContext ctxt);
	/**
	 * Create a new session and return a JWT payload for the new session
	 * @param challenge - the user challenge
	 * @param key - the authentication key
	 * @return
	 * @throws Exception if the session creation fails
	 */
	JwtPayload create(UserChallenge challenge, AuthKey key) throws Exception;
}
