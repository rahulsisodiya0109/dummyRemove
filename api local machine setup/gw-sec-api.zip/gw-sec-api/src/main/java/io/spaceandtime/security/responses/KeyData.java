package io.spaceandtime.security.responses;

import io.spaceandtime.api.annotations.*;
import io.spaceandtime.security.apis.ApiConstants.*;
import io.spaceandtime.storage.user.AuthKey;
import io.spaceandtime.storage.user.AuthKey.KeyAlgorithm;

@ApiModels.Object(name = "KeyData")
public class KeyData {
	
	@ApiModels.Property(
		name = Params.KEY_NAME,
		description = Params.KEY_DESC
	)
	private String key;

	@ApiModels.Property(
		name = Params.SCHEME_NAME,
		description = Params.SCHEME_DESC_RESP
	)
	private String scheme;

	public KeyData(){}
	public KeyData(String keyValue, String schemeValue) {
		key = keyValue;
		scheme = schemeValue;
	}
	public KeyData(AuthKey authKey) {
		key = authKey.getPublicKey();
		if (authKey.getAlgorithm() == KeyAlgorithm.ETHEREUM) {
			scheme = authKey.getChainId();
		} else {
			scheme = KeyAlgorithm.ED25519.Value;
		}
	}

	public String getKey() { return key; }
	public String getScheme() { return scheme; }

	public void setKey(String value) { key = value; }
	public void setScheme(String value) { scheme = value; }
}
