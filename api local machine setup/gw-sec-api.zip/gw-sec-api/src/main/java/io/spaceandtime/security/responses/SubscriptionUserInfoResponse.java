package io.spaceandtime.security.responses;

import io.spaceandtime.api.annotations.*;

import io.spaceandtime.security.apis.ApiConstants.Params;
import io.spaceandtime.storage.management.SubscriptionProvider;
import io.spaceandtime.storage.subscription.*;

@ApiModels.Object(name = "SubscriptionUserInfoResponse")
public class SubscriptionUserInfoResponse extends SubscriptionBaseInfoResponse {
	
	@ApiModels.Property(
		name = Params.SUBSCRIPTIONNAME_NAME,
		description = Params.SUBSCRIPTIONNAME_DESC
	)
	private String subscriptionName;

	@ApiModels.Property(
		name = Params.PROVIDERNAME_NAME,
		description = Params.PROVIDERNAME_DESC
	)
	private String providerName;

	public SubscriptionUserInfoResponse() { super(); }
	public SubscriptionUserInfoResponse(String subscriptionIdValue, SubscriptionState stateValue, String planNameValue, String lastPaymentValue, String subscriptionNameValue, String providerNameValue) {
		super(subscriptionIdValue, stateValue, planNameValue, lastPaymentValue);
		subscriptionName = subscriptionNameValue;
		providerName = providerNameValue;
	}
	public SubscriptionUserInfoResponse(Subscription subscription, SubscriptionProvider provider) {
		super(subscription);
		subscriptionName = subscription.getName();
		providerName = provider.getName();
	}

	public String getSubscriptionName() { return subscriptionName; }
	public String getProviderName() { return providerName; }

	public void setSubscriptionName(String value) { subscriptionName = value; }
	public void setProviderName(String value) { providerName = value; }
}
