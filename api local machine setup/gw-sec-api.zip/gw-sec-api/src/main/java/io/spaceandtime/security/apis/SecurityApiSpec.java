package io.spaceandtime.security.apis;

import org.springframework.stereotype.Component;

import io.spaceandtime.api.openapi.IApiSpec;

/**
 * Defines the Security API specification provider
 */
@Component
public class SecurityApiSpec implements IApiSpec {
	@Override
	public String title() { return "Security/Auth REST APIs"; }
	@Override
	public String description() { return "Enable user authentication with the platform"; }
	@Override
	public String version() { return "1.0"; }
	@Override
	public boolean jwtAuth() { return true; }
}
