package io.spaceandtime.security.controllers;
// package io.spaceandtime.security.controller;

// import static io.spaceandtime.security.constants.AuthConstant.AUTHORIZATION;
// import static io.spaceandtime.security.constants.ErrorMessage.BISCUIT_ID_NOT_FOUND;
// import static io.spaceandtime.security.constants.ErrorMessage.BISCUIT_NOT_FOUND;
// import static io.spaceandtime.security.constants.ErrorMessage.SMART_CONTRACT_ADDRESS_EXIST;
// import static io.spaceandtime.security.constants.ErrorMessage.SMART_CONTRACT_ADDRESS_NOT_FOUND;
// import static io.spaceandtime.security.constants.ErrorMessage.USER_NOT_FOUND_FOR_SC_ADDRESS;
// import static io.spaceandtime.security.constants.ErrorMessage.USER_SMART_CONTRACT_NOT_FOUND;

// import java.util.ArrayList;
// import java.util.List;
// import java.util.Optional;

// import javax.servlet.http.HttpServletRequest;

// import org.springframework.beans.factory.annotation.Autowired;
// import org.springframework.http.HttpStatus;
// import org.springframework.http.ResponseEntity;
// import org.springframework.web.bind.annotation.DeleteMapping;
// import org.springframework.web.bind.annotation.GetMapping;
// import org.springframework.web.bind.annotation.PathVariable;
// import org.springframework.web.bind.annotation.PutMapping;
// import org.springframework.web.bind.annotation.RequestBody;
// import org.springframework.web.bind.annotation.RequestMapping;
// import org.springframework.web.bind.annotation.RestController;

// import io.spaceandtime.security.exception.ResourceAlreadyExistException;
// import io.spaceandtime.security.exception.ResourceNotFoundException;
// import io.spaceandtime.security.model.SmartContract;
// import io.spaceandtime.security.model.SmartContractBiscuit;
// import io.spaceandtime.security.model.SmartContractConfig;
// import io.spaceandtime.security.model.UserSmartContract;
// import io.spaceandtime.security.request.BiscuitPayloadRequest;
// import io.spaceandtime.security.response.ErrorResponse;
// import io.spaceandtime.security.service.SmartContractService;
// import io.spaceandtime.security.service.UserSmartContractService;
// import io.spaceandtime.security.util.AppUtils;
// import io.spaceandtime.security.util.JwtUtils;
// import io.swagger.v3.oas.annotations.Operation;
// import io.swagger.v3.oas.annotations.media.Content;
// import io.swagger.v3.oas.annotations.media.Schema;
// import io.swagger.v3.oas.annotations.responses.ApiResponse;
// import io.swagger.v3.oas.annotations.responses.ApiResponses;
// import io.swagger.v3.oas.annotations.tags.Tag;

// @RestController
// @RequestMapping("v1/mgmt")
// @Tag(name = "Smart Contract Management APIs")
// public class SmartContractController {

// 	@Autowired
// 	private JwtUtils jwtUtils;

// 	@Autowired
// 	private UserSmartContractService userSmartContractService;

// 	@Autowired
// 	private SmartContractService smartContractService;

// 	@Operation(summary = "Smart contracts list", description = "Retrieve the User Smart Contracts object")
// 	@ApiResponses(value = {
// 			@ApiResponse(responseCode = "200", description = "${api.response-codes.ok.desc}", content = @Content(schema = @Schema(implementation = UserSmartContract.class))) })
// 	@GetMapping("/contracts")
// 	public ResponseEntity<UserSmartContract> requestSmartContract(HttpServletRequest request) {
// 		// Getting the user claim from the access token and retrieve the User Smart
// 		// Contracts object from KeyDB
// 		String userId = getUserByAccessToken(request);
// 		return ResponseEntity.ok(userSmartContractService.findByUserId(userId));
// 	}

// 	private String getUserByAccessToken(HttpServletRequest request) {
// 		String accessToken = AppUtils.getBearerToken(request.getHeader(AUTHORIZATION));
// 		String userId = jwtUtils.getUserByAccessToken(accessToken);
// 		return userId;
// 	}

// 	@Operation(summary = "Smart contract", description = "Add/update smart contracts")
// 	@ApiResponses(value = { @ApiResponse(responseCode = "204", description = "${api.response-codes.noContent.desc}") })
// 	@PutMapping("/contracts/{address}")
// 	public ResponseEntity<String> addOrUpdateSmartContract(HttpServletRequest request,
// 			@PathVariable(required = true) String address) {

// 		String userId = getUserByAccessToken(request);

// 		// checking the Smart Contract Object (smart contract address -> userId mapping)
// 		// already exists
// 		validateSmartContract(address, userId);

// 		UserSmartContract userSmartContract = userSmartContractService.findByUserId(userId);

// 		// If one does not exist, create a new one
// 		if (userSmartContract == null) {
// 			createNewUserSmartContract(address, userId);
// 		} else {
// 			// If the userSmartContract already exists, we need to just add a new metadata
// 			// entry
// 			addSmartContractConfig(address, userSmartContract);
// 		}
// 		// creating a new mapping in Smart Contract object in KeyDB
// 		createNewSmartContract(address, userId);

// 		return new ResponseEntity<>(HttpStatus.NO_CONTENT);
// 	}

// 	private void validateSmartContract(String address, String userId) {
// 		SmartContract smartContract = smartContractService.findByAddress(address);
// 		if (smartContract != null && (!smartContract.getUserId().equalsIgnoreCase(userId)))
// 			throw new ResourceAlreadyExistException(SMART_CONTRACT_ADDRESS_EXIST);
// 	}

// 	private void addSmartContractConfig(String address, UserSmartContract userSmartContract) {
// 		List<SmartContractConfig> smartContractConfigList = userSmartContract.getSmartContractConfig();
// 		if (smartContractConfigList == null) {
// 			smartContractConfigList = new ArrayList<>();
// 		}
// 		SmartContractConfig smartContractConfig = new SmartContractConfig();
// 		smartContractConfig.setAddress(address);
// 		smartContractConfigList.add(smartContractConfig);
// 		userSmartContract.setSmartContractConfig(smartContractConfigList);
// 		userSmartContractService.save(userSmartContract);
// 	}

// 	private void createNewSmartContract(String address, String userId) {
// 		SmartContract newSmartContract = new SmartContract();
// 		newSmartContract.setAddress(address);
// 		newSmartContract.setUserId(userId);
// 		smartContractService.save(newSmartContract);
// 	}

// 	private void createNewUserSmartContract(String address, String userId) {
// 		UserSmartContract newUserSmartContract = new UserSmartContract();
// 		newUserSmartContract.setUserId(userId);

// 		List<SmartContractConfig> smartContractConfigList = new ArrayList<>();
// 		SmartContractConfig smartContractConfig = new SmartContractConfig();
// 		smartContractConfig.setAddress(address);
// 		smartContractConfigList.add(smartContractConfig);
// 		newUserSmartContract.setSmartContractConfig(smartContractConfigList);

// 		userSmartContractService.save(newUserSmartContract);
// 	}

// 	@Operation(summary = "Smart contracts", description = "Remove smart contracts")
// 	@ApiResponses(value = { @ApiResponse(responseCode = "204", description = "${api.response-codes.noContent.desc}"),
// 			@ApiResponse(responseCode = "404", description = "${api.response-codes.notFound.desc}", content = @Content(schema = @Schema(implementation = ErrorResponse.class))) })
// 	@DeleteMapping("/contracts/{address}")
// 	public ResponseEntity<String> deleteSmartContract(HttpServletRequest request,
// 			@PathVariable(required = true) String address) {
// 		String userId = getUserByAccessToken(request);
// 		UserSmartContract userSmartContract = userSmartContractService.findByUserId(userId);
// 		// If one does not exist, return 404 Not Found
// 		if (userSmartContract == null)
// 			throw new ResourceNotFoundException(USER_SMART_CONTRACT_NOT_FOUND);

// 		// Look up the smart contract metadata object given the provided address
// 		List<SmartContractConfig> smartContractConfigList = userSmartContract.getSmartContractConfig();
// 		Optional<SmartContractConfig> smartContractConfigObj = smartContractConfigList.stream()
// 				.filter(smartContractConfig -> smartContractConfig.getAddress().equals(address)).findFirst();
// 		// If one does not exist, return 404 Not Found
// 		if (!smartContractConfigObj.isPresent()) {
// 			throw new ResourceNotFoundException(SMART_CONTRACT_ADDRESS_NOT_FOUND);
// 		}

// 		// remove the smart contract metadata object at the provided address and save to
// 		// KeyDB

// 		smartContractConfigList.removeIf(smartContractConfig -> smartContractConfig.getAddress().equals(address));
// 		userSmartContractService.save(userSmartContract);

// 		// remove the mapping from the Smart Contract object in KeyDB
// 		smartContractService.delete(address);

// 		return new ResponseEntity<>(HttpStatus.NO_CONTENT);
// 	}

// 	@Operation(summary = "Smart contracts", description = " Add/update smart contract biscuit payloads")
// 	@ApiResponses(value = { @ApiResponse(responseCode = "204", description = "${api.response-codes.noContent.desc}"),
// 			@ApiResponse(responseCode = "404", description = "${api.response-codes.notFound.desc}", content = @Content(schema = @Schema(implementation = ErrorResponse.class))),
// 			@ApiResponse(responseCode = "400", description = "${api.response-codes.badRequest.desc}", content = @Content(schema = @Schema(implementation = ErrorResponse.class))) })
// 	@PutMapping("/contracts/{address}/biscuits")
// 	public ResponseEntity<String> addOrUpdateSmartContractBiscuit(HttpServletRequest request,
// 			@PathVariable(required = true) String address,
// 			@RequestBody List<BiscuitPayloadRequest> biscuitPayloadRequest) {

// 		if (biscuitPayloadRequest.isEmpty())
// 			return ResponseEntity.status(HttpStatus.BAD_REQUEST).build();

// 		// Getting the user claim from the access token and retrieve the User Smart
// 		// Contracts object from KeyDB

// 		String userId = getUserByAccessToken(request);
// 		UserSmartContract userSmartContract = userSmartContractService.findByUserId(userId);
// 		// If one does not exist, return 404 Not Found
// 		if (userSmartContract == null)
// 			throw new ResourceNotFoundException(USER_SMART_CONTRACT_NOT_FOUND);

// 		// Look up the smart contract metadata object given the provided address
// 		List<SmartContractConfig> smartContractConfigList = userSmartContract.getSmartContractConfig();
// 		Optional<SmartContractConfig> smartContractConfigObj = smartContractConfigList.stream()
// 				.filter(smartContractConfig -> smartContractConfig.getAddress().equals(address)).findFirst();
// 		// If one does not exist, return 404 Not Found
// 		if (!smartContractConfigObj.isPresent()) {
// 			throw new ResourceNotFoundException(SMART_CONTRACT_ADDRESS_NOT_FOUND);
// 		}

// 		// iterate over all entries in the provided biscuits array, Look up the matching
// 		// entry in the smart contract metadata object’s biscuit payload (match on sc
// 		// metadata biscuit entry id = biscuits array entry id)
// 		List<SmartContractBiscuit> biscuitsList = smartContractConfigObj.get().getBiscuits();
// 		if (biscuitsList != null) {
// 			for (int i = 0; i < biscuitPayloadRequest.size(); i++) {
// 				boolean isBiscuitPresent = false;
// 				for (SmartContractBiscuit smartContractBiscuit : biscuitsList) {
// 					if (biscuitPayloadRequest.get(i).getId().equalsIgnoreCase(smartContractBiscuit.getId())) {
// 						isBiscuitPresent = true;
// 						smartContractBiscuit.setBiscuit(biscuitPayloadRequest.get(i).getEncodedBiscuit());
// 						break;
// 					} else {
// 						isBiscuitPresent = false;
// 					}
// 				}
// 				// If it doesn’t exist, create a new entry
// 				if (!isBiscuitPresent) {

// 					SmartContractBiscuit newBiscuits = new SmartContractBiscuit();
// 					newBiscuits.setId(biscuitPayloadRequest.get(i).getId());
// 					newBiscuits.setBiscuit(biscuitPayloadRequest.get(i).getEncodedBiscuit());
// 					biscuitsList.add(newBiscuits);
// 				}

// 			}
// 		} else {
// 			// code for adding first biscuit payload
// 			biscuitsList = new ArrayList<>();

// 			for (int i = 0; i < biscuitPayloadRequest.size(); i++) {

// 				SmartContractBiscuit newBiscuits = new SmartContractBiscuit();
// 				newBiscuits.setId(biscuitPayloadRequest.get(i).getId());
// 				newBiscuits.setBiscuit(biscuitPayloadRequest.get(i).getEncodedBiscuit());
// 				biscuitsList.add(newBiscuits);
// 			}
// 			smartContractConfigObj.get().setBiscuits(biscuitsList);
// 		}

// 		smartContractConfigObj.get().setBiscuits(biscuitsList);
// 		userSmartContractService.save(userSmartContract);

// 		return new ResponseEntity<>(HttpStatus.NO_CONTENT);
// 	}

// 	@Operation(summary = "Smart contracts", description = "Remove biscuit payloads from a smart contract")
// 	@ApiResponses(value = { @ApiResponse(responseCode = "204", description = "${api.response-codes.noContent.desc}"),
// 			@ApiResponse(responseCode = "404", description = "${api.response-codes.notFound.desc}", content = @Content(schema = @Schema(implementation = ErrorResponse.class))) })
// 	@DeleteMapping("/contracts/{address}/biscuits/{biscuitId}")
// 	public ResponseEntity<String> deleteBiscuitPayloadFromSmartContract(HttpServletRequest request,
// 			@PathVariable(required = true) String address, @PathVariable(required = true) String biscuitId) {
// 		String userId = getUserByAccessToken(request);
// 		UserSmartContract userSmartContract = userSmartContractService.findByUserId(userId);

// 		// If one does not exist, return 404 Not Found
// 		if (userSmartContract == null)
// 			throw new ResourceNotFoundException(USER_SMART_CONTRACT_NOT_FOUND);

// 		// Look up the smart contract metadata object given the provided address
// 		List<SmartContractConfig> smartContractConfigList = userSmartContract.getSmartContractConfig();
// 		Optional<SmartContractConfig> smartContractConfigObj = smartContractConfigList.stream()
// 				.filter(smartContractConfig -> smartContractConfig.getAddress().equals(address)).findFirst();
// 		// If one does not exist, return 404 Not Found
// 		if (!smartContractConfigObj.isPresent()) {
// 			throw new ResourceNotFoundException(SMART_CONTRACT_ADDRESS_NOT_FOUND);
// 		}

// 		// getting biscuit list from smartContractConfig object
// 		List<SmartContractBiscuit> biscuitsList = smartContractConfigObj.get().getBiscuits();

// 		// removing the entry in the sc metadata’s biscuit array where id = provided
// 		// biscuitId
// 		boolean isDeleted = biscuitsList.removeIf(biscuit -> biscuit.getId().equals(biscuitId));
// 		if (isDeleted)
// 			userSmartContractService.save(userSmartContract);
// 		else
// 			throw new ResourceNotFoundException(BISCUIT_ID_NOT_FOUND);

// 		return new ResponseEntity<>(HttpStatus.NO_CONTENT);
// 	}

// 	@Operation(summary = "Smart contracts", description = "internal-only biscuit lookup by `address` and `biscuitId`")
// 	@ApiResponses(value = { @ApiResponse(responseCode = "204", description = "${api.response-codes.noContent.desc}"),
// 			@ApiResponse(responseCode = "404", description = "${api.response-codes.notFound.desc}", content = @Content(schema = @Schema(implementation = ErrorResponse.class))) })
// 	@GetMapping("/contracts/{address}/biscuits/{biscuitId}")
// 	public ResponseEntity<SmartContractBiscuit> getBiscuitPayloadFromSmartContract(
// 			@PathVariable(required = true) String address, @PathVariable(required = true) String biscuitId) {

// 		// there will be no user claim from the access token (remember, this is an
// 		// internal API!), so we need to use the provided address to get the Smart
// 		// contract object from KeyDB
// 		SmartContract smartContract = smartContractService.findByAddress(address);
// 		// this will tell us what the user identifier is. If not found, return 404 Not
// 		// Found
// 		if (smartContract == null)
// 			throw new ResourceNotFoundException(USER_NOT_FOUND_FOR_SC_ADDRESS);

// 		// getting userId from the smart contract
// 		String userId = smartContract.getUserId();

// 		// using the user identifier to retrieve the User Smart Contracts object from
// 		// KeyDB If not found, return 404 Not Found
// 		UserSmartContract userSmartContract = userSmartContractService.findByUserId(userId);
// 		if (userSmartContract == null)
// 			throw new ResourceNotFoundException(USER_SMART_CONTRACT_NOT_FOUND);

// 		List<SmartContractConfig> smartContractConfigList = userSmartContract.getSmartContractConfig();

// 		for (SmartContractConfig smartContractConfig : smartContractConfigList) {
// 			if (smartContractConfig.getAddress().equals(address)) {
// 				List<SmartContractBiscuit> biscuitsList = smartContractConfig.getBiscuits();
// 				if (biscuitsList != null) {
// 					for (SmartContractBiscuit biscuit : biscuitsList) {
// 						if (biscuit.getId().equals(biscuitId)) {
// 							return ResponseEntity.ok().body(biscuit);
// 						}
// 					}
// 				}
// 			}
// 		}
// 		throw new ResourceNotFoundException(BISCUIT_NOT_FOUND);
// 	}
// }
