package io.spaceandtime.security.models;

import io.spaceandtime.api.core.ApiContext;

/**
 * Defines the context needed to execute an authenticated Security API request
 */
public class SecurityApiContext extends ApiContext {
	
}
