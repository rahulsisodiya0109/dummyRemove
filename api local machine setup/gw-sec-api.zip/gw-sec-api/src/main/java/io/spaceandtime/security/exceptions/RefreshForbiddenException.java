package io.spaceandtime.security.exceptions;

import org.apache.commons.lang.NotImplementedException;

import io.spaceandtime.api.errors.common.ForbiddenException;

/**
 * Represents a 403 Forbidden exception due to a session refresh not being allowed
 */
public class RefreshForbiddenException extends ForbiddenException {
	private static final String CODE = "Session refresh forbidden";
	private static final String TITLE_ITERATION = "Invalid iteration";
	private static final String TITLE_SESSION = "Invalid session";

	private static final String DESC_ITER_REVOKED = "The iteration claim of the provided refresh token has already been revoked - either you've already logged out or a refresh token hijack has been detected. Please reauthenticate";
	private static final String DESC_ITER_MISMATCH = "The iteration claim of the provided refresh token does not match platform iteration state - a refresh token hijack has been detected. Please reauthenticate";
	private static final String DESC_SSN_INVALID = "Failed to validate session state. Please reauthenticate";
	private static final String DESC_SSN_EXPIRED = "Your authenticated session has expired. Please reauthenticate";

	public enum SessionErrorType {
		ITERATION_REVOKED,
		ITERATION_MISMATCH,
		SESSION_INVALID,
		SESSION_EXPIRED,
		;
	}

	public RefreshForbiddenException(SessionErrorType type) {
		super(CODE, getTitle(type), getDetails(type));
	}

	private static String getTitle(SessionErrorType type) {
		switch (type) {
			case ITERATION_MISMATCH:
			case ITERATION_REVOKED:
				return TITLE_ITERATION;
			case SESSION_EXPIRED:
			case SESSION_INVALID:
				return TITLE_SESSION;
			default: throw new NotImplementedException();
		}
	}

	private static String getDetails(SessionErrorType type) {
		switch (type) {
			case ITERATION_MISMATCH:	return DESC_ITER_MISMATCH;
			case ITERATION_REVOKED:		return DESC_ITER_REVOKED;
			case SESSION_EXPIRED:		return DESC_SSN_EXPIRED;
			case SESSION_INVALID:		return DESC_SSN_INVALID;
			default: throw new NotImplementedException();
		}
	}
}
