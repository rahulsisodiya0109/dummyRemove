package io.spaceandtime.security.storage.impl;

import java.util.Map;
import java.util.concurrent.TimeUnit;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import io.spaceandtime.security.storage.IKeyDBProvider;
import io.spaceandtime.storage.core.*;
import io.spaceandtime.storage.management.*;
import io.spaceandtime.storage.operator.DataWarehouse;
import io.spaceandtime.storage.user.*;
import io.spaceandtime.storage.subscription.*;

/**
 * Implements {@link IKeyDBProvider}
 */
@Component
public class KeyDBProvider implements IKeyDBProvider {

	@Autowired
	private IStorageProvider _provider;

	@Override
	public boolean userExists(String userId) throws Exception {
		return _provider.hExists(User.KEY, userId);
	}

	@Override
	public User getUser(String userId) throws Exception {
		return _provider.hGet(User.KEY, userId, User.class);
	}

	@Override
	public void setUser(String userId, User user) throws Exception {
		_provider.hPut(User.KEY, userId, user);
	}

	@Override
	public boolean userChallengeExists(String userId) throws Exception {
		return _provider.vExists(Keys.User.challenge(userId));
	}

	@Override
	public UserChallenge getUserChallenge(String userId) throws Exception {
		return _provider.vGet(Keys.User.challenge(userId), UserChallenge.class);
	}

	@Override
	public void setUserChallenge(String userId, UserChallenge challenge, Long durationMs) throws Exception {
		String key = Keys.User.challenge(userId);
		_provider.vSet(key, challenge);
		_provider.setTtl(key, durationMs, TimeUnit.MILLISECONDS);
	}

	@Override
	public void deleteUserChallenge(String userId) throws Exception {
		_provider.delete(Keys.User.challenge(userId));
	}

	@Override
	public UserSession getUserSession(String userId) throws Exception {
		return _provider.vGet(Keys.User.session(userId), UserSession.class);
	}

	@Override
	public void createUserSession(String userId, UserSession session, Long sessionDurationMs) throws Exception {
		String sessionKey = Keys.User.session(userId);
		_provider.vSet(sessionKey, session);
		_provider.setTtl(sessionKey, sessionDurationMs, TimeUnit.MILLISECONDS);
	}

	@Override
	public void updateUserSession(String userId, UserSession session) throws Exception {
		_provider.vSet(Keys.User.session(userId), session);
	}

	@Override
	public void deleteUserSession(String userId) throws Exception {
		_provider.delete(Keys.User.session(userId));
	}

	@Override
	public Subscription getSubscription(String subscriptionId) throws Exception {
		return _provider.hGet(Subscription.KEY, subscriptionId, Subscription.class);
	}

	@Override
	public void setSubscription(String subscriptionId, Subscription subscription) throws Exception {
		_provider.hPut(Subscription.KEY, subscriptionId, subscription);
	}

	@Override
	public SubscriptionUserRoles getSubscriptionUserRoles(String subscriptionId) throws Exception {
		return _provider.hGet(SubscriptionUserRoles.KEY, subscriptionId, SubscriptionUserRoles.class);
	}

	@Override
	public void setSubscriptionUserRoles(String subscriptionId, SubscriptionUserRoles subscriptionUserRoles) throws Exception {
		_provider.hPut(SubscriptionUserRoles.KEY, subscriptionId, subscriptionUserRoles);
	}

	@Override
	public SubscriptionClusterAssignment getSubscriptionClusterAssignment(String subscriptionId) throws Exception {
		return _provider.hGet(SubscriptionClusterAssignment.KEY, subscriptionId, SubscriptionClusterAssignment.class);
	}

	@Override
	public void setSubscriptionClusterAssignment(String subscriptionId, SubscriptionClusterAssignment assignment) throws Exception {
		_provider.hPut(SubscriptionClusterAssignment.KEY, subscriptionId, assignment);
	}

	@Override
	public boolean subscriptionInviteExists(String joinCode) throws Exception {
		return _provider.vExists(Keys.Subscription.invite(joinCode));
	}

	@Override
	public SubscriptionInvite getSubscriptionInvite(String joinCode) throws Exception {
		return _provider.vGet(Keys.Subscription.invite(joinCode), SubscriptionInvite.class);
	}

	@Override
	public void setSubscriptionInvite(String joinCode, SubscriptionInvite invite, Long durationMs) throws Exception {
		String key = Keys.Subscription.invite(joinCode);
		_provider.vSet(key, invite);
		_provider.setTtl(key, durationMs, TimeUnit.MILLISECONDS);
	}

	@Override
	public void deleteSubscriptionInvite(String joinCode) throws Exception {
		_provider.delete(Keys.Subscription.invite(joinCode));
	}

	@Override
	public boolean subscriptionBlockTimeExists(String subscriptionId) throws Exception {
		return _provider.hExists(SubscriptionBlockTime.KEY, subscriptionId);
	}

	@Override
	public KrakendConfig getKrakenConfig() throws Exception {
		return _provider.vGet(KrakendConfig.KEY, KrakendConfig.class);
	}

	@Override
	public boolean hasBlockTimes() throws Exception {
		return _provider.vExists(BlockTime.KEY);
	}

	@Override
	public Map<String, BlockTime> getAllBlockTimes() throws Exception {
		return _provider.hGetAll(BlockTime.KEY, BlockTime.class);
	}

	@Override
	public boolean hasSubscriptionBlockTimes() throws Exception {
		return _provider.vExists(SubscriptionBlockTime.KEY);
	}

	@Override
	public Map<String, SubscriptionBlockTime> getAllSubscriptionBlockTimes() throws Exception {
		return _provider.hGetAll(SubscriptionBlockTime.KEY, SubscriptionBlockTime.class);
	}

	@Override
	public SubscriptionProvider getSubscriptionProvider(String providerId) throws Exception {
		return _provider.hGet(SubscriptionProvider.KEY, providerId, SubscriptionProvider.class);
	}

	@Override
	public SubscriptionMetadata getSubscriptionMetadata(String providerId, String subscriptionId) throws Exception {
		return _provider.hGet(SubscriptionMetadata.KEY, Keys.Management.subscriptionMetadata(providerId, subscriptionId), SubscriptionMetadata.class);
	}

	@Override
	public void setSubscriptionMetadata(String providerId, String subscriptionId, SubscriptionMetadata metadata) throws Exception {
		_provider.hPut(SubscriptionMetadata.KEY, Keys.Management.subscriptionMetadata(providerId, subscriptionId), metadata);
	}

	@Override
	public void addSubscriptionPayment(String subscriptionId, SubscriptionPayment payment) throws Exception {
		_provider.lPushTail(Keys.Subscription.payment(subscriptionId), payment);
	}

	@Override
	public Map<String, DataWarehouse> getAllClusters() throws Exception {
		return _provider.hGetAll(DataWarehouse.KEY, DataWarehouse.class);
	}
}
