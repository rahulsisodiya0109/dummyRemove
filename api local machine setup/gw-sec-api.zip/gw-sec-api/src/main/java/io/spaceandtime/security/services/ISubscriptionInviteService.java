package io.spaceandtime.security.services;

import io.spaceandtime.storage.subscription.SubscriptionInvite;

/**
 * Defines the contract for the subscription invite service
 */
public interface ISubscriptionInviteService {
	/**
	 * Save a subscription invite
	 * @param invite - the subscription invite
	 * @throws Exception if the operation fails
	 */
	void save(SubscriptionInvite invite) throws Exception;
	/**
	 * Validate a subscription invite exists with the provided join code
	 * @param joinCode - the join code
	 * @throws Exception if no invite exists
	 */
	void validate(String joinCode) throws Exception;
	/**
	 * Try to retrieve the subscription invite with the provided join code
	 * and remove it on success
	 * @param joinCode - the join code
	 * @return
	 * @throws Exception if no invite exists
	 */
	SubscriptionInvite getAndDelete(String joinCode) throws Exception;
}
