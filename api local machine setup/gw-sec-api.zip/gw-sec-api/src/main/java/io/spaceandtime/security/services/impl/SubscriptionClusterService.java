package io.spaceandtime.security.services.impl;

import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import io.spaceandtime.security.services.ISubscriptionClusterService;
import io.spaceandtime.security.storage.IKeyDBProvider;
import io.spaceandtime.storage.operator.DataWarehouse;
import io.spaceandtime.storage.subscription.SubscriptionClusterAssignment;

/**
 * Implements {@link ISubscriptionClusterService}
 */
@Component
public class SubscriptionClusterService implements ISubscriptionClusterService {
	private static final org.slf4j.Logger LOG = org.slf4j.LoggerFactory.getLogger(SubscriptionClusterService.class);

	@Autowired
	private IKeyDBProvider _keydbProvider;
	
	@Override
	public void configureClusterAssignment(String subscriptionId) {
		try {
			Map<String, DataWarehouse> allClusters = _keydbProvider.getAllClusters();
			String primary = null;
			String secondary = null;
			for (Map.Entry<String, DataWarehouse> clusterEntry : allClusters.entrySet()) {
				String clusterId = clusterEntry.getKey();
				DataWarehouse cluster = clusterEntry.getValue();
				if (cluster.isDefaultPrimary() != null && cluster.isDefaultPrimary() == true) {
					primary = clusterId;
				} else if (cluster.isDefaultSecondary() != null && cluster.isDefaultSecondary() == true) {
					secondary = clusterId;
				}
			}
			if (primary == null) {
				LOG.warn("No default primary cluster configured!");
				return;
			}
			SubscriptionClusterAssignment clusterAssignment = new SubscriptionClusterAssignment();
			clusterAssignment.setPrimary(primary);
			clusterAssignment.setSecondary(secondary);
			_keydbProvider.setSubscriptionClusterAssignment(subscriptionId, clusterAssignment);
		} catch (Exception ex) {
			// Can't fail at this point, log an error
			LOG.error("Unable to configure subscription " + subscriptionId + " cluster assignment");
		}
	}
	
}
