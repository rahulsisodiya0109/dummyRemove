package io.spaceandtime.security.services.impl;

import java.net.URI;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Component;
import org.springframework.web.client.RestTemplate;

import io.spaceandtime.security.config.EnvVars;
import io.spaceandtime.security.services.IIdentifierBloomService;

/**
 * The KrakenD implementation of {@link IIdentifierBloomService}
 */
@Component
@ConditionalOnProperty(name = EnvVars.IdentifierBloom.IMPLEMENTATION, havingValue = "krakend")
public class KrakendIdentifierBloomService implements IIdentifierBloomService {
	private static final org.slf4j.Logger LOG = org.slf4j.LoggerFactory.getLogger(KrakendIdentifierBloomService.class);

	@Value(EnvVars.IdentifierBloom.KRAKEND_URL)
	private String KRAKEND_URL;

	private final RestTemplate _restClient = new RestTemplate();

	@Override
	public void add(String iterationId) {
		try {
			URI fullUrl = buildKrakenDUri("/add", iterationId);
			_restClient.getForEntity(fullUrl, String.class);
		} catch (Exception ex) {
			LOG.warn("Failed to add iteration to KrakenD bloom filter. Reason: " + ex.getMessage());
		}
	}

	@Override
	public boolean exists(String iterationId) {
		try {
			URI fullUrl = buildKrakenDUri("/check", iterationId);
			ResponseEntity<String> result = _restClient.getForEntity(fullUrl, String.class);
			return result.getBody().equals("true");
		} catch (Exception ex) {
			LOG.warn("Failed to check if iteration exists in KrakenD bloom filter. Reason: " + ex.getMessage());
		}
		return false;
	}
	
	/**
	 * Build the KrakenD request URI
	 * @param path - the request path
	 * @param iterationId - the iteration identifier
	 * @return
	 * @throws Exception if the URI syntax is invalid
	 */
	private URI buildKrakenDUri(String path, String iterationId) throws Exception {
		return new URI(KRAKEND_URL + path + "?iteration=" + iterationId);
	}
}
