package io.spaceandtime.security.apis;

/**
 * Defines various API constants
 */
public final class ApiConstants {

	/**
	 * Defines common constant values
	 */
	private static final class Common {
		public static final String INVALID_PARAMETER = "Invalid parameter (";
		public static final String NOT_EMPTY = ") - must not be empty";
		public static final String NOT_NULL = ") - must not be null";
		public static final String POSITIVE = ") - must be positive";
		public static final String PATH_OPEN = "/{";
		public static final String PATH_CLOSE = "}";
	}
	/**
	 * Defines API parameter constants
	 */
	public static final class Params {
		public static final String AUTH_CODE_NAME = "authCode";
		public static final String AUTH_CODE_DESC_RESP = "A secure, randomly generated string";
		public static final String AUTH_CODE_DESC_REQ = "The secure, randomly generated string provided from the Authentication Code API";
		public static final String AUTH_CODE_VALID = Common.INVALID_PARAMETER + AUTH_CODE_NAME + Common.NOT_EMPTY;

		public static final String USERID_NAME = "userId";
		public static final String USERID_DESC = "The unique user identifier";
		public static final String USERID_VALID = Common.INVALID_PARAMETER + USERID_NAME + Common.NOT_EMPTY;
		public static final String USERID_PATH = Common.PATH_OPEN + USERID_NAME + Common.PATH_CLOSE;

		public static final String USERID_CHECK_NAME = "id";
		public static final String USERID_CHECK_DESC = "The user identifier to check";
		public static final String USERID_CHECK_PATH = Common.PATH_OPEN + USERID_CHECK_NAME + Common.PATH_CLOSE;

		public static final String JOIN_CODE_NAME = "joinCode";
		public static final String JOIN_CODE_OPT_DESC = "[Optional] The unique code to join a given subscription";
		public static final String JOIN_CODE_REQ_DESC = "The unique code to join a given subscription";
		public static final String JOIN_CODE_PATH = Common.PATH_OPEN + JOIN_CODE_NAME + Common.PATH_CLOSE;

		public static final String PREFIX_NAME = "prefix";
		public static final String PREFIX_DESC = "[Optional] The message prefix for signature verification (used for improved front-end UX)";

		public static final String SIGNATURE_AUTH_NAME = "signature";
		public static final String SIGNATURE_AUTH_DESC = "The signature calculated using the authCode and your private key";
		public static final String SIGNATURE_VALID = Common.INVALID_PARAMETER + SIGNATURE_AUTH_NAME + Common.NOT_EMPTY;

		public static final String KEY_NAME = "key";
		public static final String KEY_DESC = "The public key the platform uses to validate signatures";
		public static final String KEY_VALID = Common.INVALID_PARAMETER + KEY_NAME + Common.NOT_EMPTY;

		public static final String SCHEME_NAME = "scheme";
		public static final String SCHEME_DESC_REQ = "The key scheme (i.e., algorithm). This is required when adding a new key (e.g., during registration) and optional thereafter";
		public static final String SCHEME_DESC_RESP = "The key scheme (i.e., algorithm)";

		public static final String ACCESS_TOKEN_AUTH_NAME = "accessToken";
		public static final String ACCESS_TOKEN_AUTH_DESC = "The access token (JWT) to use for bearer authentication with other APIs";
		
		public static final String ACCESS_TOKEN_EXP_NAME = "accessTokenExpires";
		public static final String ACCESS_TOKEN_EXP_DESC = "The time when the access token will expire (expressed as ms since the UNIX epoch)";
		
		public static final String REFRESH_TOKEN_NAME = "refreshToken";
		public static final String REFRESH_TOKEN_DESC = "The refresh token (JWT) to use for bearer authentication with other Security APIs";
		
		public static final String REFRESH_TOKEN_EXP_NAME = "refreshTokenExpires";
		public static final String REFRESH_TOKEN_EXP_DESC = "The time when the refresh token will expire (expressed as ms since the UNIX epoch)";

		public static final String SUBSCRIPTIONID_NAME = "subscriptionId";
		public static final String SUBSCRIPTIONID_DESC = "The unique subscription identifier";
		public static final String SUBSCRIPTIONID_PATH = Common.PATH_OPEN + SUBSCRIPTIONID_NAME + Common.PATH_CLOSE;
		public static final String SUBSCRIPTIONID_VALID = Common.INVALID_PARAMETER + SUBSCRIPTIONID_NAME + Common.NOT_EMPTY;

		public static final String RESTRICTED_NAME = "restricted";
		public static final String RESTRICTED_DESC = "Defines whether or not the token's access to privileged APIs is currently restricted";

		public static final String TRIAL_NAME = "trial";
		public static final String TRIAL_DESC = "Defines whether or not the token is in trial mode. If this is provided, the subscriptionId will be empty";

		public static final String KEYCHAIN_NAME = "keychain";
		public static final String KEYCHAIN_DESC = "The current user keychain";

		public static final String PROVIDERID_NAME = "providerId";
		public static final String PROVIDERID_DESC = "The unique subscription provider identifier - this must be preconfigured with the platform";
		public static final String PROVIDERID_VALID = Common.INVALID_PARAMETER + PROVIDERID_NAME + Common.NOT_EMPTY;

		public static final String SIGNATURE_SBSC_NAME = "signature";
		public static final String SIGNATURE_SBSC_DESC = "The ED25519 signature calculated from the message payload and the provider private key";

		public static final String ACCESS_TOKEN_SBSC_NAME = "accessToken";
		public static final String ACCESS_TOKEN_SBSC_DESC = "The access token (JWT) of the authenticated user";

		public static final String PAIDAMOUNT_NAME = "amount";
		public static final String PAIDAMOUNT_DESC = "The amount paid";
		public static final String PAIDAMOUNT_VALID = Common.INVALID_PARAMETER + PAIDAMOUNT_NAME + Common.POSITIVE;

		public static final String PAIDCURRENCY_NAME = "currency";
		public static final String PAIDCURRENCY_DESC = "The currency of the amount paid";
		public static final String PAIDCURRENCY_VALID = Common.INVALID_PARAMETER + PAIDCURRENCY_NAME + Common.NOT_EMPTY;

		public static final String PAIDSTAMP_NAME = "timestamp";
		public static final String PAIDSTAMP_DESC = "The timestamp (in ms since Unix epoch) when the payment was made";
		public static final String PAIDSTAMP_VALID = Common.INVALID_PARAMETER + PAIDSTAMP_NAME + Common.NOT_NULL;

		public static final String PLANNAME_NAME = "planName";
		public static final String PLANNAME_DESC = "The common display name for the subscription plan";
		public static final String PLANNAME_VALID = Common.INVALID_PARAMETER + PLANNAME_NAME + Common.NOT_EMPTY;

		public static final String METADATA_NAME = "metadata";
		public static final String METADATA_DESC = "The additional subscription metadata";

		public static final String SUBSCRIPTION_STATE_NAME = "state";
		public static final String SUBSCRIPTION_STATE_DESC = "The current subscription state";

		public static final String LASTPAYMENT_NAME = "lastPayment";
		public static final String LASTPAYMENT_DESC = "The timestamp (in ms since Unix epoch) when the last payment was made";

		public static final String ROLE_NAME = "role";
		public static final String ROLE_DESC = "The desired role for the user to have in the subscription";

		public static final String ROLEMAP_NAME = "roleMap";
		public static final String ROLEMAP_DESC = "The user role map within the subscription";

		public static final String PROVIDERNAME_NAME = "providerName";
		public static final String PROVIDERNAME_DESC = "The subscription provider display name";

		public static final String SUBSCRIPTIONNAME_NAME = "subscriptionName";
		public static final String SUBSCRIPTIONNAME_DESC = "The subscription display name";
	}
}
