package io.spaceandtime.security.storage;

import io.spaceandtime.storage.user.*;

import java.util.Map;

import io.spaceandtime.storage.management.*;
import io.spaceandtime.storage.operator.DataWarehouse;
import io.spaceandtime.storage.subscription.*;

/**
 * Defines the contract for the Gateway KeyDB provider
 */
public interface IKeyDBProvider {
	/**
	 * Check if a user exists
	 * @param userId - the user identifier
	 * @return
	 * @throws Exception if the operation fails
	 */
	boolean userExists(String userId) throws Exception;
	/**
	 * Retrieve a user by id
	 * @param userId - the user identifier
	 * @return
	 * @throws Exception if the operation fails
	 */
	User getUser(String userId) throws Exception;
	/**
	 * Save the user
	 * @param userId - the user identifier
	 * @param user - the user data
	 * @throws Exception if the operation fails
	 */
	void setUser(String userId, User user) throws Exception;
	/**
	 * Check if a user challenge exists
	 * @param userId - the user identifier
	 * @return
	 * @throws Exception if the operation fails
	 */
	boolean userChallengeExists(String userId) throws Exception;
	/**
	 * Retrieve a user challenge by id
	 * @param userId - the user identifier
	 * @return
	 * @throws Exception if the operation fails
	 */
	UserChallenge getUserChallenge(String userId) throws Exception;
	/**
	 * Save the user challenge
	 * @param userId - the user identifier
	 * @param challenge - the user challenge
	 * @param expirationMs - the user challenge expiration (in ms)
	 * @throws Exception if the operation fails
	 */
	void setUserChallenge(String userId, UserChallenge challenge, Long expirationMs) throws Exception;
	/**
	 * Delete the user challenge
	 * @param userId - the user identifier
	 * @throws Exception if the operation fails
	 */
	void deleteUserChallenge(String userId) throws Exception;
	/**
	 * Retrieve a user session by id
	 * @param userId - the user identifier
	 * @return
	 * @throws Exception if the operation fails
	 */
	UserSession getUserSession(String userId) throws Exception;
	/**
	 * Create a new user session
	 * @param userId - the user identifier
	 * @param session - the user session
	 * @param sessionDurationMs - the session duration (in ms)
	 * @throws Exception if the operation fails
	 */
	void createUserSession(String userId, UserSession session, Long sessionDurationMs) throws Exception;
	/**
	 * Update the user session
	 * @param userId - the user identifier
	 * @param session - the user session
	 * @param sessionDurationMs - the session duration (in ms)
	 * @throws Exception if the operation fails
	 */
	void updateUserSession(String userId, UserSession session) throws Exception;
	/**
	 * Delete the user session
	 * @param userId - the user identifier
	 * @throws Exception if the operation fails
	 */
	void deleteUserSession(String userId) throws Exception;
	/**
	 * Retrieve a subscription by id
	 * @param subscriptionId - the subscription identifier
	 * @return
	 * @throws Exception if the operation fails
	 */
	Subscription getSubscription(String subscriptionId) throws Exception;
	/**
	 * Save the subscription
	 * @param subscriptionId - the subscription identifier
	 * @param subscription - the subscription
	 * @throws Exception if the operation fails
	 */
	void setSubscription(String subscriptionId, Subscription subscription) throws Exception;
	/**
	 * Retrieve the subscription user roles
	 * @param subscriptionId - the subscription identifier
	 * @return
	 * @throws Exception if the operation fails
	 */
	SubscriptionUserRoles getSubscriptionUserRoles(String subscriptionId) throws Exception;
	/**
	 * Save the subscription user roless
	 * @param subscriptionId - the subscription identifier
	 * @param subscriptionUsers - the subscription user roles
	 * @throws Exception if the operation fails
	 */
	void setSubscriptionUserRoles(String subscriptionId, SubscriptionUserRoles subscriptionUsers) throws Exception;
	/**
	 * Retrieve the subscription cluster assignment
	 * @param subscriptionId - the subscription identifier
	 * @return
	 * @throws Exception if the operation fails
	 */
	SubscriptionClusterAssignment getSubscriptionClusterAssignment(String subscriptionId) throws Exception;
	/**
	 * Save the subscription cluster assignment
	 * @param subscriptionId - the subscription identifier
	 * @param assignment - the subscription cluster assignment
	 * @throws Exception if the operation fails
	 */
	void setSubscriptionClusterAssignment(String subscriptionId, SubscriptionClusterAssignment assignment) throws Exception;
	/**
	 * Check if a subscription invite exists
	 * @param joinCode - the join code
	 * @return
	 * @throws Exception if an operation fails
	 */
	boolean subscriptionInviteExists(String joinCode) throws Exception;
	/**
	 * Retrieve the subscription invite
	 * @param joinCode - the join code
	 * @return
	 * @throws Exception if the operation fails
	 */
	SubscriptionInvite getSubscriptionInvite(String joinCode) throws Exception;
	/**
	 * Save the subscription invite
	 * @param joinCode - the join code
	 * @param invite - the subscription invite
	 * @param durationMs - the duration of the invite validity (in ms)
	 * @throws Exception
	 */
	void setSubscriptionInvite(String joinCode, SubscriptionInvite invite, Long durationMs) throws Exception;
	/**
	 * Delete a subscription invite
	 * @param joinCode - the join code
	 * @throws Exception if the operation fails
	 */
	void deleteSubscriptionInvite(String joinCode) throws Exception;
	/**
	 * Check if a subscription block time configuration exists
	 * @param subscriptionId - the subscription identifier
	 * @return
	 * @throws Exception if the operation fails
	 */
	boolean subscriptionBlockTimeExists(String subscriptionId) throws Exception;
	/**
	 * Retrieve the KrakenD configuration
	 * @return
	 * @throws Exception if the operation fails
	 */
	KrakendConfig getKrakenConfig() throws Exception;
	/**
	 * Check if there are any block times configured
	 * @return
	 * @throws Exception if the operation fails
	 */
	boolean hasBlockTimes() throws Exception;
	/**
	 * Retrieve all block time configurations
	 * @return
	 * @throws Exception if the operation fails
	 */
	Map<String, BlockTime> getAllBlockTimes() throws Exception;
	/**
	 * Check if there are any subscription block times configured
	 * @return
	 * @throws Exception if the operation fails
	 */
	boolean hasSubscriptionBlockTimes() throws Exception;
	/**
	 * Retrieve all subscription block time mappings
	 * @return
	 * @throws Exception if the operation fails
	 */
	Map<String, SubscriptionBlockTime> getAllSubscriptionBlockTimes() throws Exception;
	/**
	 * Retrieve a subscription provivder
	 * @param providerId - the provider identifier
	 * @return
	 * @throws Exception if the operation fails
	 */
	SubscriptionProvider getSubscriptionProvider(String providerId) throws Exception;
	/**
	 * Retrieve the additional metadata a provider has stored for a subscription
	 * @param providerId - the provider identifier
	 * @param subscriptionId - the subscription identifier
	 * @return
	 * @throws Exception if the operation fails
	 */
	SubscriptionMetadata getSubscriptionMetadata(String providerId, String subscriptionId) throws Exception;
	/**
	 * Save the additional metadata a provider has provided for a subscription
	 * @param providerId - the provider identifier
	 * @param subscriptionId - the subscription identifier
	 * @param metadata - the metadata
	 * @throws Exception if the operation fails
	 */
	void setSubscriptionMetadata(String providerId, String subscriptionId, SubscriptionMetadata metadata) throws Exception;
	/**
	 * Add a new payment to the subscription payment history
	 * @param subscriptionId - the subscription identifier
	 * @param payment - the payment
	 * @throws Exception
	 */
	void addSubscriptionPayment(String subscriptionId, SubscriptionPayment payment) throws Exception;
	/**
	 * Retrieve all data warehouse clusters
	 * @return
	 * @throws Exception if the operation fails
	 */
	Map<String, DataWarehouse> getAllClusters() throws Exception;
}
