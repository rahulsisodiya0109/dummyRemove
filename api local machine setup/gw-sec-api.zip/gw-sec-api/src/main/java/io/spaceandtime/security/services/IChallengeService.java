package io.spaceandtime.security.services;

import io.spaceandtime.api.jwt.JwtPayload;
import io.spaceandtime.security.requests.AuthCodeRequest;
import io.spaceandtime.security.responses.AuthCodeResponse;
import io.spaceandtime.storage.user.UserChallenge;

/**
 * Defines the contract for the auth code (i.e., challenge) generation service
 */
public interface IChallengeService {
	/**
	 * Generate a new auth code for the authentication workflow
	 * @param authCodeRequest - the auth code request
	 * @return
	 * @throws Exception
	 */
	AuthCodeResponse generateForAuth(AuthCodeRequest authCodeRequest) throws Exception;
	/**
	 * Generate a new auth code for the add key to keychain workflow
	 * @param jwt - the current authenticated user JWT payload
	 * @return
	 * @throws Exception
	 */
	AuthCodeResponse generateForAddKey(JwtPayload jwt) throws Exception;
	/**
	 * Retrieve the user challenge and validate it against the provided auth code
	 * @param userId - the user identifier
	 * @param authCode - the auth code
	 * @return
	 * @throws Exception
	 */
	UserChallenge getAndValidate(String userId, String authCode) throws Exception;
	/**
	 * Delete the user challenge
	 * @param userId - the user identifier
	 */
	void delete(String userId);
}
