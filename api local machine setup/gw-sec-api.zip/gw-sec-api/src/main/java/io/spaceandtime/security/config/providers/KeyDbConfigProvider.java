package io.spaceandtime.security.config.providers;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import io.spaceandtime.security.config.EnvVars;
import io.spaceandtime.storage.core.IStorageConfigProvider;

@Component
public class KeyDbConfigProvider implements IStorageConfigProvider {

	@Value(EnvVars.KeyDB.HOST)
	private String HOST;
	@Value(EnvVars.KeyDB.PORT)
	private int PORT;
	@Value(EnvVars.KeyDB.PASSWORD)
	private String PASSWORD;

	@Override
	public String getHost() { return HOST; }

	@Override
	public String getPassword() { return PASSWORD; }

	@Override
	public int getPort() { return PORT; }
}