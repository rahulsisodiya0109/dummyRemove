package io.spaceandtime.security.services;

import io.spaceandtime.api.jwt.JwtPayload;
import io.spaceandtime.security.responses.TokenResponse;

/**
 * Defines the contract for the security token builder service
 */
public interface ITokenBuilderService {
	/**
	 * Build tokens for the given JWT payload
	 * <p>
	 * NOTE: The payload will be modified during this method execution
	 * @param payload - the JWT payload
	 * @return
	 * @throws Exception if the tokens cannot be generated
	 */
	TokenResponse buildTokens(JwtPayload payload) throws Exception;
	/**
	 * Build an internal access token
	 * <p>
	 * NOTE: The payload will be modified during this method execution
	 * @param payload - the JWT payload
	 * @return
	 * @throws Exception if the token cannot be generated
	 */
	String buildInternal(JwtPayload payload) throws Exception;
}
