package io.spaceandtime.security.responses;

import java.util.ArrayList;
import java.util.List;

import io.spaceandtime.api.annotations.*;
import io.spaceandtime.security.apis.ApiConstants.*;
import io.spaceandtime.storage.user.AuthKey;
import io.spaceandtime.storage.user.User;

@ApiModels.Object(name = "KeychainResponse")
public class KeychainResponse {
	
	@ApiModels.Property(
		name = Params.KEYCHAIN_NAME,
		description = Params.KEYCHAIN_DESC
	)
	private List<KeyData> keychain;

	public KeychainResponse(){}
	public KeychainResponse(List<KeyData> keychainValue) {
		keychain = keychainValue;
	}
	public KeychainResponse(User user) {
		keychain = new ArrayList<>();
		for (AuthKey authKey : user.getKeychain()) {
			keychain.add(new KeyData(authKey));
		}
	}

	public List<KeyData> getKeychain() { return keychain; }
	public void setKeychain(List<KeyData> value) { keychain = value; }
}
