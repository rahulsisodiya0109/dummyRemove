package io.spaceandtime.security.apis;

import javax.servlet.http.HttpServletRequest;

import org.springframework.http.ResponseEntity;

import io.spaceandtime.api.annotations.*;
import io.spaceandtime.security.requests.*;
import io.spaceandtime.security.responses.*;

/**
 * Defines the contract for the Key Management API group
 */
@ApiGroup(
	name = "Key Management API",
	description = "Provides keychain management operations",
	basePath = "/v1/auth/keys"
)
public interface KeyManagementApi {
	
	@Apis.Get(
		operationId = "get-current-keychain",
		summary = "Get current keychain",
		description = "Retrieve public keys available for user authentication"
	)
	@Responses.OK_200
	@Responses.Unauthorized_401
	ResponseEntity<KeychainResponse> getKeychain(
		HttpServletRequest httpRequest
	) throws Exception;

	@Apis.Post(
		operationId = "get-public-key-challenge",
		summary = "Get public key challenge",
		description = "Request a challenge for adding a new public key",
		path = "/code"
	)
	@Responses.OK_200
	@Responses.BadRequest_400
	@Responses.Unauthorized_401
	ResponseEntity<AuthCodeResponse> getKeyAddChallenge(
		HttpServletRequest httpRequest
	) throws Exception;

	@Apis.Post(
		operationId = "add-key-to-keychain",
		summary = "Add key to keychain",
		description = "Add a new public key to your keychain for authentication"
	)
	@Responses.NoContent_204
	@Responses.BadRequest_400
	@Responses.Unauthorized_401
	ResponseEntity<Void> addKey(
		@Requests.Body AddKeyRequest addKeyRequest,
		HttpServletRequest httpRequest
	) throws Exception;
}
