package io.spaceandtime.security.models;

import com.fasterxml.jackson.annotation.JsonProperty;

/**
 * Defines the valid internal token types
 */
public enum InternalTokenType {
	@JsonProperty("USER") USER("USER"),
	@JsonProperty("SMART_CONTRACT") SMART_CONTRACT("SMART_CONTRACT"),
	;

	public final String Value;
	InternalTokenType(String value) {
		Value = value;
	}
}
