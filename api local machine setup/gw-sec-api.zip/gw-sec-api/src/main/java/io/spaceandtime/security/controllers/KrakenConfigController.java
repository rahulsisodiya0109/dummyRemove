package io.spaceandtime.security.controllers;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

import io.spaceandtime.api.core.BaseApiController;
import io.spaceandtime.security.exceptions.FailedOperationException;
import io.spaceandtime.security.responses.KrakendConfigResponse;
import io.spaceandtime.security.storage.IKeyDBProvider;
import io.spaceandtime.storage.management.*;
import io.spaceandtime.storage.subscription.SubscriptionBlockTime;

/**
 * Provides the payload needed to configure the KrakenD rate limiter plugin
 */
@RestController
public class KrakenConfigController extends BaseApiController {
	private static final String FAIL_TITLE = "Get KrakenD config failed";

	@Autowired
	private IKeyDBProvider _keydbProvider;
	
	@GetMapping("/krakend-config")
	public ResponseEntity<KrakendConfigResponse> getConfig() throws Exception {
		KrakendConfig krakenConfig;
		try {
			krakenConfig = _keydbProvider.getKrakenConfig();
		} catch (Exception ex) {
			throw new FailedOperationException(FAIL_TITLE, "Failed to retrieve KrakenD configuration", ex);
		}

		List<BlockTime> blocks;
		try {
			if (_keydbProvider.hasBlockTimes()) {
				Map<String, BlockTime> blockTimes = _keydbProvider.getAllBlockTimes();
				blocks = new ArrayList<>(blockTimes.values());
			} else blocks = new ArrayList<>();
		} catch (Exception ex) {
			throw new FailedOperationException(FAIL_TITLE, "Failed to retrieve KrakenD configuration", ex);
		}

		List<SubscriptionBlockTime> subscriptionBlocks;
		try {
			if (_keydbProvider.hasSubscriptionBlockTimes()) {
				Map<String, SubscriptionBlockTime> subscriptionBlockTimes = _keydbProvider.getAllSubscriptionBlockTimes();
				subscriptionBlocks = new ArrayList<>(subscriptionBlockTimes.values());
			} else subscriptionBlocks = new ArrayList<>();
		} catch (Exception ex) {
			throw new FailedOperationException(FAIL_TITLE, "Failed to retrieve KrakenD configuration", ex);
		}

		KrakendConfigResponse response = new KrakendConfigResponse(krakenConfig, subscriptionBlocks, blocks);
		return OK(response);
	}
}
