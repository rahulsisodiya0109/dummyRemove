package io.spaceandtime.security.services.impl;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;
import org.springframework.util.StringUtils;

import io.spaceandtime.api.core.RandomGenerator;
import io.spaceandtime.api.jwt.JwtPayload;
import io.spaceandtime.security.config.EnvVars;
import io.spaceandtime.security.exceptions.*;
import io.spaceandtime.security.requests.AuthCodeRequest;
import io.spaceandtime.security.responses.AuthCodeResponse;
import io.spaceandtime.security.services.IChallengeService;
import io.spaceandtime.security.services.ISubscriptionInviteService;
import io.spaceandtime.security.storage.IKeyDBProvider;
import io.spaceandtime.storage.user.UserChallenge;

/**
 * Implements {@link IChallengeService}
 */
@Component
public class ChallengeService implements IChallengeService {
	private static final org.slf4j.Logger LOG = org.slf4j.LoggerFactory.getLogger(ChallengeService.class);

	@Value(EnvVars.Core.CHALLENGE_EXPIRATION_MS)
	private Long CHALLENGE_EXPIRATION_MS;

	@Autowired
	private IKeyDBProvider _keydbProvider;

	@Autowired
	private ISubscriptionInviteService _subscriptionInvite;

	@Override
	public AuthCodeResponse generateForAuth(AuthCodeRequest authCodeRequest) throws Exception {
		boolean isRegistration;
		String userId = authCodeRequest.getUserId();
		String joinCode = authCodeRequest.getJoinCode();
		try {
			isRegistration = !_keydbProvider.userExists(userId);
		} catch (Exception ex) {
			LOG.warn("Failed to determine if user exists. Reason: " + ex.getMessage());
			// Assume if we can't find the user for whatever reason that this is a registration workflow
			isRegistration = true;
		}

		// Has the user provided a join code to auto-join a subscription on successful registration?
		if (isRegistration && StringUtils.hasLength(joinCode)) {
			_subscriptionInvite.validate(joinCode);
		}

		// Validate that a challenge does not already exist
		boolean challengeExists;
		try {
			challengeExists = _keydbProvider.userChallengeExists(userId);
		} catch (Exception ex) {
			throw new FailedOperationException("User challenge check failed", "Unable to determine if user challenge already exists, cannot proceed with auth code generation", ex);
		}
		if (challengeExists) {
			throw new BadChallengeException(true);
		}

		// Generate a new challenge 
		return generateChallenge(userId, authCodeRequest.getPrefix(), joinCode, isRegistration);
	}

	@Override
	public AuthCodeResponse generateForAddKey(JwtPayload jwt) throws Exception {
		return generateChallenge(jwt.getUserId(), null, null, false);
	}

	/**
	 * Generate a challenge and save it to KeyDB
	 * @param userId - the user identifier
	 * @param prefix - the challenge prefix
	 * @param joinCode - the join code
	 * @param isRegistration - determines whether or not this is a registration
	 * @return
	 * @throws Exception if the challenge cannot be generated or saved
	 */
	private AuthCodeResponse generateChallenge(String userId, String prefix, String joinCode, boolean isRegistration) throws Exception {
		String authCode;
		try {
			authCode = RandomGenerator.newString();
			UserChallenge challenge = new UserChallenge(
				userId,
				authCode,
				prefix,
				joinCode,
				isRegistration
			);
			_keydbProvider.setUserChallenge(userId, challenge, CHALLENGE_EXPIRATION_MS);
		} catch (Exception ex) {
			throw new FailedOperationException("Challenge generation failed", "Unable to generate challenge", ex);
		}
		return new AuthCodeResponse(authCode);
	}

	@Override
	public UserChallenge getAndValidate(String userId, String authCode) throws Exception {
		UserChallenge challenge;
		try {
			challenge = _keydbProvider.getUserChallenge(userId);
		} catch (Exception ex) {
			LOG.info("Unable to retrieve user challenge. Reason: " + ex.getMessage());
			challenge = null;
		}
		if (challenge == null || challenge.getAuthCode() == null || !authCode.equals(challenge.getAuthCode())) {
			throw new BadChallengeException(false);
		}
		return challenge;
	}

	@Override
	public void delete(String userId) {
		try {
			_keydbProvider.deleteUserChallenge(userId);
		} catch (Exception ex) {
			LOG.warn("Failed to delete user challenge. Reason: " + ex.getMessage());
		}
	}
}
