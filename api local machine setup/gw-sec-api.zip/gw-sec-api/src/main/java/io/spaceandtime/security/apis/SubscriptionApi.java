package io.spaceandtime.security.apis;

import javax.servlet.http.HttpServletRequest;

import org.springframework.http.ResponseEntity;

import io.spaceandtime.api.annotations.*;
import io.spaceandtime.security.apis.ApiConstants.Params;
import io.spaceandtime.security.responses.*;
import io.spaceandtime.storage.subscription.SubscriptionRole;

/**
 * Defines the contract for the Subscription Provider management API group
 */
@ApiGroup(
	name = "Subscription API",
	description = "Enables user management of SxT subscriptions",
	basePath = "/v1/subscription"
)
public interface SubscriptionApi {
	
	@Apis.Put(
		operationId = "set-subscription-name",
		summary = "Set subscription name",
		description = "Set the display name of the description",
		path = "/name"
	)
	@Responses.NoContent_204
	@Responses.Unauthorized_401
	@Responses.Forbidden_403
	ResponseEntity<Void> setName(
		@Requests.Query(name = Params.SUBSCRIPTIONNAME_NAME, description = Params.SUBSCRIPTIONNAME_DESC) String subscriptionName,
		HttpServletRequest httpRequest
	) throws Exception;

	@Apis.Post(
		operationId = "create-subscription-invite",
		summary = "Create subscription invite",
		description = "Create a new subscription invite with the specified role",
		path = "/invite"
	)
	@Responses.Created_201
	@Responses.Unauthorized_401
	@Responses.Forbidden_403
	ResponseEntity<String> createInvite(
		@Requests.Query(name = Params.ROLE_NAME, description = Params.ROLE_DESC) SubscriptionRole role,
		HttpServletRequest httpRequest
	) throws Exception;

	@Apis.Post(
		operationId = "join-subscription-invite",
		summary = "Join subscription",
		description = "Join a subscription given the invite code",
		path = "/invite" + Params.JOIN_CODE_PATH
	)
	@Responses.OK_200
	@Responses.Unauthorized_401
	@Responses.Forbidden_403
	@Responses.NotFound_404
	ResponseEntity<TokenResponse> joinInvite(
		@Requests.Path(name = Params.JOIN_CODE_NAME, description = Params.JOIN_CODE_REQ_DESC) String joinCode,
		HttpServletRequest httpRequest
	) throws Exception;

	@Apis.Post(
		operationId = "remove-subscription-user",
		summary = "Remove a user",
		description = "Remove a user from your subscription",
		path = "/remove" + Params.USERID_PATH
	)
	@Responses.NoContent_204
	@Responses.Unauthorized_401
	@Responses.Forbidden_403
	@Responses.NotFound_404
	ResponseEntity<Void> removeUser(
		@Requests.Path(name = Params.USERID_NAME, description = Params.USERID_DESC) String userId,
		HttpServletRequest httpRequest
	) throws Exception;

	@Apis.Post(
		operationId = "set-subscription-user-role",
		summary = "Set user role",
		description = "Set a user role in your subscription",
		path = "/setrole" + Params.USERID_PATH
	)
	@Responses.NoContent_204
	@Responses.Unauthorized_401
	@Responses.Forbidden_403
	@Responses.NotFound_404
	ResponseEntity<Void> setUserRole(
		@Requests.Path(name = Params.USERID_NAME, description = Params.USERID_DESC) String userId,
		@Requests.Query(name = Params.ROLE_NAME, description = Params.ROLE_DESC) SubscriptionRole role,
		HttpServletRequest httpRequest
	) throws Exception;

	@Apis.Get(
		operationId = "get-subscription-info",
		summary = "Get subscription information",
		description = "Retreive subscription information"
	)
	@Responses.OK_200
	@Responses.Unauthorized_401
	@Responses.NotFound_404
	ResponseEntity<SubscriptionUserInfoResponse> getSubscriptionInfo(
		HttpServletRequest httpRequest
	) throws Exception;

	@Apis.Get(
		operationId = "get-subscription-users",
		summary = "Get subscription users",
		description = "Retrieve users tied to your subscription",
		path = "/users"
	)
	@Responses.OK_200
	@Responses.Unauthorized_401
	@Responses.NotFound_404
	ResponseEntity<SubscriptionUsersResponse> getSubscriptionUsers(
		HttpServletRequest httpRequest
	) throws Exception;
}
