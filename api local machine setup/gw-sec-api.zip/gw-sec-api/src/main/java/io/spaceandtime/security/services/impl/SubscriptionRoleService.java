package io.spaceandtime.security.services.impl;

import java.util.HashMap;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import io.spaceandtime.security.services.ISubscriptionRoleService;
import io.spaceandtime.security.storage.IKeyDBProvider;
import io.spaceandtime.storage.subscription.SubscriptionRole;
import io.spaceandtime.storage.subscription.SubscriptionUserRoles;

/**
 * Implements {@link ISubscriptionRoleService}
 */
@Component
public class SubscriptionRoleService implements ISubscriptionRoleService {
	private static final org.slf4j.Logger LOG = org.slf4j.LoggerFactory.getLogger(SubscriptionRoleService.class);

	@Autowired
	private IKeyDBProvider _keydbProvider;

	@Override
	public void setUserRole(String subscriptionId, String userId, SubscriptionRole role) throws Exception {
		SubscriptionUserRoles subscriptionUserRoles = getAllRoles(subscriptionId);
		if (subscriptionUserRoles == null) {
			subscriptionUserRoles = new SubscriptionUserRoles();
			subscriptionUserRoles.setSubscriptionId(subscriptionId);
		}
		setUserRole(subscriptionUserRoles, userId, role);
	}

	@Override
	public void removeUserRole(SubscriptionUserRoles userRoles, String userId) throws Exception {
		if (!userRoles.isEmpty() && userRoles.getMap().containsKey(userId)) {
			userRoles.getMap().remove(userId);
		}
		saveRoles(userRoles);
	}

	@Override
	public void setUserRole(SubscriptionUserRoles userRoles, String userId, SubscriptionRole role) throws Exception {
		Map<String, SubscriptionRole> userRoleMap = userRoles.getMap();
		if (userRoleMap == null) {
			userRoleMap = new HashMap<>();
			userRoles.setMap(userRoleMap);
		}
		userRoleMap.put(userId, role);
		saveRoles(userRoles);
	}

	@Override
	public SubscriptionUserRoles getAllRoles(String subscriptionId) {
		SubscriptionUserRoles userRoles;
		try {
			userRoles = _keydbProvider.getSubscriptionUserRoles(subscriptionId);
		} catch (Exception ex) {
			LOG.warn("Failed to retrieve subscription users for subscription '" + subscriptionId + "'. Reason: " + ex.getMessage());
			userRoles = null;
		}
		return userRoles;
	}

	/**
	 * Save the user role map
	 * @param userRoles - the user role map
	 * @throws Exception if the operation fails
	 */
	private void saveRoles(SubscriptionUserRoles userRoles) throws Exception {
		try {
			_keydbProvider.setSubscriptionUserRoles(userRoles.getSubscriptionId(), userRoles);
		} catch (Exception ex) {
			throw new Exception("Unable to set user role in subscription");
		}
	}
}
