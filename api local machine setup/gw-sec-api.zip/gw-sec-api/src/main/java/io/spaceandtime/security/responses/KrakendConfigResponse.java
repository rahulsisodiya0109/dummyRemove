package io.spaceandtime.security.responses;

import java.util.ArrayList;
import java.util.List;

import io.spaceandtime.storage.management.BlockTime;
import io.spaceandtime.storage.management.KrakendConfig;
import io.spaceandtime.storage.subscription.SubscriptionBlockTime;

public class KrakendConfigResponse {
	
	public class SubscriptionBlock {
		private String bt;
		private String subscriptionId;

		public SubscriptionBlock(SubscriptionBlockTime sbt) {
			bt = sbt.getBlockTimeId();
			subscriptionId = sbt.getSubscriptionId();
		}

		public String getBt() { return bt; }
		public String getSubscriptionId() { return subscriptionId; }
	}

	public class Block {
		private String bt;
		private Integer incrBy;
		private Long capacity;
		private long durationvalue;
		private String durationunits;

		public Block(BlockTime blockTime) {
			bt = blockTime.getId();
			incrBy = blockTime.getIncrementBy();
			capacity = blockTime.getCapacity();
			durationvalue = blockTime.getDurationValue();
			durationunits = blockTime.getDurationUnits().Value;
		}

		public String getBt() { return bt; }
		public Integer getIncrBy() { return incrBy; }
		public Long getCapacity() { return capacity; }
		public long getDurationValue() { return durationvalue; }
		public String getDurationUnits() { return durationunits; }
	}

	private Integer trialLimit;
	private List<String> restrictedApis;
	private List<SubscriptionBlock> subscriptionBlocks;
	private List<Block> blocks;

	public KrakendConfigResponse(KrakendConfig config, List<SubscriptionBlockTime> subscriptionBlockTimes, List<BlockTime> blockTimes) {
		trialLimit = config.getTrialLimit();
		restrictedApis = config.getRestrictedApis();
		subscriptionBlocks = new ArrayList<>(subscriptionBlockTimes.size());
		for (SubscriptionBlockTime sbt : subscriptionBlockTimes) {
			subscriptionBlocks.add(new SubscriptionBlock(sbt));
		}
		blocks = new ArrayList<>(blockTimes.size());
		for (BlockTime bt : blockTimes) {
			blocks.add(new Block(bt));
		}
	}

	public Integer getTrialLimit() { return trialLimit; }
	public List<String> getRestrictedApis() { return restrictedApis; }
	public List<SubscriptionBlock> getSubscriptionBlocks() { return subscriptionBlocks; };
	public List<Block> getBlocks() { return blocks; };
}
