package io.spaceandtime.security.requests;

import java.math.BigDecimal;

import javax.validation.constraints.DecimalMin;
import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotNull;

import org.springframework.lang.Nullable;
import org.springframework.util.StringUtils;

import io.spaceandtime.api.annotations.*;
import io.spaceandtime.security.apis.ApiConstants.Params;

@ApiModels.Object(name = "SubscriptionCreateRequest")
public class SubscriptionCreateRequest extends SubscriptionBaseRequest {

	@ApiModels.Property(
		name = Params.PLANNAME_NAME,
		description = Params.PLANNAME_DESC
	)
	@NotBlank(message = Params.PLANNAME_VALID)
	private String planName;
	
	@ApiModels.PropertyOptional(
		name = Params.ACCESS_TOKEN_SBSC_NAME,
		description = Params.ACCESS_TOKEN_SBSC_DESC
	)
	private String accessToken;
	
	@ApiModels.Property(
		name = Params.PAIDAMOUNT_NAME,
		description = Params.PAIDAMOUNT_DESC
	)
	@DecimalMin(value = "0.0", inclusive = false, message = Params.PAIDAMOUNT_VALID)
	private BigDecimal amount;

	@ApiModels.Property(
		name = Params.PAIDCURRENCY_NAME,
		description = Params.PAIDCURRENCY_DESC
	)
	@NotBlank(message = Params.PAIDCURRENCY_VALID)
	private String currency;

	@ApiModels.Property(
		name = Params.PAIDSTAMP_NAME,
		description = Params.PAIDSTAMP_DESC
	)
	@NotNull(message = Params.PAIDSTAMP_VALID)
	private Long timestamp;

	public String getPlanName() { return planName; }
	@Nullable public String getAccessToken() { return accessToken; }
	public BigDecimal getAmount() { return amount; }
	public String getCurrency() { return currency; }
	public Long getTimestamp() { return timestamp; }

	public String buildPayload() {
		String payload = super.buildPayload() + SEP + amount + SEP + currency + SEP + timestamp + SEP + planName;
		if (StringUtils.hasLength(accessToken)) {
			payload += SEP + accessToken;
		}
		return payload;
	}
}
