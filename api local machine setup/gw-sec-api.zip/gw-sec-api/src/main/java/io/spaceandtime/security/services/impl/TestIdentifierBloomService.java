package io.spaceandtime.security.services.impl;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.stereotype.Component;

import io.spaceandtime.security.config.*;
import io.spaceandtime.security.services.IIdentifierBloomService;
import io.spaceandtime.storage.core.IStorageProvider;

/**
 * A test implementation of {@link IIdentifierBloomService}
 * <p>
 * NOTE: this test implementation is for local development only. It enables
 * testing against an unused key in KeyDB to easily add/remove entries
 */
@Component
@ConditionalOnProperty(name = EnvVars.IdentifierBloom.IMPLEMENTATION, havingValue = "test")
public class TestIdentifierBloomService implements IIdentifierBloomService {

	private static final String KEY = "test-identifier-bloom-key";

	@Autowired
	private IStorageProvider _storageProvider;

	@Override
	public void add(String iterationId) {
		_storageProvider.sAdd(KEY, iterationId);
	}

	@Override
	public boolean exists(String iterationId) {
		return _storageProvider.sIsMember(KEY, iterationId);
	}
}
