package io.spaceandtime.security.controllers;

import javax.servlet.http.HttpServletRequest;
import javax.validation.Valid;

import org.apache.commons.lang.NotImplementedException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import io.spaceandtime.api.errors.CommonErrors;
import io.spaceandtime.api.errors.common.UnauthorizedException;
import io.spaceandtime.api.jwt.JwtPayload;
import io.spaceandtime.api.jwt.JwtTokenType;
import io.spaceandtime.security.apis.ApiConstants.Params;
import io.spaceandtime.security.apis.AuthApi;
import io.spaceandtime.security.exceptions.FailedOperationException;
import io.spaceandtime.security.models.SecurityApiContext;
import io.spaceandtime.security.requests.AuthCodeRequest;
import io.spaceandtime.security.requests.InternalTokenRequest;
import io.spaceandtime.security.requests.TokenRequest;
import io.spaceandtime.security.responses.AuthCodeResponse;
import io.spaceandtime.security.responses.TokenMetadataResponse;
import io.spaceandtime.security.responses.TokenResponse;
import io.spaceandtime.security.services.IChallengeService;
import io.spaceandtime.security.services.ISessionService;
import io.spaceandtime.security.services.ISignatureValidatorService;
import io.spaceandtime.security.services.ITokenBuilderService;
import io.spaceandtime.security.storage.IKeyDBProvider;
import io.spaceandtime.storage.user.AuthKey;
import io.spaceandtime.storage.user.UserChallenge;

@Validated
@RestController
public class AuthController extends BaseSecurityController implements AuthApi {

	@Autowired
	private IKeyDBProvider _keydbProvider;
	@Autowired
	private IChallengeService _challengeService;
	@Autowired
	private ISessionService _sessionService;
	@Autowired
	private ISignatureValidatorService _signatureValidator;
	@Autowired
	private ITokenBuilderService _tokenBuilder;
	
	@Override
	public ResponseEntity<AuthCodeResponse> getAuthCode(
		@RequestBody(required = true) AuthCodeRequest authRequest,
		HttpServletRequest httpRequest
	) throws Exception {
		AuthCodeResponse response = _challengeService.generateForAuth(authRequest);
		return OK(response);
	}

	@Override
	public ResponseEntity<TokenResponse> getTokens(
		@RequestBody(required = true) TokenRequest tokenRequest,
		HttpServletRequest httpRequest
	) throws Exception {
		String userId = tokenRequest.getUserId();
		JwtPayload tokenPayload;
		try {
			// Retrieve a stored challenge and validate against provided auth code
			UserChallenge challenge = _challengeService.getAndValidate(userId, tokenRequest.getAuthCode());
			// Validate the provided signature
			AuthKey key = _signatureValidator.validateChallenge(challenge, tokenRequest.getSignature(), tokenRequest.getKey(), tokenRequest.getScheme(), challenge.isRegistration());
			// Create a new session
			tokenPayload = _sessionService.create(challenge, key);
		} catch (Exception ex) {
			throw ex;
		} finally {
			// Regardless of success or failure, we must delete the current challenge
			_challengeService.delete(userId);
		}

		TokenResponse response = _tokenBuilder.buildTokens(tokenPayload);
		return OK(response);
	}

	@Override
	public ResponseEntity<TokenResponse> refresh(
		HttpServletRequest httpRequest
	) throws Exception {
		SecurityApiContext ctxt = getRefreshTokenContext(httpRequest);
		JwtPayload tokenPayload = _sessionService.refresh(ctxt);
		TokenResponse response = _tokenBuilder.buildTokens(tokenPayload);
		return OK(response);
	}

	@Override
	public ResponseEntity<Void> logout(
		HttpServletRequest httpRequest
	) throws Exception {
		SecurityApiContext ctxt = getRefreshTokenContext(httpRequest);
		_sessionService.end(ctxt);
		return NoContent();
	}

	@Override
	public ResponseEntity<Boolean> checkUserId(
		@PathVariable(required = true, name = Params.USERID_CHECK_NAME) String id,
		HttpServletRequest httpRequest
	) throws Exception {
		try {
			Boolean exists = _keydbProvider.userExists(id);
			return OK(exists);
		} catch (Exception ex) {
			throw new FailedOperationException("User identifier check failed", "Unable to determine if user identifier is in use", ex);
		}
	}

	@Override
	public ResponseEntity<TokenMetadataResponse> validateToken(
		HttpServletRequest httpRequest
	) throws Exception {
		SecurityApiContext ctxt = getAuthenticatedContext(httpRequest);
		TokenMetadataResponse response = new TokenMetadataResponse(ctxt.getJwtPayload());
		return OK(response);
	}

	// NOTE: because this is an internal API, it is explicitly not documented
	@PostMapping(path = "/token-internal")
	public ResponseEntity<String> getInternalToken(
		@Valid @RequestBody(required = true) InternalTokenRequest internalTokenRequest,
		HttpServletRequest httpRequest
	) throws Exception {
		JwtPayload jwt = new JwtPayload();
		// TODO: user and smart contract validation
		switch (internalTokenRequest.getClaimType()) {
			case USER:
				jwt.setUserId(internalTokenRequest.getClaimValue());
				break;
			case SMART_CONTRACT:
				jwt.setSmartContractAddress(internalTokenRequest.getClaimValue());
				break;
			default: throw new NotImplementedException("Token type '" + internalTokenRequest.getClaimType() + "' has not been implemented");
		}
		String internalJwt = _tokenBuilder.buildInternal(jwt);
		return OK(internalJwt);
	}

	/**
	 * Get the security API context and validate that it's from a refresh token
	 * @param httpRequest - the HTTP request
	 * @return
	 * @throws Exception if the underlying JWT is not a refresh token
	 */
	private SecurityApiContext getRefreshTokenContext(HttpServletRequest httpRequest) throws Exception {
		SecurityApiContext ctxt = getAuthenticatedContext(httpRequest);
		if (ctxt.getJwtPayload().getType() != JwtTokenType.REFRESH) {
			throw new UnauthorizedException(CommonErrors.INVALID_JWT, "Invalid JWT provided", "The provided JWT is not a refresh token");
		}
		return ctxt;
	}
}
