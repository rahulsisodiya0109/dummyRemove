package io.spaceandtime.security.requests;

import javax.validation.constraints.NotBlank;

import org.springframework.lang.Nullable;

import io.spaceandtime.api.annotations.*;
import io.spaceandtime.security.apis.ApiConstants.*;

@ApiModels.Object(name = "AuthCodeRequest")
public class AuthCodeRequest {
	
	@ApiModels.Property(
		name = Params.USERID_NAME,
		description = Params.USERID_DESC
	)
	@NotBlank(message = Params.USERID_VALID)
	private String userId;

	@ApiModels.PropertyOptional(
		name = Params.PREFIX_NAME,
		description = Params.PREFIX_DESC
	)
	private String prefix;

	@ApiModels.PropertyOptional(
		name = Params.JOIN_CODE_NAME,
		description = Params.JOIN_CODE_OPT_DESC
	)
	private String joinCode;


	public String getUserId() { return userId; }
	@Nullable public String getPrefix() { return prefix; }
	@Nullable public String getJoinCode() { return joinCode; }

	public void setUserId(String value) { userId = value; }
	public void setPrefix(String value) { prefix = value; }
	public void setJoinCode(String value) { joinCode = value; }

	@Override
	public String toString() {
		return "AuthCodeRequest [userId=" + userId + ",prefix=" + prefix + ",joinCode=" + joinCode + "]";
	}
}
