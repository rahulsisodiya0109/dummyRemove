package io.spaceandtime.security.controllers;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import io.spaceandtime.security.apis.KeyManagementApi;
import io.spaceandtime.security.exceptions.FailedOperationException;
import io.spaceandtime.security.models.*;
import io.spaceandtime.security.requests.*;
import io.spaceandtime.security.responses.*;
import io.spaceandtime.security.services.*;
import io.spaceandtime.security.storage.IKeyDBProvider;
import io.spaceandtime.storage.user.*;

@Validated
@RestController
public class KeyManagementController extends BaseSecurityController implements KeyManagementApi {

	@Autowired
	private IKeyDBProvider _keydbProvider;
	@Autowired
	private IChallengeService _challengeService;
	@Autowired
	private ISignatureValidatorService _signatureValidator;

	@Override
	public ResponseEntity<KeychainResponse> getKeychain(
		HttpServletRequest httpRequest
	) throws Exception {
		SecurityApiContext ctxt = getAuthenticatedContext(httpRequest);
		User user;
		try {
			user = _keydbProvider.getUser(ctxt.getJwtPayload().getUserId());
		} catch (Exception ex) {
			throw new FailedOperationException("Get keychain failed", "Unable to retrieve user keychain", ex);
		}
		KeychainResponse response = new KeychainResponse(user);
		return OK(response);
	}

	@Override
	public ResponseEntity<AuthCodeResponse> getKeyAddChallenge(
		HttpServletRequest httpRequest
	) throws Exception {
		SecurityApiContext ctxt = getAuthenticatedContext(httpRequest);
		AuthCodeResponse response = _challengeService.generateForAddKey(ctxt.getJwtPayload());
		return OK(response);
	}

	@Override
	public ResponseEntity<Void> addKey(
		@RequestBody(required = true) AddKeyRequest addKeyRequest,
		HttpServletRequest httpRequest
	) throws Exception {
		SecurityApiContext ctxt = getAuthenticatedContext(httpRequest);
		String userId = ctxt.getJwtPayload().getUserId();
		try {
			// Retrieve a stored challenge and validate against provided auth code
			UserChallenge challenge = _challengeService.getAndValidate(userId, addKeyRequest.getAuthCode());
			// Validate the provided signature
			AuthKey key = _signatureValidator.validateChallenge(challenge, addKeyRequest.getSignature(), addKeyRequest.getKey(), addKeyRequest.getScheme(), true);
			
			// Add key to user keychain
			try {
				User user = _keydbProvider.getUser(userId);
				user.getKeychain().add(key);
				_keydbProvider.setUser(userId, user);
			} catch (Exception ex) {
				throw new FailedOperationException("Add key to keychain failed", "Unable to update user keychain", ex);
			}
		} catch (Exception ex) {
			throw ex;
		} finally {
			// Regardless of success or failure, we must delete the current challenge
			_challengeService.delete(userId);
		}

		return NoContent();
	}
}
