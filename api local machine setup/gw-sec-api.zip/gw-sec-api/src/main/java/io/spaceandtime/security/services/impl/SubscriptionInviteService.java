package io.spaceandtime.security.services.impl;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import io.spaceandtime.security.config.EnvVars;
import io.spaceandtime.security.exceptions.BadJoinCodeException;
import io.spaceandtime.security.services.ISubscriptionInviteService;
import io.spaceandtime.security.storage.IKeyDBProvider;
import io.spaceandtime.storage.subscription.*;

/**
 * Implements {@link ISubscriptionInviteService}
 */
@Component
public class SubscriptionInviteService implements ISubscriptionInviteService {
	private static final org.slf4j.Logger LOG = org.slf4j.LoggerFactory.getLogger(SubscriptionInviteService.class);

	@Value(EnvVars.Core.SUBSCRIPTION_INVITE_EXPIRATION_MS)
	private Long SUBSCRIPTION_INVITE_EXPIRATION_MS;

	@Autowired
	private IKeyDBProvider _keydbProvider;

	@Override
	public void save(SubscriptionInvite invite) throws Exception {
		_keydbProvider.setSubscriptionInvite(invite.getJoinCode(), invite, SUBSCRIPTION_INVITE_EXPIRATION_MS);
	}

	@Override
	public void validate(String joinCode) throws Exception {
		boolean joinCodeExists;
		try {
			joinCodeExists = _keydbProvider.subscriptionInviteExists(joinCode);
		} catch (Exception ex) {
			LOG.warn("Failed to determine if the join code exists. Reason: " + ex.getMessage());
			joinCodeExists = false;
		}
		if (!joinCodeExists) {
			throw new BadJoinCodeException(joinCode);
		}
	}

	@Override
	public SubscriptionInvite getAndDelete(String joinCode) throws Exception {
		SubscriptionInvite invite;
		try {
			invite = _keydbProvider.getSubscriptionInvite(joinCode);
		} catch (Exception ex) {
			LOG.info("Failed to retrieve subscription invite. Reason: " + ex.getMessage());
			invite = null;
		}
		if (invite == null) {
			throw new BadJoinCodeException(joinCode);
		} else {
			try {
				_keydbProvider.deleteSubscriptionInvite(joinCode);
			} catch (Exception ex) {
				LOG.error("Failed to delete subscription invite. Reason: " + ex.getMessage(), ex);
			}
		}
		return invite;
	}
}
