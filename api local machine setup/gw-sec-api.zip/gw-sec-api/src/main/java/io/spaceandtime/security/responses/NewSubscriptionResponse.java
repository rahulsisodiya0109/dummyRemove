package io.spaceandtime.security.responses;

import io.spaceandtime.api.annotations.*;
import io.spaceandtime.security.apis.ApiConstants.Params;

@ApiModels.Object(name = "NewSubscriptionResponse")
public class NewSubscriptionResponse {
	
	@ApiModels.Property(
		name = Params.SUBSCRIPTIONID_NAME,
		description = Params.SUBSCRIPTIONID_DESC
	)
	private String subscriptionId;

	@ApiModels.PropertyOptional(
		name = Params.JOIN_CODE_NAME,
		description = Params.JOIN_CODE_OPT_DESC
	)
	private String joinCode;

	public NewSubscriptionResponse(){}
	public NewSubscriptionResponse(String subscriptionIdValue, String joinCodeValue) {
		subscriptionId = subscriptionIdValue;
		joinCode = joinCodeValue;
	}

	public String getSubscriptionId() { return subscriptionId; }
	public String getJoinCode() { return joinCode; }

	public void setSubscriptionId(String value) { subscriptionId = value; }
	public void setJoinCode(String value) { joinCode = value; }
}
