package io.spaceandtime.security.responses;

import io.spaceandtime.api.annotations.*;

import io.spaceandtime.security.apis.ApiConstants.Params;
import io.spaceandtime.storage.subscription.Subscription;
import io.spaceandtime.storage.subscription.SubscriptionState;

public class SubscriptionBaseInfoResponse {
	
	@ApiModels.Property(
		name = Params.SUBSCRIPTIONID_NAME,
		description = Params.SUBSCRIPTIONID_DESC
	)
	private String subscriptionId;

	@ApiModels.Property(
		name = Params.SUBSCRIPTION_STATE_NAME,
		description = Params.SUBSCRIPTION_STATE_DESC
	)
	private SubscriptionState state;

	@ApiModels.Property(
		name = Params.PLANNAME_NAME,
		description = Params.PLANNAME_DESC
	)
	private String planName;

	@ApiModels.Property(
		name = Params.LASTPAYMENT_NAME,
		description = Params.LASTPAYMENT_DESC
	)
	private String lastPayment;

	public SubscriptionBaseInfoResponse(){}
	public SubscriptionBaseInfoResponse(String subscriptionIdValue, SubscriptionState stateValue, String planNameValue, String lastPaymentValue) {
		subscriptionId = subscriptionIdValue;
		state = stateValue;
		planName = planNameValue;
		lastPayment = lastPaymentValue;
	}
	public SubscriptionBaseInfoResponse(Subscription subscription) {
		subscriptionId = subscription.getSubscriptionId();
		state = subscription.getState();
		planName = subscription.getPlanName();
		lastPayment = subscription.getLastPayment();
	}

	public String getSubscriptionId() { return subscriptionId; }
	public SubscriptionState getState() { return state; }
	public String getPlanName() { return planName; }
	public String getLastPayment() { return lastPayment; }

	public void setSubscriptionId(String value) { subscriptionId = value; }
	public void setState(SubscriptionState value) { state = value; }
	public void setPlanName(String value) { planName = value; }
	public void setLastPayment(String value) { lastPayment = value; }
}
