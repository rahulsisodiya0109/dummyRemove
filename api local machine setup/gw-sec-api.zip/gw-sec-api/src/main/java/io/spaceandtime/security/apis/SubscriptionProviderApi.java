package io.spaceandtime.security.apis;

import javax.servlet.http.HttpServletRequest;

import org.springframework.http.ResponseEntity;

import io.spaceandtime.api.annotations.*;
import io.spaceandtime.security.requests.*;
import io.spaceandtime.security.responses.*;

/**
 * Defines the contract for the Subscription Provider management API group
 */
@ApiGroup(
	name = "Subscription Provider API",
	description = "Enables subscription provider management of SxT subscriptions",
	basePath = "/v1/mgmt/subscription"
)
public interface SubscriptionProviderApi {
	
	@Apis.Post(
		operationId = "manage-subscription-create",
		summary = "Create a new subscription",
		description = "Create a new subscription",
		path = "/create"
	)
//	@NotAuthorized
	@Responses.Created_201
	@Responses.BadRequest_400
	@Responses.Unauthorized_401
	@Responses.Forbidden_403
	ResponseEntity<NewSubscriptionResponse> create(
		@Requests.Body SubscriptionCreateRequest createRequest,
		HttpServletRequest httpRequest
	) throws Exception;

	@Apis.Post(
		operationId = "manage-subscription-retrieve",
		summary = "Retrieve subscription info",
		description = "Retrieve the subscription information",
		path = "/retrieve"
	)
//	@NotAuthorized
	@Responses.OK_200
	@Responses.Unauthorized_401
	@Responses.Forbidden_403
	@Responses.NotFound_404
	ResponseEntity<SubscriptionProviderInfoResponse> get(
		@Requests.Body SubscriptionReferenceRequest subscriptionRequest,
		HttpServletRequest httpRequest
	) throws Exception;

	@Apis.Post(
		operationId = "manage-subscription-alter",
		summary = "Alter subscription info",
		description = "Alter subscription information",
		path = "/alter"
	)
//	@NotAuthorized
	@Responses.NoContent_204
	@Responses.BadRequest_400
	@Responses.Unauthorized_401
	@Responses.Forbidden_403
	@Responses.NotFound_404
	ResponseEntity<Void> alter(
		@Requests.Body SubscriptionAlterRequest alterRequest,
		HttpServletRequest httpRequest
	) throws Exception;

	@Apis.Post(
		operationId = "manage-subscription-cancel",
		summary = "Cancel a subscription",
		description = "Cancel an active subscription",
		path = "/cancel"
	)
//	@NotAuthorized
	@Responses.NoContent_204
	@Responses.BadRequest_400
	@Responses.Unauthorized_401
	@Responses.Forbidden_403
	@Responses.NotFound_404
	ResponseEntity<Void> cancel(
		@Requests.Body SubscriptionReferenceRequest subscriptionRequest,
		HttpServletRequest httpRequest
	) throws Exception;

	@Apis.Post(
		operationId = "manage-subscription-suspend",
		summary = "Suspend subscription",
		description = "Suspend an active subscription due to failed payment",
		path = "/suspend"
	)
//	@NotAuthorized
	@Responses.NoContent_204
	@Responses.BadRequest_400
	@Responses.Unauthorized_401
	@Responses.Forbidden_403
	@Responses.NotFound_404
	ResponseEntity<Void> suspend(
		@Requests.Body SubscriptionReferenceRequest subscriptionRequest,
		HttpServletRequest httpRequest
	) throws Exception;

	@Apis.Post(
		operationId = "manage-subscription-reinstate",
		summary = "Reinstate subscription",
		description = "Reinstate a suspended subscription",
		path = "/reinstate"
	)
//	@NotAuthorized
	@Responses.NoContent_204
	@Responses.BadRequest_400
	@Responses.Unauthorized_401
	@Responses.Forbidden_403
	@Responses.NotFound_404
	ResponseEntity<Void> reinstate(
		@Requests.Body SubscriptionReferenceRequest subscriptionRequest,
		HttpServletRequest httpRequest
	) throws Exception;

	@Apis.Post(
		operationId = "manage-subscription-renew",
		summary = "Renew subscription",
		description = "Renew an active subscription by confirming a payment",
		path = "/renew"
	)
//	@NotAuthorized
	@Responses.NoContent_204
	@Responses.BadRequest_400
	@Responses.Unauthorized_401
	@Responses.Forbidden_403
	@Responses.NotFound_404
	ResponseEntity<Void> renew(
		@Requests.Body SubscriptionRenewRequest renewRequest,
		HttpServletRequest httpRequest
	) throws Exception;
}
