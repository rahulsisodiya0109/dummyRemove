package io.spaceandtime.security.responses;

import io.spaceandtime.api.annotations.*;
import io.spaceandtime.security.apis.ApiConstants.*;

@ApiModels.Object(name = "TokenResponse")
public class TokenResponse {
	
	@ApiModels.Property(
		name = Params.ACCESS_TOKEN_AUTH_NAME,
		description = Params.ACCESS_TOKEN_AUTH_DESC
	)
	private String accessToken;

	@ApiModels.Property(
		name = Params.REFRESH_TOKEN_NAME,
		description = Params.REFRESH_TOKEN_DESC
	)
	private String refreshToken;

	@ApiModels.Property(
		name = Params.ACCESS_TOKEN_EXP_NAME,
		description = Params.ACCESS_TOKEN_EXP_DESC
	)
	private long accessTokenExpires;

	@ApiModels.Property(
		name = Params.REFRESH_TOKEN_EXP_NAME,
		description = Params.REFRESH_TOKEN_EXP_DESC
	)
	private long refreshTokenExpires;

	public TokenResponse(){}
	public TokenResponse(String accessTokenValue, String refreshTokenValue, long accessTokenExpiration, long refreshTokenExpiration) {
		accessToken = accessTokenValue;
		refreshToken = refreshTokenValue;
		accessTokenExpires = accessTokenExpiration;
		refreshTokenExpires = refreshTokenExpiration;
	}

	public String getAccessToken() { return accessToken; }
	public String getRefreshToken() { return refreshToken; }
	public long getAccessTokenExpires() { return accessTokenExpires; }
	public long getRefreshTokenExpires() { return refreshTokenExpires; }

	public void setAccessToken(String value) { accessToken = value; }
	public void setRefreshToken(String value) { refreshToken = value; }
	public void setAccessTokenExpires(long value) { accessTokenExpires = value; }
	public void setRefreshTokenExpires(long value) { refreshTokenExpires = value; }
}
