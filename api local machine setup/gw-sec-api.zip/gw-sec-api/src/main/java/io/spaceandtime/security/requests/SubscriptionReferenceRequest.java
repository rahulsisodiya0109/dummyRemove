package io.spaceandtime.security.requests;

import javax.validation.constraints.NotBlank;

import io.spaceandtime.api.annotations.*;
import io.spaceandtime.security.apis.ApiConstants.Params;

@ApiModels.Object(name = "SubscriptionReferenceRequest")
public class SubscriptionReferenceRequest extends SubscriptionBaseRequest {
	
	@ApiModels.Property(
		name = Params.SUBSCRIPTIONID_NAME,
		description = Params.SUBSCRIPTIONID_DESC
	)
	@NotBlank(message = Params.SUBSCRIPTIONID_VALID)
	private String subscriptionId;

	public String getSubscriptionId() { return subscriptionId; }
	public void setSubscriptionId(String value) { subscriptionId = value; }

	public String buildPayload() {
		return super.buildPayload() + SEP + subscriptionId;
	}
}
