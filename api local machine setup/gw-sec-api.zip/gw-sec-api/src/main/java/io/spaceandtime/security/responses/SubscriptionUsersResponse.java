package io.spaceandtime.security.responses;

import java.util.HashMap;
import java.util.Map;

import io.spaceandtime.api.annotations.*;
import io.spaceandtime.security.apis.ApiConstants.Params;
import io.spaceandtime.storage.subscription.SubscriptionRole;
import io.spaceandtime.storage.subscription.SubscriptionUserRoles;

@ApiModels.Object(name = "SubscriptionUsersResponse")
public class SubscriptionUsersResponse {
	
	@ApiModels.Property(
		name = Params.ROLEMAP_NAME,
		description = Params.ROLEMAP_DESC
	)
	private Map<String, SubscriptionRole> roleMap;

	public SubscriptionUsersResponse(){}
	public SubscriptionUsersResponse(SubscriptionUserRoles userRoles) {
		if (userRoles == null || userRoles.isEmpty()) {
			roleMap = new HashMap<>();
		} else {
			roleMap = userRoles.getMap();
		}
	}

	public Map<String, SubscriptionRole> getRoleMap() { return roleMap; }
	public void setRoleMap(Map<String, SubscriptionRole> value) { roleMap = value; }
}
