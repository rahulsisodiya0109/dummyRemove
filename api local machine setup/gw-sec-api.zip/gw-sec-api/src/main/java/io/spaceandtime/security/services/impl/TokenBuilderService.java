package io.spaceandtime.security.services.impl;

import java.time.Instant;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import io.spaceandtime.api.core.RandomGenerator;
import io.spaceandtime.api.jwt.IJwtProvider;
import io.spaceandtime.api.jwt.JwtPayload;
import io.spaceandtime.api.jwt.JwtTokenType;
import io.spaceandtime.security.config.EnvVars;
import io.spaceandtime.security.responses.TokenResponse;
import io.spaceandtime.security.services.ITokenBuilderService;

/**
 * Implements {@link ITokenBuilderService}
 */
@Component
public class TokenBuilderService implements ITokenBuilderService {

	@Value(EnvVars.Core.ACCESS_TOKEN_EXPIRATION_MS)
	private Long ACCESS_TOKEN_EXPIRATION_MS;
	@Value(EnvVars.Core.REFESH_TOKEN_EXPIRATION_MS)
	private Long REFRESH_TOKEN_EXPIRATION_MS;
	@Value(EnvVars.Core.INTERNAL_TOKEN_EXPIRATION_MS)
	private Long INTERNAL_TOKEN_EXPIRATION_MS;

	@Autowired
	private IJwtProvider _jwtProvider;

	@Override
	public TokenResponse buildTokens(JwtPayload payload) throws Exception {
		final long now = Instant.now().toEpochMilli();
		final long accessExpires = now + ACCESS_TOKEN_EXPIRATION_MS;
		final long refreshExpires = now + REFRESH_TOKEN_EXPIRATION_MS;

		payload.setType(JwtTokenType.ACCESS);
		payload.setTokenExpiration(accessExpires);
		String accessToken = _jwtProvider.build(payload);

		payload.setType(JwtTokenType.REFRESH);
		payload.setTokenExpiration(refreshExpires);
		String refreshToken = _jwtProvider.build(payload);

		return new TokenResponse(accessToken, refreshToken, accessExpires, refreshExpires);
	}

	@Override
	public String buildInternal(JwtPayload payload) throws Exception {
		// For internal tokens, we only build an access token
		payload.setType(JwtTokenType.ACCESS);
		payload.setIterationId(RandomGenerator.newString());
		payload.setSessionId(RandomGenerator.newString());
		long expires = Instant.now().plusMillis(INTERNAL_TOKEN_EXPIRATION_MS).toEpochMilli();
		payload.setSessionExpiration(expires);
		payload.setTokenExpiration(expires);
		payload.setSubscriptionId("unknown");
		return _jwtProvider.build(payload);
	}
}
