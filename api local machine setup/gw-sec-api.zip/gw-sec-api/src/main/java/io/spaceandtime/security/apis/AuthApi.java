package io.spaceandtime.security.apis;

import javax.servlet.http.HttpServletRequest;

import org.springframework.http.ResponseEntity;

import io.spaceandtime.api.annotations.*;
import io.spaceandtime.security.apis.ApiConstants.*;
import io.spaceandtime.security.requests.*;
import io.spaceandtime.security.responses.*;

/**
 * Defines the contract for the Authentication API group
 */
@ApiGroup(
	name = "Authentication / Registration API",
	description = "Enables authentication workflows",
	basePath = "/v1/auth"
)
public interface AuthApi {

	@Apis.Post(
		operationId = "authentication-code",
		summary = "Authentication Code",
		description = "Request a temporary authentication challenge for the given user. A random `authCode` will be generated and tied to the provided `userId` for a short period of time",
		path = "/code"
	)
//	@NotAuthorized
	@Responses.OK_200
	@Responses.BadRequest_400
	ResponseEntity<AuthCodeResponse> getAuthCode(
		@Requests.Body AuthCodeRequest authRequest,
		HttpServletRequest httpRequest
	) throws Exception;

	@Apis.Post(
		operationId = "token-request",
		summary = "Token Request",
		description = "Initiate a new authentication section by proving identity via `signature` to generate a new `accessToken` and `refreshToken`",
		path = "/token"
	)
//	@NotAuthorized
	@Responses.OK_200
	@Responses.BadRequest_400
	@Responses.NotFound_404
	ResponseEntity<TokenResponse> getTokens(
		@Requests.Body TokenRequest tokenRequest,
		HttpServletRequest httpRequest
	) throws Exception;

	@Apis.Post(
		operationId = "token-refresh",
		summary = "Token Refresh",
		description = "Refresh an existing authenticated session by providing a valid `refreshToken` to generate a new `accessToken` and `refreshToken`",
		path = "/refresh"
	)
	@Responses.OK_200
	@Responses.Unauthorized_401
	@Responses.Forbidden_403
	ResponseEntity<TokenResponse> refresh(
		HttpServletRequest httpRequest
	) throws Exception;
	

	@Apis.Post(
		operationId = "logout",
		summary = "Logout",
		description = "End an authenticated session",
		path = "/logout"
	)
	@Responses.NoContent_204
	@Responses.Unauthorized_401
	ResponseEntity<Void> logout(
		HttpServletRequest httpRequest
	) throws Exception;

	@Apis.Get(
		operationId = "user-identifier-check",
		summary = "User Identifier Check",
		description = "Checks if a given user identifier (`userId`) is in use across the platform, facilitating registration process. Returns `true` if the userId is in use",
		path = "/idexists" + Params.USERID_CHECK_PATH
	)
//	@NotAuthorized
	@Responses.OK_200
	ResponseEntity<Boolean> checkUserId(
		@Requests.Path(name = Params.USERID_CHECK_NAME, description = Params.USERID_CHECK_DESC) String id,
		HttpServletRequest httpRequest
	) throws Exception;

	@Apis.Get(
		operationId = "validate-token",
		summary = "Validate token",
		description = "Perform simple token validation and return claim metadata on success",
		path = "/validtoken"
	)
	@Responses.OK_200
	@Responses.BadRequest_400
	@Responses.Unauthorized_401
	ResponseEntity<TokenMetadataResponse> validateToken(
		HttpServletRequest httpRequest
	) throws Exception;
}
