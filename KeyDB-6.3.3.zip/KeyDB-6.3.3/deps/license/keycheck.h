#pragma once

bool FValidKey(const char *key, size_t cch);
